/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc.test;

import amgen.ri.json.JSONObject;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.dao.NamedQuery;
import amgen.ri.rnai.dao.SurvivalPlotInput;
import amgen.ri.rnai.dao.SurvivalPlotMapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.Debug;
import java.sql.Connection;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jemcdowe
 */
public class TesterMyBatis extends ResourceFactory {

  public TesterMyBatis() {
  }

  private void test() throws Exception {
    SqlSession sqlSession = getSqlSessionFactory("rnai-local").openSession();
    //Connection c= sqlSession.getConnection();

    JSONObject j = new JSONObject();
    j.put("experiment_id", 4985);

    ExperimentRecord expRecord = new ExperimentRecord(j);
    SurvivalPlotInput input = new SurvivalPlotInput(expRecord, null, null);
    sqlSession.getMapper(SurvivalPlotMapper.class).getSurvivalPlotData(input);

    sqlSession.close();
  }

  public static void main(String[] args) throws Exception {
    new TesterMyBatis().test();
  }

}
