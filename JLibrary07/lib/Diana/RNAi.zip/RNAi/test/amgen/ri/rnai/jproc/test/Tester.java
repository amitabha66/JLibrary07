/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc.test;

import amgen.ri.csv.CSVReader;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.ExtOracle;
import amgen.ri.rnai.analyze.AbstractAnalysisDetails;
import amgen.ri.rnai.analyze.geneticinteraction.GIAnalysisDetails;
import amgen.ri.rnai.analyze.geneticinteraction.GIExperiments;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchJProc;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtClass;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import oracle.jdbc.OracleCallableStatement;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import oracle.sql.BLOB;
import oracle.sql.CLOB;
import org.apache.commons.lang.StringUtils;
import org.apache.jcs.utils.timing.ElapsedTimer;

/**
 *
 * @author jemcdowe
 */
public class Tester {
  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  private static final String INSTANCE = "PROD";

  public static void main(String[] args) throws Exception {
    //executeFASTQBuilder();
    executeLocal();
    //executeRemote();
    //executeRawLocal();
    //executeRawRemote();
    //executeRawRemote2();
    //executeGetCharts();
    //executeRunAndSaveRemote();
    //executeAnalysisRemoteLocal();
    //executeNamedQueryRemote();
  }
  
  public static void pullExps() throws Exception {
    List<String> columnKeys
            = Arrays.asList(
                    "experiment",
                    "experiment_id",
                    "gene_id",
                    "gene_symbol",
                    "gene_name",
                    "entrezgene_id",
                    "rnai_count",
                    "exp_count",
                    "OGA METHOD V2:CORRECTED_PVALUE",
                    "OGA METHOD V2:PVALUE_RANK",
                    "OGA METHOD V2:PVALUE");

    int[] expIDs = {4929, 4953, 4931, 4954, 4943, 4962, 4948, 4963, 4971, 4964, 4972, 4957, 4966, 4967, 4981, 4985, 4982, 4984, 4993, 5016, 5019, 5010, 5014, 5002, 5007, 5013, 5015};

    for (int expID : expIDs) {
      JSONObject jExperiment = (JSONObject)executeExperiment(expID).getJSONArray("results").asList().get(0);
      JSONObject jResults = executeLocalExp(expID);
      List<JSONObject> jExps = jResults.getJSONArray("results").asList();
      List<String> keys = jExps.get(0).names().asList();

      PrintWriter writer = new PrintWriter("/temp/exp_" + expID + ".tab");
      //PrintWriter writer = new PrintWriter(System.out);
      writer.println(StringUtils.join(columnKeys, '\t'));
      writer.flush();
      List<String> values = new ArrayList<String>();
      for (JSONObject jExp : jExps) {
        values.clear();
        String geneID = jExp.optString("gene_id", jExp.optString("gene_mixture_id"));
        for (String columnKey : columnKeys) {
          if (columnKey.equals("experiment")) {
            values.add(jExperiment.getString("experiment_name"));
          } else if (columnKey.equals("gene_id")) {
            values.add(geneID);
          } else {
            String value= jExp.getString(columnKey).replace("$$", ";");
            values.add(value);
          }
        }
        writer.println(StringUtils.join(values, '\t'));
        writer.flush();
      }
      writer.flush();
    }

  }

  public static void executeRawRemote2() throws Exception {
    Connection conn = getConnection();
    String RUN_QUERY = "begin ? := RNAIQUERY.getExperimentResults2(?); end;";
    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
    cs.registerOutParameter(1, Types.CLOB);
    cs.setInt(2, 4760);
    cs.execute();
    CLOB resultBlob = (CLOB) cs.getClob(1);

    //String results = ExtOracle.readObjectFromBlob(resultBlob, true).toString();
    String s = resultBlob.getSubString(1, (int) resultBlob.length());

    System.out.println(s.length());

    conn.close();
    //write(results);

  }

  public static void executeAnalysisInsertLocal() throws Exception {
    Connection conn = getConnection();

    JSONObject results = new JSONObject(ExtFile.readTextFile(new File("/temp/oga.json_txt")));
    JSONObject jInsertDetails = new RNAiSearchJProc().executeAnalysisInsert(conn, results);
    conn.close();
  }

  public static void executeNamedQueryRemote() throws Exception {
    Connection conn = getConnection();
    String RUN = "begin ? := RNAIQUERY.runNamedQuery2Tabs(?,?); end;";
    List query = q(new String[]{"experiment_id:4929"});

    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN);
    cs.registerOutParameter(1, Types.BLOB);
    cs.setString(2, "COMBINED_POCS_PVALUESBYEXPID");
    cs.setBLOB(3, createBLOB(conn, query));
    cs.execute();
    Blob resultBlob = cs.getBlob(1);
    System.out.println(fromBlob(resultBlob));
    conn.close();

  }

  public static void executeAnalysisRemoteLocal() throws Exception {
    String RUN_INSERT = "begin ? := RNAIQUERY.runAnalysisInsert(?); end;";

    Connection conn = getConnection();

    JSONObject results = new JSONObject(ExtFile.readTextFile(new File("/temp/oga.json_txt")));

    ElapsedTimer timer = new ElapsedTimer();

    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_INSERT);
    cs.registerOutParameter(1, Types.BLOB);
    cs.setBLOB(2, createBLOB(conn, results));
    cs.execute();
    Blob resultBlob = cs.getBlob(1);
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");
    System.out.println(fromBlob(resultBlob));
    conn.close();

  }

  public static void executeLocal() throws Exception {

    Connection conn = getConnection();
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.RNAI_ID, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"barcode:1500086117"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_ID, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol:mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"eg_id:207"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"root_number:2558018", "lot_number:3"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.RNAI_IDS, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_IDS, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol: mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.ENTREZGENE_IDS, q(new String[]{"eg_id: 207"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"barcode: 1500086117"}));

    //List query = q(new String[]{"root_number:3093889", "lot_number:1"});
    //List query = q(new String[]{"experiment_id:4180"});
    //List query = q(new String[]{"barcodes:1158772,1500086027"});
    //List query = q(new String[]{"gene_id:509317"});
    //List query = q(new String[]{"seq:GCGCACCACCACCAACCTCTA"});
    //List query = q(new String[]{"experiment_id:List"});
    //query.addAll(q(new String[]{"experiment_id:4667"}));
    //List query = q(new String[]{"collection_id:76276"});
    //List query = q(new String[]{"barcodes:1500086027,1500086028,1500086029,1500086030,1500086031,1500086032,1500086033,1500086034,1500086035,1500086036,1500086037,1500086038,1500086039,1500086040,1500086041,1500086042,1500086043,1500086044,1500086045,1500086046,1500086047,1500086048,1500086049"});
    //List query = q(new String[]{"gene_id:594303","analysis_type_id:1", "result_type_ids:1,2,3" });
    //List query = q(new String[]{"gene_id:594303"});
    //List query = q(new String[]{"experiment_id:4667", "analysis_type_id:1", "result_type_ids:2,3,11"});
    //List query = q(new String[]{"experiment_id:4798"});
    //query = q(new String[]{"experiment_id:4650"});
    //List query = q(new String[]{"gene_symbol:mdm2"});
    // List query = q(new String[]{"analysis_type_id:1", "result_type_ids:3,2,13", "experiment_id:4985"});
    //List query = q(new String[]{"gene_mixture_ids:100000267", "experiment_id:4985"});
    //List query = q(new String[]{"gene_mixture_id:100000267"});
    //List query = q(new String[]{"gene_symbol:[SRPK1,SRPK2]"});
    List query = q(new String[]{"gene_mixture_id:100000267","analysis_type_id:1", "result_type_ids:1,2,3" });

    ElapsedTimer timer = new ElapsedTimer();
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    //JSONObject results = new RNAiSearchJProc().getGeneHits(conn, RNAiSearchInputType.EXPERIMENT_IDS, query);
    //JSONObject results = new RNAiSearchJProc().getResults(conn, RNAiSearchInputType.EXPERIMENT_IDS, query, null);
    //Map results = new RNAiSearchJProc().getResultTypes(conn);
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    //System.out.println(new RNAiSearchJProc().getExperiments(conn, RNAiSearchInputType.ALL, null));
    //System.out.println(new RNAiSearchJProc().getGIResults(conn, RNAiSearchInputType.EXPERIMENT_IDS, query, null));
    //Blob blobResult = new RNAiSearchJProc().executeQuery(conn, RNAiSearchInputType.EXPERIMENT_IDS + "",
    //        RNAiSearchOutputType.EXPERIMENTS + "", createBLOB(conn, query));
    //Blob blobResult= new RNAiSearchJProc().runGeneInteractionResults(conn, 3989, 3734, "");
    Blob blobResult = new RNAiSearchJProc().executeQuery(conn, RNAiSearchInputType.GENE_MIXTURE_IDS + "", RNAiSearchOutputType.RESULTS + "", createBLOB(conn, query));

    Object resultObj = ExtOracle.readObjectFromBlob(blobResult, true);
    if (resultObj instanceof String) {
      //System.out.println(resultObj.toString());
      System.out.println(resultObj.toString().split("\n").length);

    } else if (resultObj instanceof JSONObject) {
      //System.out.println(((JSONObject) resultObj).toString(2));
      JSONArray jObj = ((JSONObject) resultObj).getJSONArray("results");
      System.out.println(jObj.toString(2));

    } else if (resultObj instanceof JSONArray) {
      System.out.println(((JSONArray) resultObj).toString(2));
    }
    System.out.println("==================================================");

    /*
     * Iterator<String> keys = results.keys(); while (keys.hasNext()) { String
     * key = keys.next(); System.out.println(key + " = " +
     * results.getJSONArray(key).length()); System.out.println(key + " \n " +
     * results.getJSONArray(key)); }
     */
    conn.close();

  }

  public static JSONObject executeLocalExp(int expID) throws Exception {

    Connection conn = null;
    try {
      //String RUN_QUERY = "begin ? := RNAIQUERY.runQuery2Tabs(?, ?, ?); end;";
      String RUN_QUERY = "begin ? := RNAIQUERY.runQuery(?, ?, ?); end;";
      conn = getConnection();
      List query = q(new String[]{"analysis_type_id:1", "result_type_ids:3,2,13", "experiment_id:" + expID});

      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, RNAiSearchInputType.EXPERIMENT_IDS + "");
      cs.setString(3, RNAiSearchOutputType.RESULTS + "");
      cs.setBLOB(4, createBLOB(conn, query));
      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      return (JSONObject) ExtOracle.readObjectFromBlob(resultBlob, true);
    } finally {
      conn.close();
    }

  }

  public static JSONObject executeExperiment(int expID) throws Exception {

    Connection conn = null;
    try {
      //String RUN_QUERY = "begin ? := RNAIQUERY.runQuery2Tabs(?, ?, ?); end;";
      String RUN_QUERY = "begin ? := RNAIQUERY.runQuery(?, ?, ?); end;";
      conn = getConnection();
      List query = q(new String[]{"experiment_id:" + expID});

      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, RNAiSearchInputType.EXPERIMENT_IDS + "");
      cs.setString(3, RNAiSearchOutputType.EXPERIMENTS + "");
      cs.setBLOB(4, createBLOB(conn, query));
      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      return (JSONObject) ExtOracle.readObjectFromBlob(resultBlob, true);
    } finally {
      conn.close();
    }

  }

  public static void executeRawRemote() throws Exception {
    Connection conn = getConnection();
    String RUN_QUERY = "begin ? := RNAIQUERY.getExperimentResults(?); end;";
    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
    cs.registerOutParameter(1, Types.CLOB);
    cs.setInt(2, 4964);
    cs.execute();
    Clob resultClob = cs.getClob(1);
    String results = resultClob.getSubString(1, (int) resultClob.length());

    System.out.println("Size: " + results);

    //JSONObject results = fromBlob(resultBlob);
    System.out.println(results);
    System.out.println("--------------------------------------------------");
    System.out.println(results.split("\n").length);
    System.out.println("==================================================");
    /*
     * Iterator<String> keys = results.keys(); while (keys.hasNext()) { String
     * key = keys.next(); System.out.println(key + " = " +
     * results.getJSONArray(key).length()); }
     */
    conn.close();
    //write(results);

  }

  public static void executeGetCharts() throws Exception {
    Connection conn = getConnection();
    String RUN_QUERY = "begin ? := RNAIQUERY.getCharts; end;";
    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
    cs.registerOutParameter(1, Types.BLOB);
    cs.execute();
    Blob resultBlob = cs.getBlob(1);
    JSONObject results = (JSONObject) fromBlob(resultBlob);

    System.out.println(results.toString(2));

    conn.close();
    //write(results);

  }

  public static void executeRemote() throws Exception {
    //String RUN_QUERY = "begin ? := RNAIQUERY.runQuery2Tabs(?, ?, ?); end;";
    String RUN_QUERY = "begin ? := RNAIQUERY.runQuery(?, ?, ?); end;";

    Connection conn = getConnection();
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.RNAI_ID, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"plate_id:1500086117"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_ID, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol:mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"eg_id:207"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"root_number:2558018", "lot_number:3"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.RNAI_IDS, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_IDS, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol: mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.ENTREZGENE_IDS, q(new String[]{"eg_id: 207"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"plate_id: 1500086117"}));

    //List query = q(new String[]{"root_number:2558018", "lot_number:3"});
    // List query = q(new String[]{"experiment_id:3856,3843,4101,4100"});
    //List query = q(new String[]{"eg_id:207"});
//    List query = q(new String[]{"rnai_id:555039"});
    //List query = q(new String[]{"collection_id:76266"});
    //List query = q(new String[]{"barcodes:1158772,1500086027"});
    //List query = q(new String[]{"experiment_id1:4100", "experiment_id2:4101"});
//    List query = q(new String[]{"gene_symbol:mdm2"});
    List query = q(new String[]{"analysis_type_id:1", "result_type_ids:3,2,13", "experiment_id:4985"});

    //List query = q(new String[]{"experiment_id:3882", "analysis_type:OGA Method v2", "result_types:'POC','CORRECTED_PVALUE','PVALUE_RANK'" });
    //List query = q(new String[]{"gene_id:592331","analysis_type:OGA Method v2", "result_types:'POC','CORRECTED_PVALUE','PVALUE_RANK'" });
    //List query = q(new String[]{"experiment_id:4000", "analysis_type_id:1", "result_type_ids:1,2,3" });
    //List query = q(new String[]{"experiment_id:4000", "analysis_type_id:1", "result_type_ids:1,2,3" });
    //List query = q(new String[]{"experiment_id:3782", "analysis_type_id:1", "result_type_ids:2,3,11,13"});
    ElapsedTimer timer = new ElapsedTimer();

    System.out.println("Start");
    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
    cs.registerOutParameter(1, Types.BLOB);
    cs.setString(2, RNAiSearchInputType.EXPERIMENT_IDS + "");
    cs.setString(3, RNAiSearchOutputType.RESULTS + "");
    //cs.setNull(4, Types.BLOB);
    cs.setBLOB(4, createBLOB(conn, query));

    System.out.println("Execute");
    cs.execute();
    System.out.println("Execute Done. Get Blob...");

    Blob resultBlob = cs.getBlob(1);
    System.out.println("Size: " + resultBlob.length());
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    Object resultObj = ExtOracle.readObjectFromBlob(resultBlob, true);
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");
    if (resultObj instanceof String) {
      //String[] lines = resultObj.toString().split("[\\r\\n]+");
      //System.out.println(lines[0]);
      //System.out.println(lines[1]);

      JSONObject jResults = new JSONObject();

      CSVReader csv = new CSVReader(new StringReader(resultObj.toString()), '\t');
      if (csv.readHeaders()) {
        String[] headers = csv.getHeaders();
        Map<String, Integer> typeMap = new HashMap<String, Integer>();
        for (String header : headers) {
          String value = csv.get(header);
          if ((header.endsWith("id") || header.endsWith("number")) && ExtString.isAInteger(value)) {
            typeMap.put(header, Types.INTEGER);
          } else if (header.endsWith("date")) {
            typeMap.put(header, Types.DATE);
          }
        }

        while (csv.readRecord()) {
          JSONObject jResult = new JSONObject();
          jResults.append("results", jResult);
          for (String header : headers) {
            String value = csv.get(header);
            Integer type = typeMap.get(header);
            if (type != null) {
              switch (type.intValue()) {
                case Types.INTEGER:
                  int intValue = ExtString.toInteger(value, -191919191);
                  jResult.put(header, (intValue == -191919191 ? value : intValue + ""));
                  break;
                case Types.DATE:
                  jResult.put(header, value);
                  break;
              }
            } else {
              jResult.put(header, value);
            }
          }
        }
      }

    } else if (resultObj instanceof JSONObject) {
      System.out.println(((JSONObject) resultObj).toString(2));
    } else if (resultObj instanceof JSONArray) {
      System.out.println(((JSONArray) resultObj).toString(2));
    }
    //JSONObject results = fromBlob(resultBlob);

    System.out.println("==================================================");
    /*
     * Iterator<String> keys = results.keys(); while (keys.hasNext()) { String
     * key = keys.next(); System.out.println(key + " = " +
     * results.getJSONArray(key).length()); }
     */

    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    conn.close();
  }

  public static void executeRunAndSaveRemote() throws Exception {
    String RUN_QUERY = "begin ? := RNAIQUERY.runAndSaveQuery(?, ?, ?); end;";

    Connection conn = getConnection();
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.RNAI_ID, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"plate_id:1500086117"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_ID, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol:mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"eg_id:207"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.COMPOUND_IDS, q(new String[]{"root_number:2558018", "lot_number:3"}));
    //JSONObject obj = new RNAiSearchJProc().getPlates(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.EXPERIMENT_IDS, q(new String[]{"experiment_id:4000"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.RNAI_IDS, q(new String[]{"rnai_id:708283"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_IDS, q(new String[]{"gene_id:518041"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.GENE_SYMBOLS, q(new String[]{"gene_symbol: mdm2"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.ENTREZGENE_IDS, q(new String[]{"eg_id: 207"}));
    //JSONObject obj = new RNAiSearchJProc().getExperiments(getConnection(), RNAiSearchJProc.InputType.PLATE_IDS, q(new String[]{"plate_id: 1500086117"}));

    //List query = q(new String[]{"root_number:2558018", "lot_number:3"});
    //List query = q(new String[]{"experiment_id:4000"});
//    List query = q(new String[]{"gene_symbol:mdm2"});
    //List query = q(new String[]{"experiment_id:3882", "analysis_type:OGA Method v2", "result_types:'POC','CORRECTED_PVALUE','PVALUE_RANK'" });
    //List query = q(new String[]{"gene_id:592331","analysis_type:OGA Method v2", "result_types:'POC','CORRECTED_PVALUE','PVALUE_RANK'" });
    //List query = q(new String[]{"experiment_id:4000", "analysis_type_id:1", "result_type_ids:1,2,3" });
    //List query = q(new String[]{"experiment_id:4000", "analysis_type_id:1", "result_type_ids:1,2,3" });
    List query = q(new String[]{"experiment_id:3782", "analysis_type_id:1", "result_type_ids:2,3,11,13"});

    ElapsedTimer timer = new ElapsedTimer();
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_QUERY);
    cs.registerOutParameter(1, Types.INTEGER);
    cs.setString(2, RNAiSearchInputType.EXPERIMENT_IDS + "");
    cs.setString(3, RNAiSearchOutputType.RESULTS + "");
    cs.setBLOB(4, createBLOB(conn, query));
    cs.execute();
    int resultID = cs.getInt(1);
    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    System.out.println("ID: " + resultID);
    //JSONObject results = fromBlob(resultBlob);

    System.out.println((double) timer.getElapsedTime() / 1000 + " s");

    /*
     * Iterator<String> keys = results.keys(); while (keys.hasNext()) { String
     * key = keys.next(); System.out.println(key + " = " +
     * results.getJSONArray(key).length()); }
     */
    conn.close();
  }

  private static Connection getConnection() throws SQLException {
    if (System.getProperty("os.name").indexOf("Windows") >= 0) {
      OracleDataSource ods = new OracleDataSource();
      ods.setDriverType("thin");
      if (INSTANCE.equalsIgnoreCase("PROD")) {
        ods.setServerName("uswa-pdbx-ora45.amgen.com");
        ods.setDatabaseName("Wa0630p");
      } else if (INSTANCE.equalsIgnoreCase("DEV")) {
        ods.setServerName("uswa-ddbx-ora10.amgen.com");
        ods.setDatabaseName("wa0630d");
      }
      ods.setPortNumber(1771);
      ods.setUser("rnai_index");
      ods.setPassword("Ra1n1ng#");

      return ods.getConnection();
    } else {
      return DriverManager.getConnection("jdbc:default:connection:");
    }
  }

  private static Connection getSQUIDConnection() throws SQLException {
    if (System.getProperty("os.name").indexOf("Windows") >= 0) {
      OracleDataSource ods = new OracleDataSource();
      ods.setDriverType("thin");

      ods.setServerName("uswa-pdbx-ora10.amgen.com");
      ods.setDatabaseName("wa0800p");
//      ods.setServerName("uswa-pdbx-ora09.amgen.com");
//      ods.setDatabaseName("Wa0630p");
      ods.setPortNumber(1521);
      ods.setUser("svc_squid_ro");
      ods.setPassword("Tabu62908#");

      return ods.getConnection();
    } else {
      return DriverManager.getConnection("jdbc:default:connection:");
    }
  }

  public static List<Map<String, String>> q(String[] queryStr) {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value = new HashMap<String, String>();
    query.add(value);
    for (String q : queryStr) {
      value.put(q.split(":")[0].trim(), q.split(":")[1].trim());
    }
    return query;
  }

  private static BLOB createBLOB(Connection conn, Object obj) throws SQLException {
    BLOB tempBlob = null;
    try {
      tempBlob = BLOB.createTemporary(conn, true, BLOB.DURATION_SESSION);
      OutputStream blobOutStream = tempBlob.setBinaryStream(0);
      ObjectOutputStream oop = new ObjectOutputStream(blobOutStream);
      oop.writeObject(obj);
      oop.flush();
      oop.close();
      blobOutStream.close();
    } catch (Exception exp) {
      tempBlob.freeTemporary();
      throw new SQLException(exp);
    }
    return tempBlob;
  }

  private static Object fromBlob(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      Object obj = objIN.readObject();
      if (obj instanceof JSONObject) {
        return (JSONObject) obj;
      } else {
        return obj.toString();
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new JSONObject();
  }

  private static String fromBlob2String(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      return (String) objIN.readObject();
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new String();
  }

  public static void write(Object j) {
    FileWriter writer = null;
    try {
      writer = new FileWriter("/temp/out.js");
      if (j instanceof JSONObject) {
        writer.write(((JSONObject) j).toString(2));
      } else {
        writer.write(j + "");
      }
      writer.close();

    } catch (Exception ex) {
      Logger.getLogger(Tester.class
              .getName()).log(Level.SEVERE, null, ex);
    } finally {
      try {
        writer.close();

      } catch (IOException ex) {
        Logger.getLogger(Tester.class
                .getName()).log(Level.SEVERE, null, ex);
      }
    }

  }

  public static void executeFASTQBuilder() throws Exception {
    String plsql = "DECLARE "
            + "   OUT_CLOB   CLOB; "
            + "   IN_CLOB    CLOB; "
            + "   l_ctr      PLS_INTEGER := 1; "
            + "BEGIN "
            + "FOR R IN "
            + "   (SELECT '>' || DEFINITION || CHR (10) || \"SEQUENCE\" "
            + "         INTO IN_CLOB "
            + "     FROM (SELECT S.ACC_ID || ' ' || S.DESCRIPTION || ' (GI:' || S.AMGEN_GENE_ID || ')' "
            + "                     \"DEFINITION\",        S.SEQ_TEXT \"SEQUENCE\" "
            + "             FROM SQUID.SEQ_INFO S "
            + "            WHERE     S.DATASET_ID = 213 "
            + "                  AND S.SEQ_TYPE_ID IN (2, 3, 4, 5) "
            + "                  AND taxon_id IN (    SELECT TAXON_ID "
            + "                                         FROM TAXONOMY.TAXON t "
            + "                                   START WITH TAXON_ID = ? "
            + "                                   CONNECT BY NOCYCLE PRIOR T.TAXON_ID = T.PARENT_TAXON_ID))) "
            + "     LOOP "
            + "      DBMS_LOB.COPY (OUT_CLOB, "
            + "                      IN_CLOB, "
            + "                      DBMS_LOB.GETLENGTH (IN_CLOB), "
            + "                      l_ctr); "
            + "      l_ctr := l_ctr + DBMS_LOB.GETLENGTH (IN_CLOB); "
            + "   END LOOP; "
            + "?:=    OUT_CLOB; "
            + "end; ";

    Connection conn = getSQUIDConnection();
    CallableStatement cs = conn.prepareCall(plsql);

    cs.setInt(1, 9606);
    cs.registerOutParameter(2, OracleTypes.CLOB);
    cs.execute();

    System.out.println("Result = " + cs.getClob(2));

    conn.close();
  }
}
