/**
 * Defines the namespaces
 */
Ext.namespace("RNAi", "RNAi.Record", "RNAi.Labware", "RNAi.Dialog", 'RNAi.Spotfire');

Ext.Ajax.timeout = 600000

/**
 * Checks for an error_mesg in the header
 * if nothing, return FALSE (no error, all OK)
 * TRUE otherwise
 * 
 * @return FALSE- no error found
 * TRUE- an error message was returned and the message displayed
 */
RNAi.checkForErrorResponse= function(response, title) {
  var msg= null;
  try {
    msg= response.getResponseHeader("error_mesg")
  } catch(e) {}
  try {
    var json= Ext.decode(response.responseText)
    if (json && json.error_mesg) {
      msg= Ext.util.Format.nl2br(json.error_mesg)
    }
  } catch(e) {}
  if (!msg) {
    return false
  }    
  RNAi.showErrorResponse(msg, title)      
  return true
}


RNAi.showErrorResponse= function(msg, title) {   
  Ext.Msg.show({
    title: title || 'Request Failed',
    msg: msg,
    buttons: Ext.Msg.OK,
    icon: Ext.MessageBox.ERROR,
    minWidth: 250
  });      
  return true
}

/**
 * Show the notifier message box
 * 
 * @param {Object} msg
 * @param {Object} title
 */
RNAi.notify= function(msg) {
  new Ext.ux.Notify({
    title : 'Message',
    html :msg,
    hideDelay :3000,
    closable :false,
    autoDestroy :true
  }).show(document)

}

