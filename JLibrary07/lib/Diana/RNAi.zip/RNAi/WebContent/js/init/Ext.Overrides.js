
Ext.BLANK_IMAGE_URL = "http://uswa-papp-dweb2.amgen.com:9090/extjs/ext3/resources/images/default/s.gif"


/**
 * Appends content to the query string of a URL, handling logic for whether to place a question mark or ampersand. - Copied from Ext 3.x
 * 
 * @param {String} url The URL to append to.
 * @param {String} s The content to append to the URL.
 * @return (String) The resulting URL
 */
Ext.urlAppend = function(url, s, v) {
  if (!Ext.isEmpty(s)) {
    var s1 = s
    if (!Ext.isEmpty(v)) {
      s1 = s + "=" + escape(v)
    }
    return url + (url.indexOf('?') === -1 ? '?' : '&') + s1;
  }
  return url;
}
Ext.util.JSON.clone = function(obj) {
  return Ext.util.JSON.decode(Ext.util.JSON.encode(obj))
}

Ext.isRecord= function(r) {
  return (Ext.isObject(r) &&  Ext.isObject(r.data))
}

Ext.override(Ext.grid.ColumnModel, {
  destroy : function(){
    for(var i = 0, len = this.config.length; i < len; i++){
      Ext.destroy(this.config[i]);
    }
    this.purgeListeners();
  }
});

