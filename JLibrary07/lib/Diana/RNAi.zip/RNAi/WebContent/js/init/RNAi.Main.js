
RNAi.FeaturesTreeNodes = [{
    id: 'SEARCH',
    "text": "Search",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-view"
  }, {
    id: 'ALL_EXPERIMENTS',
    "text": "All Experiments",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-text_view"
  }, {
    id: 'MY_EXPERIMENTS',
    "text": "My Experiments",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-text_view"
  }, {
    id: 'USER_EXPERIMENTS',
    "text": "User Experiments",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-text_view"
  }, {
    id: 'ANALYZE_FILE',
    "text": "Analyze File",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-document_gear"
  }/*, {
   "text" : "Registration", 
   "leaf" : false, 
   singleClickExpand:true,
   iconCls: "tree-icon-24 ix-v0-24-index",
   "children" : [{
   "text" : "siRNA", 
   "leaf" : true, 
   "id" : "reg-siRNA",
   iconCls: "tree-icon-24 ix-v0-24-index_edit"
   }, {
   "text" : "shRNA", 
   "leaf" : true, 
   "id" : "reg-shRNA",
   iconCls: "tree-icon-24 ix-v0-24-index_edit"
   }]
   }*/, {
    "text": "Collections",
    "leaf": false,
    iconCls: "tree-icon-24 ix-v0-24-table",
    singleClickExpand: true,
    "children": [{
        "text": "Manage Collections",
        "leaf": true,
        "id": "COLLECTIONS",
        iconCls: "tree-icon-24 ix-v0-24-tables_edit"
      }, {
        "text": "Plate Utilities",
        "leaf": true,
        "id": "PLATEUTILITIES",
        iconCls: "tree-icon-24 ix-v0-24-table_view"
      }/*,{
       "text" : "Compare a list of screening plates to the registered plate list for a library", 
       "leaf" : true, 
       iconCls: "tree-icon-24 ix-v0-24-table_view"
       },{
       "text" : "Pull failed plates from ALDI by specifying QC session", 
       "leaf" : true, 
       iconCls: "tree-icon-24 ix-v0-24-table_view"
       },{
       "text" : "Compare two free-form plate lists", 
       "leaf" : true, 
       iconCls: "tree-icon-24 ix-v0-24-table_view"
       },{
       "text" : "Given a gene, identify the plate(s) that the siRNAs for gene are on", 
       "leaf" : true, 
       iconCls: "tree-icon-24 ix-v0-24-table_view"
       },{
       "text" : "Plate map visualization with options to show gene/siRNA info", 
       "leaf" : true, 
       "id":"rgnew",
       iconCls: "tree-icon-24 ix-v0-24-table_view"
       }*/]
  }, {
    "text": "Import",
    "leaf": false,
    "id": "IMPORT_NODE",
    iconCls: "tree-icon-24 ix-v0-24-import1",
    singleClickExpand: true,
    "children": [/*
     {
     "text" : "Experiments", 
     "leaf" : true, 
     "id" : "GETEXPERIMENTS",
     iconCls: "tree-icon-24 ix-v0-24-import2"
     },*/{
        text: "Screener Load",
        id: "SCREENERDATALOAD",
        leaf: true,
        disabled: true,
        iconCls: "tree-icon-24 ix-v0-24-import2"
      }, {
        text: "Screener Append",
        id: "SCREENERDATAAPPEND",
        leaf: true,
        disabled: true,
        iconCls: "tree-icon-24 ix-v0-24-import2"
      }, {
        text: "shRNA Load",
        id: "SHRNADATALOAD",
        leaf: true,
        disabled: true,
        iconCls: "tree-icon-24 ix-v0-24-import2"
      }, {
        text: "Annotation Group",
        leaf: true,
        disabled: true,
        id: "GETANNOTATIONGROUP",
        iconCls: "tree-icon-24 ix-v0-24-import2"
      }, {
        text: "Annotation",
        leaf: true,
        id: "GETANNOTATION",
        disabled: true,
        iconCls: "tree-icon-24 ix-v0-24-import2"
      }]
  }, {
    "text": "Cosmic Viewer (Spotfire)",
    "leaf": true,
    "id": "RNAIWEBPLAYER",
    iconCls: "tree-icon-24 spotfire"
  }, {
    text: "Analysis Results",
    leaf: false,
    id: 'analysis_results',
    iconCls: "tree-icon-24 ix-v0-24-folder_gear",
    listeners: {
      beforeexpand: function(node) {
        node.loaded = false
      },
      expand: function(node) {
        if (!Ext.isArray(node.childNodes) || node.childNodes.length == 0) {
          node.collapse()
        }
      }
    },
    loader: new Ext.tree.TreeLoader({
      url: '/RNAi/rnai.go',
      baseParams: {
        req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
        rx: 'prev_run_analysis_nodes'
      },
      processResponse: function(response, node, callback, scope) {
        var json = response.responseText;
        try {
          var nodes = Ext.decode(json)
          response.responseData = nodes.nodes
        } catch (e) {
        }
        Ext.tree.TreeLoader.prototype.processResponse.call(this, response, node, callback, scope)
      },
      createNode: function(attr) {
        if (attr.type == 'analysis') {
          if (!attr.finished) {
            attr.iconCls = 'tree-icon-24 ix-v0-24-gear_run'
          } else {
            attr.iconCls = 'tree-icon-24 ix-v0-24-gear_stop'
          }
        } else if (attr.type == 'experiment') {
          attr.iconCls = 'tree-icon-24 ix-v0-24-text_view'
        }
        return Ext.tree.TreeLoader.prototype.createNode.call(this, attr)
      }
    }),
    singleClickExpand: true
  }, {
    id: 'HELP',
    "text": "Help",
    "leaf": true,
    iconCls: "tree-icon-24 ix-v0-24-help2"
  }
];

RNAi.ContentPanelUi = Ext.extend(Ext.TabPanel, {
  activeTab: 0,
  id: 'main-tab-panel',
  enableTabScroll: true,
  plugins: new Ext.ux.TabCloseMenu(),
  initComponent: function() {
    var panel = this
    this.items = [
    ];
    RNAi.ContentPanelUi.superclass.initComponent.call(this);
  },
  handleAlignment: function() {
    var active = this.getActiveTab()
    var getRNAIRecordsScope
    var getRNAIRecords = null
    if (Ext.isFunction(active.getRNAIRecords)) {
      getRNAIRecordsScope = active
      getRNAIRecords = active.getRNAIRecords
    } else {
      active.findBy(function(child, container) {
        if (Ext.isFunction(child.getRNAIRecords)) {
          getRNAIRecordsScope = child
          getRNAIRecords = child.getRNAIRecords
          return false
        }
        return true
      })
    }

    if (getRNAIRecords) {
      var rnaiRecords = getRNAIRecords.call(getRNAIRecordsScope)
      if (Ext.isArray(rnaiRecords) && rnaiRecords.length > 0) {
        // Prompt for user data and process the result using a callback:
        Ext.Msg.prompt('RNAi Alignment', 'Please enter the target accession number:', function(btn, text) {
          if (btn == 'ok') {
            new RNAi.TabPanelLoader('ALIGN').load({
              targetID: text,
              rnaiRecords: rnaiRecords
            })
          }
        }, this, false, "NM_020630")
      }
    }
  }
})

RNAi.FeaturesTreePanelUi = Ext.extend(Ext.tree.TreePanel, {
  title: 'Features',
  id: 'main-tree-panel',
  width: 165,
  autoScroll: true,
  rootVisible: false,
  initComponent: function() {
    var tree = this
    this.root = new Ext.tree.AsyncTreeNode({
      text: 'RNAi',
      expandable: true,
      expanded: true,
      //iconCls: "tree-icon-24 ix-v0-24-folder_closed",      
      children: RNAi.FeaturesTreeNodes
    });
    this.loader = new Ext.tree.TreeLoader()

    this.on('click', function(node) {
      if (node.attributes.type && node.attributes.type == 'analysis') {
        new RNAi.TabPanelLoader(node.id).loadAnalysis({
          node: node
        })
      } else if (node.attributes.type && node.attributes.experiment_id && node.attributes.type == 'experiment') {
        new RNAi.TabPanelLoader().loadRNAiExperimentsSearchResults({
          searchBy: 'EXPERIMENT_IDS',
          query: node.attributes.experiment_id
        })
      } else {
        new RNAi.TabPanelLoader(node.id).load()
      }
    })

    RNAi.FeaturesTreePanelUi.superclass.initComponent.call(this);


    //Select Search Node for Now        
    this.on('render', function() {
      new Ext.util.DelayedTask().delay(100, function() {
        new RNAi.TabPanelLoader("SEARCH").load()
      })
    })

    this.on('expandnode', function(node) {
      if (node.id == 'IMPORT_NODE') {
        tree.setImportNodesPermissions(node)
      }
    })
  },
  setImportNodesPermissions: function(importNode) {
    sessionIdentity.userHasPermission('IMPORT', null, function(hasPermission) {
      if (hasPermission) {
        importNode.enable()
      } else {
        importNode.disable()
      }
      importNode.eachChild(function(node) {
        if (hasPermission) {
          node.enable()
        } else {
          node.disable()
        }
      })
    })
  }
});

