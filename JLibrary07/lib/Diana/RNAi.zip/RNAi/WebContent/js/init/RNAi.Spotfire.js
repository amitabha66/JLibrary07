RNAi.Spotfire.URLs= function() {
  var sfURLS= {
    COMPAREPOC: {
      url: 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/ComparePOC',
      params: [
        'exp_id1',
        'exp_id2'
      ]
    },
    PVALUERANKS: {
      url : 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/RNAi_PValueRank',
      params: [
        'exp_id'
      ]
    },
    PVALUEVSGENES: {
      url : 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/PValuesToGene',
      params: [
        'exp_ids'
      ]
    }
  }
  return {   
    getsfURL: function(sfName, params) {      
      var sfURL= sfURLS[sfName]
      var configBlock= sfURL.configBlock || ''
      for(var i=0; i< sfURL.params.length; i++) {
        var pName= sfURL.params[i]
        if (params[pName]) {
          configBlock= configBlock + pName + '="' + params[pName] + '";'
        }
      }
      return sfURL.url+"&configurationBlock="+ encodeURI(configBlock)
    }
  }
}()