/*
 * Overrides & extensions to Global and Core JS objects
 */

/**
 * Returns whether the given object has length meaning: The object must be a String or Number and must contain a non-whitespace character
 * 
 * @param {Object} s
 */
function hasLength(s) {
  if (Ext.type(s) == 'string') {
    return (s.length > 0)
  }
  if (Ext.type(s) == 'number') {
    return true
  }
  return false
}

/**
 * Returns whether the given String is in the array
 * 
 * @param {Object} s
 * @param {Object} array
 */
function isIn(s, array) {
  if (Ext.type(s) != 'string' || Ext.type(array) != 'array') {
    return false
  }
  var ret = false
  Ext.each(array, function(item) {
    if (item == s) {
      ret = true
    }
  })
  return ret
}

/**
 * Add statics to String
 */
Ext.applyIf(String, {
  /**
   * Returns whether the 2 Strings are equivalent- Both must be non-null && be equal
   */   
  equals : function(s1, s2){
    if (!s1 || !s2) {
      return false
    }
    return (s1== s2)
  },
  encodeHTML: function () {
    return this.replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
  }
});
/**
 * Add methods to String
 */
Ext.apply(String.prototype, {
  /**
 * Add an equalsIgnoreCase to the String object
 * 
 * @param {Object} otherStr
 */
  equalsIgnoreCase: function(otherStr) {
    if (!otherStr) {
      return false
    }
    return (this.toLowerCase() == otherStr.toLowerCase())
  },
  /**
 * adds a toTitleCase to String
 */
  toTitleCase: function() {
    var objValues = this.split(" ");
    var outText = "";
    for ( var i = 0; i < objValues.length; i++) {
      outText = outText + objValues[i].substr(0, 1).toUpperCase() + objValues[i].substr(1).toLowerCase() + ((i < objValues.length - 1) ? " " : "");
    }
    return outText;
  },
  pixelLength: function(className) {
    // create hidden target iframe
    var id = Ext.id();
    var ruler = document.createElement('div');
    ruler.id = id;
    ruler.className = 'x-hidden';
    document.body.appendChild(ruler);
  
    var el = Ext.fly(id)
    if (className) {
      el.addClass(className)
    }
    var width = el.getTextWidth(this);
    el.remove()
    return width
  },
  startsWith: function(str) {
    return (this.match("^"+str)==str)
  },
  endsWith: function(str) {    
    return this.indexOf(str, this.length - str.length) !== -1
  },
  /**
 * Performs word wrapping. Returns the input string with long lines of text
 * cut (between words) for readability.
 *   
 * @param length number of characters in a line
 */
  wrap: function(length, splitOnHyphen) {
    var s= this
    s= s.trim();
    if (splitOnHyphen) {
      s= s.replace(/^-/, "")
    }
    var newline = "\n";

    //If Small Enough Already, Return Original
    if (s.length < length) {
      return s;
    }
    //If Next length Contains Newline, Split There
    if (s.substring(0, length).indexOf(newline)> -1) {
      return s.substring(0, s.indexOf(newline)).trim() + newline
      + s.substring(s.indexOf("\n") + 1).wrap(length, splitOnHyphen);
    }
    //Otherwise, Split Along Nearest Previous Space/Tab/Dash  
    var spaceIndex = Math.max(s.lastIndexOf(" ", length), s.lastIndexOf("\t", length));    
    if (splitOnHyphen) {
      spaceIndex = Math.max(spaceIndex, s.lastIndexOf("-", length));
    }  
    //If No Nearest Space, Split At length
    if (spaceIndex == -1) {
      spaceIndex = length;
    }
    //Split
    return s.substring(0, spaceIndex).trim() + newline + s.substring(spaceIndex).wrap(length, splitOnHyphen);
  }  
})


/**
 * Add methods to Array
 */
Ext.apply(Array.prototype, {
  /**
 * Adds a unique function to the Array object which returns only
 */
  unique: function() {
    var o = {}, i, l = this.length, r = [];
    for (i = 0; i < l; i++) {
      o[this[i]] = this[i];
    }
    for (i in o) {
      r.push(o[i]);
    }
    return r;
  }
})

/**
 * Add statics to Number
 */
Ext.apply(Number, {
  isANumber: function(v) {
    if (Ext.type(v) == 'number') {
      return true
    }
    return ((new Number(v) == (v - 0)) ? true : false)
  }
})

/**
 * Add methods to Number
 */
Ext.apply(Number.prototype, {
  /**
 * Adds a makeDivisible method to Number. Mathematically, this subtracts the modulus from the value v= n - (n % d) Ensuring v/d is an integer.
 * 
 * @param {Object} divisor
 */
  makeDivisible: function(divisor) {
    return this - (this % divisor)
  },
  isInt: function() {
    var y=parseInt(this.toString())
    if (isNaN(y)) {
      return false
    }
    return this==y && this.toString()==y.toString();
  }
})

