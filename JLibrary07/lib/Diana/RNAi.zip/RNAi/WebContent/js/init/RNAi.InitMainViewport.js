

Ext.onReady( function() {  
  Ext.QuickTips.init();  
  new RNAi.RNAiViewportUi()
  try {
    Ext.getBody().child('.init-loading').remove()
  } catch (e) {
  }        
})

RNAi.RNAiViewportUi = Ext.extend(Ext.Viewport, {
  layout:'border' ,
  id:'root-id',
  initComponent:function() {
    this.items=[new RNAi.FeaturesTreePanelUi({
      region: 'west',
      width:200,
      split:true,
      collapsible :true,
      collapseMode :'mini'
    }),new RNAi.ContentPanelUi({
      region: 'center'
    })]
        
    RNAi.RNAiViewportUi.superclass.initComponent.call(this); 
    this.featuresPanel = this.items.itemAt(0);
    this.contentPanel = this.items.itemAt(1);
  }         
}); 

