

Ext.onReady( function() {  
  Ext.QuickTips.init();
  RNAi.buildRNAiViewportUi(results)
})


      
RNAi.buildRNAiViewportUi= function(results) {
  if (Ext.isObject(results) && Ext.isArray(results.analysis) && Ext.isArray(results.result_types) && results.dataID) {
    var analysisTypeRecords= []
    var resultTypeRecords= []
    for(var i=0; i< results.analysis.length; i++) {
      analysisTypeRecords.push(new RNAi.Record.Analysis(results.analysis[i]))
    }              
    for(var i=0; i< results.result_types.length; i++) {
      resultTypeRecords.push(new RNAi.Record.ResultType(results.result_types[i]))
    }
              
    new RNAi.RNAiViewportUi({
      dataID: results.dataID,
      host: results.host,
      inputType: results.inputType,
      dataProxy: (Ext.isString(results.dataProxy) && results.dataProxy.length> 0 ? results.dataProxy : null),
      cacheID: results.cacheID,
      analysisTypeRecords: analysisTypeRecords,
      resultTypeRecords: resultTypeRecords
    })       
  } else {
    new Ext.Viewport({
      items: [{
        html: 'No RNAi results found for gene provided',
        autoHeight: true,
        border: false,
        margins: {
          top:25, 
          right:0, 
          bottom:0, 
          left:25
        }
      }]
    })          
  }
}

RNAi.RNAiViewportUi = Ext.extend(Ext.Viewport, {
  layout:'border' ,
  id:'root-id',
  initComponent:function() {    
    var vp= this
    if (results.expRecord) {
      this.expRecord= new RNAi.Record.Experiment(results.expRecord)
    }    
    var dataSrcURL= this.host+'/rnaicache.go'
    var proxy= new Ext.data.HttpProxy({
      url: (this.dataProxy ? Ext.urlAppend(this.dataProxy, 'src', dataSrcURL) : dataSrcURL)
    })
    if (this.inputType== 'GENE_IDS') {
      this.items=[new RNAi.ExperimentResults({
        dataProxy: proxy,
        dataID: this.dataID,
        cacheID: this.cacheID,
        disableToolbar: true,
        region: 'center',
        border: true,
        resultsLoaded: true,
        analysisRecords: this.analysisTypeRecords,
        resultTypeRecords: this.resultTypeRecords        
      })] 
    } else {
      this.items=[new RNAi.ExperimentGeneSummaryResults({
        dataProxy: proxy,
        dataID: this.dataID,
        cacheID: this.cacheID,
        disableToolbar: true,
        expRecord: this.expRecord,
        disableExport: true,         
        region: 'center',
        border: true,
        resultsLoaded: true,
        analysisRecords: this.analysisTypeRecords,
        resultTypeRecords: this.resultTypeRecords        
      })]
    }
    RNAi.RNAiViewportUi.superclass.initComponent.call(this); 
  } 
        
}); 	  