
RNAi.PlateComparisonGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    var grid= this
    Ext.applyIf(this, {
      root: 'plates',
      fields: RNAi.Record.PlateLineage,
      rowActions: [{
        text: 'Legend',
        iconCls:'ix-v0-16-text_view', 
        cb: Ext.emptyFn,
        menu: [{
          items: [new Ext.menu.Item({
            onRender : function(){   
              this.el.insertFirst({
                tag: 'div',
                children: [{
                  tag: 'div', 
                  children: [{
                    tag: 'DIV', 
                    cls: 'x-collectioncomp-match-row', 
                    html: 'Match'
                  }]
                }, {
                  tag: 'div', 
                  children:  [{
                    tag: 'DIV', 
                    cls: 'x-collectioncomp-missing-row', 
                    html: 'Extra Plate (Not in Collection)'
                  }]
                }, {
                  tag: 'div', 
                  children:  [{
                    tag: 'DIV', 
                    cls: 'x-collectioncomp-none-row', 
                    html: 'Missing'
                  }]
                }]
              })
              Ext.menu.Item.prototype.onRender.apply(this, arguments);
            }
          })]
        }
        ]
      }]
    })
    this.baseTitle= this.title
    Ext.apply(this, {    
      autoExpandColumn: 'descendants'
    })
    var colDefs= [{
      header: 'Collection Plate',
      dataIndex: 'barcode',
      sortable: true,
      width: 150,
      renderer: function(value) {
        if (value.match(/^NONE/)) {
          return ""
        }
        return value
      }
    }, {
      header: 'Experiment Plate(s)',
      id: 'descendants',
      dataIndex: 'descendants'
    }, {
      header: 'Collection/Experiment Match',
      width: 150,
      dataIndex: 'flag',
      filterType: 'bool',
      renderer: function(value) {
        return (value=== true ? 'Yes' : 'No')
      }
    }]
  
    this.colModel= new Ext.grid.ColumnModel({     
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })       
    
    this.viewConfig= {
      getRowClass : function(record, rowIndex, p, ds){
        //var cls= Ext.grid.GridView.prototype.getRowClass.call(this, record, rowIndex, p, ds)
        var collectionBarcode= record.data.barcode
        var expBarcode= record.data.descendants
        if (collectionBarcode.match(/^NONE/)) {
          return 'x-collectioncomp-missing-row'
        }
        if (expBarcode.trim().length== 0) {
          return 'x-collectioncomp-none-row'
        }
        return 'x-collectioncomp-match-row'
      }  
    }
    RNAi.PlateComparisonGrid.superclass.initComponent.call(this);  
   
  }
})