
RNAi.GeneSearchResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent: function() {
    var panel = this
    var rowActions = [{
        groups: [{
            groupName: 'View',
            columns: 2,
            rowActions: [{
                text: 'Results',
                iconCls: 'ix-v0-16-text_view',
                recordSelectCount: 1,
                cb: function(grid, geneRecord) {
                  if (geneRecord.get('is_mixture') === true && geneRecord.get('gene_mixture_id')) {                    
                    new RNAi.TabPanelLoader().loadRNAiExperimentsSearchResults({
                      searchBy: 'GENE_MIXTURE_IDS',
                      searchResponse: 'RESULTS',
                      query: geneRecord.data.gene_mixture_id,
                      gene_mixture_id: geneRecord.data.gene_mixture_id
                    },
                    "Experiments [" + geneRecord.data.gene_symbol.replace(/\$\$/g, ',') + ", " + geneRecord.data.gene_name.replace(/\$\$/g, ',') + "] ",
                            RNAi.getDefaultAnalysisRecords(), RNAi.getDefaultResultTypeRecords(), geneRecord)
                  } else {
                    new RNAi.TabPanelLoader().loadRNAiExperimentsSearchResults({
                      searchBy: 'GENE_IDS',
                      searchResponse: 'RESULTS',
                      query: geneRecord.data.gene_id,
                      gene_id: geneRecord.data.gene_id
                    },
                    "Experiments [" + geneRecord.data.gene_symbol + ", " + geneRecord.data.gene_name + "] ",
                            RNAi.getDefaultAnalysisRecords(), RNAi.getDefaultResultTypeRecords(), geneRecord)
                  }
                }
              }, {
                text: 'RNAi',
                iconCls: 'ix-v0-16-pawn_glass_blue',
                recordSelectCount: 1,
                cb: function(grid, record) {
                  if (record.get('is_mixture') === true && record.get('gene_mixture_id')) {
                    new RNAi.TabPanelLoader().loadRNAiSearchResults({
                      query: record.data.gene_mixture_id,
                      searchBy: 'GENE_MIXTURE_IDS'
                    },
                    "RNAi [" + record.data.gene_symbol.replace(/\$\$/g, ',') + ", " + record.data.gene_name.replace(/\$\$/g, ',') + "] ")
                  } else {
                    new RNAi.TabPanelLoader().loadRNAiSearchResults({
                      query: record.data.gene_id,
                      searchBy: 'GENE_IDS'
                    },
                    "RNAi [" + record.data.gene_symbol + ", " + record.data.gene_name + "] ")
                  }
                }
              }, {
                text: 'Properties',
                iconCls: 'ix-v0-16-form_yellow',
                recordSelectCount: 1,
                cb: function(grid, geneRecord) {
                  grid.rowExpander.openAsWindow(geneRecord, geneRecord.data.gene_symbol + ", " + geneRecord.data.gene_name)
                }
              }]
          }, {
            groupName: 'Analysis',
            columns: 1,
            rowActions: [{
                text: 'Composite Histograms',
                iconCls: 'ix-v0-16-column-chart',
                recordSelectCount: 1,
                cb: function(grid, geneRecord) {
                  new RNAi.TabPanelLoader().createCompositeHistograms(geneRecord)
                }
              }]
          }, {
            groupName: 'Charts',
            columns: 1,
            rowActions: RNAi.Chart.getChartRowAction('Gene')
          }]
      }]
    if (Ext.isArray(this.addRowActions)) {
      rowActions = rowActions.concat(this.addRowActions)
    }

    this.items = [(this.contentGrid = new RNAi.GeneSummaryGrid({
        region: 'center',
        title: this.gridTitle,
        columnDefs: this.columnDefs,
        showExpRNAiCount: this.showExpRNAiCount,
        fields: this.fields,
        dataID: this.dataID,
        rowActions: rowActions
      }))]


    RNAi.GeneSearchResults.superclass.initComponent.call(this);
  },
  handleSearch: function(values) {
    var panel = this
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {
          panel.contentGrid.getStore().load()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchType: values.searchBy,
        searchResponse: 'Genes',
        query: values.query,
        dataID: panel.contentGrid.dataID
      }
    });
  }
});

