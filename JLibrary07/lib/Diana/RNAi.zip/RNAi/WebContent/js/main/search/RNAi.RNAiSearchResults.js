
RNAi.RNAiSearchResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {           
    this.items=[(this.contentGrid= new RNAi.RNAISummaryGrid({
      region: 'center',
      autoExpandColumn: 'sequence',
      rowActions: [{
        groups: [{
          groupName: 'View',
          columns: 1,
          rowActions: [{
            text: 'Properties',
            iconCls:'ix-v0-16-form_yellow',
            recordSelectCount: 1,
            cb: function(grid, rnaiRecord) {
              grid.rowExpander.openAsWindow(rnaiRecord, rnaiRecord.data.compound_id)    
            }
          }]
        }]        
      }]    
    }))
    ]         
    RNAi.RNAiSearchResults.superclass.initComponent.call(this); 
  },  
  handleSearch: function(values) {  
    var panel= this    
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {    
          panel.contentGrid.getStore().load()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchType: values.searchBy,
        searchResponse: 'RNAi',
        query: values.query,
        dataID: panel.contentGrid.dataID
      }
    });
  }     
}); 

