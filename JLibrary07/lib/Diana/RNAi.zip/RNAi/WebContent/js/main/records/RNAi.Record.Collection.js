/**
 * Creates a data structure for Collection records
 */
RNAi.Record.Collection= Ext.data.Record.create([
{
  name:'collection_id',                     
  type:'integer'
},{
  name:'collection_name'
},{
  name:'collection_desc'
}, {
  name:'created_by'
}, {
  name:'created_by_name'
}, {
  name: 'created', 
  type :'date',
  dateFormat :'m/d/Y h:i:s A'
}, {
  name: 'experiment_count', 
  type :'int'
}, {
  name: 'gene_count', 
  type :'int'
}, {
  name: 'rnai_count', 
  type :'int'
} 
])

RNAi.Record.Collection.prototype.recordType= 'Collection'
