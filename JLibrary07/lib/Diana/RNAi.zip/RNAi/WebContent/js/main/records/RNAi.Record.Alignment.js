/**
 * Creates a data structure for Alignment records
 */
RNAi.Record.Alignment= Ext.data.Record.create([
{
  name:'compound_id'
},{
  name:'rnai_id'
},{
  name:'target_accession'
},{
  name:'hsps'
}                  
])
  
RNAi.Record.Alignment.prototype.recordType= 'Alignment'
