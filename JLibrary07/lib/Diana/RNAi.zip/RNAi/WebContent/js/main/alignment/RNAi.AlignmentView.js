/**
 * @author jemcdowe
 */
RNAi.AlignmentView = Ext.extend(Ext.BoxComponent, {
  initComponent: function() {
    var view= this
    
    Ext.apply(this, {
      autoEl: {
        tag: 'div',
        style: 'padding: 5px'
      }, 
      autoScroll: true
    })
    
    this.addEvents(
            
      /**
        * @event nodeover
        * Fires when an RNAi is moused-over
        * @param {RNAi.AlignmentView} this
        * @param {RNAi.Record} record The alignment record
        * @param {Ext.EventObject} e The raw event object
        */
      "nodeover",
           
      /**
        * @event nodeout
        * Fires when an RNAi is moused-out
        * @param {RNAi.AlignmentView} this
        * @param {RNAi.Record} record The alignment record
        * @param {Ext.EventObject} e The raw event object
        */
      "nodeout",
           
      /**
        * @event nodeclick
        * Fires when an RNAi is click
        * @param {RNAi.AlignmentView} this
        * @param {RNAi.Record} record The alignment record
        * @param {Ext.EventObject} e The raw event object
        */
      "nodeclick")
                
    this.store.on('load', function(){
      view.draw()
    })
        
    this.on('resize', function(panel, adjWidth, adjHeight, rawWidth, rawHeight) {
      if (!view.currWidth || view.currWidth!= adjWidth) {
        view.currWidth= adjWidth
        view.draw()
      }
    })
    
    this.on('render', function() {
      //view.store.loadData(alignData)
      })
    RNAi.AlignmentView.superclass.initComponent.call(this);      
  },
  afterRender : function(){
    var view= this
    RNAi.AlignmentView.superclass.afterRender.call(this);
    this.mon(this.el, {
      "mouseover": this.onMouseOver,
      "mouseout": this.onMouseOut,
      "click": this.onClick,
      scope:this
    });
  },
  onMouseOver: function(evt, t, obj) {
    this.fireNodeEvent("nodeover", evt, t, obj)
  },
  onMouseOut: function(evt, t, obj) {    
    this.fireNodeEvent("nodeout", evt, t, obj)
  }, 
  onClick: function(evt, t, obj) {
    this.fireNodeEvent("nodeclick", evt, t, obj)    
  },
  fireNodeEvent: function(eventName, evt, t, obj) {
    if (this.alignmentEl) {
      var item = evt.getTarget("TR.align-hit-row", this.alignmentEl);
      if (item!= null) {
        var itemEl= Ext.fly(item)
        var recordID= itemEl.getAttribute('record')
        if (recordID && this.store.getById(recordID)) {
          if (eventName== 'nodeover') {
            itemEl.addClass('align-highlight')
          } else if (eventName== 'nodeout') {
            itemEl.removeClass('align-highlight')
          }
          this.fireEvent(eventName, this, this.store.getById(recordID), evt);
        }
      }
    }    
  },
  draw: function() {
    if (this.store.getCount()== 0) {
      this.alignmentEl= Ext.DomHelper.overwrite(this.el, {
        tag: 'table',
        "class": 'align',
        cellpadding: '0',
        cellspacing: '0'
      }, true)
      return
    }
    var targetID= this.store.reader.jsonData.target_id
    var targetLength= this.store.reader.jsonData.target_length
    var alignWidth= this.el.getWidth() - 100   
    var pixelSize= targetLength / alignWidth    
    var scale= Math.pow(10, Math.floor(Math.log(targetLength/10)/Math.log(10)))        
    var targetPixels= [{
      tag: 'th',
      "class":  'align-target-label',
      children: [{
        tag: 'span',
        'class': 'align-label',
        html: targetID          
      }
      ]              
    }]  
  
    var scalePixels= []
    var pixelPos= 0
    var count= 0
    var t= []
    while(pixelPos<= alignWidth) {
      var posStart= (count++) * scale
      pixelPos= posStart / pixelSize
      
      t.push(posStart)
      t.push(pixelPos)
      if (pixelPos> 0 && Math.floor(pixelPos)< alignWidth) {
        scalePixels.push({
          tag: 'div',
          cls: 'align-scale',
          style: 'top:0px;left:'+Math.floor(pixelPos)+"px"
        })
      }
    }
        
    targetPixels.push({
      tag: 'td',
      "class": 'align-target',
      style: 'width:' + alignWidth + 'px !important',
      children: {
        tag: 'div',
        style: 'position:relative;height:20;left:+0px;top:+0px;width:100%;background-color:transparent',
        children: scalePixels
      }
    })
    
    
    
    var table= {
      tag: 'table',
      "class": 'align',
      cellpadding: '0',
      cellspacing: '0',
      children: [{
        tag: 'tr',
        children: targetPixels
      }]
    }    
    this.store.each(function(record, index, length) {
      var isFirst= (index== 0)
      var isLast= (index== (length -1))
      var hitPixels= [{
        tag: 'th',
        children: [{
          tag: 'span',
          'class': 'align-label',
          html: record.data.compound_id           
        }
        ]        
      }]
    
      var borderCss= (isLast ? ' align-last ' : '') + (isFirst ? ' align-top ' : '')
    
      hitPixels.push({
        tag: 'td',
        "class": "align-hit-bk " + borderCss,
        style: 'width:' + alignWidth + 'px'        
      })
      var alignCell= hitPixels[hitPixels.length-1]

      var hsps= record.data.hsps
      for(var k=0; k< hsps.length; k++) {
        if (!Ext.isArray(alignCell.children)) {
          alignCell.children= []
        }
        var qStart= hsps[k].qStart
        var qEnd= hsps[k].qEnd          
        var qStartScaled= Math.ceil(qStart / pixelSize)
        var qEndScaled= Math.ceil(qEnd / pixelSize)          
        var width= qEndScaled - qStartScaled
          
        var div= {
          tag: 'div',
          cls: 'align-hit',
          style: 'width:'+width+'px;left:'+qStartScaled+"px;"
        }  
        alignCell.children.push(div)
        
      /*
        for(var i=1; i<=10; i++) {    
          var lineLeft= Math.ceil(i * (alignWidth/10))
          var divLine= {
            tag: 'div',
            cls: 'align-vline',
            style: 'width:'+1+'px;left:'+lineLeft+"px;",
            html: '1'
          }  
          alignCell.children.push(divLine)
        }
        */
      }      
      
      var hitRow= {
        tag: 'tr',
        "class": "align-hit-row",
        record: record.id,
        children: hitPixels
      }   
      table.children.push(hitRow)      
    }, this)    
    var child= {
      tag: 'div',
      style: 'border-right: 1px solid black;border-left: 1px solid black;border-top: 1px solid black',
      children: [table]
    }
    this.alignmentEl= Ext.DomHelper.overwrite(this.el, child, true)
  }
});




var t= 
{
  "hits":[{
    "rnai_id":"702346",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2918,
      "qEnd":2938
    }],
    "compound_id":"1964322#2"
  },{
    "rnai_id":"702613",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":3305,
      "qEnd":3325
    }],
    "compound_id":"1971298#3"
  },{
    "rnai_id":"694211",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2542,
      "qEnd":2562
    }],
    "compound_id":"1957172#1"
  },{
    "rnai_id":"550044",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":463,
      "qEnd":483
    }],
    "compound_id":"2363460#1"
  },{
    "rnai_id":"550045",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":1898,
      "qEnd":1918
    }],
    "compound_id":"2363462#1"
  },{
    "rnai_id":"550046",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":3094,
      "qEnd":3114
    }],
    "compound_id":"2363463#1"
  },{
    "rnai_id":"547556",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":1252,
      "qEnd":1272
    }],
    "compound_id":"1978290#1"
  },{
    "rnai_id":"550357",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2542,
      "qEnd":2562
    }],
    "compound_id":"1957172#2"
  },{
    "rnai_id":"551405",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":3305,
      "qEnd":3325
    }],
    "compound_id":"1971298#2"
  },{
    "rnai_id":"561674",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2930,
      "qEnd":2950
    }],
    "compound_id":"2576364#1"
  },{
    "rnai_id":"582174",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":420,
      "qEnd":438
    }],
    "compound_id":"2011517#2"
  },{
    "rnai_id":"585103",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":3195,
      "qEnd":3213
    }],
    "compound_id":"2011516#1"
  },{
    "rnai_id":"585104",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":420,
      "qEnd":438
    }],
    "compound_id":"2011517#1"
  },{
    "rnai_id":"585106",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":2934,
      "qEnd":2952
    }],
    "compound_id":"2011519#1"
  },{
    "rnai_id":"589894",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":2934,
      "qEnd":2952
    }],
    "compound_id":"2011519#2"
  },{
    "rnai_id":"595743",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":3305,
      "qEnd":3325
    }],
    "compound_id":"1971298#1"
  },{
    "rnai_id":"611939",
    "hsps":[{
      "sEnd":19,
      "sStart":1,
      "qStart":3195,
      "qEnd":3213
    }],
    "compound_id":"2011516#2"
  },{
    "rnai_id":"625091",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2918,
      "qEnd":2938
    }],
    "compound_id":"1964322#1"
  },{
    "rnai_id":"691366",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":1454,
      "qEnd":1474
    }],
    "compound_id":"2363461#1"
  },{
    "rnai_id":"690909",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":1252,
      "qEnd":1272
    }],
    "compound_id":"1978290#2"
  },{
    "rnai_id":"708883",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":1252,
      "qEnd":1272
    }],
    "compound_id":"1978290#3"
  },{
    "rnai_id":"707605",
    "hsps":[{
      "sEnd":21,
      "sStart":1,
      "qStart":2542,
      "qEnd":2562
    }],
    "compound_id":"1957172#3"
  }],
  "rnai":[{
    "alignment":{
      "rnai_id":"702346",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2918,
        "qEnd":2938
      }],
      "compound_id":"1964322#2"
    },
    "gene_symbol":"RET",
    "rnai_id":702346,
    "vendor":"Qiagen",
    "root_number":1964322,
    "substance_id":3357276,
    "gene_id":509542,
    "vendor_id":"Hs_RET_5",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"CAGGGTCGGATTCCAGTTAAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"702613",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":3305,
        "qEnd":3325
      }],
      "compound_id":"1971298#3"
    },
    "gene_symbol":"RET",
    "rnai_id":702613,
    "vendor":"Qiagen",
    "root_number":1971298,
    "substance_id":3357278,
    "gene_id":509542,
    "vendor_id":"Hs_RET_9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":3,
    "sequence":"CCGCTGGTGGACTGTAATAAT",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"694211",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2542,
        "qEnd":2562
      }],
      "compound_id":"1957172#1"
    },
    "gene_symbol":"RET",
    "rnai_id":694211,
    "vendor":"Qiagen",
    "root_number":1957172,
    "substance_id":2545848,
    "gene_id":509542,
    "vendor_id":"DG2_84B_KIN_4B-C9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CCCACATGTCATCAAATTGTA",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":550040,
    "sequence":"NNAGAUGAAGAUUUCGGAUUU",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2363456,
    "substance_id":2981495,
    "vendor_id":"RET_1",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":550041,
    "sequence":"NNGAACACUGGCCCAACGAGA",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2363457,
    "substance_id":2981496,
    "vendor_id":"RET_2",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":550042,
    "sequence":"NNGGCCGGUGUUUGCGGACAU",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2363458,
    "substance_id":2981497,
    "vendor_id":"RET_3",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":550043,
    "sequence":"NNCAUAUCUACACCACGCAAA",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2363459,
    "substance_id":2981498,
    "vendor_id":"RET_4",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"550044",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":463,
        "qEnd":483
      }],
      "compound_id":"2363460#1"
    },
    "gene_symbol":"RET",
    "rnai_id":550044,
    "vendor":"Qiagen",
    "root_number":2363460,
    "substance_id":2981499,
    "gene_id":509542,
    "vendor_id":"RET_1",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CACCGGCCTCCTCTACCTTAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"550045",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":1898,
        "qEnd":1918
      }],
      "compound_id":"2363462#1"
    },
    "gene_symbol":"RET",
    "rnai_id":550045,
    "vendor":"Qiagen",
    "root_number":2363462,
    "substance_id":2981501,
    "gene_id":509542,
    "vendor_id":"RET_3",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"TGCGATGTTGTGGAGACCCAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"550046",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":3094,
        "qEnd":3114
      }],
      "compound_id":"2363463#1"
    },
    "gene_symbol":"RET",
    "rnai_id":550046,
    "vendor":"Qiagen",
    "root_number":2363463,
    "substance_id":2981502,
    "gene_id":509542,
    "vendor_id":"RET_4",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CCGGATGGAGAGGCCAGACAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"547556",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":1252,
        "qEnd":1272
      }],
      "compound_id":"1978290#1"
    },
    "gene_symbol":"RET",
    "rnai_id":547556,
    "vendor":"Qiagen",
    "root_number":1978290,
    "substance_id":2566977,
    "gene_id":509542,
    "vendor_id":"DG2_84D_KIN_4D-C9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"TAGGCTGGTTCTCAACCGGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"550357",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2542,
        "qEnd":2562
      }],
      "compound_id":"1957172#2"
    },
    "gene_symbol":"RET",
    "rnai_id":550357,
    "vendor":"Qiagen",
    "root_number":1957172,
    "substance_id":3134727,
    "gene_id":509542,
    "vendor_id":"Hs_RET_11",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"CCCACATGTCATCAAATTGTA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"551405",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":3305,
        "qEnd":3325
      }],
      "compound_id":"1971298#2"
    },
    "gene_symbol":"RET",
    "rnai_id":551405,
    "vendor":"Qiagen",
    "root_number":1971298,
    "substance_id":3134746,
    "gene_id":509542,
    "vendor_id":"Hs_RET_9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"CCGCTGGTGGACTGTAATAAT",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":552396,
    "sequence":"TAGGGCTTGTACTCACTTTAA",
    "vendor":"Qiagen",
    "gene_name":"ret proto-oncogene",
    "root_number":2424907,
    "substance_id":3134835,
    "vendor_id":"Hs_RET_6",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":555094,
    "sequence":"GGAUUGAAAACAAACUCUATT",
    "vendor":"Ambion",
    "gene_name":"ret proto-oncogene",
    "root_number":2573936,
    "substance_id":3292205,
    "vendor_id":"CPF00Q45:E5",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"561674",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2930,
        "qEnd":2950
      }],
      "compound_id":"2576364#1"
    },
    "gene_symbol":"RET",
    "rnai_id":561674,
    "vendor":"Sigma",
    "root_number":2576364,
    "substance_id":3294774,
    "gene_id":509542,
    "vendor_id":"Human Kinase Plate 19:F4",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CCAGUUAAAUGGAUGGCAATT",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":576266,
    "sequence":"GCAUCAACGUCCAGUACAATT",
    "vendor":"Sigma",
    "gene_name":"ret proto-oncogene",
    "root_number":2576505,
    "substance_id":3294934,
    "vendor_id":"Human Kinase Plate 21:F4",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"582174",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":420,
        "qEnd":438
      }],
      "compound_id":"2011517#2"
    },
    "gene_symbol":"RET",
    "rnai_id":582174,
    "vendor":"Dharmacon",
    "root_number":2011517,
    "substance_id":2751007,
    "gene_id":509542,
    "vendor_id":"D-003170-06",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"GCACACGGCUGCAUGAGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"585103",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":3195,
        "qEnd":3213
      }],
      "compound_id":"2011516#1"
    },
    "gene_symbol":"RET",
    "rnai_id":585103,
    "vendor":"Dharmacon",
    "root_number":2011516,
    "substance_id":2602773,
    "gene_id":509542,
    "vendor_id":"D-003170-05",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"GCAAAGACCUGGAGAAGAU",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"585104",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":420,
        "qEnd":438
      }],
      "compound_id":"2011517#1"
    },
    "gene_symbol":"RET",
    "rnai_id":585104,
    "vendor":"Dharmacon",
    "root_number":2011517,
    "substance_id":2602774,
    "gene_id":509542,
    "vendor_id":"D-003170-06",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"GCACACGGCUGCAUGAGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":585105,
    "sequence":"GAACUGGCCUGGAGAGAGU",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2011518,
    "substance_id":2602775,
    "vendor_id":"D-003170-07",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"585106",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":2934,
        "qEnd":2952
      }],
      "compound_id":"2011519#1"
    },
    "gene_symbol":"RET",
    "rnai_id":585106,
    "vendor":"Dharmacon",
    "root_number":2011519,
    "substance_id":2602776,
    "gene_id":509542,
    "vendor_id":"D-003170-08",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"UUAAAUGGAUGGCAAUUGA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"589894",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":2934,
        "qEnd":2952
      }],
      "compound_id":"2011519#2"
    },
    "gene_symbol":"RET",
    "rnai_id":589894,
    "vendor":"Dharmacon",
    "root_number":2011519,
    "substance_id":2751009,
    "gene_id":509542,
    "vendor_id":"D-003170-08",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"UUAAAUGGAUGGCAAUUGA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"595743",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":3305,
        "qEnd":3325
      }],
      "compound_id":"1971298#1"
    },
    "gene_symbol":"RET",
    "rnai_id":595743,
    "vendor":"Qiagen",
    "root_number":1971298,
    "substance_id":2559985,
    "gene_id":509542,
    "vendor_id":"DG2_84C_KIN_4C-C9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CCGCTGGTGGACTGTAATAAT",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":588473,
    "sequence":"CCACUGCUACCACAAGUUUTT",
    "vendor":"Ambion",
    "gene_name":"ret proto-oncogene",
    "root_number":2574641,
    "substance_id":3292915,
    "vendor_id":"CPF00Q4E:E5",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":613343,
    "sequence":"GCGUAUACUUCUCCUUCUUTT",
    "vendor":"Sigma",
    "gene_name":"ret proto-oncogene",
    "root_number":2576434,
    "substance_id":3294854,
    "vendor_id":"Human Kinase Plate 20:F4",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"611939",
      "hsps":[{
        "sEnd":19,
        "sStart":1,
        "qStart":3195,
        "qEnd":3213
      }],
      "compound_id":"2011516#2"
    },
    "gene_symbol":"RET",
    "rnai_id":611939,
    "vendor":"Dharmacon",
    "root_number":2011516,
    "substance_id":2751006,
    "gene_id":509542,
    "vendor_id":"D-003170-05",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"GCAAAGACCUGGAGAAGAU",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"625091",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2918,
        "qEnd":2938
      }],
      "compound_id":"1964322#1"
    },
    "gene_symbol":"RET",
    "rnai_id":625091,
    "vendor":"Qiagen",
    "root_number":1964322,
    "substance_id":2553009,
    "gene_id":509542,
    "vendor_id":"DG2_84A_KIN_4A-C9",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"CAGGGTCGGATTCCAGTTAAA",
    "gene_name":"ret proto-oncogene"
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "gene_symbol":"RET",
    "rnai_id":625614,
    "sequence":"GAACUGGCCUGGAGAGAGU",
    "vendor":"Dharmacon",
    "gene_name":"ret proto-oncogene",
    "root_number":2011518,
    "substance_id":2751008,
    "vendor_id":"D-003170-07",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "gene_symbol":"RET",
    "rnai_id":651020,
    "sequence":"GCUUGUCCCGAGAUGUUUATT",
    "vendor":"Ambion",
    "gene_name":"ret proto-oncogene",
    "root_number":2573226,
    "substance_id":3291495,
    "vendor_id":"CPF00Q3W:E5",
    "gene_id":509542,
    "entrezgene_id":5979
  },{
    "alignment":{
      "rnai_id":"691366",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":1454,
        "qEnd":1474
      }],
      "compound_id":"2363461#1"
    },
    "gene_symbol":"RET",
    "rnai_id":691366,
    "vendor":"Qiagen",
    "root_number":2363461,
    "substance_id":2981500,
    "gene_id":509542,
    "vendor_id":"RET_2",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":1,
    "sequence":"ATCGGGAAAGTCTGTGTGGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"690909",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":1252,
        "qEnd":1272
      }],
      "compound_id":"1978290#2"
    },
    "gene_symbol":"RET",
    "rnai_id":690909,
    "vendor":"Qiagen",
    "root_number":1978290,
    "substance_id":3134834,
    "gene_id":509542,
    "vendor_id":"Hs_RET_10",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":2,
    "sequence":"TAGGCTGGTTCTCAACCGGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"708883",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":1252,
        "qEnd":1272
      }],
      "compound_id":"1978290#3"
    },
    "gene_symbol":"RET",
    "rnai_id":708883,
    "vendor":"Qiagen",
    "root_number":1978290,
    "substance_id":3357279,
    "gene_id":509542,
    "vendor_id":"Hs_RET_10",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":3,
    "sequence":"TAGGCTGGTTCTCAACCGGAA",
    "gene_name":"ret proto-oncogene"
  },{
    "alignment":{
      "rnai_id":"707605",
      "hsps":[{
        "sEnd":21,
        "sStart":1,
        "qStart":2542,
        "qEnd":2562
      }],
      "compound_id":"1957172#3"
    },
    "gene_symbol":"RET",
    "rnai_id":707605,
    "vendor":"Qiagen",
    "root_number":1957172,
    "substance_id":3357277,
    "gene_id":509542,
    "vendor_id":"Hs_RET_11",
    "entrezgene_id":5979,
    "gene_record":{
      "gene_symbol":"RET",
      "organism_id":9606,
      "alias":"PTC,MTC1,HSCR1,MEN2A,MEN2B,RET51,CDHF12,CDHR16,RET-ELE1",
      "description":"This gene, a member of the cadherin superfamily, encodes one of the receptor tyrosine kinases, which are cell-surface molecules that transduce signals for cell growth and differentiation. This gene plays a crucial role in neural crest development, and it can undergo oncogenic activation in vivo and in vitro by cytogenetic rearrangement. Mutations in this gene are associated with the disorders multiple endocrine neoplasia, type IIA, multiple endocrine neoplasia, type IIB, Hirschsprung disease, and medullary thyroid carcinoma. Two transcript variants encoding different isoforms have been found for this gene. Additional transcript variants have been described but their biological validity has not been confirmed. [provided by RefSeq, Jul 2008]",
      "gene_name":"ret proto-oncogene",
      "gene_id":509542,
      "gene_type":"Protein-Coding",
      "entrezgene_id":5979,
      "organism":"Homo sapiens"
    },
    "lot_number":3,
    "sequence":"CCCACATGTCATCAAATTGTA",
    "gene_name":"ret proto-oncogene"
  }],
  "target_length":4174,
  "target_id":"NM_020630.4"
}
