/**
 * Defines an RNAi Person record
 * 
 * $Author: jemcdowe $
 * $GlobalRev$
 * 
 */
RNAi.Record.Person= Ext.data.Record.create([{
  name: 'person_id',
  type: 'int'
},
'amgen_login',
'first_name',
'last_name',
'ledger_name',
'email',
'location_code', {
  name:  'is_administrator',
  type: 'boolean',
  defaultValue: false
}
])
  
RNAi.Record.Person.prototype.recordType= 'Person'
