/**
 * Creates a plate visualization
 */
RNAi.Labware.RNAIPlateViewUI = Ext.extend(Ext.Panel, {
  layout: 'border',
  border: false,
  initComponent: function() {
    var panel= this
    panel.baseURL= '/RNAi/rnai.go?req=amgen.ri.rnai.search.PlateMapResponder'
    this.items = [
    (this.plateMapUI= new RNAi.Labware.PlateMap({              
      region: 'center',        
      height: 420,
      split: true,
      collapsible: true,
      header :false,
      collapseMode :'mini',      
      barcode: panel.barcode,
      plateUrl: panel.baseURL,
      parent: this
    })),
    (this.plateGridView= new RNAi.RNAiSearchResults({      
      query: {
        query: panel.barcode, 
        searchBy: 'BARCODES'
      },
      region: 'south',
      hideCollapseTool: true,
      parent: this, 
      height: 200, 
      split: true, 
      collapseMode: 'mini', 
      collapsible: true
    }))
    ]
    RNAi.Labware.RNAIPlateViewUI.superclass.initComponent.call(this);
  },
  plateWellSelectionHandler: function(obj) {
    if (Ext.isObject(obj) && Ext.isObject(obj.well)) {
      this.plateGridView.selectById(obj.well.rnai_id)
    }    
  }
}
)
