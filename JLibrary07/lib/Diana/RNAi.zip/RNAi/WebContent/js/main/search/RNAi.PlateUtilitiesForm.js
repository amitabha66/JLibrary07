

RNAi.PlateUtilitiesForm = Ext.extend(Ext.form.FormPanel, {    
  initComponent: function() {
    var formPanel= this
    Ext.apply(this, {      
      padding: 10,
      labelWidth: 75,
      frame: true,
      autoScroll: true
    })
    
    this.items= []
    //---------------------------------------------------------
    //Add the Gene & RNAi Search form and handlers
    this.items.push({
      xtype: 'fieldset',
      title: 'Search Plates Parentage',
      items: [{        
        xtype: 'compositefield',
        fieldLabel: 'Search By',
        anchor: '100%',
        layoutConfig: {
          align: 'stretch'
        },
        items: [(this.barcodesField= new Ext.form.TextArea({
          flex: 1,
          height: 150,          
          name: 'barcodes'
        //,value: '1500086740'
        }))
        ]
      }]
    })
    
    var buttons= []
    buttons.push(new Ext.Button({
      text: 'Lookup Plate Lineage',
      iconCls: "ix-v0-16-view", 
      handler: this.getPlateLineage.createDelegate(this)
    }))
    
    buttons.push([{        
      xtype: 'compositefield',     
      hideLabel: true,
      items: [new Ext.Button({
        text: 'Compare To Collection',
        iconCls: "ix-v0-16-view", 
        handler: this.compareToCollection.createDelegate(this)
      }), this.collectionCombo= new Ext.form.ComboBox({        
        width: 300,
        name: 'collection',
        mode: 'local',
        triggerAction: 'all',
        forceSelection: true,
        editable: false,  
        lazyInit: false,
        hiddenName: 'collection',
        valueField: 'collection_id',
        displayField: 'collection_name',   
        emptyText: 'Select Collection',
        store: new Ext.data.Store({
          url: '/RNAi/rnai.go',       
          autoLoad: true,
          reader :new Ext.data.JsonReader({
            idProperty: 'collection_id',
            root :"collection"
          }, RNAi.Record.Collection),
          sortInfo: {
            field: 'collection_name',
            direction: 'ASC' 
          },
          baseParams: {
            req:'amgen.ri.rnai.screener.CollectionResponder',                
            action_id: 'get-collection'              
          }
        })        
      })
      ]
    }])
       
    this.items[this.items.length-1].items.push({
      xtype: 'fieldset',
      border: false,
      defaults:{
        padding:'50 0 0 0'
      },      
      items: buttons
    })    
    RNAi.PlateUtilitiesForm.superclass.initComponent.call(this);
  },
  getBarcodes: function() {
    if (this.barcodesField.getValue().trim().length==0) {
      return []
    }
    return this.barcodesField.getValue().trim().split(/\W+/)
  },
  getCollection: function() { 
    if (this.collectionCombo.selectedIndex< 0) {
      return null
    }
    return this.collectionCombo.view.getSelectedRecords().shift()
  },
  getPlateLineage: function() {
    if (this.getBarcodes().length== 0) {
      showMessageDialog('No barcodes provided')
      return
    }
    new RNAi.TabPanelLoader().loadPlateLineageResults(this.getBarcodes())         
  },
  compareToCollection: function() {
    var barcodes= this.getBarcodes()
    var collectionRecord= this.getCollection()
    if (barcodes.length== 0) {
      showMessageDialog('No barcodes provided')
      return
    }  
    if (!collectionRecord) {
      showMessageDialog('Please select a collection to compare')
      return
    }  
    new RNAi.TabPanelLoader().loadCollectionComparisonResults(collectionRecord, barcodes)  
  }
});
