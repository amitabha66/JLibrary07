
RNAi.PlateSearchResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {           
    this.items=[(this.contentGrid= new RNAi.PlateSummaryGrid({
      region: 'center',
      rowActions: [{
        text: 'Plate Map',
        iconCls:'rg-entity-assay', 
        cb: function(grid, plateRecord) {
          new RNAi.TabPanelLoader().loadPlateMapPanel(plateRecord)

        }
      },{
        text: 'Plate Lineage',
        iconCls:'rg-entity-assay', 
        cb: function(grid, plateRecord, plateRecords) {
          new RNAi.TabPanelLoader().loadPlateLineageResults(RNAi.joinFields(plateRecords, 'barcode', 'array'))

        }
      }]          
    }))
    ]    
    RNAi.RNAiSearchResults.superclass.initComponent.call(this);     
  },  
  handleSearch: function(values) {  
    var panel= this    
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {    
          panel.contentGrid.store.load()   
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchType: values.searchBy,
        searchResponse: 'PLATES',
        query: values.query,
        dataID: panel.contentGrid.dataID
      }
    });
  }   
}); 

