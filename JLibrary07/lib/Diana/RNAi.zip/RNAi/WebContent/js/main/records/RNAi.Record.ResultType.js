RNAi.Record.ResultType= Ext.data.Record.create([
  {
    name:'result_type_id',                     
    type:'integer'
  }, {
    name:'result_type'
  }, {
    name:'result_name'
  }, {
    name:'format'
  }, {
    name:'precision',                     
    type:'integer',
    defaultValue: 5
  } ,{
    name:'view_bydefault',                     
    type:'boolean',
    defaultValue: false
  }             
  ])  
RNAi.Record.ResultType.prototype.recordType= 'ResultType'
  