
RNAi.PlateLineageGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    var grid= this
    Ext.applyIf(this, {
      root: 'plates',
      fields: RNAi.Record.PlateLineage
    })
    this.baseTitle= this.title
    Ext.apply(this, {    
      autoExpandColumn: 'descendants'
    })
    var colDefs= [
    {
      header: 'Plate',
      dataIndex: 'barcode',
      sortable: true,
      width: 100
    }, {
      header: 'Parents',
      dataIndex: 'parents',
      sortable: true,
      width: 120
    }, {
      header: 'Decendants',
      id: 'descendants',
      dataIndex: 'descendants'
    }]
  
    this.colModel= new Ext.grid.ColumnModel({     
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })       
    RNAi.PlateLineageGrid.superclass.initComponent.call(this);  
   
  }
})