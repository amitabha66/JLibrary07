/**
 * Creates a data structure for AnnotationGroup records
 */
RNAi.Record.AnnotationGroup= Ext.data.Record.create([{
  name:'annotation_group_id',                     
  type:'integer'
},{
  name:'annotation_group_name'
}                   
])

  RNAi.Record.AnnotationGroup.prototype.recordType= 'AnnotationGroup'
