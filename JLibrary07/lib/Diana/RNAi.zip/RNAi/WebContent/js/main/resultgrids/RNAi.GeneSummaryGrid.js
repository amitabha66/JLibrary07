RNAi.GeneSummaryGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    Ext.applyIf(this, {
      root: 'genes',
      fields: RNAi.Record.Gene
    })
    this.rowExpander = new RNAi.GeneGridExpander();

    this.plugins = [this.rowExpander]

    var columns = [this.rowExpander]
    if (this.rowActionsPlugin) {
      columns.push(this.rowActionsPlugin)
    }
    if (Ext.isArray(this.columnDefs)) {
      columns = columns.concat(this.columnDefs)
    } else {
      columns.push({
        header: 'Gene',
        dataIndex: 'gene_symbol',
        renderer: this.geneMixtureRenderer.createDelegate(this)
      }, {
        header: 'Name',
        dataIndex: 'gene_name',
        renderer: this.geneMixtureRenderer.createDelegate(this)
      }, {
        header: 'Organism',
        dataIndex: 'organism',
        renderer: this.geneMixtureRenderer.createDelegate(this)
      }, {
        id: 'description',
        header: 'Description',
        dataIndex: 'description',
        css: 'gene_description',
        width: 400,
        renderer: this.geneMixtureRenderer.createDelegate(this)
      }, {
        header: 'Entrez Gene ID',
        dataIndex: 'entrezgene_id',
        renderer: this.geneMixtureRenderer.createDelegate(this)
      })
      if (this.showExpRNAiCount === true) {
        columns.push({
          header: 'Exp RNAi Count',
          dataIndex: 'exp_rnai_count',
          align: 'right',
          width: 100
        })
      } else {
        columns.push({
          header: 'RNAi Count',
          dataIndex: 'rnai_count',
          align: 'right',
          width: 75
        })
      }
      columns.push({
        header: 'Exp Count',
        dataIndex: 'exp_count',
        align: 'right',
        width: 75
      })
    }

    for (var i = 0; i < columns.length; i++) {
      Ext.applyIf(columns[i], {
        renderer: this.defaultRenderer.createDelegate(this)
      })
    }

    this.colModel = new Ext.grid.ColumnModel({
      defaults: {
        width: 100,
        sortable: true
      },
      columns: columns
    })
    RNAi.GeneSummaryGrid.superclass.initComponent.call(this);
  }
})