

// @todo raw results need fixed!!
  
  
RNAi.RawPOCResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {           
    this.items=[(this.contentGrid= new RNAi.RNAISummaryGrid({
      region: 'center',
      root: 'poc',      
      autoExpandColumn: 'sequence',
      disableToolbar: this.disableToolbar,
      showRawResults: true
    }))
    ]         
    RNAi.RawPOCResults.superclass.initComponent.call(this); 
  },  
  handleSearch: function(values) {  
    var panel= this        
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    var geneIDs= []
    var geneMixtureIDs= []
    
    for(var i=0; i< values.geneRecords.length; i++) {
      var geneRecord= values.geneRecords[i]
      if (geneRecord.get('is_mixture')) {
        geneMixtureIDs.push(geneRecord.get('gene_id'))
      } else {
        geneIDs.push(geneRecord.get('gene_id'))        
      }
    }
    
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {    
          panel.contentGrid.getStore().load()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchType: 'EXPERIMENT_GENE_IDS',
        searchResponse: 'RAWRESULTS',
        experiment_ids: RNAi.joinFields(values.expRecords, 'experiment_id', ','),
        gene_ids: (geneIDs.length> 0 ? geneIDs.join(',') : null),
        gene_mixture_ids: (geneMixtureIDs.length> 0 ? geneMixtureIDs.join(',') : null),
        dataID: panel.contentGrid.dataID
      }
    });
  }     
}); 
