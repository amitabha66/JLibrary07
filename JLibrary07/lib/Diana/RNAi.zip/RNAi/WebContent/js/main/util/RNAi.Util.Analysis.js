
RNAi.analysisStore= new Ext.data.Store({
  reader: new Ext.data.JsonReader({
    idProperty: 'analysis_type_id',
    root: 'analysis'
  }, RNAi.Record.Analysis),
  url: '/RNAi/rnai.go',
  baseParams: {
    req: 'amgen.ri.rnai.search.SearchResponder',
    rx: 'analysis_types'
  },
  autoLoad: false
})      
RNAi.analysisStore.load()
    
RNAi.resultTypeStore= new Ext.data.Store({
  reader: new Ext.data.JsonReader({
    idProperty: 'result_type_id',
    root: 'result_types'
  }, RNAi.Record.ResultType),
  url: '/RNAi/rnai.go',
  baseParams: {
    req: 'amgen.ri.rnai.search.SearchResponder',
    rx: 'result_types'
  },
  autoLoad: false
})      
RNAi.resultTypeStore.load()

RNAi.getDefaultAnalysisRecords= function() {
  var defaultAnalysisRecords= []
  RNAi.analysisStore.each(function(r) {
    if (r.data.view_bydefault) {
      defaultAnalysisRecords.push(r)
    }
  })
  return defaultAnalysisRecords
}


RNAi.getDefaultResultTypeRecords= function() {
  var defaultResultTypeRecords= []
  RNAi.resultTypeStore.each(function(r) {
    if (r.data.view_bydefault) {
      defaultResultTypeRecords.push(r)
    }
  })
  return defaultResultTypeRecords
}

    