
RNAi.RNAISummaryGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    var grid = this
    Ext.applyIf(this, {
      root: 'rnai',
      fields: RNAi.Record.RNAi
    })
    this.baseTitle = this.title
    this.rowExpander = new RNAi.RNAiGridExpander()
    Ext.apply(this, {
      autoExpandColumn: 'sequence',
      plugins: [this.rowExpander]
    })
    var colDefs = [
      this.rowExpander, {
        header: 'Compound ID',
        dataIndex: 'compound_id',
        sortable: true,
        width: 100
      }, {
        header: 'Vendor',
        dataIndex: 'vendor',
        sortable: true,
        width: 100
      }, {
        header: 'Vendor Library',
        dataIndex: 'vendor_library_name',
        sortable: true,
        width: 150
      }, {
        header: 'Primary Gene Target',
        dataIndex: 'primary_gene_symbol',
        sortable: true,
        width: 120,
        renderer: function(value, md, record) {
          var isMixture = (record.get('is_mixture') === true || record.get('is_mixture') == 'true')
          if (!isMixture) {
            return value
          }
          var val = []
          if (Ext.isArray(record.get('components'))) {
            for (var i = 0; i < record.get('components').length; i++) {
              if (Ext.isString(record.get('components')[i].primary_gene_symbol) && record.get('components')[i].primary_gene_symbol.length > 0)
                val.push(record.get('components')[i].primary_gene_symbol)
            }
          }
          return '[' + val.join(',') + ']'
        }
      }, {
        header: 'Has Secondary Targets',
        dataIndex: 'has_secondary_targets',
        sortable: true,
        width: 140,
        filterType: 'bool',
        renderer: function(value, md, record) {
          var isMixture = (record.get('is_mixture') === true || record.get('is_mixture') == 'true')
          if (isMixture) {
            return ''
          }
          return (value === true ? 'Yes' : 'No')
        }
      }, {
        id: 'sequence',
        header: 'Sequence',
        dataIndex: 'sequence',
        sortable: true,
        width: 100,
        renderer: function(value, d, record) {
          var isMixture = (record.get('is_mixture') === true || record.get('is_mixture') == 'true')
          if (!isMixture) {
            return value
          }
          return '[Mixture]'
        }
      }, {
        xtype: 'datecolumn',
        header: 'Registered Date',
        dataIndex: 'registered_date',
        sortable: true,
        width: 100
      }]

    if (this.showRawResults === true) {
      var resultColDefs = [{
          header: 'Barcode',
          dataIndex: 'barcode',
          sortable: true,
          width: 100
        }, {
          header: 'Column',
          dataIndex: 'wellcolumn',
          sortable: true,
          width: 100,
          renderer: function(value, metaData, record, rowIndex, colIndex, store) {
            return record.data.wellrow + record.data.wellcolumn
          }
        }, {
          header: 'POC',
          dataIndex: 'poc',
          sortable: true,
          width: 100,
          filterType: 'numeric'
        }]
      colDefs = colDefs.concat(resultColDefs)
    }

    if (this.showPlateWells === true) {
      colDefs.push({
        header: 'Plate Wells',
        dataIndex: 'wells',
        sortable: true,
        width: 100
      })
    }
    if (this.showAlignment === true) {
      colDefs.push({
        header: 'Alignment',
        dataIndex: 'alignment',
        sortable: true,
        width: 200,
        renderer: function(value, md, record, rowIndx, colIndx, store) {
          if (!Ext.isRecord(record) || !Ext.isArray(record.data.alignment.hsps)) {
            return ''
          }
          var alignmentRecord = new RNAi.Record.Alignment(record.data.alignment)
          var alignments = []
          for (var i = 0; i < alignmentRecord.data.hsps.length; i++) {
            var hsp = alignmentRecord.data.hsps[i]
            alignments.push(alignmentRecord.data.target_accession + '(' + hsp.qStart + ".." + hsp.qEnd + ')')
          }
          return alignments.join(',')
        }
      })
    }

    this.colModel = new Ext.grid.ColumnModel({
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })

    RNAi.RNAISummaryGrid.superclass.initComponent.call(this);

  },
  getRNAIRecords: function() {
    if (this.getSelectionModel().getCount() == 0) {
      return this.getStore().getRange()
    } else {
      return this.getSelectionModel().getSelections()
    }
  }
})