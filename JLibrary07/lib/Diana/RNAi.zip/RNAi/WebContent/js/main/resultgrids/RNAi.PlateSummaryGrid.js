
RNAi.PlateSummaryGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    var grid= this
    Ext.applyIf(this, {
      root: 'plates',
      fields: RNAi.Record.PlateInfo
    })
    this.baseTitle= this.title    
    Ext.apply(this, {    
      autoExpandColumn: 'layout'
    })
    var colDefs= [
    {
      header: 'Barcode',
      dataIndex: 'barcode',
      sortable: true,
      width: 150
    }, {
      header: 'Site',
      dataIndex: 'site',
      sortable: true
    }, {
      header: 'Density',
      dataIndex: 'density',
      sortable: true
    }, {
      header: 'Type',
      dataIndex: 'type',
      sortable: true,
      width: 200
    }, {
      id: 'layout',
      header: 'Layout',
      dataIndex: 'layout',
      sortable: true,
      width: 200
    }]
     
    this.colModel= new Ext.grid.ColumnModel({     
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })      
    
    RNAi.PlateSummaryGrid.superclass.initComponent.call(this);        
  }
})