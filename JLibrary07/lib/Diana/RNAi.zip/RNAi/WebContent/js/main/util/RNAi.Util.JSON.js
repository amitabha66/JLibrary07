/* 
 * Any JSON utilities
 */

RNAi.decode= function(s, defaultValue) {
  try {
    if (Ext.isObject(s) && Ext.isString(s.responseText)) {
      return Ext.decode(s.responseText)      
    }
    return Ext.decode(s)
  } catch(e) {}
  return defaultValue
}

