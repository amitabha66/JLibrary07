/**
 * Creates a data structure for Chart records
 */
RNAi.Record.Chart= Ext.data.Record.create([
{
  name:'chart_id',                     
  type:'integer'
}, 
'name',
'description', 
{
  name:'target_record_type'
}, {
  name:'record_select_count',
  type: 'integer'
}, {
  name:'record_select_count_comparison',
  defaultValue: 'exact'
}, {
  name:'url',
  defaultValue: 'exact'
}, {
  name:'config_block'
}, {
  name: 'params'
}
])
Ext.apply(RNAi.Record.Chart.prototype, {
  recordType: 'Chart', 
  createSFURL: function(params) {      
    var url= this.get('url')
    var configBlock= this.get('config_block') || ''
    var pNames= this.get('params').split(",")    
    for(var i=0; i< pNames.length; i++) {
      var pName= pNames[i]
      if (params[pName]) {
        configBlock= configBlock + pName + '="' + params[pName] + '";'
      }
    }
    return url+"&configurationBlock="+ encodeURI(configBlock)
  }
})
