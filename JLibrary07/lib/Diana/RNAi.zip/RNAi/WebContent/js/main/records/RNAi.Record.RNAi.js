/**
 * Creates a data structure for RNAi records
 */
RNAi.Record.RNAi = Ext.data.Record.create([
  {
    name: 'rnai_id',
    type: 'integer'
  }, {
    name: 'root_number',
    type: 'integer'
  }, {
    name: 'lot_number',
    type: 'integer'
  }, {
    name: 'substance_id',
    type: 'integer'
  }, {
    name: 'compound_id'
  }, {
    name: 'type'
  }, {
    name: 'is_mixture',
    type: 'boolean',
    defaultValue: 'false'
  }, {
    name: 'components'
  }, {
    name: 'primary_gene_id',
    type: 'integer'
  }, {
    name: 'primary_entrezgene_id',
    type: 'integer'
  }, {
    name: 'primary_gene_symbol'
  }, {
    name: 'primary_gene_name'
  }, {
    name: 'primary_gene_description'
  }, {
    name: 'primary_gene_organism'
  }, {
    name: 'vendor_gene_id',
    type: 'integer'
  }, {
    name: 'vendor_entrezgene_id',
    type: 'integer'
  }, {
    name: 'vendor_gene_symbol'
  }, {
    name: 'vendor_gene_name'
  }, {
    name: 'vendor_gene_description'
  }, {
    name: 'vendor_gene_organism'
  }, {
    name: 'has_secondary_targets',
    type: 'boolean',
    defaultValue: 'false'
  }, {
    name: 'other_on_target'
  }, {
    name: 'vendor'
  }, {
    name: 'vendor_id'
  }, {
    name: 'vendor_product_id'
  }, {
    name: 'vendor_product_name'
  }, {
    name: 'vendor_library_name'
  }, {
    name: 'sequence'
  }, {
    name: 'registered_date',
    type: 'date',
    dateFormat: 'm/d/Y h:i:s A'
  }, {
    name: 'secondary_gene_targets'
  },
  {
    name: 'barcodes'
  }, {
    name: 'barcode'
  }, {
    name: 'well_id',
    type: 'float'
  }, {
    name: 'wellcolumn',
    type: 'integer'
  }, {
    name: 'wellrow'
  }, {
    name: 'poc',
    type: 'float'
  }, {
    name: 'barcodes'
  }, {
    name: 'wells'
  }, {
    name: 'alignment' //this is an optionally alignment
  }
])

RNAi.Record.RNAi.prototype.recordType = 'RNAi'
