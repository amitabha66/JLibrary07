/**
 * Creates a data structure for RNAi records
 */
RNAi.Record.ScreenerExperiment= Ext.data.Record.create([
{
    name:'experiment_id'
},
{
    name:'assay_code'
},
{
    name:'qc_session_name'
},
{
    name:'layer_name'
},
{
    name:'qc_owner'
},
{
    name:'qc_date'
},
{
    name:'upload_date'
}             
])

RNAi.Record.ScreenerExperiment.prototype.recordType= 'ScreenerExperiment'
