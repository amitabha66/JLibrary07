/**
 * @author jemcdowe
 */
RNAi.Clipboard = function() {
  var copyText = function(text, cb, scope) {
    if (!text) {
      cb.call(scope, true)
      return false;
    }
    if (window.clipboardData) { // Internet Explorer
      try {
        window.clipboardData.setData("Text", text);
        cb.call(scope, true)
        return true;
      } catch (e) {
        cb.call(scope, 'Your IE browser currently does not support copying to the clipboard.')
        return false
      }
    } else if (navigator.userAgent.match(/ Gecko\//)) {
      var tempiframe = document.createElement("iframe");
      tempiframe.width = '1'
      tempiframe.height = '1'
      tempiframe.frameborder = '0'
      tempiframe.scrolling = 'no'
      tempiframe.className = 'x-hidden';

      var parent = document.body;
      var myiframe = parent.appendChild(tempiframe);

      // Mozilla needs time to recognize iframe. We'll do the
      // rest in this function after a short timeout.
      function finish_copy_text_to_clipboard() {
        myiframe.contentDocument.designMode = "on"; // Use Midas editor.
        myiframe.contentDocument.body.innerHTML = "<pre>" + text + "</pre>";

        var sel = myiframe.contentWindow.getSelection();
        sel.removeAllRanges();
        myiframe.contentWindow.focus();
        var range;
        if (typeof sel != "undefined") {
          try {
            range = sel.getRangeAt(0);
          } catch (e) {
            range = myiframe.contentDocument.createRange();
          }
        } else {
          range = myiframe.contentDocument.createRange();
        }

        range.selectNodeContents(myiframe.contentDocument.body);
        sel.addRange(range);

        try {
          myiframe.contentDocument.execCommand('copy', null, null); // copy data to clipboard
        } catch (e) {
          parent.removeChild(myiframe); // the temp iframe is no longer needed
          cb.call(scope, false, UPDATE_ALERT_MSG)
          return false
        }

        parent.removeChild(myiframe); // the temp iframe is no longer needed
        cb.call(scope, true)
        return true;
      }
      ;
      setTimeout(finish_copy_text_to_clipboard, 100); // Mozilla needs time to recognize iframe.
      return true; // This might not be true, because the timeout function may screw up!
    } else {
      cb.call(scope, false, "Your browser currently does not support copying to the clipboard. Please upgrade to the latest version of Mozilla FireFox or Internet Explorer")
      return false
    }
    return false;
  }
  var getPasteText = function(cb, scope) {
    if (window.clipboardData) { // Internet Explorer
      try {
        var text = window.clipboardData.getData("Text");
        cb.call(scope, true, text)
        return true;
      } catch (e) {
        cb.call(scope, false)
        return false
      }
    } else if (navigator.userAgent.match(/ Gecko\//)) {
      var tempiframe = document.createElement("iframe");
      tempiframe.width = '1'
      tempiframe.height = '1'
      tempiframe.frameborder = '0'
      tempiframe.scrolling = 'no'
      tempiframe.className = 'x-hidden';

      var parent = document.body;
      var myiframe = parent.appendChild(tempiframe);

      // Mozilla needs time to recognize iframe. We'll do the
      // rest in this function after a short timeout.
      function finish_paste_text_from_clipboard() {
        myiframe.contentDocument.designMode = "on"; // Use Midas editor.
        var clipboardText = null
        myiframe.contentDocument.body.innerHTML = "";
        var sel = myiframe.contentWindow.getSelection();
        sel.removeAllRanges();
        myiframe.contentWindow.focus();
        var range;
        if (typeof sel != "undefined") {
          try {
            range = sel.getRangeAt(0);
          } catch (e) {
            range = myiframe.contentDocument.createRange()
          }
        } else {
          range = myiframe.contentDocument.createRange()
        }
        range.selectNodeContents(myiframe.contentDocument.body)
        sel.addRange(range)
        try {
          myiframe.contentDocument.execCommand('paste', null, null); // paste data to the <PRE> tag
          clipboardText = myiframe.contentDocument.body.textContent
        } catch (e) {
          parent.removeChild(myiframe); // the temp iframe is no longer needed
          cb.call(scope, false)
          return false
        }
        parent.removeChild(myiframe); // the temp iframe is no longer needed
        cb.call(scope, true, clipboardText)
        return true;
      }
      ;
      setTimeout(finish_paste_text_from_clipboard, 100); // Mozilla needs time to recognize iframe.
      return true; // This might not be true, because the timeout function may screw up!
    } else {
      cb.call(scope, false, "Your browser currently does not support copying to the clipboard. Please upgrade to the latest version of Mozilla FireFox or Internet Explorer")
      return false
    }
    return false;
  }

  this.systemHasClipboardAccess = null

  return {
    setClipboardAccess: function() {
      this.systemHasClipboardAccess = false
      getPasteText(function(success, text) {
        try {
          copyText("Amgen", function(success, msg) {
            if (success === true) {
              this.systemHasClipboardAccess = true
              if (text) {
                copyText(text, Ext.emptyFn)
              }
            }
          }, this)
        } catch (e) {
        }
      }, this)

    },
    setClipboardText: function(text) {      
      if (!this.hasClipboardAccess()) {
        return
      }
      try {
        copyText(text, function(success, msg) {
          if (success === false) {
            showErrorDialog('Clipboard Access Error', msg)
          }
        }, this)
      } catch (e) {
      }
    },
    getClipboardText: function(text, cb, scope) {      
      if (!this.hasClipboardAccess()) {
        return
      }
      try {
        getPasteText(text, cb, scope)
      } catch (e) {
      }
    },
    hasClipboardAccess: function() {
      if (this.systemHasClipboardAccess == null) {
        this.setClipboardAccess()
      }
      return this.systemHasClipboardAccess
    }
  }


}();
