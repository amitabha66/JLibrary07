


RNAi.AnnotationParameterAdd = Ext.extend(Ext.form.FormPanel, {
 
  // defaults - can be changed from outside
    
  border:false
  ,
  frame:true
  ,
  labelWidth:80
  ,
  url:'/RNAi/rnai.go'
  ,
  buttonAlign: 'center',
  initComponent:function() {
    // configure ourselves
    // hard coded config - cannot be changed from outside
    var config = {
      defaultType:'textfield'
      ,
      defaults:{
        anchor:'-24'
      }
      ,
      monitorValid:true
      //          ,buttonAlign:'right'
      ,
      items:[{
        name:'annotation_name'
        ,
        fieldLabel:'Annotation Name'
      },{
        name:'rnai_type_id'
        ,
        fieldLabel:'RNAi Type'
        ,
        allowBlank:false
        ,
        xtype:'combo'
        ,
        triggerAction:'all'
        ,
        mode:'local'
        ,
        editable:false
        ,
        store:new Ext.data.SimpleStore({
          fields:['rnai_type_id', 'rnai_type_name']
          ,
          data:[['1', 'SIRNA'], ['2', 'SHRNA']]
        })
        ,
        displayField:'rnai_type_name'
        ,
        valueField:'rnai_type_id'
        ,
        hiddenName:'rnai_type_id'
      },{
        name:'annotation_type'
        ,
        fieldLabel:'Annotation Type'
        ,
        allowBlank:false
        ,
        xtype:'combo'
        ,
        triggerAction:'all'
        ,
        mode:'local'
        ,
        editable:false
        ,
        store:new Ext.data.SimpleStore({
          fields:['annotation_type_id', 'annotation_type_name']
          ,
          data:[['TEXT', 'TEXT'], ['INTEGER', 'INTEGER']]
        })
        ,
        displayField:'annotation_type_name'
        ,
        valueField:'annotation_type_id'
        ,
        hiddenName:'annotation_type'
      },new Ext.form.ComboBox({                       
        fieldLabel: 'Annotation Group',
        hiddenName:'annotation_group_id',                
        store: new Ext.data.Store({
          url: '/RNAi/rnai.go',     
          autoLoad: true,
          baseParams:{
            req:'amgen.ri.rnai.screener.AnnotationResponder',                
            action_id: 'get-annotation-group'
          },
          reader :new Ext.data.JsonReader({
            root :"annotation_group",
            idProperty: "annotation_group_id"
          }, RNAi.Record.AnnotationGroup)
        }),
        valueField:'annotation_group_id',
        displayField:'annotation_group_name',
        triggerAction: 'all',
        emptyText:'Select annotation group',
        selectOnFocus:true,
        editable: false                       
      }), {
        xtype: 'numberfield',
        fieldLabel: 'Display Order',
        name: 'display_order',
        width: 25
      },{
        name:'annotation_option_name'
        ,
        fieldLabel:'Annotation Options Name'
        ,
        xtype:'textarea'
      },{
        name:'annotation_option_desc'
        ,
        fieldLabel:'Annotation Options Description'
        ,
        xtype:'textarea'
      },{
        name:'annotation_default_value'
        ,
        fieldLabel:'Annotation Default Value'
      }
      ]
      ,
      buttons:[{
        text:'Submit'
        //,formBind:true
        ,
        scope:this
        ,
        handler:this.submit
      }]
    }; // eo config object
 
    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
 
    // call parent
    RNAi.AnnotationParameterAdd.superclass.initComponent.apply(this, arguments);
 
  } // eo function initComponent
    
  /**
     * Form onRender override
     */
  ,
  onRender:function() {
 
    // call parent
    RNAi.AnnotationParameterAdd.superclass.onRender.apply(this, arguments);
 
    // set wait message target
    this.getForm().waitMsgTarget = this.getEl();
 
  } // eo function onRender
 
    
    
  /**
     * Submits the form. Called after Submit buttons is clicked
     * @private
     */
  ,
  submit:function() {
    //doAction:function() {
    var formData = Ext.encode(this.getForm().getValues());
    //Ext.Msg.alert('formData', formData);
    Ext.Ajax.request({
      url:'/RNAi/rnai.go', 
      success: function(response){
        if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                    
          this.ownerCt.close()
        }
        else {
          Ext.MessageBox.show({
            title: 'Add Annotation',
            msg: 'Unable to save Annotation changes1.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
        }
      },
      failure: function(response){
        Ext.MessageBox.show({
          title: 'Add Annotation',
          msg: 'Unable to save Annotation changes2.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.screener.AnnotationResponder',
        annotation_json :formData,
        table_name:'annotation',
        action_id: 'add-annotation'
      }
    })
        
  } // eo function submit
 
    
 
}); // eo extend







RNAi.AnnotationOptionsAdd = Ext.extend(Ext.form.FormPanel, {
 
  // defaults - can be changed from outside
    
  border:false
  ,
  frame:true
  ,
  labelWidth:80
  ,
  url:'/RNAi/rnai.go'
  ,
  buttonAlign: 'center',
  initComponent:function() {
    // configure ourselves
    // hard coded config - cannot be changed from outside
    var config = {
      defaultType:'textfield'
      ,
      defaults:{
        anchor:'-24'
      }
      ,
      monitorValid:true
      //          ,buttonAlign:'right'
      ,
      items:[{
        name:'annotation_option_name'
        ,
        fieldLabel:'Annotation Options Name'
        ,
        xtype:'textarea'
      },{
        name:'annotation_option_desc'
        ,
        fieldLabel:'Annotation Options Description'
        ,
        xtype:'textarea'
      },{  
        xtype:'hidden',  
        name:'annotation_id',   
        value:this.annotation_id  
      } 
      ]
      ,
      buttons:[{
        text:'Submit'
        //,formBind:true
        ,
        scope:this
        ,
        handler:this.submit
      }]
    }; // eo config object
 
    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
 
    // call parent
    RNAi.AnnotationOptionsAdd.superclass.initComponent.apply(this, arguments);
 
  } // eo function initComponent
    
  /**
     * Form onRender override
     */
  ,
  onRender:function() {
 
    // call parent
    RNAi.AnnotationOptionsAdd.superclass.onRender.apply(this, arguments);
 
    // set wait message target
    this.getForm().waitMsgTarget = this.getEl();
 
  } // eo function onRender
 
    
    
  /**
     * Submits the form. Called after Submit buttons is clicked
     * @private
     */
  ,
  submit:function() {
    //doAction:function() {
    var formData = Ext.encode(this.getForm().getValues());
        
        
    Ext.Ajax.request({
      url:'/RNAi/rnai.go', 
      success: function(response){
        if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                    
          this.ownerCt.close()
        }
        else {
          Ext.MessageBox.show({
            title: 'Add Annotation Option',
            msg: 'Unable to save Annotation Option changes1.',
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
        }
      },
      failure: function(response){
        Ext.MessageBox.show({
          title: 'Add Annotation',
          msg: 'Unable to save Annotation Option changes2.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.screener.AnnotationResponder',
        annotation_json :formData,
        table_name:'annotation_option',
        action_id: 'add-annotation'
      }
    }) 
        
  } // eo function submit
 
    
 
}); // eo extend