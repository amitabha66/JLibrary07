/**
 * Creates a data structure for RNAi records
 */
RNAi.Record.OperationLogRecord= Ext.data.Record.create([
{
  name:'log_id',
  type: 'integer'
},
{
  name:'reference_id',
  type: 'integer'
},
{
  name:'log_type'
},{
  name:'entered_by'
},
{
  name:'entry_date',
  type: 'date',
  dateFormat: 'Y-m-d',
  defaultValue: 0
},
{
  name: 'name',
  convert: function(v, r) {
    var type= r.log_type
    type= type.replace(/_/g, ' ').toTitleCase()
    type= type.replace(/oga/gi, 'OGA')
    return type
  }
}
])

RNAi.Record.OperationLogRecord.prototype.recordType= 'OperationLog'

