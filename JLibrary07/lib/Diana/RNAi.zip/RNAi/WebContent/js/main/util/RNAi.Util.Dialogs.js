/**
 * Show the notifier message box
 * 
 * @param {Object} msg
 * @param {Object} title
 */
RNAi.showMessage= function(msg, title) {
  new Ext.ux.Notify({
    title :title || 'Message',
    html :msg,
    hideDelay :3000,
    closable :false,
    autoDestroy :true
  }).show(document)
}


/**
 * Shows a message box with a message and optional title NOTE the parameter order!!! Oh well- it was easier
 * 
 * @param {Object} msg
 * @param {Object} title
 */
function showMessageDialog(msg, title) {
  Ext.Msg.show({
    title :title || 'Message',
    icon :Ext.Msg.INFO,
    msg :msg,
    minWidth :250,
    buttons :Ext.Msg.OK
  })
}