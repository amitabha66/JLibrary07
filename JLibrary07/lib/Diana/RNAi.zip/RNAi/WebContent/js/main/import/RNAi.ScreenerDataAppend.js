

RNAi.ScreenerDataAppend = Ext.extend(Ext.form.FormPanel, {
  title: 'Load Screener Data using Assay code or QC Session Name',
  autoScroll: true,
  frame: true,
  bodyStyle: 'padding:10px',    
  height: 864,    
  footer: true,
  labelWidth: 300,
  labelPad: 10,
  buttonAlign: 'center',
  url:'/RNAi/rnai.go',    
  loadMask: {
    msg: 'Loading Aliases'
  },
  initComponent: function() {
    this.layoutConfig = {
      trackLabels: true,
      labelSeparator: ''
    };            
        
        
    var config = {
      items : this.form_items,
      //items: x,
      buttons:[{
        text:'Submit',
        formBind:true,
        scope:this,
        handler:this.submit
      },{
        text:'Cancel',
        scope:this,
        handler:this.cancel
      }]
    }
        
    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
    RNAi.ScreenerDataAppend.superclass.initComponent.apply(this, arguments);
         
    var form = this.getForm();
    var fromDate = form.findField('fromDate');
    var toDate = form.findField('toDate');
    var site = form.findField('Site');
    var assayCombo = form.findField('assay');
    var qcCombo = form.findField('qcName');               
    var layerCombo = form.findField('layerName');               
        
        
      
    assayCombo.on('beforequery',function(qe){
      delete qe.combo.lastQuery; 
    });
        
    qcCombo.on('beforequery',function(qe){
      delete qe.combo.lastQuery; 
            
    });
        
    layerCombo.on('beforequery',function(qe){
      delete qe.combo.lastQuery;            
    });
        
              
        
        
        
    assayCombo.store.on('beforeload', function(store){
      store.baseParams.fromDate = fromDate.value;  
      store.baseParams.toDate = toDate.value;  
      store.baseParams.site = site.value;  
    });
        
    qcCombo.store.on('beforeload', function(store){
      store.baseParams.fromDate = fromDate.value;  
      store.baseParams.toDate = toDate.value;  
      store.baseParams.site = site.value;  
      store.baseParams.assay = assayCombo.getValue();  
    });
        
    layerCombo.store.on('beforeload', function(store){            
      store.baseParams.site = site.value;  
      store.baseParams.qcName = qcCombo.getValue();  
    });
        
               
                
  }
  ,
  onRender:function() { 
    // call parent
    RNAi.ScreenerDataAppend.superclass.onRender.apply(this, arguments); 
    // set wait message target
    this.getForm().waitMsgTarget = this.getEl();      

  }
  /**
     * Submits the form. Called after Submit buttons is clicked
     * @private
     */
  ,
  submit:function() {
    var formPanel = this;
    var viewport = Ext.getCmp('root-id');
    var tabPanel = viewport.contentPanel;
    var formData = Ext.encode(this.getForm().getValues());
                
    //var myMask = new Ext.LoadMask(Ext.getBody(), {msg:"Please wait..."});
    //var myMask = new Ext.LoadMask(tabPanel.el, {msg:"Please wait..."});
    var myMask = new Ext.LoadMask(this.el, {
      msg:"Please wait..."
    });
    myMask.show();
    Ext.Ajax.request({
      url:'/RNAi/rnai.go', 
      success: function(response){
        myMask.hide()
        if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
          var assayCombo = this.getForm().findField('assay');
          var qcCombo = this.getForm().findField('qcName');               
          var layerCombo = this.getForm().findField('layerName'); 
          var result = assayCombo.getValue() + ":" + qcCombo.getValue() + ":" + layerCombo.getValue();
          Ext.MessageBox.show({
            title: 'Append Screener Experiment',
            msg: 'Append Complete' + ":" + result,
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.INFO
          })
                    
          var tab = formPanel.ownerCt;
          tabPanel.remove(tab);
          new RNAi.TabPanelLoader().loadAllRNAiExperimentsSearchResults()                    
        }
        else {
          Ext.MessageBox.show({
            title: 'Append Screener Experiment',
            msg: Ext.util.JSON.decode(response.responseText).message,
            buttons: Ext.MessageBox.OK,
            icon: Ext.MessageBox.ERROR
          })
        }
      },
      failure: function(response){
        myMask.hide()
        Ext.MessageBox.show({
          title: 'Append Screener Experiment',
          msg: 'Unable to Append Screener Experiment.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.screener.ScreenerResponder',
        experiment_json :formData,
        table_name:'screener',
        action_id: 'append-experiment'
      }
    })
        
  } // eo function submit
  ,
  cancel:function() {        
    var viewport = Ext.getCmp('root-id');
    var tabPanel = viewport.contentPanel;
    var tab = this.ownerCt;
    tabPanel.remove(tab);
        
  } // eo function submit
  /**
     * Success handler
     * @param {Ext.form.BasicForm} form
     * @param {Ext.form.Action} action
     * @private
     */
  ,
  onSuccess:function(form, action) {        
        
        
        
        
  } // eo function onSuccess
 
  /**
     * Failure handler
     * @param {Ext.form.BasicForm} form
     * @param {Ext.form.Action} action
     * @private
     */
  ,
  onFailure:function(form, action) {
    this.showError(action.result.error || action.response.responseText);
  } // eo function onFailure
    
  /**
     * Shows Message Box with error
     * @param {String} msg Message to show
     * @param {String} title Optional. Title for message box (defaults to Error)
     * @private
     */
  ,
  showError:function(msg, title) {
    title = title || 'Error';
    Ext.Msg.show({
      title:title,
      msg:msg,
      modal:true,
      icon:Ext.Msg.ERROR,
      buttons:Ext.Msg.OK
    });
  } // eo function showError
});
