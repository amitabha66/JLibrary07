
RNAi.ExperimentGeneSummaryResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {
    var panel = this
    var rowActions= null
    if (this.disableToolbar!== true) {      
      rowActions= [{
        groups: [{
          groupName: 'View',
          rowActions: [{
            text: 'Survival Plot',
            iconCls:'ix-v0-16-gantt-chart',
            minRecordSelectCount: 1,
            cb: function(grid, geneRecord, geneRecords) {
              if (geneRecords && panel.expRecord) {
                new RNAi.Dialog.CreateSuvivalPlot({
                  expRecord:panel.expRecord, 
                  geneRecords: geneRecords,
                  handler: function(selExpRecords, refGeneSymbols) {                    
                    new RNAi.TabPanelLoader().openSurvivalPlot(geneRecords, panel.expRecord, refGeneSymbols, panel, panel.dataProxy)                                             
                  }, 
                  scope: this
                }).show()
              }
            }
          },{
            text: 'Individual Results',
            iconCls:'ix-v0-16-pawn_view',
            minRecordSelectCount: 1,
            tooltip: 'Select genes, then click to view individual RNAi POC values',
            cb: function(grid, geneRecord, geneRecords) {
              if (geneRecord && panel.expRecord) {
                new RNAi.TabPanelLoader().loadRNAiRawResults(panel.expRecord, geneRecords, 'POCs ['+panel.expRecord.data.experiment_name+']')
              }
            }
          }, {
            text: 'Properties',
            iconCls:'ix-v0-16-form_yellow',
            recordSelectCount: 1,
            cb: function(grid, geneRecord) {
              grid.rowExpander.openAsWindow(geneRecord, geneRecord.data.gene_symbol + ", " + geneRecord.data.gene_name)    
            }
          }]
        }, {
          groupName: 'Charts',
          columns: 1,
          rowActions: RNAi.Chart.getChartRowAction('Gene')        
        }]
      }
      ]      
    }    
    this.items=[(this.contentGrid= new RNAi.ExperimentGeneSummaryGrid({
      region: 'center',
      dataID: this.dataID,
      dataProxy: this.dataProxy,
      cacheID: this.cacheID,     
      analysisRecords: this.analysisRecords,
      resultTypeRecords: this.resultTypeRecords,      
      disableToolbar: this.disableToolbar,
      disableExport: this.disableExport,
      rowActions: rowActions,
      cellActions: {        
        rnai_count: {
          handler: function(grid, geneRecord, dataIndex) {
            new RNAi.TabPanelLoader().openRNAiRawResultsDialog(panel, panel.expRecord, geneRecord, 'POCs ['+panel.expRecord.data.experiment_name+']')
          },
          scope: panel                
        }
      }
    }))
    ]   
    RNAi.ExperimentGeneSummaryResults.superclass.initComponent.call(this);   
  },  
  handleSearch: function(values) {  
    var panel= this    
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {
          panel.loadResults()              
        }        
      },
      failure: function(response) {
        panel.contentGrid.getEl().unmask()
        RNAi.checkForErrorResponse(response)
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchResponse: (values.searchResponse || 'RESULTS'),        
        searchType: values.searchBy || 'EXPERIMENT_IDS',
        query: values.query,        
        experiment_id: values.experiment_id,
        dataID: panel.contentGrid.dataID,
        analyses: (Ext.isArray(panel.analysisRecords) ? RNAi.joinFields(panel.analysisRecords, 'analysis_type', ',') : null),
        resultTypes: (Ext.isArray(panel.resultTypeRecords) ? RNAi.joinFields(panel.resultTypeRecords, 'result_type', ',') : null)        
      }     
    })   
  },
  loadResults: function() {
    this.contentGrid.getStore().load()              
  }
}); 
