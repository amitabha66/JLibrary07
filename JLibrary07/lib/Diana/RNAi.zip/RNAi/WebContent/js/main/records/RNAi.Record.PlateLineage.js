/**
 * Creates a data structure for RNAi records
 */
RNAi.Record.PlateLineage= Ext.data.Record.create([
{
  name: 'barcode'
},{
  name: 'parents'
},{
  name: 'descendants'
},{
  name: 'flag',
  type: 'boolean',
  defaultValue: 'false'
}             
])

RNAi.Record.PlateLineage.prototype.recordType= 'PlateLineage'
