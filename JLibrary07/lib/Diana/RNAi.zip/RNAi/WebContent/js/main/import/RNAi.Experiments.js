
var e_cb = new Ext.grid.CheckboxSelectionModel({
    singleSelect: false
})

RNAi.Experiments = Ext.extend(Ext.grid.GridPanel, {    
    initComponent:function() {
        var ExperimentsPanel = this       
        
        var config = {            
            store:new Ext.data.JsonStore({                
                url:'/RNAi/rnai.go',
                root :"experiments",
                fields:[
                {
                    name:'experiment_id'
                },
                {
                    name:'assay_code'
                },
                {
                    name:'qc_session_name'
                },
                {
                    name:'layer_name'
                },
                {
                    name:'qc_owner'
                },
                {
                    name:'qc_date'
                },
                {
                    name:'upload_date'
                }             
                ]              
            }),
            sm: e_cb,
            columns:[e_cb,{
                id:'experiment_id',
                header:"experiment_id",
                hidden: true,
                dataIndex:'experiment_id'
            },{
                header:"Assay",
                width:20,
                sortable:true,
                dataIndex:'assay_code'
            },{
                header:"QCName",
                width:50,
                sortable:true,
                dataIndex:'qc_session_name'                
                
            },{
                header:"Layer",
                width:20,
                sortable:true,
                dataIndex:'layer_name'
            },{
                header:"QCOwner",
                width:15,
                sortable:true,                
                dataIndex:'qc_owner'
            },{
                header:"QCDate",
                width:20,
                sortable:true,
                dataIndex:'qc_date'                
            },{
                header:"UploadDate",
                width:20,
                sortable:true,
                dataIndex:'upload_date'
            }]
            ,
            listeners:{
                afteredit: function(e){
 
                }  
            }
            ,
            buttons:[{
                text: 'View Annotations',
                listeners: {
                    'click': function(button, e){  
                        
                    
                    }
                }
            },{
                text: 'View Plates',
                listeners: {
                    'click': function(button, e){  
                        
                    
                    }
                }
            },{
                text: 'Gene Report',
                listeners: {
                    'click': function(button, e){  
                        
                    
                    }
                }
            },{
                text: 'Experiment Report',
                listeners: {
                    'click': function(button, e){  
                        
                    
                    }
                }
            },{
                text: 'Delete',
                listeners: {
                    'click': function(button, e){  
                        var apstore = this.ownerCt.ownerCt.store;
                        var records = this.ownerCt.ownerCt.getSelectionModel().getSelections();
                        if (records.length > 0) {
                            var ids_todelete = "";
                            var names_todelete = "";
                            for (i = 0; i < records.length; i++) {
                                var record = records[i];
                                ids_todelete = ids_todelete + record.data.experiment_id + ",";
                                names_todelete = names_todelete + record.data.qc_session_name + ",";
                            }
                            if (ids_todelete.length > 0) {
                                ids_todelete = ids_todelete.substring(0, ids_todelete.length - 1);
                                names_todelete = names_todelete.substring(0, names_todelete.length - 1);
                            }
                            Ext.MessageBox.show({
                                title: 'Delete Experiment',
                                msg: 'Do you want to delete the selected Experiments : ' + names_todelete + '?',
                                buttons: Ext.MessageBox.YESNO,
                                fn: function(buttonId){
                                    if (buttonId != 'yes') {
                                        return
                                    }
                                    Ext.Ajax.request({
                                        url:'/RNAi/rnai.go', 
                                        success: function(response){
                                            if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                                                apstore.reload();                                                
                                            }
                                            else {
                                                Ext.MessageBox.show({
                                                    title: 'Delete Experiment',
                                                    msg: 'Unable to save Experiment changes1.',
                                                    buttons: Ext.MessageBox.OK,
                                                    icon: Ext.MessageBox.ERROR
                                                })
                                            }
                                        },
                                        failure: function(response){
                                            Ext.MessageBox.show({
                                                title: 'Delete Experiment',
                                                msg: 'Unable to save Experiment changes2.',
                                                buttons: Ext.MessageBox.OK,
                                                icon: Ext.MessageBox.ERROR
                                            })
                                        },
                                        scope: this,
                                        params: {
                                            req:'amgen.ri.rnai.screener.ScreenerResponder',
                                            deleteIds :ids_todelete,
                                            action_id: 'delete-experiment'
                                        }
                                    })
                                } 
                            })
                   
                        }else{
                            Ext.Msg.alert('Delete Experiment Options', 'Please select one or more Experiment options');             
                        }
                    }
                }
            }],
            viewConfig:{
                forceFit:true
            }
        }; // eo config object

        // apply config
        Ext.apply(this, Ext.apply(this.initialConfig, config));
 
        this.bbar = new Ext.PagingToolbar({
            store:this.store            ,
            displayInfo:true            ,
            pageSize:10
        });
 
        // call parent
        RNAi.Experiments.superclass.initComponent.apply(this, arguments);
    } // eo function initComponent
 
    ,
    onRender:function() {
        var grid = this;
        // call parent
        RNAi.Experiments.superclass.onRender.apply(this, arguments);
 
        // load the store
        this.store.load({
            params:{
                start:0, 
                limit:10,                
                req:'amgen.ri.rnai.screener.ScreenerResponder',                
                action_id: 'get-experiments'
                           
            }
        });
        
    
        
 
    } // eo function onRender
 
});





