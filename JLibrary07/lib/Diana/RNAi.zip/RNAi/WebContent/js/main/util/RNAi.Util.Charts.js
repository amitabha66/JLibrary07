
    
    
var chartData= {
  charts: [{
    chart_id: 1,
    name: 'POC Comparison',
    description: 'Create a plot comparing the POCs of RNAi common to 2 experiments',
    target_record_type: 'Experiment',
    record_select_count: 2,
    record_select_count_comparison: 'exact',
    url: 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/ComparePOC',
    config_block: null,
    params: 'exp_id1,exp_id2'
  }, {
    chart_id: 2,
    name: 'PValue Rank Comparison',
    description: 'Create a plot of the analyzed gene PValues and PValue ranks of an experiment',
    target_record_type: 'Experiment',
    record_select_count: 1,
    record_select_count_comparison: 'exact',
    url: 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/RNAi_PValueRank',
    config_block: null,
    params: 'exp_id'
  }, {
    chart_id: 3,
    name: 'PValue Vs Exp Gene Plot',
    description: 'Create a plot of analyzed gene PValues vs experiment genes',
    target_record_type: 'Experiment',
    record_select_count: 2,
    record_select_count_comparison: 'min',
    url: 'http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/PValuesToGene',
    config_block: null,
    params: 'exp_ids'
  }]
}
    
RNAi.Chart= function () {  
  return {
    chartStore: new Ext.data.Store({
      reader: new Ext.data.JsonReader({
        idProperty: 'chart_id',
        root: 'charts'
      }, RNAi.Record.Chart),
      url: '/RNAi/rnai.go',
      baseParams: {
        req: 'amgen.ri.rnai.search.AvailableChartResponder'
      },
      autoLoad: true
    }),
    getChartRowAction: function(recordType) {
      var chartGroup= []
      RNAi.Chart.chartStore.query('target_record_type', recordType).each(function(chartRecord) {
        var chart= {
          text: chartRecord.get('name'),
          iconCls:'x-rnai-16-spotfire',
          tooltip: chartRecord.get('description'),
          chartRecord: chartRecord,
          cb: function(grid, expRecord, expRecords) {
            new RNAi.ChartLoader().loadChart(chartRecord, expRecords)      
          }
        }               
        switch(chartRecord.get('record_select_count_comparison')) {
          case 'min':
            chart.minRecordSelectCount= chartRecord.get('record_select_count')
            break;
          case 'max':
            chart.maxRecordSelectCount= chartRecord.get('record_select_count')
            break;
          default:
            chart.recordSelectCount= chartRecord.get('record_select_count')
            break; 
        }        
        chartGroup.push(chart)        
      })
      return chartGroup      
    }
  }
}();
    