RNAi.SearchFormPanel = Ext.extend(Ext.Panel, {    
  initComponent: function() {
    var panel= this
    
    Ext.apply(this, {      
      frame: true,
      layout: 'border'
    })    
    this.items= [
    new RNAi.BasicSearchForm({
      scope: this.scope,
      gene:  this.gene,
      region: 'north',
      height: 300,
      split: true,
      collapsible :true,
      collapseMode :'mini',   
      hideCollapseTool: true
    }),
    new Ext.TabPanel({
      region: 'center',
     
      activeTab: 0,
      items: [
      new Ext.grid.GridPanel({
        title: 'Screened Collections',
        iconCls: "ix-v0-16-table",    
        loadMask: 'Loading Collections',
        store: new Ext.data.Store({
          url: '/RNAi/rnai.go',       
          autoLoad: true,
          reader :new Ext.data.JsonReader({
            idProperty: 'collection_id',
            root :"collection"
          }, RNAi.Record.Collection),
          sortInfo: {
            field: 'collection_name',
            direction: 'ASC' 
          },
          baseParams: {
            req:'amgen.ri.rnai.screener.CollectionResponder',                
            action_id: 'all_exp_collections'              
          }
        }),
        sm: new Ext.grid.RowSelectionModel({
          singleSelect:true
        }),
        columns: [{
          id: 'collection_name', 
          header: 'Collection', 
          width: 200, 
          sortable: true, 
          dataIndex: 'collection_name',
          renderer: function(value, metaData) {
            metaData.css = 'x-rnai-cell-link' 
            return value
          }
        },{
          id: 'collection_desc', 
          header: 'Description', 
          sortable: true, 
          dataIndex: 'collection_desc',
          renderer: function(value, metaData) {
            metaData.css = 'x-cell-pointer' 
            return value
          }
        },{
          header: 'Member Gene Count', 
          width: 200, 
          sortable: true, 
          dataIndex: 'gene_count',
          renderer: function(value, metaData) {
            if (value!=0) {
              metaData.css = 'x-rnai-cell-link' 
            }
            return value
          }
        },{
          header: 'Member RNAi Count', 
          width: 200, 
          sortable: true, 
          dataIndex: 'rnai_count',
          renderer: function(value, metaData) {
            if (value!=0) {
              metaData.css = 'x-rnai-cell-link' 
            }
            return value
          }
        },{
          header: 'Experiment Count', 
          sortable: true, 
          dataIndex: 'experiment_count',
          renderer: function(value, metaData) {
            metaData.css = 'x-cell-pointer' 
            return value
          }
        }
        ],
        stripeRows: true,
        autoExpandColumn: 'collection_desc',
        listeners: {
          cellclick: function(grid, rowIndex, columnIndex) {       
            var collectionRecord = grid.getStore().getAt(rowIndex);  // Get the Record            
            var fieldName = grid.getColumnModel().getDataIndex(columnIndex); // Get field name
            var fieldValue= collectionRecord.get(fieldName)
            if (fieldName== 'gene_count') {
              if (fieldValue!=0 && Ext.isFunction(panel.handlers.searchGenesByCollection)) {
                panel.handlers.searchGenesByCollection.call(panel.scope, collectionRecord)
              }
            } else if (fieldName== 'rnai_count') {
              if (fieldValue!=0 && Ext.isFunction(panel.handlers.searchRNAIByCollection)) {
                panel.handlers.searchRNAIByCollection.call(panel.scope, collectionRecord)
              }
            } else {
              if (Ext.isFunction(panel.handlers.searchByCollection)) {
                panel.handlers.searchByCollection.call(panel.scope, collectionRecord)
              }
            }
          }
        }
      }
      ), (this.cellLineGrid= new Ext.grid.GridPanel({
        title: 'Screened Cell Lines',
        iconCls: 'ix-v0-16-bullet_ball_grey',
        loadMask: 'Loading Cell Lines',
        split: true,
        store: new Ext.data.Store({
          url: '/RNAi/rnai.go',       
          autoLoad: true,
          reader :new Ext.data.JsonReader({
            idProperty: 'annotation_id',
            root :"annotation"
          }, RNAi.Record.Annotation),
          sortInfo: {
            field: 'annotation_name',
            direction: 'ASC' 
          },
          baseParams: {
            req:'amgen.ri.rnai.screener.AnnotationResponder',                
            action_id: 'get-celllines'              
          }
        }),
        sm: new Ext.grid.RowSelectionModel({
          singleSelect:true
        }),
        columns: [{
          id: 'annotation_name', 
          header: 'Cell Line', 
          width: 200, 
          sortable: true, 
          dataIndex: 'annotation_name',
          renderer: function(value, metaData) {
            metaData.css = 'x-rnai-cell-link' 
            return value
          }
        },{
          header: 'Tissue', 
          width: 200, 
          sortable: true, 
          dataIndex: 'tissue_attribute',
          renderer: function(value, metaData) {
            metaData.css = 'x-rnai-cell-link' 
            return value
          }
        },{
          header: 'Experiment Count', 
          sortable: true, 
          dataIndex: 'experiment_count',
          renderer: function(value, metaData) {
            metaData.css = 'x-cell-pointer' 
            return value
          }
        }
        ],
        stripeRows: true,
        viewConfig: {
          forceFit:true,
          enableRowBody:true,
          showDescription: true,
          getRowClass : function(record, rowIndex, p, store){
            if (this.showDescription) {
              p.body = '<p>'+record.data.annotation_desc+'</p>'
              return 'x-grid3-row-expanded'
            } else {
              return 'x-grid3-row-collapsed'
            }
          }
        },        
        listeners: {          
          cellclick: function(grid, rowIndex, columnIndex) {       
            var cellLineAnnotationRecord = grid.getStore().getAt(rowIndex);  // Get the Record            
            var fieldName = grid.getColumnModel().getDataIndex(columnIndex); // Get field name
            if (fieldName== 'tissue_attribute') {
              if (Ext.isFunction(panel.handlers.searchByTissue)) {
                panel.handlers.searchByTissue.call(panel.scope, cellLineAnnotationRecord)
              }
            } else {
              if (Ext.isFunction(panel.handlers.searchByCellLine)) {
                panel.handlers.searchByCellLine.call(panel.scope, cellLineAnnotationRecord)
              }
            }
          }
        } ,
        bbar: [{
          pressed: true,
          enableToggle:true,
          text: 'Show Descriptions',
          iconCls: 'ix-v0-16-text',
          toggleHandler: function(btn, pressed){
            var view = panel.cellLineGrid.getView();
            view.showDescription = pressed;
            view.refresh();
          }
        }]        
      }
      ))]
    })
    ]   
    RNAi.SearchFormPanel.superclass.initComponent.call(this);
  }
}
)


RNAi.BasicSearchForm = Ext.extend(Ext.form.FormPanel, {    
  initComponent: function() {
    var formPanel= this
    Ext.apply(this, {      
      labelWidth: 75,
      autoScroll: true
    })
    
    this.items= []
    //---------------------------------------------------------
    //Add the Gene & RNAi Search form and handlers
    this.items.push({
      xtype: 'fieldset',
      title: 'Search for Experiments, Genes and RNAi',
      items: [{        
        xtype: 'compositefield',
        fieldLabel: 'Search By',
        anchor: '100%',
        layoutConfig: {
          align: 'stretch'
        },
        items: [{
          xtype: 'combo',
          flex: 1,
          width: 150,
          name: 'searchBy',
          mode: 'local',
          triggerAction: 'all',
          forceSelection: true,
          editable: false,        
          hiddenName: 'searchBy',
          value: 'GENE_SYMBOLS',
          store: [['GENE_KEYWORDS', 'Gene Keywords'], ['GENE_NAMES', 'Gene Names'], ['GENE_SYMBOLS', 'Gene Symbols'], ['ENTREZGENE_IDS', 'EntrezGene IDs'], ['COMPOUND_IDS', 'Compound IDs'], ['EXPERIMENT_IDS', 'Experiments'], ['SEQUENCES', 'Trigger Sequence'], ['BARCODES', 'Plate Barcodes']]        
        }, (this.focusTextInput= new Ext.form.TextArea({
          flex: 1,
          height: 150,          
          name: 'query'
        }))
        ]
      }]
    })
    if (Ext.isArray(this.gene.handlers)) {
      var buttons= []
      for(var i=0; i<this.gene.handlers.length; i++) {
        buttons.push(new Ext.Button({
          text: this.gene.handlers[i].text,
          iconCls: this.gene.handlers[i].iconCls || "ix-v0-16-view", 
          handler: (Ext.isFunction(this.gene.handlers[i].handler) ? this.gene.handlers[i].handler.createDelegate(this.scope, [formPanel]) : Ext.emptyFn)
        }))
      }        
      this.items[this.items.length-1].items.push({        
        padding: '20 0 0 0',
        layout: 'form',
        items: {
          xtype: 'fieldset',
          layout: 'hbox',
          border: false,
          fieldLabel: 'Search For',
          layoutConfig: {
            pack: 'left',
            align: 'top'
          },
          defaults:{
            margins:'0 5 0 0'
          },  
          items: buttons
        }
      })      
    }
    
    //When rendered, either load the provided records or do the search        
    this.on('render', function(panel) {
      new Ext.util.DelayedTask().delay(100, function() {
        panel.focusTextInput.focus(true)
      })
    })     
    RNAi.BasicSearchForm.superclass.initComponent.call(this);
  }
});
