/**
 * Creates a data structure for Analysis records
 */
RNAi.Record.Analysis= Ext.data.Record.create([
  {
    name:'analysis_type_id',                     
    type:'integer'
  }
  ,{
    name:'analysis_type'
  } ,{
    name:'analysis_name'
  } ,{
    name:'view_bydefault',                     
    type:'boolean',
    defaultValue: false
  }                  
  ])  
  RNAi.Record.Analysis.prototype.recordType= 'Analysis'
