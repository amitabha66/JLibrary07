
RNAi.ExperimentSummaryGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  initComponent: function() {
    var grid= this
    Ext.applyIf(this, {
      root: 'experiments',
      highlightDef: {
        field: 'OGA METHOD V2:CORRECTED_PVALUE',
        comp: '<',
        compareValue: 0.05        
      }
    })
    this.rowExpander= new RNAi.ExperimentGridExpander()     
    
    this.fields= []
    for(var i=0; i< RNAi.Record.Experiment.prototype.fields.items.length; i++) {
      this.fields.push(RNAi.Record.Experiment.prototype.fields.items[i])
    }        
    this.recordType= RNAi.Record.Experiment.prototype.recordType
      
    var colDefs= [this.rowExpander]           
    colDefs.push({
      id: 'experiment_name',
      header: 'Name',
      dataIndex: 'experiment_name',
      sortable: true,
      width: 300,
      groupHeader: 'Experiment'
    }, {
      header: 'Type',
      dataIndex: 'experiment_type',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment'
    }, {
      header: 'Cell Line',
      dataIndex: 'cell_line',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment'
    }, {
      header: 'Tissue',
      dataIndex: 'tissue',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment'
    }, {
      header: 'Collection',
      dataIndex: 'library',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment'
    }, {
      header: 'Experiment Gene Count',
      dataIndex: 'exp_gene_count',
      filterType: 'int',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      xtype: 'datecolumn',
      header: 'Date',
      dataIndex: 'experiment_date',
      filterType: 'date',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      header: 'Uploaded By',
      dataIndex: 'uploaded_by',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      xtype: 'datecolumn',
      header: 'Analyzed Date',
      dataIndex: 'last_analyzed',
      filterType: 'date',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      header: 'Analyzed By',
      dataIndex: 'analyzed_by',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      header: 'Analyzed Gene Count',
      dataIndex: 'analyzed_gene_count',
      filterType: 'int',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details'
    }, {
      header: 'Status',
      dataIndex: 'status',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details',
      filterType: {
        type: 'list',
        options: ['Valid', 'Invalid']
      }      
    }, {
      header: 'Visibility',
      dataIndex: 'visibility',
      sortable: true,
      width: 100,
      groupHeader: 'Experiment Details',
      filterType: {
        type: 'list',
        options: ['Public', 'Private']
      }      
    })

    if (Ext.isArray(this.analysisRecords) && Ext.isArray(this.resultTypeRecords)) {
      for(var i=0; i<this.analysisRecords.length; i++) {
        var analysis= this.analysisRecords[i]     
        var analysisName= analysis.data.analysis_name
        var analysisType= analysis.data.analysis_type        
        for(var j=0; j< this.resultTypeRecords.length; j++) {
          var resultType= this.resultTypeRecords[j]
          var resultTypeName= resultType.data.result_type
          var format= resultType.data.format
          var precision= resultType.data.precision
          var dataIndex= analysisType+":"+resultTypeName
                        
          this.fields.push({
            name: analysisType+":"+resultTypeName,
            type: (format== 'int' ? 'int' : 'float')
          })               
          colDefs.push({
            header: resultType.data.result_name,
            dataIndex: dataIndex,
            align: 'right',
            analysisName: analysisName,
            resultTypeName: resultTypeName,
            format: format,
            precision: precision,
            filterType: 'numeric',
            sortable: true,
            width: 150,
            groupHeader: analysisName,
            renderer: function(value, metaData, record, rowIndex, colIndex, store) {
              var cm= grid.getColumnModel()
              var col= cm.getColumnById(this.id)
              var val= new Number(value)
              
              if (isNaN(val)) {
                return value
              }              
              switch(col.format) {
                case 'int':
                  return val.toFixed(0)
                case 'scientific':
                  return val.toExponential((col.precision || 5))
                default:
                  return val.toPrecision((col.precision || 5))
              } 
            }
          })
          
          
          if (resultTypeName== 'CORRECTED_PVALUE') {
            this.cellActions= this.cellActions || {}
            this.cellActions[dataIndex]= {
              handler: function(grid, expRecord, dataIndex) {
                var panel= this.parentPanel   
                panel.openSurvivalPlot(expRecord)                
              },
              scope: this                            
            }  
          }              
        }        
      }        
    }
        
    var columnGroups= this.createColumnGroups(colDefs, {
      "Experiment": 0,
      "Experiment Details": 100
    }, true)
    
    if (columnGroups) {    
      this.group= columnGroups.group
      var sortedColDefs= [this.rowExpander]
      for(var i=0; i< columnGroups.colDefs.length; i++) {
        sortedColDefs.push(columnGroups.colDefs[i])
      }      
      colDefs= sortedColDefs
    }
      
    this.plugins= [this.rowExpander]      
    if (this.group) {
      this.plugins.push(this.group)
    }
    if (this.rowActionsPlugin) {
      this.plugins.push(this.rowActionsPlugin)
    }     
    
    
    this.colModel= new Ext.grid.ColumnModel({     
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })   
    RNAi.ExperimentSummaryGrid.superclass.initComponent.call(this);      
  },
  getExperimentRecords: function() {
    if (this.getSelectionModel().getCount()== 0) {
      return this.getStore().getRange()
    } else {
      return this.getSelectionModel().getSelections()
    }
  }
})