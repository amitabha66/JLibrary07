
RNAi.ExperimentResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent: function() {
    var me = this
    var rowActions = null
    var exportGroup = null

    if (this.disableToolbar !== true) {
      rowActions = [{
          groups: [{
              groupName: 'View',
              columns: 2,
              rowActions: [{
                  text: 'Results',
                  iconCls: 'ix-v0-16-text_view',
                  recordSelectCount: 1,
                  cb: function(grid, expRecord) {
                    new RNAi.TabPanelLoader().loadRNAiExperimentGeneSummaryResults({
                      searchBy: 'EXPERIMENT_IDS',
                      searchResponse: 'RESULTS',
                      query: expRecord.data.experiment_id,
                      experiment_id: expRecord.data.experiment_id,
                      expRecord: expRecord
                    },
                    "Experiments [" + expRecord.data.experiment_name + "]",
                            RNAi.getDefaultAnalysisRecords(), RNAi.getDefaultResultTypeRecords())
                  }
                }, {
                  text: 'RNAi',
                  iconCls: 'ix-v0-16-pawn_glass_red',
                  recordSelectCount: 1,
                  cb: function(grid, expRecord) {
                    new RNAi.TabPanelLoader().loadRNAiSearchResults({
                      searchBy: 'EXPERIMENT_IDS',
                      query: expRecord.data.experiment_id
                    },
                    "RNAi [" + expRecord.data.experiment_name + ", " + expRecord.data.experiment_name + "] ")
                  }
                }, {
                  text: 'Properties',
                  iconCls: 'ix-v0-16-form_yellow',
                  recordSelectCount: 1,
                  cb: function(grid, expRecord) {
                    grid.rowExpander.openAsWindow(expRecord, expRecord.data.experiment_name)
                  }
                }, {
                  text: 'Genes',
                  iconCls: 'rg-entity-gene',
                  recordSelectCount: 1,
                  cb: function(grid, expRecord) {
                    new RNAi.TabPanelLoader().loadGenesForExp(expRecord)
                  }
                }, {
                  text: 'Survival Plot',
                  iconCls: 'ix-v0-16-gantt-chart',
                  recordSelectCount: 1,
                  disabled: (!Ext.isObject(me.geneRecord)),
                  checkDisabled: function() {
                    if (!Ext.isObject(me.geneRecord)) {
                      return true;
                    }
                  },
                  cb: function(grid, expRecord) {
                    if (me.geneRecord && expRecord) {
                      me.openSurvivalPlot(expRecord)
                    }
                  }
                }, {
                  text: 'Logs',
                  iconCls: 'ix-v0-16-scroll',
                  minRecordSelectCount: 1,
                  cb: function(grid, expRecord, expRecords) {
                    new RNAi.TabPanelLoader().openLogsForExperiment(expRecords)
                  }
                }
              ]
            }, {
              groupName: 'Analysis',
              rowActions: [{
                  text: 'OGA Analysis',
                  iconCls: 'ix-v0-16-gears_run',
                  permission: 'can_analyze',
                  tooltip: 'Perform OGA analysis on the selected experiments and save to the database.',
                  orig_tooltip: 'Perform OGA analysis on the selected experiments and save to the database.',
                  minRecordSelectCount: 1,
                  cb: function(grid, expRecord, expRecords) {
                    new RNAi.Dialog.OGAAnalysis({
                      expRecords: expRecords,
                      handler: function(selExpRecords, maskedCompoundIDs) {
                        new RNAi.TabPanelLoader().runRNAiAnalysis(expRecords, {
                          masked_compound_ids: maskedCompoundIDs
                        })
                      },
                      scope: this
                    }).show()
                  }
                }, {
                  text: 'OGA Excel Analysis',
                  iconCls: 'ix-v0-16-gears_run',
                  tooltip: 'Perform OGA analysis on the selected experiments and return the results in MS Excel',
                  minRecordSelectCount: 1,
                  cb: function(grid, expRecord, expRecords) {

                    new RNAi.Dialog.OGAAnalysis({
                      expRecords: expRecords,
                      handler: function(selExpRecords, values) {
                        new RNAi.TabPanelLoader().runRNAiAnalysis2Excel(expRecords, {
                          masked_compound_ids: (values.has_masked_compound_ids ? values.masked_compound_ids : null)
                        })
                      },
                      scope: this
                    }).show()
                  }
                }, {
                  text: 'Genetic Interaction',
                  iconCls: 'ix-v0-16-gears_run',
                  tooltip: 'Perform a Genetic Interaction analysis on the selected experiments',
                  minRecordSelectCount: 2,
                  cb: function(grid, expRecord, expRecords) {
                    new RNAi.TabPanelLoader().runGeneticInteractionAnalysis(expRecords)
                  }
                }]
            }, {
              groupName: 'Charts',
              columns: 1,
              rowActions: RNAi.Chart.getChartRowAction('Experiment')
            }, {
              groupName: 'Edit',
              columns: 1,
              rowActions: [{
                  text: 'Update Status and Visibility',
                  iconCls: 'ix-v0-16-link_edit',
                  permission: 'can_edit',
                  tooltip: 'Update the visibility and status flags on the selected experiment(s)',
                  minRecordSelectCount: 1,
                  cb: function(grid, expRecord, expRecords) {
                    new RNAi.TabPanelLoader().updateExperimentFlags(expRecords, grid)
                  }
                }, {
                  text: 'Delete',
                  iconCls: 'ix-v0-16-delete2',
                  permission: 'can_delete',
                  tooltip: 'Delete the selected experiment(s)',
                  minRecordSelectCount: 1,
                  cb: function(grid, expRecord, expRecords) {
                    new RNAi.TabPanelLoader().deleteExperiments(expRecords, grid)
                  }
                }]
            }]
        }
      ]
      exportGroup = {
        groupName: 'Export',
        rowActions: [{
            text: 'Export POC and PValues',
            iconCls: 'ix-v0-16-document_into',
            recordSelectCount: 1,
            cb: function(grid, expRecord) {
              if (expRecord) {
                new RNAi.TabPanelLoader().exportPOCandPValues(expRecord)
              }
            }
          }]}
    }
    this.items = [(this.contentGrid = new RNAi.ExperimentSummaryGrid({
        region: 'center',
        dataID: this.dataID,
        dataProxy: this.dataProxy,
        cacheID: this.cacheID,
        analysisRecords: this.analysisRecords,
        resultTypeRecords: this.resultTypeRecords,
        disableToolbar: this.disableToolbar,
        rowActions: rowActions,
        exportGroup: exportGroup,
        parentPanel: this
      }))
    ]
    RNAi.ExperimentResults.superclass.initComponent.call(this)
  },
  handleSearch: function(values) {
    var panel = this
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {
          panel.loadResults()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'search',
        searchResponse: (values.searchResponse || 'experiments'),
        searchType: values.searchBy,
        query: (RNAi.isRecordType(values.query, 'Person') ?  values.query.get('amgen_login') : values.query),
        gene_id: values.gene_id,
        gene_mixture_id: values.gene_mixture_id,
        dataID: panel.contentGrid.dataID,
        analyses: (Ext.isArray(panel.analysisRecords) ? RNAi.joinFields(panel.analysisRecords, 'analysis_type', ',') : null),
        resultTypes: (Ext.isArray(panel.resultTypeRecords) ? RNAi.joinFields(panel.resultTypeRecords, 'result_type', ',') : null)
      }
    });
  },
  loadResults: function() {
    this.contentGrid.getStore().load()
  },
  openSurvivalPlot: function(expRecord) {
    if (!this.geneRecord || !expRecord) {
      return
    }
    new RNAi.Dialog.CreateSuvivalPlot({
      expRecord: expRecord,
      geneRecords: this.geneRecord,
      handler: function(selExpRecords, refGeneSymbols) {
        new RNAi.TabPanelLoader().openSurvivalPlot(this.geneRecord, expRecord, refGeneSymbols, this, this.dataProxy)
      },
      scope: this
    }).show()
  }
});