/**
 * Returns whether the given record is of type 'type'
 * This assumes the Record prototype has been given a recordType property
 * 
 * Returns false if 
 *   1. record does not return Ext.isRecord true (Ext.isRecord is an extension in Ext.Overrides)
 *   2. type is null/undefined
 *   3. record.recordType != type
 * 
 */
RNAi.isRecordType= function(record, type) {
  if (!Ext.isRecord(record)) {
    return false
  }
  if (!record.recordType || !type) {
    return false
  }
  return (record.recordType== type)
}
/**
 * Joins the specified field of a set of records into either a delimited String
 * or an array.
 * 
 * If fieldName is null, this uses the record ID.
 * If separator is null, this returns an Array; otherwise, this returns a String with separator as the demimiter
 * 
 */
RNAi.joinFields= function(records, fieldName, separator) {
  if (!Ext.isArray(records)) {
    return null
  }
  var n= []
  for(var i=0; i< records.length; i++) {
    var val= (fieldName ? records[i].get(fieldName) : records[i].id)
    if (val) {
      n.push(val)
    }
  }
  if (separator== 'array') {
    return n
  }
  return n.join(separator)
}

RNAi.buildRecordFromResponse= function(response, recordType) {
  var json= RNAi.decode(response)
  return RNAi.buildRecord(json, recordType)  
}

RNAi.buildRecord= function(json, recordType) {
  if (!json) {
    return null;
  }
  switch(recordType) {
    case 'PlateInfo':
      return new RNAi.Record.PlateInfo(json)
    case 'Alignment':
      return new RNAi.Record.Alignment(json)
    case 'Analysis':
      return new RNAi.Record.Analysis(json)
    case 'Annotation':
      return new RNAi.Record.Annotation(json)
    case 'AnnotationGroup':
      return new RNAi.Record.AnnotationGroup(json)
    case 'BioSequence':
      return new RNAi.Record.BioSequence(json)
    case 'Collection':
      return new RNAi.Record.Collection(json)
    case 'Experiment':
      return new RNAi.Record.Experiment(json)
    case 'Gene':
      return new RNAi.Record.Gene(json)
    case 'PlateLineage':
      return new RNAi.Record.PlateLineage(json)
    case 'RNAi':
      return new RNAi.Record.RNAi(json)         
  }     

}