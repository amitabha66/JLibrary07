/**
 * Creates a data structure for Annotation records
 */
RNAi.Record.Annotation= Ext.data.Record.create([
{
  name:'annotation_id',                     
  type:'integer'
}
,{
  name:'annotation_name'
} ,{
  name:'annotation_desc'
} ,{
  name:'annotation_default_value'
} ,{
  name:'rnai_type_id'
} ,{
  name:'rnai_type'
} ,{
  name:'annotation_type'
} ,{
  name:'display_order'
} ,{
  name:'annotation_group_id'
} ,{
  name:'annotation_group_name'
} ,{
  name:'value'
} ,{
  name:'tissue_attribute'
},{
  name:'tissue_term_id'
} , {
  name: 'experiment_count', 
  type :'int'
}                 
])
  
RNAi.Record.Annotation.prototype.recordType= 'Annotation'
