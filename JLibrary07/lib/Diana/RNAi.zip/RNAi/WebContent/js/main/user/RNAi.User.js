
RNAi.User = Ext.extend(Ext.util.Observable, {
  constructor: function(config){
    this.addEvents({
      "fired" : true,
      "quit" : true
    });
    Ext.applyIf(this, config)
    RNAi.User.superclass.constructor.call(this, config)
  },
  /**
 * Returns whether the user has privilege to the given permission
 * Unless the user specifically does not have permission===false, this return true
 */
  userHasPermission: function(permission, experimentRecords, cb, scope) {
    try {
      Ext.Ajax.request({
        url:'/RNAi/rnai.go',	   
        params: {
          req:'amgen.ri.rnai.security.PermissionResponder',
          permission: permission,
          experiment_ids: RNAi.joinFields(experimentRecords, 'experiment_id', ',')
        }, 
        scope: this,
        success: function(response){                  
          var jResponse = RNAi.decode(response.responseText)
          if (Ext.isFunction(cb)) {
            cb.call(scope, (jResponse[permission.toUpperCase()] === true ? true : false))
          }          
        },
        failure: function (response) {
          if (!RNAi.checkForErrorResponse(response)) {
            showMessageDialog('RNAi Analysis Failed to Start')       
          }
        }
      });       
    } catch(e) {}
    return true
  }
})
