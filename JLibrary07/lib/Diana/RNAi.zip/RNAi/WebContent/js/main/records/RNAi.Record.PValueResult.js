/**
 * Creates a data structure for Gene records
 */
RNAi.Record.PValueResult= Ext.data.Record.create([
{
  name:'exp_id',                     
  type:'integer'
}, {
  name:'exp_name'
}, {
  name:'exp_type'
} ,{
  name:'pvalue',                     
  type:'float'
} ,{
  name:'raw_pvalue',                     
  type:'float'
} ,{
  name:'pvalue_rank',                     
  type:'integer'
} ,{
  name:'relative_poc',                     
  type:'float'
} ,{
  name:'cellline'
},{
  name: 'collection'
},{
  name:'rnai_count',
  type: 'integer',
  defaultValue: 0
},{
  name:'gene_count',
  type: 'integer',
  defaultValue: 0
}                  
])

RNAi.Record.PValueResult.prototype.recordType= 'PValueResult'
