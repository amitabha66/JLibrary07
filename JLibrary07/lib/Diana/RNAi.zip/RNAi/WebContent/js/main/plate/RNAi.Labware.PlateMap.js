/**
 * @author jemcdowe
 */

RNAi.Labware.PlateMap = Ext.extend(Ext.grid.GridPanel, {
  stripeRows :true,
  columnLines :true,
  highlightRecord :null,
  colorScheme :'None',
  layerScheme :'gene_symbol',
  maxColors :64,
  maxColor :{
    r :255,
    g :0,
    b :0,
    a :1
  },
  minColor :{
    r :0,
    g :255,
    b :0,
    a :1
  },
  emptyDataColor :{
    r :255,
    g :255,
    b :255,
    a :1
  },
  passThroughBlack :true,
  initComponent : function() {
    var grid = this
    this.enableHdMenu = false
    this.enableColumnMove = false
    this.enableColumnHide = false
    this.selModel= new Ext.grid.CellSelectionModel()

    this.dataRange = {
      min :-100,
      max :100
    }
    this.columns = [new RNAi.Labware.PlateRowLabeller()]

    this.selModel.on('cellselect', function(selModel, rowIndex, colIndex) {
      var record = grid.getStore().getAt(rowIndex)
      grid.parent.plateWellSelectionHandler({
        record: record,
        fieldName: colIndex,
        well: record.get(colIndex)
      })
      grid.handleWellSelection({
        record: record,
        fieldName: colIndex,
        well: record.get(colIndex)
      })
    })

    grid.on('celldblclick', function(grid, rowIndex, colIndex, evt) {
      var record = grid.getStore().getAt(rowIndex)
      var fieldName = grid.getColumnModel().getDataIndex(colIndex)
      var wellID= grid.layerObj.WellIDs[rowIndex][fieldName]
      grid.parent.openGeneViewHandler({
        barcode: grid.barcode, 
        id: wellID
      })
    }) 

    this.addEvents('plateloaded')
    this.store = new Ext.data.Store({
      autoLoad :false,
      url :new Ext.data.MemoryProxy([]),
      reader :new Ext.data.JsonReader({
        root :'Rows'
      }, Ext.data.Record.create(["id"])),
      listeners :{
        load : function() {
          grid.fireEvent('plateloaded', grid, grid.layerScheme)
        }
      }
    })    
    
    this.tbar = new Ext.Toolbar({
      disabled: true,
      listeners :{
        render : function(tb) {
          tb.addText('Available Layers')
          grid.layerCombo = new Ext.form.ComboBox({
            store :new Ext.data.Store({
              autoLoad :false,
              url :new Ext.data.MemoryProxy([]),
              reader :new Ext.data.JsonReader({
                root :'LayerTypes', 
                fields: ['label', 'type']
              })
            }),
            displayField :'label',
            valueField :'type',
            typeAhead :false,
            editable: false,
            mode :'local',
            forceSelection :true,
            triggerAction :'all',
            emptyText :'Select a layer...',
            selectOnFocus :true
          })
          tb.addField(grid.layerCombo)
          grid.layerCombo.on('select', function(combo, record) {
            this.changeLayer(record.data.type)            
          }, grid)
          tb.addText('Color Schemes')
          grid.colorCombo = new Ext.form.ComboBox({
            store :['None', 'Displayed Value', 'Displayed Numeric'],
            displayField :'layer',
            typeAhead :false,
            mode :'local',
            forceSelection :true,
            triggerAction :'all',
            emptyText :'Select a color scheme...',
            value :grid.colorScheme,
            selectOnFocus :true
          })
          tb.addField(grid.colorCombo)
          grid.colorCombo.on('select', function(combo, record) {
            this.changeColorScheme(record.data.field1)
          }, grid)

          tb.addButton({
            text :'Color Gradient Options',
            menu :{
              items :[{
                text :'Center on Black',
                xtype :'menucheckitem',
                checked :grid.passThroughBlack,
                listeners :{
                  checkchange : function(item, checked) {
                    grid.updateNumericColorScheme(null, null, null, checked)
                  }
                }
              }, {
                text :'Start Color',
                menu :{
                  xtype :'colormenu',
                  handler : function(item, color) {
                    grid.updateNumericColorScheme(color, null, null, this.passThroughBlack)
                  }
                }
              }, {
                text :'End Color',
                menu :{
                  xtype :'colormenu',
                  handler : function(item, color) {
                    grid.updateNumericColorScheme(null, null, color, this.passThroughBlack)
                  }
                }
              }, {
                text :'Empty/Non-numeric Color',
                menu :{
                  xtype :'colormenu',
                  handler : function(item, color) {
                    grid.updateNumericColorScheme(null, color, null, this.passThroughBlack)
                  }
                }
              }]
            }
          })
        }
      }
    })

    this.on('render', function(panel) {
      if (grid.barcode != null) {
        new Ext.util.DelayedTask().delay(250, function() {
          grid.loadPlate()
        }, grid)
      }
    })
    
    RNAi.Labware.PlateMap.superclass.initComponent.call(this);
  },
  loadPlate: function(barcode) {
    var grid= this
    barcode= barcode || this.barcode
    grid.getEl().mask('Loading...', 'x-mask-loading')
    
    Ext.Ajax.request({
      url :this.plateUrl,
      timeout :600000, 
      success : function(response, opts) {
        grid.getEl().unmask()
        var plateObj = Ext.decode(response.responseText)
        if (plateObj && Ext.isArray(plateObj.plates) && plateObj.plates.length> 0) {
          var plateRecord= RNAi.buildRecord(plateObj.plates[0], 'PlateInfo')        
          if (plateRecord) {  
            grid.plateRecord= plateRecord
            this.plateDensity= {
              cols :plateRecord.data.cols,
              rows :plateRecord.data.rows
            }
            var plateRecordArray = ["id"]
            var columnConfigs= [new RNAi.Labware.PlateRowLabeller()]
            for ( var i = 1; i <= this.plateDensity.cols; i++) {
              var name = i + ""
              columnConfigs.push({
                header :name,
                width :this.colWidth || 75,
                sortable :false,
                dataIndex :name,
                renderer : function(value, metaData, record, row, col, store) { 
                  if (value == null || !Ext.isObject(value)) {
                    return value
                  }
                  var wellValue= value[grid.layerScheme]
                  
                  var fieldName= grid.getColumnModel().getDataIndex(col);                
                  var colors = grid.getColors(wellValue, record, fieldName)
                  metaData.attr = "style='background-color:" + colors[0] + ";color:" + colors[1] + ";" + (colors[2] ? "border: solid 1px " + colors[2]: "") +"'"
                
                  return wellValue
                }
              })
              plateRecordArray.push({
                name :name
              })
            }                              
            grid.reconfigure(new Ext.data.Store({
              autoLoad :true,
              data :plateObj,
              reader :new Ext.data.JsonReader({
                root :'Rows'
              }, Ext.data.Record.create(plateRecordArray))
            }), new Ext.grid.ColumnModel(columnConfigs))
            grid.store= grid.getStore()
            grid.getTopToolbar().enable()
          }                 
          if (Ext.isArray(plateObj.LayerTypes)) {
            grid.layerCombo.getStore().loadData(plateObj)
          }
        }
      },
      failure: function() {
        grid.getEl().unmask()
      },
      scope :this,
      params :{
        barcode :barcode
      }
    });
  },
  updateNumericColorScheme : function(startColor, emptyDataColor, endColor, passThroughBlack) {
    this.passThroughBlack = passThroughBlack
    if (startColor) {
      var r = startColor.substring(0, 2)
      var g = startColor.substring(2, 4)
      var b = startColor.substring(4, 6)

      this.maxColor = {
        r :parseInt(r, 16),
        g :parseInt(g, 16),
        b :parseInt(b, 16),
        a :1
      }
    }
    if (endColor) {
      var r = endColor.substring(0, 2)
      var g = endColor.substring(2, 4)
      var b = endColor.substring(4, 6)

      this.minColor = {
        r :parseInt(r, 16),
        g :parseInt(g, 16),
        b :parseInt(b, 16),
        a :1
      }
    }
    if (emptyDataColor) {
      var r = emptyDataColor.substring(0, 2)
      var g = emptyDataColor.substring(2, 4)
      var b = emptyDataColor.substring(4, 6)

      this.emptyDataColor = {
        r :parseInt(r, 16),
        g :parseInt(g, 16),
        b :parseInt(b, 16),
        a :1
      }
    }
    this.discreteColorRange = null
    this.getView().refresh(false)
  },
  setNumericColorScheme : function() {
    this.dataRange = {
      min :0,
      max :0
    }

    this.store.each( function(r) {
      this.store.fields.each( function(f) {
        var fieldName = f.name
        var fieldValue = r.get(fieldName)
        var value= fieldValue[this.layerScheme]        
        if (this.dataRange.min > value) {
          this.dataRange.min = value
        }
        if (this.dataRange.max < value) {
          this.dataRange.max = value
        }
      }, this)
    }, this)    
    this.discreteColorRange = new RNAi.Labware.DiscreteColorRange({
      maxColors :this.maxColors,
      dataRange :this.dataRange,
      options :{
        maxColor :this.maxColor,
        minColor :this.minColor,
        emptyDataColor :this.emptyDataColor,
        passThroughBlack :this.passThroughBlack
      }
    })

  },
  getColors : function(value, record, fieldName) {
    var fgColor = '#000000'
    var bgColor = '#FFFFFF'
    var bdColor = null
    switch (this.colorScheme) {
      case 'None' :
        break
      case 'Displayed Value' :
        bgColor = getColor(value)
        fgColor = getContrastColor(bgColor)
        break
      case 'Displayed Numeric' :
        if (!this.discreteColorRange) {
          this.setNumericColorScheme()
        }
        if (this.discreteColorRange) {
          bgColor = this.discreteColorRange.getCellColorHex(value)
          fgColor = getContrastColor(bgColor)
        }
        break;
    }
        
    if (Ext.isObject(this.highlightRecord)) {
      var highlightFieldName= this.highlightRecord.fieldName
      var highlightValue= this.highlightRecord.record.get(highlightFieldName)[this.layerScheme]
      
      if (this.highlightRecord.record.id == record.id && highlightFieldName== fieldName) {
        bgColor = '#EAF1DD'
        fgColor = '#000000'              
        bdColor = '#000000'
      } else if (highlightValue== value && hasLength(highlightValue) && hasLength(value)) {  
        bgColor = '#EAF1DD'
        fgColor = '#000000'
      }
    }
    return [bgColor, fgColor, bdColor]
  },
  handleWellSelection : function(highlightRecord) {
    if (this.highlightRecord && this.highlightRecord.record.id == highlightRecord.record.id && this.highlightRecord.fieldName== highlightRecord.fieldName) {
      this.highlightRecord= null
    } else {
      this.highlightRecord = highlightRecord
    }
    this.getView().refresh(false)
  },
  changeColorScheme : function(colorScheme) {
    this.colorScheme = colorScheme
    switch (this.colorScheme) {
      case 'None' :
        break;
      case 'Displayed Value' :
        break;
      case 'Displayed Numeric' :
        this.setNumericColorScheme()
        break;
    }
    this.highlightRecord= null    
    this.getView().refresh(false)
  },
  changeLayer : function(layerScheme) {
    this.layerScheme = layerScheme   
    this.discreteColorRange= null    
    this.highlightRecord= null
    this.getView().refresh(false)
  }
});

/**
 * Row Number column defintion class
 * 
 * @param {Object} config
 */
RNAi.Labware.PlateRowLabeller = function(config) {
  Ext.apply(this, config);
  if (this.rowspan) {
    this.renderer = this.renderer.createDelegate(this);
  }
}
RNAi.Labware.PlateRowLabeller.prototype = {
  header :"",
  width :23,
  sortable :false,
  fixed :true,
  menuDisabled :true,
  dataIndex :'',
  id :'pagednumberer',
  rowspan :undefined,
  
  renderer : function(v, p, record, rowIndex, colIndex, store) {
    if (this.rowspan && p) {
      p.cellAttr = 'rowspan="' + this.rowspan + '"';
    }
    var rowHeader = 0
    if (store.lastOptions && store.lastOptions.params && store.lastOptions.params.start) {
      rowHeader = store.lastOptions.params.start
    }
    if (isNaN(rowHeader)) {
      rowHeader = 0;
    }
    rowHeader = rowHeader + rowIndex + 1;
    return String.fromCharCode(new String("A").charCodeAt(0) + (rowHeader - 1));
  }
};

function getColor(v) {
  var s= v+""
  var index = 0
  for ( var i = 0; i < s.length; i++) {
    index += s.charCodeAt(i)
  }
  return COLORS[index % COLORS.length]
}

function getColorIndex(s) {
  var index = 0
  for ( var i = 0; i < s.length; i++) {
    index += s.charCodeAt(i)
  }
  return (index % COLORS.length)
}

var COLORS = ['#F0F8FF', '#FAEBD7', '#00FFFF', '#7FFFD4', '#F0FFFF', '#F5F5DC', '#FFE4C4', '#000000', '#FFEBCD', '#0000FF', '#8A2BE2', '#A52A2A', '#DEB887', '#5F9EA0', '#7FFF00', '#D2691E',
'#FF7F50', '#6495ED', '#FFF8DC', '#DC143C', '#00FFFF', '#00008B', '#008B8B', '#B8860B', '#A9A9A9', '#A9A9A9', '#006400', '#BDB76B', '#8B008B', '#556B2F', '#FF8C00', '#9932CC', '#8B0000',
'#E9967A', '#8FBC8F', '#483D8B', '#2F4F4F', '#2F4F4F', '#00CED1', '#9400D3', '#FF1493', '#00BFFF', '#696969', '#696969', '#1E90FF', '#B22222', '#FFFAF0', '#228B22', '#FF00FF', '#DCDCDC',
'#F8F8FF', '#FFD700', '#DAA520', '#808080', '#808080', '#008000', '#ADFF2F', '#F0FFF0', '#FF69B4', '#CD5C5C', '#4B0082', '#FFFFF0', '#F0E68C', '#E6E6FA', '#FFF0F5', '#7CFC00', '#FFFACD',
'#ADD8E6', '#F08080', '#E0FFFF', '#FAFAD2', '#D3D3D3', '#D3D3D3', '#90EE90', '#FFB6C1', '#FFA07A', '#20B2AA', '#87CEFA', '#778899', '#778899', '#B0C4DE', '#FFFFE0', '#00FF00', '#32CD32',
'#FAF0E6', '#FF00FF', '#800000', '#66CDAA', '#0000CD', '#BA55D3', '#9370D8', '#3CB371', '#7B68EE', '#00FA9A', '#48D1CC', '#C71585', '#191970', '#F5FFFA', '#FFE4E1', '#FFE4B5', '#FFDEAD',
'#000080', '#FDF5E6', '#808000', '#6B8E23', '#FFA500', '#FF4500', '#DA70D6', '#EEE8AA', '#98FB98', '#AFEEEE', '#D87093', '#FFEFD5', '#FFDAB9', '#CD853F', '#FFC0CB', '#DDA0DD', '#B0E0E6',
'#800080', '#FF0000', '#BC8F8F', '#4169E1', '#8B4513', '#FA8072', '#F4A460', '#2E8B57', '#FFF5EE', '#A0522D', '#C0C0C0', '#87CEEB', '#6A5ACD', '#708090', '#708090', '#FFFAFA', '#00FF7F',
'#4682B4', '#D2B48C', '#008080', '#D8BFD8', '#FF6347', '#40E0D0', '#EE82EE', '#F5DEB3', '#FFFFFF', '#F5F5F5', '#FFFF00', '#9ACD32']

var COLORS1 = ['#0000cc', '#330066', '#660000', '#6600cc', '#990066', '#cc0000', '#cc00cc', '#ff0066', '#003300', '#0033cc', '#333366', '#663300', '#6633cc', '#993366', '#cc3300', '#cc33cc',
'#ff3366', '#006600', '#0066cc', '#336666', '#666600', '#6666cc', '#996666', '#cc6600', '#cc66cc', '#ff6666', '#009900', '#0099cc', '#339966', '#669900', '#6699cc', '#999966', '#cc9900',
'#cc99cc', '#ff9966', '#00cc00', '#00cccc', '#33cc66', '#66cc00', '#66cccc', '#99cc66', '#cccc00', '#cccccc', '#ffcc66', '#00ff00', '#00ffcc', '#33ff66', '#66ff00', '#66ffcc', '#99ff66',
'#ccff00', '#ccffcc', '#ffff66']

function getContrastColor(color) {
  var hexString = (color + '').replace(/[^a-f0-9]/gi, '');
  var dec = parseInt(hexString, 16);  
  return (dec > 0xffffff / 2) ? '000000' : 'ffffff';
}
