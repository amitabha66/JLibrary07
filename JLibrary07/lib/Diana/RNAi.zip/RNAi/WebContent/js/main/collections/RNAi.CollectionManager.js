
RNAi.CollectionManager = Ext.extend(Ext.Panel, {
  layout:'border' ,
  split:true, 
  border: false,
  collection_id: '',
  initComponent:function() {
    var collectionPanel = this;
    this.items=[(this.parameterPanel= new RNAi.CollectionParameter({
      region: 'center',
      mgr: this
    })),(this.optionsPanel= new RNAi.CollectionOptions({
      region: 'south',
      split:true,
      height: 300,
      mgr: this
    }))]       
    collectionPanel.parameterPanel.getSelectionModel().on('rowselect', function(sm, row, rec) {
      collectionPanel.collection_id = rec.data.collection_id;
      collectionPanel.optionsPanel.store.removeAll()
      collectionPanel.optionsPanel.store.load({
        params:{               
          req:'amgen.ri.rnai.screener.CollectionResponder',                
          action_id: 'get-collection-members',
          collection_id:collectionPanel.collection_id                           
        }
      })
      collectionPanel.parameterPanel.updateButtons()      
    })
    collectionPanel.parameterPanel.on('afteredit', this.updateCollection.createDelegate(this))
    
    RNAi.CollectionManager.superclass.initComponent.call(this);     
  },
  createNewCollection: function() {         
    Ext.Ajax.request({
      url:'/RNAi/rnai.go', 
      success: function(response){   
        RNAi.checkForErrorResponse(response, 'Error Creating Collection')
        
        this.parameterPanel.store.reload({
          callback: function() {
            var jResponse= RNAi.decode(response)
            var collectionRecord= this.parameterPanel.store.getById(jResponse.collectionID)
            if (!RNAi.isRecordType(collectionRecord, 'Collection')) {     
              return
            }
            var rowIndex= this.parameterPanel.store.indexOf(collectionRecord)
            this.parameterPanel.getSelectionModel().selectRow(rowIndex)
            this.parameterPanel.startEditing(rowIndex, 0)
          }, 
          scope: this
        })
      },
      failure: function(response){
        Ext.MessageBox.show({
          title: 'Create Collection',
          msg: 'Unable to create new collection.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.screener.CollectionResponder',
        action_id: 'create-collection'
      }
    })          
  },
  deleteCollection: function() {
    var collectionRecord = this.parameterPanel.getSelectionModel().getSelected();
    if (!RNAi.isRecordType(collectionRecord, 'Collection')) {      
      return
    }
    Ext.Msg.confirm('Confirm', 'Delete collection '+collectionRecord.data.collection_name, function(btn){
      if (btn == 'yes'){
        Ext.Ajax.request({
          url:'/RNAi/rnai.go', 
          success: function(response){   
            RNAi.checkForErrorResponse(response, 'Error Deleting Collection')
            this.parameterPanel.store.reload()
          },
          failure: function(response){
            Ext.MessageBox.show({
              title: 'Delete Collection',
              msg: 'Unable to delete collection.',
              buttons: Ext.MessageBox.OK,
              icon: Ext.MessageBox.ERROR
            })
          },
          scope: this,
          params: {
            req:'amgen.ri.rnai.screener.CollectionResponder',
            action_id: 'delete-collection',
            collection_id: collectionRecord.data.collection_id                                   
          }
        })
      }
    }, this)      
  },
  editCollectionMembers: function() {
    var memberEditMode= this.optionsPanel.editMode
    if (memberEditMode) {
      this.updateCollection()
    }
    this.optionsPanel.setEditMode(!memberEditMode)
    this.parameterPanel.updateButtons()      
  },
  updateCollection: function() {
    var collectionRecord= this.parameterPanel.getSelectionModel().getSelected();
    if (!RNAi.isRecordType(collectionRecord, 'Collection')) {
      return
    }
    var members= this.optionsPanel.getMembers()
        
    Ext.Ajax.request({
      url:'/RNAi/rnai.go', 
      success: function(response){
        RNAi.checkForErrorResponse(response, 'Error Updating Collection')
      },
      failure: function(response){
        Ext.MessageBox.show({
          title: 'Update Collection',
          msg: 'Unable to update collection.',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.screener.CollectionResponder',
        action_id: 'update-collection',
        collection_id: collectionRecord.data.collection_id,
        collection_name: collectionRecord.data.collection_name,
        collection_desc: collectionRecord.data.collection_desc,
        collection_members: members.join(',')
      }
    })      
  }
}); 


RNAi.CollectionParameter = Ext.extend(Ext.grid.EditorGridPanel, {
  initComponent:function() {     
    var config = {   
      autoExpandColumn: 'collection_desc',
      loadMask: {
        msg: 'Loading Collections'
      },
      store: new Ext.data.Store({
        url: '/RNAi/rnai.go',       
        reader :new Ext.data.JsonReader({
          idProperty: 'collection_id',
          root :"collection"
        }, RNAi.Record.Collection),
        sortInfo: {
          field: 'collection_id',
          direction: 'ASC' 
        }        
      }),
      columns:[{
        header:"Collection Name",
        width:200,
        sortable:true,
        dataIndex:'collection_name',                
        editor: new Ext.form.TextField({
          allowBlank: false,
          selectOnFocus:true
        })
      },{
        header:"Created By",
        dataIndex:'created_by_name',                
        editable: false
      },{
        header:"Created",
        xtype: 'datecolumn',
        width:75,
        sortable:true,
        dataIndex:'created',                
        editable: false
      },{
        id:'collection_desc',                
        header:"Description",
        sortable:true,
        dataIndex:'collection_desc',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      }],
      sm: new Ext.grid.RowSelectionModel({
        singleSelect: true
      }),
      buttons:[{
        text: 'New',
        iconCls: 'ix-v0-16-table_add',
        handler: this.mgr.createNewCollection.createDelegate(this.mgr)
      },(this.editMembersButton= new Ext.Button({
        text: 'Edit Members',
        iconCls: 'ix-v0-16-table_edit',
        handler: this.mgr.editCollectionMembers.createDelegate(this.mgr, null, false)
      })), (this.deleteCollectionButton= new Ext.Button({
        text: 'Delete',
        iconCls: 'ix-v0-16-table_delete',
        handler: this.mgr.deleteCollection.createDelegate(this.mgr, null, false)
      }))]
    }
    Ext.apply(this, Ext.apply(this.initialConfig, config))
    RNAi.CollectionParameter.superclass.initComponent.apply(this, arguments);
  },
  onRender:function() {
    RNAi.CollectionParameter.superclass.onRender.apply(this, arguments);
    // load the store
    this.store.load.defer(50, this.store, [{
      params:{                
        req:'amgen.ri.rnai.screener.CollectionResponder',                
        action_id: 'get-collection'                           
      }
    }])
    this.updateButtons()
  },
  updateButtons: function() {
    var collectionSelected= (this.mgr.parameterPanel.getSelectionModel().getCount()> 0)
    var memberEditMode= this.mgr.optionsPanel.editMode   
    
    this.deleteCollectionButton.setDisabled(!collectionSelected)
    this.editMembersButton.setDisabled(!collectionSelected)
    if (!collectionSelected) {
      this.editMembersButton.setText('Update Members')
    } else {
      this.editMembersButton.setText((memberEditMode ? 'Save Members' : 'Update Members'))
    }
  }   

});

RNAi.CollectionOptions = Ext.extend(Ext.form.FormPanel, {
  title: 'Member Parent Plates',
  layout: 'border',
  initComponent:function() {
    this.items= (this.field= new Ext.form.TextArea({
      region: 'center',
      readOnly: true
    }))    
    this.store= new Ext.data.JsonStore({
      id:'plate_id',
      root:'members',
      url:'/RNAi/rnai.go',
      fields:[{
        name:'member'
      }]
    })
    this.store.on("load", this.addMembers.createDelegate(this));
    this.store.on("clear", this.clearMembers.createDelegate(this));      
    
    this.store.on('beforeload', function() {
      this.getEl().mask('Loading...', 'x-mask-loading')
    }, this)

    this.store.on('load', function() {
      this.getEl().unmask()
    }, this)

    this.store.on('exception', function() {
      this.getEl().unmask()
    }, this)
    
    RNAi.CollectionOptions.superclass.initComponent.apply(this, arguments);
  },
  addMembers: function(store, records) {
    this.field.setValue(RNAi.joinFields(records, 'member', '\n'))    
    this.setEditMode(false)
  },
  clearMembers: function() {
    this.field.setValue('')  
    this.setEditMode(false)
  },
  setEditMode: function(editMode) {
    this.editMode= editMode
    this.field.setReadOnly(!this.editMode)
    
    if (this.editMode) {
      this.field.el.removeClass('x-collectionedit-off')      
      this.field.focus(true, true)
    } else {
      this.field.el.addClass('x-collectionedit-off')
    }
  },
  getMembers: function() {
    return this.field.getValue().split(/[\s,;]+/)
  }
});
