/**
 * Creates a data structure for Gene records
 */
RNAi.Record.Gene = Ext.data.Record.create([
  {
    name: 'gene_id',
    type: 'integer'
  },{
    name: 'gene_mixture_id',
    type: 'integer'
  }, {
    name: 'entrezgene_id',
    type: 'integer'
  }, {
    name: 'entrezgene_ids'
  }, {
    name: 'gene_name'
  }, {
    name: 'gene_names'
  }, {
    name: 'gene_symbol'
  }, {
    name: 'gene_symbols'
  }, {
    name: 'alias'
  }, {
    name: 'gene_type'
  }, {
    name: 'description'
  }, {
    name: 'organism'
  }, {
    name: 'organism_id'
  }, {
    name: 'is_mixture',
    type: 'boolean',
    defaultValue: false
  }, {
    name: 'exp_rnai_count',
    type: 'integer',
    defaultValue: 0
  }, {
    name: 'rnai_count',
    type: 'integer',
    defaultValue: 0
  }, {
    name: 'exp_count',
    type: 'integer',
    defaultValue: 0
  }, {
    name: 'rnai'
  }
])

RNAi.Record.Gene.prototype.recordType = 'Gene'
