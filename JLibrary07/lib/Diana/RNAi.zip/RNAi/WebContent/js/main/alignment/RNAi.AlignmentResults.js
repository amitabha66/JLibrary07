
RNAi.AlignmentResults = Ext.extend(Ext.Panel, {
  layout:'border',
  initComponent:function() {
    var panel = this    
    this.border= false    
    
    this.items=[(this.alignmentView= new RNAi.AlignmentView({
      region: 'center',
      store: new Ext.data.Store({
        reader: new Ext.data.JsonReader({
          idProperty: 'rnai_id',
          root: 'hits'
        }, RNAi.Record.Alignment),
        data: {
          hits: []
        }
      })
    })),
    (this.rnaiGrid= new RNAi.RNAISummaryGrid({
      title: 'RNAi',
      height: 0.6 * (Ext.lib.Dom.getViewHeight()- 150),
      region: 'south',
      autoExpandColumn: 'sequence',
      split: true,
      showAlignment: true,
      store: new Ext.data.Store({
        reader: new Ext.data.JsonReader({
          idProperty: 'rnai_id',
          root: 'rnai'
        }, RNAi.Record.RNAi),
        data: {
          rnai: []
        }
      })
    }))
    ]    
    
    this.alignmentView.on('nodeclick', function(view, record) {
      var rnaiRecord= panel.rnaiGrid.getStore().getById(record.id)
      var rowIndex= panel.rnaiGrid.getStore().indexOf(rnaiRecord)
      panel.rnaiGrid.getSelectionModel().selectRow(rowIndex, false)
      panel.rnaiGrid.getView().getRow(rowIndex).scrollIntoView()   
    })
    
    //When rendered, either load the provided records or do the search        
    this.on('render', function(panel) {
      new Ext.util.DelayedTask().delay(100, function() {
        panel.handleLoad()
      })
    })    
    
    
    
    RNAi.AlignmentResults.superclass.initComponent.call(this);     
  },
  handleLoad: function() {
    var panel= this    
    if (!Ext.isString(this.targetID)) {
      RNAi.showErrorResponse('Invalid target sequence')
    }
    if (!Ext.isArray(this.rnaiRecords) || this.rnaiRecords.length==0 || !Ext.isRecord(this.rnaiRecords[0])) {
      RNAi.showErrorResponse('Invalid RNAi records')
    }
    var rnaiIDs= []
    
    for(var i=0; i<this.rnaiRecords.length; i++) {
      rnaiIDs.push(this.rnaiRecords[i].data.compound_id)
    }
    
    panel.getEl().mask('Loading...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.getEl().unmask()        
        if (!RNAi.checkForErrorResponse(response)) {
          var obj = Ext.decode(response.responseText);       
          panel.loadResults(obj)
        }
      },
      failure: function(response) {
        panel.getEl().unmask()

        RNAi.checkForErrorResponse(response)
      },
      params: {
        req: 'amgen.ri.rnai.search.AlignmentResponder',
        target: panel.targetID,
        rnai_ids:rnaiIDs.join(',')
      }
    })    
  },
  loadResults: function(results) {
    if (Ext.isObject(results)) {
      if (results.hits) {
        this.alignmentView.store.loadData(results)
      }
      if (results.rnai) {
        this.rnaiGrid.store.loadData(results)
      }
    }
  },
  getRNAIRecords: function() {
    return this.rnaiGrid.getStore().getRange()
  }
}); 
