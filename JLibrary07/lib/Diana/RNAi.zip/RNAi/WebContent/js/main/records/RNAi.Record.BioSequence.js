/**
 * Creates a data structure for BioSequence records
 */
RNAi.Record.BioSequence= Ext.data.Record.create([
{
  name:'seq_id'
}, {
  name:'description'
}, {
  name:'type'
}, {
  name:'length',
  type:'integer'
}, {
  name:'dataset'
}, {
  name:'gene_id',
  type:'integer'
}, {
  name:'entrezgene_id',
  type:'integer'
}, {
  name:'sequence'
}, {
  name:'organism'
} ,{
  name:'organism_id',
  type:'integer'
} ,{
  name:'organism_term_id',
  type:'integer'
}              
])

RNAi.Record.BioSequence.prototype.recordType= 'BioSequence'
