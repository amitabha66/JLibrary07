/**
 * Encapsulates & abstracts the main Tab Panel loading into a single loader class
 * 
 * 
 * @param {Mixed} config 
 *  
 *  The config is used to indicate the type of tab panel to create and provide 
 *  any parameters needed to create the panel
 *  
 *  If this is a String, it is assumed to be the type. 
 *  Otherwise, the config object should include the tab panel
 *  as the field type with any additions fields needed to create the panel
 *  
 *  This also exposes 2 events:
 *  
 *  beforeload: Called before the tab panel is created. This loader object is included in the function call. If this returns false, the panel is not created
 *  load: Called after the tab panel is created. Passed to the handler is this loader object and the if the tab panel was successfully created, the new tab panel. If the
 *  creation failed, no tab panel is passed
 * 
 */
RNAi.TabPanelLoader = Ext.extend(Ext.util.Observable, {
  constructor: function(config) {
    if (Ext.isString(config)) {
      config = {
        type: config
      }
    }
    Ext.applyIf(this, config)
    Ext.applyIf(this, {
      tabParent: Ext.getCmp('main-tab-panel')
    })
    this.addEvents(
            "beforeload",
            "load"
            )
    //defines standard panel loaders
    this.loadHandlers = {
      HELP: this.loadHelpPanel.createDelegate(this),
      SCREENERDATALOAD: this.loadScreenerDataLoadPanel.createDelegate(this),
      SHRNADATALOAD: this.loadShrnaDataLoadPanel.createDelegate(this),
      SCREENERDATAAPPEND: this.loadScreenerDataAppendPanel.createDelegate(this),
      GETEXPERIMENTS: this.loadGetExperimentsPanel.createDelegate(this),
      GETANNOTATIONGROUP: this.loadGetAnnotationGroupPanel.createDelegate(this),
      GETANNOTATION: this.loadGetAnnotationsPanel.createDelegate(this),
      COLLECTIONS: this.loadCollectionsPanel.createDelegate(this),
      SEARCH: this.loadSearchPanel.createDelegate(this),
      PLATEUTILITIES: this.loadPlateUtilitiesPanel.createDelegate(this),
      ALIGN: this.loadAlignmentPanel.createDelegate(this),
      PLATEMAP: this.loadPlateMapPanel.createDelegate(this),
      EXPERIMENTS: this.loadRNAiExperimentsSearchResults.createDelegate(this),
      ALL_EXPERIMENTS: this.loadAllRNAiExperimentsSearchResults.createDelegate(this),
      MY_EXPERIMENTS: this.loadMyRNAiExperimentsSearchResults.createDelegate(this),
      USER_EXPERIMENTS: this.loadUserRNAiExperimentsSearchResults.createDelegate(this),
      ANALYZE_FILE: this.analyzeFile.createDelegate(this),
      RNAIWEBPLAYER: this.openRNAiWebPlayer.createDelegate(this)
    }
    RNAi.TabPanelLoader.superclass.constructor.call(this, config)
  },
  load: function(config) {
    if (this.fireEvent('beforeload', this) !== false) {
      if (Ext.isFunction(this.loadHandlers[this.type])) {
        var loadResp = this.loadHandlers[this.type](config)
        //
        //If loadResp is false or an Object, fire the event
        //Otherwise, it has an Ajax call, so let that handler fire the event
        //
        if (loadResp === false) {
          this.fireEvent('load', this)
        } else if (Ext.isObject(loadResp)) {
          this.fireEvent('load', this, loadResp)
        }
      } else {
        this.fireEvent('load', this)
      }
    }
  },
  loadAnalysis: function(config) {
    var me = this
    if (this.fireEvent('beforeload', this) !== false) {
      if (config.node.attributes.analysis == 'Genetic Interaction') {
        me.showProgress('Loading ' + config.node.attributes.analysis + '...', 'Please wait...')
        Ext.Ajax.request({
          url: '/RNAi/rnai.go',
          params: {
            req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
            rx: 'GI_RESULTS',
            analysisKey: config.node.id
          },
          success: function(response, opts) {
            Ext.Msg.hide()
            if (RNAi.checkForErrorResponse(response)) {
              return
            }
            var giResults = Ext.decode(response.responseText)

            if (!Ext.isArray(giResults.results)) {
              RNAi.showErrorResponse('No results returned', 'Genetic Interaction')
              return
            }
            var giResultGrids = []
            for (var i = 0; i < giResults.results.length; i++) {
              var results = giResults.results[i]
              if (results && Ext.isArray(results.columns)) {
                var dataID = results.dataID
                var experimentRecordA = new RNAi.Record.Experiment(results.expA)
                var experimentRecordB = new RNAi.Record.Experiment(results.expB)
                var columns = [{
                    header: 'Gene',
                    dataIndex: 'gene_symbol'
                  }, {
                    header: 'Organism',
                    dataIndex: 'organism'
                  }, {
                    header: 'Entrez Gene ID',
                    dataIndex: 'entrezgene_id',
                    hidden: true
                  }, {
                    header: 'RNAi Count',
                    dataIndex: 'rnai_count',
                    align: 'right',
                    width: 75,
                    hidden: true
                  }, {
                    header: 'Experiment Count',
                    dataIndex: 'exp_count',
                    align: 'right',
                    width: 75,
                    hidden: true
                  }]
                columns = columns.concat(results.columns)

                var giFieldsRecord = Ext.data.Record.create(results.fields);
                giFieldsRecord.prototype.recordType = 'Gene'

                giFieldsRecord.prototype.fields.addAll(RNAi.Record.Gene.prototype.fields.items);
                giResultGrids.push(new RNAi.GeneSearchResults({
                  region: 'center',
                  title: (giResults.results.length > 1 ? experimentRecordA.data.experiment_name + ' | ' + experimentRecordB.data.experiment_name : null),
                  tabTip: experimentRecordA.data.experiment_name + ' | ' + experimentRecordB.data.experiment_name,
                  callSearch: true,
                  columnDefs: columns,
                  fields: giFieldsRecord,
                  dataID: dataID,
                  addRowActions: [{
                      groups: [{
                          groupName: 'Manage Analysis',
                          columns: 2,
                          rowActions: [{
                              text: 'Delete Analysis',
                              iconCls: 'ix-v0-16-gear_delete',
                              selectionRequired: false,
                              cb: function(grid) {
                                me.deleteAnalysis(results.giID, grid.findParentByType('window'))
                              }
                            }]
                        }]
                    }],
                  handleSearch: function(values) {
                    this.contentGrid.getStore().load()
                  }
                }))
              }
            }
            switch (giResultGrids.length) {
              case 0:
                RNAi.showErrorResponse('No results returned', 'Genetic Interaction')
                return
              case 1:
                new Ext.Window({
                  title: 'Genetic Interaction: ' + (giResultGrids[0].tabTip),
                  layout: 'border',
                  maximizable: true,
                  closeable: true,
                  resizable: true,
                  items: giResultGrids[0],
                  width: Ext.getBody().getWidth() * 0.75,
                  height: Ext.getBody().getHeight() * 0.75
                }).show()
                break
              default:
                new Ext.Window({
                  title: 'Genetic Interaction',
                  layout: 'border',
                  maximizable: true,
                  closeable: true,
                  resizable: true,
                  items: new Ext.TabPanel({
                    region: 'center',
                    activeTab: 0,
                    resizeTabs: true,
                    minTabWidth: 115,
                    tabWidth: 135,
                    enableTabScroll: true,
                    defaults: {
                      autoScroll: true
                    },
                    plugins: new Ext.ux.TabCloseMenu(),
                    items: giResultGrids
                  }),
                  width: Ext.getBody().getWidth() * 0.75,
                  height: Ext.getBody().getHeight() * 0.75
                }).show()
            }
          },
          failure: function() {
            Ext.Msg.hide()
          },
          scope: this
        })
      } else {
        new RNAi.Dialog.LogMonitor({
          title: (Ext.isObject(config) ? config.node.text : 'OGA Analysis Monitor'),
          width: Ext.getBody().getWidth() * 0.75,
          height: Ext.getBody().getHeight() * 0.75,
          noScroll: true,
          analysisKey: this.type,
          scope: this
        }).show()
      }
      this.fireEvent('load', this)
    }
  },
  deleteAnalysis: function(giID, analysisWindow) {
    Ext.MessageBox.confirm('Confirm', 'Are you sure you want to delete the current analysis?',
            function(btn) {
              if (btn != 'yes') {
                return
              }
              if (analysisWindow) {
                analysisWindow.close()
              }
              this.closeAnalysisNode()
              var params = Ext.apply({}, {
                req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
                rx: 'GI_DELETE',
                analysisKey: giID
              }
              )
              RNAi.showMessage('Delete Analysis', 'Deleting...')

              Ext.Ajax.request({
                url: '/RNAi/rnai.go',
                success: function(response, options) {
                  if (!RNAi.checkForErrorResponse(response, 'Error Deleting Analysis')) {
                  }
                },
                failure: function(response, options) {
                  RNAi.checkForErrorResponse(response, 'Error Deleting Analysis')
                },
                scope: this,
                params: params
              })
            },
            this)
  },
  closeAnalysisNode: function() {
    var analysisNode = Ext.getCmp('main-tree-panel').getNodeById('analysis_results')
    if (analysisNode) {
      analysisNode.collapse(true)
    }
  },
  loadHelpPanel: function() {
    var strUrl = "https://myteams.amgen.com/sites/rnai/RNAi%20Help%20Documents/Forms/RNAi%20Help%20Documents.aspx"

    var tab = this.tabParent.add({
      title: 'RNAi Help',
      iconCls: 'ix-v0-16-help2 tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: strUrl
      }
    });

    this.tabParent.setActiveTab(tab);
    return tab
    return tab
  },
  analyzeFile: function() {
    new RNAi.ExcelAnalysisDialog().show()
  },
  openRNAiWebPlayer: function() {
    //var strUrl= "http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/RNAi_WebPlayer"       
    var strUrl = "http://tspotfireweb.amgen.com/SpotfireWeb/ViewAnalysis.aspx?file=/Lead%20Discovery/siRNA/RNAi_WebPlayer2"


    var tab = this.tabParent.add({
      title: 'RNAi WebPlayer Visualization',
      iconCls: 'x-rnai-16-spotfire tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: strUrl
      }
    });

    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the Screener Load panel
   */
  loadScreenerDataLoadPanel: function() {
    var title = 'Screener Data Load'
    if (this.findTabByTitle(title, true)) {
      return
    }

    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      scope: this,
      success: function(response) {
        var form_items = Ext.util.JSON.decode(response.responseText).items;
        var tab = this.tabParent.add({
          title: title,
          iconCls: 'ix-v0-16-import2',
          closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
          layout: 'border',
          items: new RNAi.ScreenerDataLoad({
            region: 'center',
            form_items: form_items

          })
        });
        this.tabParent.setActiveTab(tab);
        this.fireEvent('load', this, tab)
      },
      failure: function() {
        Ext.MessageBox.show({
          title: 'Failed to create Experiment load form',
          msg: 'Failed to create Experiment load form',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
        this.fireEvent('load', this)
      },
      params: {
        req: 'amgen.ri.rnai.screener.ScreenerResponder',
        action_id: 'exp-load-form-items'
      }
    });
  },
  /**
   * Load the Screener Append panel
   */
  loadScreenerDataAppendPanel: function() {
    var title = 'Screener Data Append'
    if (this.findTabByTitle(title, true)) {
      return
    }

    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      scope: this,
      success: function(response) {
        var form_items = Ext.util.JSON.decode(response.responseText).items;
        var tab = this.tabParent.add({
          title: title,
          iconCls: 'ix-v0-16-import2',
          closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
          layout: 'border',
          items: new RNAi.ScreenerDataAppend({
            region: 'center',
            form_items: form_items

          })
        });
        this.tabParent.setActiveTab(tab);
        this.fireEvent('load', this, tab)
      },
      failure: function() {
        Ext.MessageBox.show({
          title: 'Failed to create Experiment Append form',
          msg: 'Failed to create Experiment Append form',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
        this.fireEvent('load', this)
      },
      params: {
        req: 'amgen.ri.rnai.screener.ScreenerResponder',
        action_id: 'exp-append-form-items'
      }
    });
  },
  /**
   * Loads the SHRNA Data Load panel
   */
  loadShrnaDataLoadPanel: function() {
    var title = 'shRNA Data Load'
    if (this.findTabByTitle(title, true)) {
      return
    }
    var tab = this.tabParent.add({
      title: title,
      iconCls: 'ix-v0-16-import2',
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      items: new RNAi.ShrnaDataLoad({
        region: 'center',
        form_items: {
          "items": [{
              "xtype": "fieldset",
              "columnWidth": 0.5,
              "title": "Experiment Information",
              "items": [{
                  "hiddenName": "import_data_file",
                  "width": 300,
                  "name": "import_data_file",
                  "xtype": "fileuploadfield",
                  "emptyText": "Select a file",
                  "fieldLabel": "Experiment File",
                  "buttonText": "Browse"
                }, {
                  "minChars": "2",
                  "store": {
                    "id": "id",
                    "baseParams": {
                      "action_id": "get-rtf",
                      "input": "",
                      "req": "amgen.ri.rnai.screener.ScreenerResponder",
                      "inputtype": "cellline"
                    },
                    "root": "term",
                    "xtype": "jsonstore",
                    "autoLoad": true,
                    "url": "/RNAi/rnai.go",
                    "fields": ["id", "name"]
                  },
                  "allowBlank": false,
                  "emptyText": "Select ",
                  "forceSelection": true,
                  "fieldLabel": "Cell Line",
                  "editable": true,
                  "mode": "remote",
                  "hiddenName": "AN__Cell_SPACE_Line",
                  "displayField": "name",
                  "xtype": "combo",
                  "valueField": "id",
                  "typeAhead": true,
                  "triggerAction": "all",
                  "autoLoad": true,
                  "selectOnFocus": true
                }, {
                  "hiddenName": "AN__Collection",
                  "store": {
                    "id": "collection_id",
                    "baseParams": {
                      "action_id": "get-collection",
                      "req": "amgen.ri.rnai.screener.CollectionResponder"
                    },
                    "root": "collection",
                    "xtype": "jsonstore",
                    "autoLoad": true,
                    "url": "/RNAi/rnai.go",
                    "fields": ["collection_id", "collection_name"]
                  },
                  "displayField": "collection_name",
                  "xtype": "combo",
                  "valueField": "collection_id",
                  "emptyText": "Select ",
                  "triggerAction": "all",
                  "fieldLabel": "Collection",
                  "editable": false,
                  "selectOnFocus": true
                }]
            }
          ]/*
           {
           }
           "items":[{
           "name":"experiment_name",
           "xtype":"textfield",
           "fieldLabel":"Experiment Name"
           },{
           "title":"Experiment Information",
           "items":[{
           "hiddenName":"import_data_file",
           "width":300,
           "name":"import_data_file",
           "xtype":"fileuploadfield",
           "emptyText":"Select a file",
           "fieldLabel":"Experiment File",
           "buttonText":"Browse"
           }],
           "xtype":"fieldset",
           "columnWidth":0.5,
           "border":false
           },{
           "title":"Experiment Information",
           "items":[{
           "minChars":"2",
           "store":{
           "id":"id",
           "baseParams":{
           "action_id":"get-rtf",
           "input":"",
           "req":"amgen.ri.rnai.screener.ScreenerResponder",
           "inputtype":"cellline"
           },
           "root":"term",
           "xtype":"jsonstore",
           "autoLoad":true,
           "url":"/RNAi/rnai.go",
           "fields":["id","name"]
           },
           "allowBlank":false,
           "emptyText":"Select ",
           "forceSelection":true,
           "fieldLabel":"Cell Line",
           "editable":true,
           "mode":"remote",
           "hiddenName":"AN__Cell_SPACE_Line",
           "displayField":"name",
           "xtype":"combo",
           "valueField":"id",
           "typeAhead":true,
           "triggerAction":"all",
           "autoLoad":true,
           "selectOnFocus":true
           },{
           "hiddenName":"AN__Collection",
           "store":{
           "id":"collection_id",
           "baseParams":{
           "action_id":"get-collection",
           "req":"amgen.ri.rnai.screener.CollectionResponder"
           },
           "root":"collection",
           "xtype":"jsonstore",
           "autoLoad":true,
           "url":"/RNAi/rnai.go",
           "fields":["collection_id","collection_name"]
           },
           "displayField":"collection_name",
           "xtype":"combo",
           "valueField":"collection_id",
           "emptyText":"Select ",
           "triggerAction":"all",
           "fieldLabel":"Collection",
           "editable":false,
           "selectOnFocus":true
           }],
           "xtype":"fieldset",
           "columnWidth":0.5,
           "border":false
           }],
           "layout":"column",
           "xtype":"fieldset"
           }]*/
        }

      })
    });
    this.tabParent.setActiveTab(tab);

    return


    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      scope: this,
      success: function(response) {
        var form_items = Ext.util.JSON.decode(response.responseText).items;
        var tab = this.tabParent.add({
          title: title,
          closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
          layout: 'border',
          items: new RNAi.ShrnaDataLoad({
            region: 'center',
            form_items: form_items

          })
        });
        this.tabParent.setActiveTab(tab);
        this.fireEvent('load', this, tab)
      },
      failure: function() {
        Ext.MessageBox.show({
          title: 'Failed to create Experiment load form',
          msg: 'Failed to create Experiment load form',
          buttons: Ext.MessageBox.OK,
          icon: Ext.MessageBox.ERROR
        })
        this.fireEvent('load', this)
      },
      params: {
        req: 'amgen.ri.rnai.screener.ScreenerResponder',
        action_id: 'shrna-exp-load-form-items'
      }
    });
  },
  /**
   * Loads Experiments Panel
   */
  loadGetExperimentsPanel: function() {
    var title = 'Experiments'
    if (this.findTabByTitle(title, true)) {
      return
    }

    var tab = this.tabParent.add({
      title: title,
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      items: new RNAi.Experiments({
        region: 'center'
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the Annotation Group panel
   */
  loadGetAnnotationGroupPanel: function() {
    var title = 'Annotation Group'
    if (this.findTabByTitle(title, true)) {
      return
    }

    var tab = this.tabParent.add({
      title: title,
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      items: new RNAi.AnnotationGroup({
        region: 'center'
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the annotations panel
   */
  loadGetAnnotationsPanel: function() {
    var title = 'Annotation'
    if (this.findTabByTitle(title, true)) {
      return
    }

    var tab = this.tabParent.add({
      title: title,
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      items: new RNAi.Annotation({
        region: 'center'
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the collections panel
   */
  loadCollectionsPanel: function() {
    var title = 'Collection Manager'
    if (this.findTabByTitle(title, true)) {
      return
    }

    var tab = this.tabParent.add({
      title: title,
      iconCls: 'ix-v0-16-tables_edit tab-icon-bg-pos',
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      items: new RNAi.CollectionManager({
        region: 'center'
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the Search Panel
   */
  loadSearchPanel: function() {
    var title = 'Search'
    if (this.findTabByTitle(title, true)) {
      return
    }

    var tab = this.tabParent.add({
      title: title,
      iconCls: 'ix-v0-16-view tab-icon-bg-pos',
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'fit',
      items: new RNAi.SearchFormPanel({
        scope: this,
        gene: {
          handlers: [{
              text: 'Genes Targeted by RNAi',
              iconCls: 'rg-entity-gene',
              handler: function(formPanel) {
                this.loadGeneSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'RNAi Experiments',
              iconCls: 'ix-v0-16-text_code_colored',
              handler: function(formPanel) {
                this.loadRNAiExperimentsSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'Registered RNAi Molecules',
              iconCls: 'ix-v0-16-pawn_glass_red',
              handler: function(formPanel) {
                this.loadRNAiSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'Registered Plates',
              iconCls: 'ix-v0-16-table',
              handler: function(formPanel) {
                this.loadPlateSearchResults(formPanel.getForm().getValues())
              }
            }]
        },
        handlers: {
          searchByCollection: function(collectionRecord) {
            if (RNAi.isRecordType(collectionRecord, 'Collection')) {
              this.loadRNAiExperimentsSearchResults({
                query: collectionRecord.id,
                searchBy: 'COLLECTION_IDS'
              }, "Experiments (" + collectionRecord.data.collection_name + ")")
            }
          },
          searchGenesByCollection: function(collectionRecord) {
            if (RNAi.isRecordType(collectionRecord, 'Collection')) {
              this.loadGeneSearchResults({
                query: collectionRecord.id,
                searchBy: 'COLLECTION_IDS'
              }, "Genes (" + collectionRecord.data.collection_name + ")")
            }
          },
          searchRNAIByCollection: function(collectionRecord) {
            if (RNAi.isRecordType(collectionRecord, 'Collection')) {
              this.loadRNAiSearchResults({
                query: collectionRecord.id,
                searchBy: 'COLLECTION_IDS'
              }, "RNAi (" + collectionRecord.data.collection_name + ")")
            }
          },
          searchByCellLine: function(cellLineAnnotationRecord) {
            if (RNAi.isRecordType(cellLineAnnotationRecord, 'Annotation')) {
              this.loadRNAiExperimentsSearchResults({
                query: cellLineAnnotationRecord.id,
                searchBy: 'CELLLINE_RTF_TERMID'
              }, "Experiments (" + cellLineAnnotationRecord.data.annotation_name + ")")
            }
          },
          searchByTissue: function(cellLineAnnotationRecord) {
            if (RNAi.isRecordType(cellLineAnnotationRecord, 'Annotation')) {
              this.loadRNAiExperimentsSearchResults({
                query: cellLineAnnotationRecord.data.tissue_term_id,
                searchBy: 'TISSUE_RTF_TERMID'
              }, "Experiments (" + cellLineAnnotationRecord.data.tissue_attribute + ")")
            }
          }
        }
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /**
   * Loads the Plate Utilities Panel
   */
  loadPlateUtilitiesPanel: function() {
    var title = 'Plate Utilities'
    if (this.findTabByTitle(title, true)) {
      return
    }
    var tab = this.tabParent.add({
      title: title,
      iconCls: 'ix-v0-16-table_view tab-icon-bg-pos',
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'fit',
      items: new RNAi.PlateUtilitiesForm({
        scope: this,
        gene: {
          handlers: [{
              text: 'Search For Genes',
              handler: function(formPanel) {
                this.loadGeneSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'Search For RNAi',
              handler: function(formPanel) {
                this.loadRNAiSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'Search For Plates',
              handler: function(formPanel) {
                this.loadPlateSearchResults(formPanel.getForm().getValues())
              }
            }, {
              text: 'Search For Experiments',
              handler: function(formPanel) {
                this.loadRNAiExperimentsSearchResults(formPanel.getForm().getValues())
              }
            }]
        }
      })
    });
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadPlateLineageResults: function(barcodes) {
    var tab = this.tabParent.add({
      title: 'Plate Lineage',
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.PlateLineageResults({
        region: 'center',
        query: {
          barcodes: barcodes.join(',')
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadCollectionComparisonResults: function(collectionRecord, barcodes) {
    var tab = this.tabParent.add({
      title: 'Collection Comparison- ' + collectionRecord.data.collection_name,
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.PlateComparisonResults({
        region: 'center',
        query: {
          barcodes: barcodes.join(','),
          collection_id: collectionRecord.data.collection_id
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadPlateMapPanel: function(barcode) {
    if (RNAi.isRecordType(barcode, 'PlateInfo')) {
      barcode = barcode.data.barcode
    }
    barcode = barcode || this.barcode
    var tab = this.tabParent.add({
      title: "Plate " + barcode,
      iconCls: 'rg-entity-assay tab-icon-bg-pos',
      closable: (Ext.isBoolean(this.tabClosable) ? this.tabClosable : true),
      layout: 'border',
      type: {
        type: 'plate',
        barcode: barcode
      },
      items: new RNAi.Labware.RNAIPlateViewUI({
        region: 'center',
        main: this,
        barcode: barcode
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /*
   * Below are loaders for search result panels
   */
  loadGeneSearchResults: function(searchValues, title) {
    var tab = this.tabParent.add({
      title: title || "Gene Results",
      iconCls: 'rg-entity-gene tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.GeneSearchResults({
        region: 'center',
        query: searchValues
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  /*
   * Below are loaders for search result panels
   */
  loadGenesForExp: function(expRecord) {
    var tab = this.tabParent.add({
      title: "Genes (" + expRecord.get("experiment_name") + ")",
      iconCls: 'rg-entity-gene tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.GeneSearchResults({
        region: 'center',
        showExpRNAiCount: true,
        query: {
          query: expRecord.get('experiment_id'),
          searchBy: 'EXPERIMENT_IDS'
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadRNAiSearchResults: function(searchValues, title) {
    var tab = this.tabParent.add({
      title: title || "RNAi Results",
      iconCls: 'ix-v0-16-pawn_glass_red tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.RNAiSearchResults({
        region: 'center',
        query: searchValues
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadRNAiRawResults: function(expRecords, geneRecords, title) {
    var tab = this.tabParent.add({
      title: title || "RNAi POC Results",
      iconCls: 'ix-v0-16-pawn_view tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.RawPOCResults({
        region: 'center',
        query: {
          expRecords: (Ext.isArray(expRecords) ? expRecords : [expRecords]),
          geneRecords: (Ext.isArray(geneRecords) ? geneRecords : [geneRecords])
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  openRNAiRawResultsDialog: function(parentPanel, expRecords, geneRecords, title) {
    var win = new Ext.Window({
      title: title || "RNAi POC Results",
      iconCls: 'ix-v0-16-pawn_view',
      layout: 'border',
      modal: false,
      renderTo: (parentPanel ? parentPanel.getEl() : null),
      width: (parentPanel ? parentPanel.getWidth() * .75 : 400),
      height: 300,
      closeable: false,
      items: new RNAi.RawPOCResults({
        region: 'center',
        disableToolbar: true,
        query: {
          expRecords: (Ext.isArray(expRecords) ? expRecords : [expRecords]),
          geneRecords: (Ext.isArray(geneRecords) ? geneRecords : [geneRecords])
        }
      }),
      buttons: [{
          text: 'Close',
          handler: function() {
            win.close()
          }
        }
      ]
    })
    win.show()
  },
  loadAlignmentPanel: function(config) {
    var tab = this.tabParent.add({
      title: "RNAi Alignment",
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.AlignmentResults({
        region: 'center',
        targetID: config.targetID,
        rnaiRecords: config.rnaiRecords
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadRNAiExperimentsSearchResults: function(searchConfig, title, analysisRecords, resultTypeRecords, geneRecord) {
    var tab = this.tabParent.add({
      title: title || "Experiments",
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.ExperimentResults({
        region: 'center',
        query: searchConfig,
        analysisRecords: analysisRecords,
        resultTypeRecords: resultTypeRecords,
        geneRecord: geneRecord
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadAllRNAiExperimentsSearchResults: function() {
    var tab = this.tabParent.add({
      title: "All Experiments",
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.ExperimentResults({
        region: 'center',
        query: {
          searchBy: 'ALL'
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadMyRNAiExperimentsSearchResults: function() {
    this.loadRNAiExperiments(sessionIdentity.username)
  },
  loadUserRNAiExperimentsSearchResults: function() {
    new RNAi.Dialog.PersonSelector({
      title: 'Load Experiments for User',
      handler: function(personRecord) {
        this.loadRNAiExperiments(personRecord)
      },
      scope: this
    }
    ).show()
  },
  loadRNAiExperiments: function(personRecord) {
    var title
    var query
    if (Ext.isString(personRecord) && personRecord == sessionIdentity.username) {
      query = personRecord
      title = 'My Experiments'      
    } else if (RNAi.isRecordType(personRecord, 'Person')) {
      title = "Experiments ("+personRecord.get('ledger_name')+")" 
      query = personRecord      
    } else {
      return
    }
    var tab = this.tabParent.add({
      title: title,
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.ExperimentResults({
        region: 'center',
        query: {
          searchBy: 'AMGEN_LOGIN',
          query: personRecord
        }
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadRNAiExperimentGeneSummaryResults: function(searchConfig, title, analysisRecords, resultTypeRecords) {
    var tab = this.tabParent.add({
      title: title || "Experiments",
      iconCls: 'ix-v0-16-text_code_colored tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.ExperimentGeneSummaryResults({
        region: 'center',
        query: searchConfig,
        expRecord: searchConfig.expRecord,
        analysisRecords: analysisRecords,
        resultTypeRecords: resultTypeRecords
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadPlateSearchResults: function(searchValues) {
    var tab = this.tabParent.add({
      title: "Plate Results",
      iconCls: 'ix-v0-16-table tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: new RNAi.PlateSearchResults({
        region: 'center',
        query: searchValues
      })
    })
    this.tabParent.setActiveTab(tab);
    return tab
  },
  findTabByTitle: function(title, activate) {
    var tabs = this.tabParent.find("title", title)
    if (Ext.isArray(tabs) && tabs.length > 0) {
      if (activate) {
        this.tabParent.setActiveTab(tabs[0].getId())
      }
      return tabs[0]
    }
    return null
  },
  exportPOCandPValues: function(expRecord) {
    var exportURL = "/RNAi/export2excel.go"

    if (!Ext.fly('form_temp')) {
      var frm = document.createElement('form');
      frm.id = 'form_temp';
      frm.name = frm.id;
      frm.className = 'x-hidden';
      document.body.appendChild(frm);
    }
    Ext.Ajax.request({
      url: exportURL,
      method: 'POST',
      form: Ext.fly('form_temp'),
      isUpload: true,
      params: {
        rx: 'POCANDPVALUES',
        exp_id: expRecord.get("experiment_id")
      }
    })
  },
  openSurvivalPlot: function(geneRecords, expRecord, refGeneSymbols, parentTab, dataProxy) {
    var win = new RNAi.Dialog.SurvivalPlot({
      renderTo: (parentTab ? parentTab.getEl() : null),
      dataProxy: dataProxy,
      expRecord: expRecord,
      query: {
        geneRecords: geneRecords,
        expRecord: expRecord,
        refGeneSymbols: refGeneSymbols
      }
    })
    win.show()
  },
  runRNAiAnalysis: function(experimentRecords, analysisParams) {
    if (Ext.isArray(experimentRecords)) {
      var expIDs = []
      for (var i = 0; i < experimentRecords.length; i++) {
        var experimentRecord = experimentRecords[i]
        if (Ext.isRecord(experimentRecord) && experimentRecord.data.experiment_id) {
          var permissions = experimentRecord.get('permissions')
          if (!permissions || !permissions.can_analyze) {
            RNAi.showErrorResponse('You have insufficient privledges to analyze one or more of the selected experiments', 'Insufficient Privledges')
            return
          }
          expIDs.push(experimentRecord.data.experiment_id)
        }
      }
      if (expIDs.length > 0) {
        analysisParams = Ext.applyIf(analysisParams || {}, {
          req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
          experiment_ids: expIDs.join(',')
        })
        RNAi.showMessage('OGA Analysis Started', 'Running...')
        Ext.Ajax.request({
          url: '/RNAi/rnai.go',
          scope: this,
          success: function(response) {
            var jResponse = Ext.decode(response.responseText)
            new RNAi.Dialog.LogMonitor({
              title: 'OGA Analysis Monitor' + (experimentRecords.length == 1 ? ' (' + experimentRecords[0].data.experiment_name + ')' : ''),
              width: Ext.getBody().getWidth() * 0.75,
              height: Ext.getBody().getHeight() * 0.75,
              analysisKey: jResponse.analysisKey,
              analysisComplete: function() {
                this.loadRNAiExperimentsSearchResults({
                  query: expIDs.join('\n'),
                  searchBy: 'EXPERIMENT_IDS'
                }, "Experiments")
              },
              scope: this
            }).show()
          },
          failure: function(response) {
            if (!RNAi.checkForErrorResponse(response)) {
              showMessageDialog('RNAi Analysis Failed to Start')
            }
          },
          params: analysisParams
        });
      }
    }
  },
  runRNAiAnalysis2Excel: function(experimentRecords, analysisParams) {
    //new RNAi.Dialog.LogMonitor().show()
    //return 

    var expIDs = []
    if (Ext.isArray(experimentRecords)) {
      for (var i = 0; i < experimentRecords.length; i++) {
        var experimentRecord = experimentRecords[i]
        if (Ext.isRecord(experimentRecord) && experimentRecord.data.experiment_id) {
          expIDs.push(experimentRecord.data.experiment_id)
        }
      }
    }
    if (expIDs.length > 0) {
      analysisParams = Ext.applyIf(analysisParams || {}, {
        req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
        rx: 'RUN_ANALYSIS2EXCEL',
        experiment_ids: expIDs.join(',')
      })

      RNAi.showMessage('OGA Analysis Started', 'Running...')
      var form = Ext.DomHelper.append(document.body, {
        tag: 'form',
        method: 'post',
        action: '/RNAi/rnai.go',
        "accept-charset": "UTF-8",
        enctype: 'multipart/form-data',
        encoding: 'multipart/form-data'
      });

      Ext.Ajax.request({
        url: '/RNAi/rnai.go',
        success: function(response, options) {
          RNAi.checkForErrorResponse(response, 'Error Running Analysis')
        },
        failure: function(response, options) {
          RNAi.checkForErrorResponse(response, 'Error Running Analysis')
        },
        scope: this,
        form: form,
        params: analysisParams
      })
    }
  },
  runGeneticInteractionAnalysis: function(experimentRecords) {
    //new RNAi.Dialog.LogMonitor().show()
    //return 

    var expIDs = []
    if (Ext.isArray(experimentRecords)) {
      for (var i = 0; i < experimentRecords.length; i++) {
        var experimentRecord = experimentRecords[i]
        if (Ext.isRecord(experimentRecord) && experimentRecord.data.experiment_id) {
          expIDs.push(experimentRecord.data.experiment_id)
        }
      }
    }
    if (expIDs.length > 0) {
      new RNAi.Dialog.GIAnalysis({
        expRecords: experimentRecords,
        handler: function(selExpRecords, values) {
          this.closeAnalysisNode()

          RNAi.showMessage('Genetic Interaction Analysis Started', 'Running...')
          Ext.Ajax.request({
            url: '/RNAi/rnai.go',
            success: function(response, options) {
              RNAi.checkForErrorResponse(response, 'Error Running Analysis')
              RNAi.showMessage('Genetic Interaction Analysis Completed', 'Analysis Completed')
            },
            failure: function(response, options) {
              if (!RNAi.checkForErrorResponse(response, 'Error Running Analysis')) {
              }
            },
            scope: this,
            params: {
              req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
              rx: 'RUN_GI_ANALYSIS',
              overwrite: (values.overwrite ? 'true' : 'false'),
              experiment_ids: expIDs.join(',')
            }
          })
        },
        scope: this
      }).show()

    }
  },
  createCompositeHistograms: function(geneRecord) {
    if (RNAi.isRecordType(geneRecord, "Gene")) {
      RNAi.showMessage('Creating Composite Histograms', 'Running...')

      Ext.Ajax.request({
        url: '/RNAi/rnai.go',
        success: function(response, options) {
          RNAi.checkForErrorResponse(response, 'Error Creating Composite Histograms')
          var jResults = RNAi.decode(response)
          if (Ext.isObject(jResults) && Ext.isArray(jResults.CompositeHistograms) && jResults.CompositeHistograms.length > 0)
            new RNAi.Dialog.GeneHistograms({
              geneRecord: geneRecord,
              plotDetails: jResults.CompositeHistograms[0]
            }).show()
        },
        failure: function(response, options) {
          RNAi.showErrorResponse('Error Creating Composite Histograms')
        },
        scope: this,
        params: {
          req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
          rx: 'RUN_GENE_EXP_HISTOGRAM_PLOT',
          gene_id: geneRecord.id
        }
      })

    }
  },
  updateExperimentFlags: function(experimentRecords, sourceGrid) {
    var expIDs = []
    if (Ext.isArray(experimentRecords)) {
      for (var i = 0; i < experimentRecords.length; i++) {
        var experimentRecord = experimentRecords[i]
        if (Ext.isRecord(experimentRecord) && experimentRecord.data.experiment_id) {
          var permissions = experimentRecord.get('permissions')
          if (!permissions || !permissions.can_edit) {
            RNAi.showErrorResponse('You have insufficient privledges to edit one or more of the selected experiments', 'Insufficient Privledges')
            return
          }
          expIDs.push(experimentRecord.data.experiment_id)
        }
      }
    }
    if (expIDs.length > 0) {
      var win = new Ext.Window({
        title: 'Update Experiment(s) Status',
        layout: 'border',
        modal: true,
        width: 400,
        height: 150,
        closeable: false,
        items: new Ext.form.FormPanel({
          region: 'center',
          frame: true,
          autoWidth: true,
          labelWidth: 150,
          items: [new Ext.form.ComboBox({
              fieldLabel: 'Visibility',
              name: 'visibility',
              width: 200,
              typeAhead: true,
              editable: false,
              triggerAction: 'all',
              mode: 'local',
              store: ['Public', 'Private'],
              value: experimentRecords[0].data.visibility
            }), new Ext.form.ComboBox({
              fieldLabel: 'Status',
              name: 'status',
              width: 200,
              typeAhead: true,
              editable: false,
              triggerAction: 'all',
              mode: 'local',
              store: ['Valid', 'Invalid'],
              value: experimentRecords[0].data.status
            })]
        }),
        buttons: [{
            text: 'OK',
            handler: function() {
              var params = win.findByType('form')[0].getForm().getValues()
              Ext.apply(params, {
                req: 'amgen.ri.rnai.edit.UpdateExperimentResponder',
                experiment_ids: expIDs.join(',')
              })
              if (sourceGrid) {
                Ext.apply(params, {
                  dataID: sourceGrid.dataID
                })
              }
              RNAi.showMessage('Update Experiment(s)', 'Updating...')

              Ext.Ajax.request({
                url: '/RNAi/rnai.go',
                success: function(response, options) {
                  if (!RNAi.checkForErrorResponse(response, 'Error Updating Experiments')) {
                    if (sourceGrid) {
                      sourceGrid.getStore().reload()
                    }
                  }
                },
                failure: function(response, options) {
                  RNAi.checkForErrorResponse(response, 'Error Updating Experiments')
                },
                scope: this,
                params: params
              })
              win.close.defer(500, win)
            },
            scope: this
          }, {
            text: 'Cancel',
            handler: function() {
              win.close()
            }
          }
        ]
      })
      win.show()
    }
  },
  deleteExperiments: function(experimentRecords, sourceGrid) {
    var expIDs = []
    if (Ext.isArray(experimentRecords)) {
      for (var i = 0; i < experimentRecords.length; i++) {
        var experimentRecord = experimentRecords[i]
        if (Ext.isRecord(experimentRecord) && experimentRecord.data.experiment_id) {
          var permissions = experimentRecord.get('permissions')
          if (!permissions || !permissions.can_delete) {
            RNAi.showErrorResponse('You have insufficient privledges to delete one or more of the selected experiments', 'Insufficient Privledges')
            return
          }
          expIDs.push(experimentRecord.data.experiment_id)
        }
      }
    }
    if (expIDs.length > 0) {
      Ext.MessageBox.confirm('Confirm', 'Are you sure you want to delete the selected experiments?',
              function(btn) {
                if (btn != 'yes') {
                  return
                }
                var params = Ext.apply({}, {
                  req: 'amgen.ri.rnai.edit.DeleteExperimentResponder',
                  experiment_ids: expIDs.join(',')
                })
                if (sourceGrid) {
                  Ext.apply(params, {
                    dataID: sourceGrid.dataID
                  })
                }
                RNAi.showMessage('Delete Experiment(s)', 'Deleting...')

                Ext.Ajax.request({
                  url: '/RNAi/rnai.go',
                  success: function(response, options) {
                    if (!RNAi.checkForErrorResponse(response, 'Error Deleting Experiments')) {
                      if (sourceGrid) {
                        sourceGrid.getStore().reload()
                      }
                    }
                  },
                  failure: function(response, options) {
                    RNAi.checkForErrorResponse(response, 'Error Deleting Experiments')
                  },
                  scope: this,
                  params: params
                })
              },
              this)
    }
  },
  handleGlobalGridSelection: function(grid, selectedRecords) {
    if (Ext.isArray(selectedRecords) && selectedRecords.length > 0) {
      if (RNAi.isRecordType(selectedRecords[0], "Gene")) {
        Ext4.WindowManager.each(function(win) {
          if (win.widgetType && win.widgetType == 'poc_chart') {
            win.highlightGene(selectedRecords[0])
          }
        })
      }
    }
  },
  showProgress: function(title, msg, progress) {
    Ext.MessageBox.show({
      title: title,
      msg: msg || 'Loading, please wait...',
      progressText: progress || 'Loading...',
      width: 300,
      wait: true,
      waitConfig: {
        interval: 200
      },
      icon: 'ix-v0-32-hourglass'
    })
  },
  downloadFile: function(url, params, cb, scope) {
    // create hidden target iframe
    var id = Ext.id();
    var frame = document.createElement('iframe');
    frame.id = id;
    frame.name = id;
    frame.className = 'x-hidden';
    frame.src = Ext.SSL_SECURE_URL;
    document.body.appendChild(frame);

    if (Ext.isIE) {
      document.frames[id].name = id;
    }

    var hiddenFields = []
    var form = Ext.DomHelper.append(document.body, {
      tag: 'form',
      method: 'post',
      action: url,
      "accept-charset": "UTF-8",
      target: id
    });
    document.body.appendChild(form);
    if (Ext.type(params) == 'object') {
      for (var k in params) {
        if (params.hasOwnProperty(k)) {
          var hd = document.createElement('input');
          hd.type = 'hidden';
          hd.name = k;
          hd.value = params[k];
          form.appendChild(hd);
          hiddenFields.push(hd);
        }
      }
    }
    var callback = function(e) {
      var rstatus = Ext.isIE ? this.readyState : e.type;
      switch (rstatus) {
        case 'interactive' : // IE
        case 'loading' : // IE has several readystate transitions, ignore these
          if (Ext.isFunction(cb)) {
            cb.call(scope, rstatus, 'load');
          }
          break;
        case 'complete' : // IE readyState == done
        case 'load' : // Gecko, Opera, others == done
          var fnCleanup = function() {
            this.src = "javascript:false"; // cleanup
            Ext.fly(this).remove(); // kill frame
            Ext.fly(form).remove(); // kill form
          };
          if (Ext.isFunction(cb)) {
            cb.call(scope, rstatus, 'done');
          }
          // 'this' refers to the frame object, ie. the dom object not the Ext element
          fnCleanup.defer(30000, this);
          break;
        default :
          break;
      }
    };
    frame[Ext.isIE ? 'onreadystatechange' : 'onload'] = callback.createDelegate(frame);
    form.submit();
  },
  loadPValueRankChart: function(experimentRecord) {
    if (!RNAi.isRecordType(experimentRecord, 'Experiment')) {
      return
    }
    var sfURL = RNAi.Spotfire.URLs.getsfURL('PVALUERANKS', {
      exp_id: experimentRecord.get("experiment_id")
    })

    var tab = this.tabParent.add({
      title: 'PValue Ranks- ' + experimentRecord.get("experiment_name") + " (Experimental)",
      iconCls: 'x-rnai-16-spotfire tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: sfURL
      }
    });

    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadPValueVsGenesChart: function(experimentRecords) {
    if (!Ext.isArray(experimentRecords) || experimentRecords.length == 0) {
      return
    }
    var expIDs = RNAi.joinFields(experimentRecords, 'experiment_id', ',')
    var sfURL = RNAi.Spotfire.URLs.getsfURL('PVALUEVSGENES', {
      exp_ids: expIDs
    })
    var tab = this.tabParent.add({
      title: 'PValue Vs Genes' + " (Experimental)",
      iconCls: 'x-rnai-16-spotfire tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: sfURL
      }
    });

    this.tabParent.setActiveTab(tab);
    return tab
  },
  loadPOCChart: function(experimentRecords) {
    if (!Ext.isArray(experimentRecords) || experimentRecords.length != 2) {
      return
    }
    var sfURL = RNAi.Spotfire.URLs.getsfURL('COMPAREPOC', {
      exp_id1: experimentRecords[0].get("experiment_id"),
      exp_id2: experimentRecords[1].get("experiment_id")
    })


    var tab = this.tabParent.add({
      title: 'POCs- ' + experimentRecords[0].get("experiment_name") + " | " + experimentRecords[1].get("experiment_name") + " (Experimental)",
      iconCls: 'x-rnai-16-spotfire tab-icon-bg-pos',
      closable: true,
      layout: 'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: sfURL
      }
    });

    this.tabParent.setActiveTab(tab);
    return tab


    /*
     var store= new Ext4.data.JsonStore({
     autoLoad: true,
     proxy: {
     type: 'ajax',
     url: '/RNAi/rnai.go',
     extraParams : {
     req:'amgen.ri.rnai.analyze.RNAiAnalysisResponder',        
     rx: 'POC_RESULTS',
     experiment_ids: RNAi.joinFields(experimentRecords, "experiment_id", ",")         
     },
     reader: {
     type: 'json',
     root: 'results',
     idProperty: 'rnai_id'
     }
     },
     fields: [{
     name:'data1', 
     type: 'float'
     }, {
     name:'data2', 
     type: 'float'
     }, {
     name:'gene_symbol'
     }, {
     name:'gene_id', 
     type: 'int'
     }, {
     name:'rnai_id', 
     type: 'int'
     }]
     })
     
     var chart= Ext4.create('Ext.chart.Chart', {    
     store: store,
     checkList: new Ext4.util.MixedCollection(), 
     region: 'center',
     axes: [{
     type: 'Numeric',
     position: 'left',
     fields: ['data1', 'data2'],
     title: experimentRecords[0].get("experiment_name"),
     grid: true,
     minimum: -100,
     maximim: 20
     }, {
     type: 'Numeric',
     position: 'bottom',
     fields: ['data2', 'data1'],
     title: experimentRecords[1].get("experiment_name"),
     grid: true,
     minimum: -100,
     maximim: 20
     }],
     series: [{
     type: 'scatter',
     markerConfig: {
     type: 'circle',
     radius: 5
     },
     style: {
     opacity: 0.0
     },
     shadowAttributes: [],
     axis: ['left', 'bottom'],
     xField: 'data1',
     yField: 'data2',
     tips: {
     trackMouse: true,
     width: 140,
     height: 40,
     renderer: function(storeItem, item) {
     this.update(storeItem.get('gene_symbol')+"<BR/>("+storeItem.get('data1')+", "+storeItem.get('data2')+")")
     }
     },
     listeners: {
     itemmouseup: function(obj) {
     if (obj.storeItem) {
     var win= this.chart.ownerCt
     var geneRecord= new RNAi.Record.Gene(obj.storeItem.data)
     win.highlightGene(geneRecord)
     }
     }
     },
     renderer: function(sprite, record, attributes, index, store) {
     var c= getColor(record.get("gene_symbol"))
     return Ext.apply(attributes, {
     fill: c
     });
     }
     }],
     highlightGene: function(geneRecord) {
     var series = this.series.get(0),
     i, items, l;
     
     series.highlight = true;
     series.unHighlightItem();
     series.cleanHighlights();
     for (i = 0, items = series.items, l = items.length; i < l; i++) {
     if (geneRecord.get("gene_id") == items[i].storeItem.get('gene_id')) {
     series.highlightItem(items[i]);
     }
     }
     series.highlight = false;
     }
     });
     
     var checkedTree= Ext4.create('Ext.tree.Panel', {
     collapseMode: 'mini',
     collapsible: true,
     header: false,
     split: true,
     rootVisible: false,
     useArrows: true,
     lines: false,
     width: '25%',
     region: 'west',
     root: {
     text: "Root node"
     }
     });
     
     var win = Ext4.widget('window', {
     x: 90,
     y: 50,
     width: 800,
     height: 600,
     maximizable: true,
     origTitle: 'POCs- ' + experimentRecords[0].get("experiment_name") + " | " + experimentRecords[1].get("experiment_name"),
     title: 'POCs- ' + experimentRecords[0].get("experiment_name") + " | " + experimentRecords[1].get("experiment_name"),
     closeAction: 'hide',
     layout: 'border',
     widgetType: 'poc_chart',
     items: [checkedTree, chart],
     highlightGene: function(geneRecord) {
     this.items.get(1).highlightGene(geneRecord)
     this.setTitle(this.origTitle+' ('+geneRecord.get('gene_symbol')+')')
     }
     })
     win.show()
     
     store.on('load', function(store, records) {
     var geneSymbols= new Ext4.util.MixedCollection() 
     for(var i=0; i< records.length; i++) {
     geneSymbols.add(records[i].get('gene_symbol'), 0);
     }
     geneSymbols.sortByKey()
     geneSymbols.eachKey(function(key) {
     var root= checkedTree.getRootNode()
     root.appendChild(Ext4.create('Ext.tree.Panel', {
     text: key,
     iconCls: 'rg-entity-gene',
     leaf: true,
     checked: false
     }))
     })
     
     })
     //checkchange( Ext.data.NodeInterface node, Boolean checked, Object eOpts )
     checkedTree.on('checkchange', function(node, checked) {
     var count= 0
     chart.checkList.add(node.data.text, checked)
     var store= chart.getStore()
     store.clearFilter(true);
     store.filterBy(function(r){
     var geneSymbol= r.get("gene_symbol")
     var inc= (chart.checkList.containsKey(geneSymbol) && chart.checkList.get(geneSymbol)=== true)
     if (inc) {
     count++
     }
     return inc
     })
     chart.bindStore(store)
     chart.redraw(true)
     })    */
  },
  openLogsForExperiment: function(expRecords) {
    if (!Ext.isArray(expRecords) || expRecords.length == 0) {
      return
    }
    new RNAi.Dialog.LogsDialog({
      expRecords: expRecords
    }).show()
  }
})