/**
 * Creates a data structure for RNAi records
 */
RNAi.Record.Experiment= Ext.data.Record.create([
{
  name:'experiment_id'
},
{
  name:'experiment_name'
},
{
  name:'cell_line'
},{
  name:'tissue'
},
{
  name:'experiment_type'
},
{
  name:'library'
},
{
  name:'screened_by'
},
{
  name:'uploaded_by'
},
{
  name:'qc_by'
},
{
  name:'analyzed_by'
},
{
  name:'status'
},
{
  name:'visibility'
},
{
  name:'exp_gene_count',
  type: 'integer',
  defaultValue: 0
},
{
  name:'analyzed_gene_count',
  type: 'integer',
  defaultValue: 0
},
{
  name:'experiment_date',
  type: 'date',
  dateFormat: 'Y-m-d',
  defaultValue: 0
},
{
  name:'last_analyzed',
  type: 'date',
  dateFormat: 'Y-m-d',
  defaultValue: 0
},
{
  name: 'analyses'
},
{
  name: 'results'
},
{
  name: 'permissions'
}
])

RNAi.Record.Experiment.prototype.recordType= 'Experiment'

