var ag_cbs = new Ext.grid.CheckboxSelectionModel();


RNAi.AnnotationGroup = Ext.extend(Ext.grid.EditorGridPanel, {
  initComponent:function() {
    var config = {
      store: new Ext.data.Store({
        url: '/RNAi/rnai.go',       
        reader :new Ext.data.JsonReader({
          root :"annotation_group",
          idProperty: "annotation_group_id"
        }, RNAi.Record.AnnotationGroup)
      }),
      sm: ag_cbs,
      columns:[ag_cbs,{
        id:'annotation_group_id',
        header:"annotation_group_id",
        hidden: true,
        dataIndex:'annotation_group_id'
      },{
        header:"Annotation Group Name",
        width:20,
        sortable:true,
        dataIndex:'annotation_group_name',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      }]
      ,
            
      buttons:[{
        text: 'Add',
        listeners: {
          'click': function(button, e){                        
            Ext.Msg.prompt('Create New Annotation Group', 'Please enter annotation group name:', function(btn, text){
              if (btn == 'ok'){
                var jsonString = Ext.util.JSON.encode({
                  'annotation_group_name': text
                })
                                
                                
                Ext.Ajax.request({
                  url:'/RNAi/rnai.go', 
                  success: function(response){
                    if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                      this.ownerCt.ownerCt.store.reload();
                    }
                    else {
                      Ext.MessageBox.show({
                        title: 'Add Annotation Group',
                        msg: 'Unable to save Annotation group changes1.',
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                      })
                    }
                  },
                  failure: function(response){
                    Ext.MessageBox.show({
                      title: 'Add Annotation Group',
                      msg: 'Unable to save Annotation group changes2.',
                      buttons: Ext.MessageBox.OK,
                      icon: Ext.MessageBox.ERROR
                    })
                  },
                  scope: this,
                  params: {
                    req:'amgen.ri.rnai.screener.AnnotationResponder',
                    annotation_json :jsonString,
                    table_name:'annotation_group',
                    action_id: 'add-annotation'
                  }
                })
                                
              /* Ext.Ajax.request({
                                    url:'/RNAi/rnai.go', 
                                    timeout :600000,
                                    success : function(response, opts) {
                                        this.ownerCt.ownerCt.store.reload();
                                        
                                    },
                                    scope :this,
                                    params :{
                                        req:'amgen.ri.rnai.screener.AnnotationResponder',
                                        annotation_group_name :text,
                                        action_id: 'reg-annotation-group'
                                    }
                                }); */
              }
            }, this);                       
                    
          }
        }
      },{
        text: 'Save',
        listeners: {
          'click': function(button, e){
            var agstore = this.ownerCt.ownerCt.store;
            var records = agstore.getModifiedRecords();
                        
            var datar = new Array();
            var annotation_json = "";
            for (var i = 0; i < records.length; i++) {
              datar.push(records[i].data);
            }
            annotation_json = Ext.util.JSON.encode(datar);
                        
            Ext.Ajax.request({
              url:'/RNAi/rnai.go', 
              success: function(response){
                                
                if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                  agstore.reload();
                }
                else {
                  Ext.MessageBox.show({
                    title: 'Save Annotation Group',
                    msg: 'Unable to save Annotation Group changes1.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                }
              },
              failure: function(response){
                Ext.MessageBox.show({
                  title: 'Save Annotation Group',
                  msg: 'Unable to save Annotation Group changes2.',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
              },
              scope: this,
              params: {
                req:'amgen.ri.rnai.screener.AnnotationResponder',
                annotation_json :annotation_json,
                table_name: 'annotation_group',
                action_id: 'edit-annotation'
              }
            })
          }
        }
      }, {
        text: 'Delete',
        listeners: {
          'click': function(button, e){  
            var agstore = this.ownerCt.ownerCt.store;
            var records = this.ownerCt.ownerCt.getSelectionModel().getSelections();
            if (records.length > 0) {
              var ids_todelete = "";
              var names_todelete = "";
              for (i = 0; i < records.length; i++) {
                var record = records[i];
                ids_todelete = ids_todelete + record.data.annotation_group_id + ",";
                names_todelete = names_todelete + record.data.annotation_group_name + ",";
              }
              if (ids_todelete.length > 0) {
                ids_todelete = ids_todelete.substring(0, ids_todelete.length - 1);
                names_todelete = names_todelete.substring(0, names_todelete.length - 1);
              }
              Ext.MessageBox.show({
                title: 'Delete Annotation Group',
                msg: 'Do you want to delete the selected Annotation groups: ' + names_todelete + '?',
                buttons: Ext.MessageBox.YESNO,
                fn: function(buttonId){
                  if (buttonId != 'yes') {
                    return
                  }
                  Ext.Ajax.request({
                    url:'/RNAi/rnai.go', 
                    success: function(response){
                      if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                        agstore.reload();
                      }
                      else {
                        Ext.MessageBox.show({
                          title: 'Delete Annotation Group',
                          msg: 'Unable to save Annotation Group changes1.',
                          buttons: Ext.MessageBox.OK,
                          icon: Ext.MessageBox.ERROR
                        })
                      }
                    },
                    failure: function(response){
                      Ext.MessageBox.show({
                        title: 'Delete Annotation Group',
                        msg: 'Unable to save Annotation Group changes2.',
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                      })
                    },
                    scope: this,
                    params: {
                      req:'amgen.ri.rnai.screener.AnnotationResponder',
                      deleteIds :ids_todelete,
                      table_name: 'annotation_group',
                      action_id: 'delete-annotation'
                    }
                  })
                } 
              })
                   
            }else{
              Ext.Msg.alert('Delete Annotation Group', 'Please select one or more annotation groups');             
            }
          }
        }
      }],
      viewConfig:{
        forceFit:true
      }
    }; // eo config object
 
    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
 
    this.bbar = new Ext.PagingToolbar({
      store:this.store            ,
      displayInfo:true            ,
      pageSize:10
    });
 
    // call parent
    RNAi.AnnotationGroup.superclass.initComponent.apply(this, arguments);
  } // eo function initComponent
 
  ,
  onRender:function() {
 
    // call parent
    RNAi.AnnotationGroup.superclass.onRender.apply(this, arguments);
 
    // load the store
    this.store.load({
      params:{
        start:0, 
        limit:10,                
        req:'amgen.ri.rnai.screener.AnnotationResponder',                
        action_id: 'get-annotation-group'
                           
      }
    });
 
  } // eo function onRender
 
});

