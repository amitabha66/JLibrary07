
RNAi.PlateLineageResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {      
    var panel= this
    this.items=[(this.contentGrid= new RNAi.PlateLineageGrid({
      region: 'center',
      autoExpandColumn: 'lineage',
      cellActions: {
        barcode: {
          handler: function(grid, record, dataIndex) {
            var barcode= record.data.barcode            
            if (!barcode || barcode.match(/^NONE/)) {
              return
            }
            this.handleOpenPlates([record.data.barcode])            
          },
          scope: panel                
        },       
        parents: {
          handler: function(grid, record, dataIndex) {
            var barcodes= []
            if (Ext.isArray(record.data.parents)) {
              barcodes= record.data.parents
            } else if (Ext.isString(record.data.parents)) {
              barcodes= [record.data.parents]
            } else {
              return
            }
            this.handleOpenPlates(barcodes)
          },
          scope: panel                
        }, 
        descendants: {
          handler: function(grid, record, dataIndex) {
            var barcodes= []
            if (Ext.isArray(record.data.descendants)) {
              barcodes= record.data.descendants
            } else if (Ext.isString(record.data.descendants)) {
              barcodes= [record.data.descendants]
            } else {
              return
            }
            this.handleOpenPlates(barcodes)
          },
          scope: panel                
        }
      }
    }))
    ]         
    RNAi.RNAiSearchResults.superclass.initComponent.call(this); 
  },  
  handleSearch: function(values) {  
    var panel= this    
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {    
          panel.contentGrid.getStore().load()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'PLATE_UTILITIES',
        action_id: 'PLATE_LINEAGE',
        barcodes: values.barcodes,
        dataID: panel.contentGrid.dataID
      }
    });
  },
  handleOpenPlates: function(barcodes) {
    if (Ext.isArray(barcodes) && barcodes.length> 0) {
      new RNAi.TabPanelLoader().loadPlateSearchResults({
        searchBy: 'BARCODES', 
        query: barcodes.join(',')
      })
    }    
  }
}); 

