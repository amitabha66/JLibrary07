/**
 * Encapsulates & abstracts the main Tab Panel loading into a single loader class
 * 
 * 
 * @param {Mixed} config 
 *  
 *  The config is used to indicate the type of tab panel to create and provide 
 *  any parameters needed to create the panel
 *  
 *  If this is a String, it is assumed to be the type. 
 *  Otherwise, the config object should include the tab panel
 *  as the field type with any additions fields needed to create the panel
 *  
 *  This also exposes 2 events:
 *  
 *  beforeload: Called before the tab panel is created. This loader object is included in the function call. If this returns false, the panel is not created
 *  load: Called after the tab panel is created. Passed to the handler is this loader object and the if the tab panel was successfully created, the new tab panel. If the
 *  creation failed, no tab panel is passed
 * 
 */
RNAi.ChartLoader =  Ext.extend(Ext.util.Observable, {
  constructor: function(config){ 
    if (Ext.isString(config)) {
      config= {
        type: config
      }
    } 
    Ext.applyIf(this, config)
    Ext.applyIf(this, {
      tabParent: Ext.getCmp('main-tab-panel')
    })
    this.addEvents(
      "beforeload",
      "load"
      )
    RNAi.ChartLoader.superclass.constructor.call(this, config)
  },
  loadChart: function(chartRecord, records) {
    if(this.fireEvent('beforeload', this) !== false) {
      var loadResp= this.doChartLoad(chartRecord, records)
      this.fireEvent('load', this, loadResp)    
    }
  },
  doChartLoad: function(chartRecord, records) {
    var reqRecordType= chartRecord.get('target_record_type')
    var reqRecordCount=chartRecord.get('record_select_count')
    var reqRecordCountComp= chartRecord.get('record_select_count_comparison')
    var params= chartRecord.get('params').split(',')
        
    if (!Ext.isArray(records) || records.length==0 ||  !RNAi.isRecordType(records[0], reqRecordType)) {
      return false
    }    
    
    switch(reqRecordCountComp) {
      case 'min':
        if (records.length< reqRecordCount) {
          return false
        }
        break;
      case 'max':
        if (records.length> reqRecordCount) {
          return false
        }
        break;
      default:
        if (records.length!= reqRecordCount) {
          return false
        }
        break; 
    }
    
    var paramValues= {}
    if (params.length== 1) {
      if (records[0].fields.contains(params[0])) {
        paramValues[params[0]]= RNAi.joinFields(records, params[0], ',')
      } else {
        paramValues[params[0]]= RNAi.joinFields(records, null, ',')
      }
    } else if (params.length== records.length) {
      for(var i=0; i< params.length; i++) {
        if (records[i].fields.contains(params[i])) {
          paramValues[params[i]]= records[i].get(params[i])
        } else {
          paramValues[params[i]]= records[i].id
        }
      }      
    } else {
      for(var i=0; i< params.length; i++) {
        if (records[i].fields.contains(params[i])) {        
          paramValues[params[i]]= RNAi.joinFields(records, params[i], ',')
        } else {
          paramValues[params[i]]= RNAi.joinFields(records, null, ',')
        }
      }
    }
    var title= chartRecord.get('name')
    if (RNAi.isRecordType(records[0], 'Experiment')) {
      if (records.length== 1) {
        title= title + ' - ' + records[0].get("experiment_name")
      } else if (records.length== 2) {
        title= title + ' - ' + records[0].get("experiment_name") + " | " + records[1].get("experiment_name")
      }
    }
    if (RNAi.isRecordType(records[0], 'Gene')) {
      if (records.length== 1) {
        title= title + ' - ' + records[0].get("gene_symbol")
      } else if (records.length== 2) {
        title= title + ' - ' + records[0].get("gene_symbol") + " | " + records[1].get("gene_symbol")
      }
    }

    var tab = this.tabParent.add({
      title: title,
      iconCls: 'x-rnai-16-spotfire tab-icon-bg-pos',
      closable: true,
      layout:'border',
      items: {
        xtype: 'iframepanel',
        region: 'center',
        defaultSrc: chartRecord.createSFURL(paramValues)    
      }                         
    });    
    this.tabParent.setActiveTab(tab);           
    return true
  }
  
})