/**
 * Creates a data structure for Analysis records
 */
RNAi.Record.OGAAnalysis= Ext.data.Record.create([{
  name:'analysisKey'
}, {
  name:'name'
}, {
  name:'startTime',                     
  type:'date',
  dateFormat: 'm/d/y h:i:s A'
}                  
]) 

RNAi.Record.OGAAnalysis.prototype.recordType= 'OGAAnalysis'