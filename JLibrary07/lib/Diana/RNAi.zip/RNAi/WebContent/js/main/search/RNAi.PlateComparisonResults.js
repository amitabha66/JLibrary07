
RNAi.PlateComparisonResults = Ext.extend(RNAi.ResultsPanel, {
  initComponent:function() {         
    var panel= this
    this.items=[(this.contentGrid= new RNAi.PlateComparisonGrid({
      region: 'center',
      autoExpandColumn: 'descendants',
      cellActions: {        
        barcode: {
          handler: function(grid, record, dataIndex) {
            var barcode= record.data.barcode            
            if (!barcode || barcode.match(/^NONE/)) {
              return
            }
            this.handleOpenPlates([record.data.barcode])            
          },
          scope: panel                
        }, 
        descendants: {
          handler: function(grid, record, dataIndex) {
            var barcodes= []
            if (Ext.isArray(record.data.descendants)) {
              barcodes= record.data.descendants
            } else if (Ext.isString(record.data.descendants)) {
              barcodes= [record.data.descendants]
            } else {
              return
            }
            this.handleOpenPlates(barcodes)
          },
          scope: panel                
        }
      }
    }))
    ]         
    RNAi.PlateComparisonResults.superclass.initComponent.call(this); 
  },  
  handleSearch: function(values) {  
    var panel= this    
    panel.contentGrid.getEl().mask('Searching...', 'x-mask-loading')
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, opts) {
        panel.contentGrid.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {    
          panel.contentGrid.getStore().load()
        }
      },
      failure: function() {
        panel.contentGrid.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'PLATE_UTILITIES',
        action_id: 'COLLECTION_COMPARISON',
        barcodes: values.barcodes,
        collection_id: values.collection_id,
        dataID: panel.contentGrid.dataID
      }
    });
  },
  handleOpenPlates: function(barcodes) {
    if (Ext.isArray(barcodes) && barcodes.length> 0) {
      new RNAi.TabPanelLoader().loadPlateSearchResults({
        searchBy: 'BARCODES', 
        query: barcodes.join(',')
      })
    }    
  }   
}); 

