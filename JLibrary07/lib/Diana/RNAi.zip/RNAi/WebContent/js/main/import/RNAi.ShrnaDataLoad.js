

RNAi.ShrnaDataLoad = Ext.extend(Ext.form.FormPanel, {
    autoScroll: true,
    frame: true,
    fileUpload: true,
    bodyStyle: 'padding:10px',    
    height: 864,    
    footer: true,
    labelWidth: 300,
    labelPad: 10,
    buttonAlign: 'center',
    url:'/RNAi/rnai.go',    
    loadMask: {
        msg: 'Loading ..'
    },
    initComponent: function() {
        this.layoutConfig = {
            trackLabels: true,
            labelSeparator: ''
        };            
        
        
        var config = {
            items : this.form_items,
            //items: x,
            buttons:[{
                text:'Submit',
                formBind:true,
                scope:this,
                handler:this.submit
            },{
                text:'Cancel',
                scope:this,
                handler:this.cancel
            }]
        }
        
        // apply config
        Ext.apply(this, Ext.apply(this.initialConfig, config));
        RNAi.ShrnaDataLoad.superclass.initComponent.apply(this, arguments);
         
        
        var form = this.getForm();
        var cellline = form.findField("AN__Cell_SPACE_Line");
        
        
        cellline.store.on('beforeload', function(store){
            store.baseParams.input = cellline.lastQuery;  
        }); 
                
    }
    ,
    onRender:function() { 
        // call parent
        RNAi.ShrnaDataLoad.superclass.onRender.apply(this, arguments); 
        // set wait message target
        this.getForm().waitMsgTarget = this.getEl();      

    }
    /**
     * Submits the form. Called after Submit buttons is clicked
     * @private
     */
    ,
    submit:function() {
        var formPanel = this;
        var viewport = Ext.getCmp('root-id');
        var tabPanel = viewport.contentPanel;
        var formData = Ext.encode(this.getForm().getValues());

        var myMask = new Ext.LoadMask(this.el, {
            msg:"Please wait..."
        });
        myMask.show();
        Ext.Ajax.request({
            url:'/RNAi/rnai.go', 
            form: this.getForm().getEl(),
            isUpload: true,
            success: function(response){
                myMask.hide()
                if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                    var experiment_name = this.getForm().findField('experiment_name');
                    var result = experiment_name.getValue();
                    Ext.MessageBox.show({
                        title: 'Add Experiment',
                        msg: 'Load Complete' + ":" + result,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.INFO
                    })
                    
                    var tab = formPanel.ownerCt;
                    tabPanel.remove(tab);
                    new RNAi.TabPanelLoader().loadAllRNAiExperimentsSearchResults()                    
                }
                else {
                    Ext.MessageBox.show({
                        title: 'Add Experiment',
                        msg: Ext.util.JSON.decode(response.responseText).message,
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                    })
                }
            },
            failure: function(response){
                myMask.hide()
                Ext.MessageBox.show({
                    title: 'Add Experiment',
                    msg: 'Unable to save Experiment changes.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                })
            },
            scope: this,
            params: {
                req:'amgen.ri.rnai.screener.ScreenerResponder',
                experiment_json :formData,
                table_name:'shrna',
                action_id: 'add-experiment'
            }
        })
        
    } // eo function submit
    ,
    cancel:function() {        
        var viewport = Ext.getCmp('root-id');
        var tabPanel = viewport.contentPanel;
        var tab = this.ownerCt;
        tabPanel.remove(tab);
        
    } // eo function submit
    /**
     * Success handler
     * @param {Ext.form.BasicForm} form
     * @param {Ext.form.Action} action
     * @private
     */
    ,
    onSuccess:function(form, action) {        
        
        
        
        
    } // eo function onSuccess
 
    /**
     * Failure handler
     * @param {Ext.form.BasicForm} form
     * @param {Ext.form.Action} action
     * @private
     */
    ,
    onFailure:function(form, action) {
        this.showError(action.result.error || action.response.responseText);
    } // eo function onFailure
    
    /**
     * Shows Message Box with error
     * @param {String} msg Message to show
     * @param {String} title Optional. Title for message box (defaults to Error)
     * @private
     */
    ,
    showError:function(msg, title) {
        title = title || 'Error';
        Ext.Msg.show({
            title:title,
            msg:msg,
            modal:true,
            icon:Ext.Msg.ERROR,
            buttons:Ext.Msg.OK
        });
    } // eo function showError
});
