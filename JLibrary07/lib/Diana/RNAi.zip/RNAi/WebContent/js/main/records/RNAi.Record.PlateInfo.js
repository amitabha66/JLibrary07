/**
 * Creates a data structure for Plate Metadata records
 */
RNAi.Record.PlateInfo= Ext.data.Record.create([{
  name:'barcode'
}, {
  name:'site'
}, {
  name:'density',
  type: 'integer'
}, {
  name:'type'
} ,{
  name:'layout'
} ,{
  name:'rows',
  type: 'integer'
} ,{
  name:'cols',
  type: 'integer'
} ,{
  name:'wells'
}            
])

RNAi.Record.PlateInfo.prototype.recordType= 'PlateInfo'
