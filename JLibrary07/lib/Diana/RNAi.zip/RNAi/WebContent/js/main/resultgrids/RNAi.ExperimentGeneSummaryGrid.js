
RNAi.ExperimentGeneSummaryGrid = Ext.extend(RNAi.CachedResultGridPanel, {
  dndProxyTpl: new Ext.Template(
          '<table class="x-rnai-gene-dNd">',
          '<tr><th valign= "top" nowrap="Y">Symbol:</th><td>{gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{gene_name}</td></tr>',
          '</table>'
          ),
  initComponent: function() {
    var grid = this
    Ext.applyIf(this, {
      root: 'genes',
      rowsDraggable: true,
      ddGroup: 'geneDDGroup',
      highlightDef: {
        field: 'OGA METHOD V2:CORRECTED_PVALUE',
        comp: '<',
        compareValue: 0.05
      }
    })
    this.rowExpander = new RNAi.GeneGridExpander();

    this.fields = []
    for (var i = 0; i < RNAi.Record.Gene.prototype.fields.items.length; i++) {
      this.fields.push(RNAi.Record.Gene.prototype.fields.items[i])
    }
    this.recordType = RNAi.Record.Gene.prototype.recordType

    var colDefs = [this.rowExpander]

    colDefs.push({
      header: 'Gene',
      dataIndex: 'gene_symbol',
      renderer: this.geneMixRenderer.createDelegate(this, [','], true)
    }, {
      header: 'Name',
      dataIndex: 'gene_name',
      renderer: this.geneMixRenderer.createDelegate(this, [','], true)
    }, {
      header: 'Entrez Gene ID',
      dataIndex: 'entrezgene_id',
      renderer: this.geneMixRenderer.createDelegate(this, [','], true)
    }, {
      header: 'RNAi Count',
      dataIndex: 'rnai_count',
      align: 'right'
    })


    if (Ext.isArray(this.analysisRecords) && Ext.isArray(this.resultTypeRecords)) {
      var topGroupRow = [{
          header: 'Gene',
          align: 'center',
          colspan: colDefs.length
        }]

      for (var i = 0; i < this.analysisRecords.length; i++) {
        var analysis = this.analysisRecords[i]
        var analysisName = analysis.data.analysis_name
        var analysisType = analysis.data.analysis_type
        topGroupRow.push({
          header: analysisName,
          align: 'center',
          colspan: this.resultTypeRecords.length
        })
        for (var j = 0; j < this.resultTypeRecords.length; j++) {
          var resultType = this.resultTypeRecords[j]
          var resultTypeName = resultType.data.result_type
          var format = resultType.data.format
          var precision = resultType.data.precision

          this.fields.push({
            name: analysisType + ":" + resultTypeName,
            type: (format == 'int' ? 'int' : 'float')
          })
          colDefs.push({
            header: resultType.data.result_name,
            dataIndex: analysisType + ":" + resultTypeName,
            align: 'right',
            analysisName: analysisName,
            resultTypeName: resultTypeName,
            format: format,
            precision: precision,
            filterType: 'numeric',
            sortable: true,
            width: 150,
            renderer: function(value, metaData, record, rowIndex, colIndex, store) {
              var cm = grid.getColumnModel()
              var col = cm.getColumnById(this.id)
              var val = new Number(value)
              if (isNaN(val)) {
                return value
              }
              switch (col.format) {
                case 'int':
                  return val.toFixed(0)
                case 'scientific':
                  return val.toExponential((col.precision || 5))
                default:
                  return val.toPrecision((col.precision || 5))
              }
            }
          })
        }
      }
      this.group = new Ext.ux.grid.ColumnHeaderGroup({
        rows: [topGroupRow]
      })
    }

    this.plugins = [this.rowExpander]
    if (this.group) {
      this.plugins.push(this.group)
    }
    if (this.rowActionsPlugin) {
      this.plugins.push(this.rowActionsPlugin)
    }

    //    this.addFilterPlugins(colDefs)

    this.colModel = new Ext.grid.ColumnModel({
      defaults: {
        width: 100,
        sortable: true
      },
      columns: colDefs
    })
    RNAi.ExperimentGeneSummaryGrid.superclass.initComponent.call(this);
  },
  geneMixRenderer: function(value, metaData, record, rowIndex, colIndex, store, delim) {
    if (record.get('is_mixture')) {
      var dataIndex = this.getColumnModel().getDataIndex(colIndex)
      var mixValue = record.get(dataIndex + 's')
      if (mixValue && mixValue.toString().indexOf('$$') > 0) {
        return mixValue.toString().replace(/\$\$/g, delim)
      }
    }
    return value
  },
  createDDProxy: function(geneRecords) {
    var proxyHTML = null

    if (Ext.isRecord(geneRecords)) {      
      return this.dndProxyTpl.apply({
        gene_symbol: geneRecords.data.gene_symbol.replace(/\$\$/g, ','),
        gene_name: geneRecords.data.gene_name.replace(/\$\$/g, ',')
      })
    } else if (Ext.isArray(geneRecords) && geneRecords.length > 0) {
      this.ddel.innerHTML = Ext.DomHelper.markup({
        tag: 'span',
        unselectable: "on",
        style: "white-space: nowrap !important;",
        children: [{
            tag: 'img',
            src: Ext.BLANK_IMAGE_URL,
            width: 16,
            height: 16,
            "class": 'ix-v0-16-documents',
            style: "background-position: center center; background-repeat: no-repeat; border: 0 none; height: 16px; margin: 0; padding: 0; vertical-align: middle; width: 16px;"
          }, {
            tag: 'span',
            unselectable: "on",
            style: "padding-left: 2px",
            html: geneRecords.length + ' genes'
          }]
      })
    }
    return proxyHTML
  }
})