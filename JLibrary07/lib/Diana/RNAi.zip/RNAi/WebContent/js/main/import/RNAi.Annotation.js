
var a_cb = new Ext.grid.CheckboxSelectionModel({
  singleSelect: true
})
//new Ext.grid.RowSelectionModel({singleSelect: true})
var ao_cb = new Ext.grid.CheckboxSelectionModel();


RNAi.Annotation = Ext.extend(Ext.Panel, {
  layout:'border' ,
  split:true,
  initComponent:function() {
    this.items=[new RNAi.AnnotationParameter({
      region: 'center',
      split:true
    }),new RNAi.AnnotationOptions({
      region: 'south',
      split:true,
      height: 200
    })]
    var annotationPanel = this;
        
    RNAi.Annotation.superclass.initComponent.call(this); 
    annotationPanel.parameterPanel = this.items.itemAt(0);
    annotationPanel.optionsPanel = this.items.itemAt(1);
    annotationPanel.annotation_id = '';
        
    annotationPanel.parameterPanel.getSelectionModel().on('rowselect', function(sm, row, rec) {
      annotationPanel.annotation_id = rec.data.annotation_id;
      annotationPanel.optionsPanel.store.load({
        params:{
          start:0, 
          limit:10,                
          req:'amgen.ri.rnai.screener.AnnotationResponder',                
          action_id: 'get-annotation-option',
          annotation_id:annotationPanel.annotation_id
                           
        }
      })
    });
  } 
        
}); 


RNAi.AnnotationParameter = Ext.extend(Ext.grid.EditorGridPanel, {
    
  initComponent:function() {
    var annotationParameterPanel = this;
    annotationParameterPanel.defoptionstore = new Ext.data.JsonStore({
      id:'annotation_option_id',
      root:'annotationoptions',
      url:'/RNAi/rnai.go',
      baseParams:{
        req:'amgen.ri.rnai.screener.AnnotationResponder',                
        action_id: 'get-annotation-option',
        annotation_id : '0'
      },
      fields:[
      {
        name:'annotation_option_id',                     
        type:'integer'
      }
      ,{
        name:'annotation_option_name'
      }                  
      ]
            
    })        
    annotationParameterPanel.defoptionstore.on('beforeload', function(store){
      var records = annotationParameterPanel.getSelectionModel().getSelections();
      var record = records[0];
      store.baseParams = {
        req:'amgen.ri.rnai.screener.AnnotationResponder',                
        action_id: 'get-annotation-option',
        annotation_id : record.data.annotation_id
      };
    });
        
    var config = {          
      store: new Ext.data.Store({
        url: '/RNAi/rnai.go',       
        reader :new Ext.data.JsonReader({
          root :"annotation"
        }, RNAi.Record.Annotation)
      }),
      sm: a_cb,
      columns:[a_cb,{
        id:'annotation_id',
        header:"annotation_id",
        hidden: true,
        dataIndex:'annotation_id'
      },{
        header:"annotation_name",
        width:20,
        sortable:true,
        dataIndex:'annotation_name',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"annotation_default_value",
        width:20,
        sortable:true,
        dataIndex:'annotation_default_value', 
        renderer: function(v, params, record){ 
          var store = this.editor.store
          var x = store.find('annotation_option_id',v);
          if(x>=0){
            record.set("annotation_default_value",store.getAt(x).get('annotation_option_name'));
            return store.getAt(x).get('annotation_option_name'); 
          }else{
            return v
          }
        }, 
        editor: new Ext.form.ComboBox({                       
          fieldLabel: 'Annotation Option',
          hiddenName:'annotation_default_value',
          store:annotationParameterPanel.defoptionstore,
          valueField:'annotation_option_id',
          displayField:'annotation_option_name',
          triggerAction: 'all',
          emptyText:'Select annotation option',
          selectOnFocus:true,
          editable: false     ,
          listeners: {
            expand: function(combo){
              combo.store.reload()
            }
          }
        })
                
      },{
        header:"rnai_type_id",
        width:20,
        sortable:true,
        hidden:true,
        dataIndex:'rnai_type_id',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"rnai_type",
        width:20,
        sortable:true,
        dataIndex:'rnai_type',   
        renderer: function(v, params, record){ 
          var store = this.editor.store
          var x = store.find('rnai_type_id',v);
          if(x>=0){
            record.set("rnai_type_id",store.getAt(x).get('rnai_type_id'));
            return store.getAt(x).get('rnai_type_name'); 
          }else{
            return v
          }
        }, 
        editor: {
          name:'rnai_type_id'
          ,
          fieldLabel:'RNAi Type'
          ,
          allowBlank:false
          ,
          xtype:'combo'
          ,
          triggerAction:'all'
          ,
          mode:'local'
          ,
          editable:false
          ,
          store:new Ext.data.SimpleStore({
            fields:['rnai_type_id', 'rnai_type_name']
            ,
            data:[['1', 'SIRNA'], ['2', 'SHRNA']]
          })
          ,
          displayField:'rnai_type_name'
          ,
          valueField:'rnai_type_id'
          ,
          hiddenName:'rnai_type_id'
        }
      },{
        header:"annotation_type",
        width:20,
        sortable:true,
        dataIndex:'annotation_type',                
        editor: {
          name:'annotation_type'
          ,
          fieldLabel:'Annotation Type'
          ,
          allowBlank:false
          ,
          xtype:'combo'
          ,
          triggerAction:'all'
          ,
          mode:'local'
          ,
          editable:false
          ,
          store:new Ext.data.SimpleStore({
            fields:['annotation_type_id', 'annotation_type_name']
            ,
            data:[['TEXT', 'TEXT'], ['INTEGER', 'INTEGER']]
          })
          ,
          displayField:'annotation_type_name'
          ,
          valueField:'annotation_type_id'
          ,
          hiddenName:'annotation_type'
        }
      },{
        header:"display_order",
        width:20,
        sortable:true,
        dataIndex:'display_order',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"annotation_group_id",
        width:20,
        hidden: true,
        sortable:true,
        dataIndex:'annotation_group_id',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"annotation_group_name",
        width:20,
        sortable:true,
        renderer: function(v, params, record){ 
          var store = this.editor.store
          var x = store.find('annotation_group_id',v);
          if(x>=0){
            record.set("annotation_group_id",store.getAt(x).get('annotation_group_id'));
            return store.getAt(x).get('annotation_group_name'); 
          }else{
            return v
          }
        }, 
        dataIndex:'annotation_group_name',                
        editor: new Ext.form.ComboBox({                       
          fieldLabel: 'Annotation Group',
          hiddenName:'annotation_group_id',
          store: new Ext.data.JsonStore({
            id:'annotation_group_id',
            root:'annotation_group',
            url:'/RNAi/rnai.go',
            autoLoad: true,
            baseParams:{
              req:'amgen.ri.rnai.screener.AnnotationResponder',                
              action_id: 'get-annotation-group'
            },
            fields:[
            {
              name:'annotation_group_id',                     
              type:'integer'
            }
            ,{
              name:'annotation_group_name'
            }                   
            ]
                
          }),
          valueField:'annotation_group_id',
          displayField:'annotation_group_name',
          triggerAction: 'all',
          emptyText:'Select annotation group',
          selectOnFocus:true,
          editable: false                       
        })
      }]
      ,
      listeners:{
        afteredit: function(e){
 
        }  
      }
      ,
      buttons:[{
        text: 'Add',
        listeners: {
          'click': function(button, e){  
            var apstore = this.ownerCt.ownerCt.store;
            var aostore = this.ownerCt.ownerCt.ownerCt.optionsPanel.store;
                        
            var AddAnnWindowUI =  new Ext.Window({
              width: 600,
              height: 420,
              title: "Add Annotation",
              layout: 'fit',
              resizable: false,
              constrain: true,
              buttonAlign: 'center',
              items:new RNAi.AnnotationParameterAdd({
            
                })
            })
                        
            AddAnnWindowUI.on("close", function() {
              apstore.reload();
              aostore.load({
                params:{
                  start:0, 
                  limit:10,                
                  req:'amgen.ri.rnai.screener.AnnotationResponder',                
                  action_id: 'get-annotation-option',
                  annotation_id:'0'
                           
                }
              })
                            
            })
                        
            AddAnnWindowUI.show(); 
                    
          }
        }
      },{
        text: 'Save',
        listeners: {
          'click': function(button, e){
            var apstore = this.ownerCt.ownerCt.store;
            var aostore = this.ownerCt.ownerCt.ownerCt.optionsPanel.store;
            var records = apstore.getModifiedRecords();
                        
            var datar = new Array();
            var annotation_json = "";
            for (var i = 0; i < records.length; i++) {
              datar.push(records[i].data);
            }
            annotation_json = Ext.util.JSON.encode(datar);
                        
            Ext.Ajax.request({
              url:'/RNAi/rnai.go', 
              success: function(response){
                                
                if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                  apstore.reload();
                                    
                  aostore.load({
                    params:{
                      start:0, 
                      limit:10,                
                      req:'amgen.ri.rnai.screener.AnnotationResponder',                
                      action_id: 'get-annotation-option',
                      annotation_id:'0'
                           
                    }
                  })
                }
                else {
                  Ext.MessageBox.show({
                    title: 'Save Annotation',
                    msg: 'Unable to save Annotation changes1.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                }
              },
              failure: function(response){
                Ext.MessageBox.show({
                  title: 'Save Annotation',
                  msg: 'Unable to save Annotation changes2.',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
              },
              scope: this,
              params: {
                req:'amgen.ri.rnai.screener.AnnotationResponder',
                annotation_json :annotation_json,
                table_name: 'annotation',
                action_id: 'edit-annotation'
              }
            })
          }
        }
      }, {
        text: 'Delete',
        listeners: {
          'click': function(button, e){  
            var apstore = this.ownerCt.ownerCt.store;
            var aostore = this.ownerCt.ownerCt.ownerCt.optionsPanel.store;
            var records = this.ownerCt.ownerCt.getSelectionModel().getSelections();
            if (records.length > 0) {
              var ids_todelete = "";
              var names_todelete = "";
              for (i = 0; i < records.length; i++) {
                var record = records[i];
                ids_todelete = ids_todelete + record.data.annotation_id + ",";
                names_todelete = names_todelete + record.data.annotation_name + ",";
              }
              if (ids_todelete.length > 0) {
                ids_todelete = ids_todelete.substring(0, ids_todelete.length - 1);
                names_todelete = names_todelete.substring(0, names_todelete.length - 1);
              }
              Ext.MessageBox.show({
                title: 'Delete Annotation',
                msg: 'Do you want to delete the selected Annotation : ' + names_todelete + '?',
                buttons: Ext.MessageBox.YESNO,
                fn: function(buttonId){
                  if (buttonId != 'yes') {
                    return
                  }
                  Ext.Ajax.request({
                    url:'/RNAi/rnai.go', 
                    success: function(response){
                      if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                        apstore.reload();
                        aostore.load({
                          params:{
                            start:0, 
                            limit:10,                
                            req:'amgen.ri.rnai.screener.AnnotationResponder',                
                            action_id: 'get-annotation-option',
                            annotation_id:'0'
                           
                          }
                        })
                      }
                      else {
                        Ext.MessageBox.show({
                          title: 'Delete Annotation',
                          msg: 'Unable to save Annotation changes1.',
                          buttons: Ext.MessageBox.OK,
                          icon: Ext.MessageBox.ERROR
                        })
                      }
                    },
                    failure: function(response){
                      Ext.MessageBox.show({
                        title: 'Delete Annotation',
                        msg: 'Unable to save Annotation changes2.',
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                      })
                    },
                    scope: this,
                    params: {
                      req:'amgen.ri.rnai.screener.AnnotationResponder',
                      deleteIds :ids_todelete,
                      table_name:'annotation',
                      action_id: 'delete-annotation'
                    }
                  })
                } 
              })
                   
            }else{
              Ext.Msg.alert('Delete Annotation Options', 'Please select one or more annotation options');             
            }
          }
        }
      }],
      viewConfig:{
        forceFit:true
      }
    }; // eo config object

    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
 
    this.bbar = new Ext.PagingToolbar({
      store:this.store            ,
      displayInfo:true            ,
      pageSize:10
    });
 
    // call parent
    RNAi.AnnotationParameter.superclass.initComponent.apply(this, arguments);
  } // eo function initComponent
 
  ,
  onRender:function() {
    var grid = this;
    // call parent
    RNAi.AnnotationParameter.superclass.onRender.apply(this, arguments);
 
    // load the store
    this.store.load({
      params:{
        start:0, 
        limit:10,                
        req:'amgen.ri.rnai.screener.AnnotationResponder',                
        action_id: 'get-annotation'
                           
      }
    });
        
    
        
 
  } // eo function onRender
 
});




RNAi.AnnotationOptions = Ext.extend(Ext.grid.EditorGridPanel, {
  initComponent:function() {
    var config = {
      store:new Ext.data.JsonStore({
        id:'annotation_option_id',
        root:'annotationoptions',
        url:'/RNAi/rnai.go',
        fields:[
        {
          name:'annotation_option_id',                     
          type:'integer'
        }
        ,{
          name:'annotation_id'
        } ,{
          name:'annotation_option_name'
        } ,{
          name:'annotation_option_description'
        } ,{
          name:'display_order'
        }                   
        ]
      }),
      sm: ao_cb,
      columns:[ao_cb,{
        id:'annotation_option_id',
        header:"annotation_option_id",
        hidden: true,
        dataIndex:'annotation_option_id'
      },{
        header:"annotation_id",
        width:20,
        hidden: true,
        sortable:true,
        dataIndex:'annotation_id',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"annotation_option_name",
        width:20,
        sortable:true,
        dataIndex:'annotation_option_name',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"annotation_option_description",
        width:20,
        sortable:true,
        dataIndex:'annotation_option_description',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      },{
        header:"display_order",
        width:20,
        sortable:true,
        dataIndex:'display_order',                
        editor: new Ext.form.TextField({
          allowBlank: false
        })
      }]
      ,
            
      buttons:[{
        text: 'Add',
        listeners: {
          'click': function(button, e){  
            var aostore = this.ownerCt.ownerCt.store;
            var annotation_id = this.ownerCt.ownerCt.ownerCt.annotation_id;
                        
            var AddAnnOptionWindowUI =  new Ext.Window({
              width: 600,
              height: 420,
              title: "Add Annotation Option",
              layout: 'fit',
              resizable: false,
              constrain: true,
              buttonAlign: 'center',
              items:new RNAi.AnnotationOptionsAdd({
                annotation_id:annotation_id
            
              })
            })
                        
            AddAnnOptionWindowUI.on("close", function() {
              aostore.reload();
                            
                            
            })
                        
            AddAnnOptionWindowUI.show(); 
                    
          }
        }
      },{
        text: 'Save',
        listeners: {
          'click': function(button, e){
            var aostore = this.ownerCt.ownerCt.store;
            var optionsPanel = this.ownerCt.ownerCt.ownerCt.optionsPanel;
            var records = aostore.getModifiedRecords();
                        
            var datar = new Array();
            var annotation_json = "";
            for (var i = 0; i < records.length; i++) {
              datar.push(records[i].data);
            }
            annotation_json = Ext.util.JSON.encode(datar);
                        
            Ext.Ajax.request({
              url:'/RNAi/rnai.go', 
              success: function(response){
                if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                  aostore.reload();
                  optionsPanel.doLayout();
                                    
                }
                else {
                  Ext.MessageBox.show({
                    title: 'Save Annotation Options',
                    msg: 'Unable to save Annotation Option changes1.',
                    buttons: Ext.MessageBox.OK,
                    icon: Ext.MessageBox.ERROR
                  })
                }
              },
              failure: function(response){
                Ext.MessageBox.show({
                  title: 'Save Annotation Options',
                  msg: 'Unable to save Annotation Option changes2.',
                  buttons: Ext.MessageBox.OK,
                  icon: Ext.MessageBox.ERROR
                })
              },
              scope: this,
              params: {
                req:'amgen.ri.rnai.screener.AnnotationResponder',
                annotation_json :annotation_json,
                table_name: 'annotation_option',
                action_id: 'edit-annotation'
              }
            })
          }
        }
      }, {
        text: 'Delete',
        listeners: {
          'click': function(button, e){  
            var aostore = this.ownerCt.ownerCt.store;
            var records = this.ownerCt.ownerCt.getSelectionModel().getSelections();
            if (records.length > 0) {
              var ids_todelete = "";
              var names_todelete = "";
              for (i = 0; i < records.length; i++) {
                var record = records[i];
                ids_todelete = ids_todelete + record.data.annotation_option_id + ",";
                names_todelete = names_todelete + record.data.annotation_option_name + ",";
              }
              if (ids_todelete.length > 0) {
                ids_todelete = ids_todelete.substring(0, ids_todelete.length - 1);
                names_todelete = names_todelete.substring(0, names_todelete.length - 1);
              }
              Ext.MessageBox.show({
                title: 'Delete Annotation Option',
                msg: 'Do you want to delete the selected Annotation options: ' + names_todelete + '?',
                buttons: Ext.MessageBox.YESNO,
                fn: function(buttonId){
                  if (buttonId != 'yes') {
                    return
                  }
                  Ext.Ajax.request({
                    url:'/RNAi/rnai.go', 
                    success: function(response){
                      if (Ext.util.JSON.decode(response.responseText).message == "Passed") {
                        aostore.reload();
                      }
                      else {
                        Ext.MessageBox.show({
                          title: 'Delete Annotation Option',
                          msg: 'Unable to save Annotation option changes1.',
                          buttons: Ext.MessageBox.OK,
                          icon: Ext.MessageBox.ERROR
                        })
                      }
                    },
                    failure: function(response){
                      Ext.MessageBox.show({
                        title: 'Delete Annotation Option',
                        msg: 'Unable to save Annotation option changes2.',
                        buttons: Ext.MessageBox.OK,
                        icon: Ext.MessageBox.ERROR
                      })
                    },
                    scope: this,
                    params: {
                      req:'amgen.ri.rnai.screener.AnnotationResponder',
                      deleteIds :ids_todelete,
                      table_name:'annotation_option',
                      action_id: 'delete-annotation'
                    }
                  })
                } 
              })
                   
            }else{
              Ext.Msg.alert('Delete Annotation Options', 'Please select one or more annotation options');             
            }
          }
        }
      }],
      viewConfig:{
        forceFit:true
      }
    }; // eo config object
 
    // apply config
    Ext.apply(this, Ext.apply(this.initialConfig, config));
 
    this.bbar = new Ext.PagingToolbar({
      store:this.store            ,
      displayInfo:true            ,
      pageSize:10
    });
 
    // call parent
    RNAi.AnnotationOptions.superclass.initComponent.apply(this, arguments);
  } // eo function initComponent
 
  ,
  onRender:function() {
        
    // call parent
    RNAi.AnnotationOptions.superclass.onRender.apply(this, arguments);
        
  } // eo function onRender
 
});
