RNAi.Dialog.OGAAnalysis= Ext.extend(RNAi.Dialog.AnalysisBase, {
  fields: [{
    xtype: 'fieldset',
    title: 'Provide RNAi Compound IDs to Mask',
    checkboxToggle: true,
    checkboxName: 'has_masked_compound_ids',
    collapsed: true,
    baseCls: 'x-plain',
    items:[{
      xtype: 'textarea',
      hideLabel: true,
      name: 'masked_compound_ids',
      flex: 1  ,
      height: 100,
      width: '100%'
    }]
  }]   
})