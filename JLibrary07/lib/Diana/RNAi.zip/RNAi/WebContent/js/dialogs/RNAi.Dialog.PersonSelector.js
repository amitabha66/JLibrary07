RNAi.Dialog.PersonSelector= Ext.extend(Ext.Window, {
  initComponent: function() {
    var me= this
    Ext.apply(this, {
      layout:'border',
      width:330,
      height:175,
      items: new Ext.FormPanel({
        region: 'center',
        labelAlign: 'top',
        frame: true,
        items: [me.ownerSelectFieldSet= new Ext.form.FieldSet({
          title: 'Select User',
          items:[(me.combo= new RNAi.UserSelectorCombo({          
            fieldLabel: 'Search',
            width: 280
          }))]
        })]
      }),     
      buttons: [{
        text:'OK',
        handler: function(){
          if (Ext.isFunction(me.handler)) {            
            if (me.handler.call(me.scope, me.combo.selectedRecord)!== false) {
              me.hide()
            }
          } else {
            me.hide()
          }
        }
      },{
        text: 'Cancel',
        handler: function(){
          me.hide();
        }
      }]
    })
    RNAi.Dialog.PersonSelector.superclass.initComponent.call(this)
  }
})