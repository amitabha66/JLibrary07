/**
 * @author jemcdowe
 */
RNAi.ConditionalHighlight = Ext.extend(Ext.Window, {
  title: 'ConditionalHighlight',
  width: 450,
  height: 150,
  fileLoaded: false,
  layout: 'border',
  initComponent: function(){
    var dialog = this
    
    var recordArray= []
    var hasDefaultValues= false
    
    for(var i=0; i< this.grid.getColumnModel().getColumnCount(); i++) {
      var header= this.grid.getColumnModel().getColumnHeader(i)
      var isHidden= this.grid.getColumnModel().isHidden(i)
      var dataIndex= this.grid.getColumnModel().getDataIndex(i)
      if (!isHidden) {
        recordArray.push({
          dataIndex: dataIndex, 
          displayText: header
        })
        if (Ext.isObject(this.highlightDef) && this.highlightDef.field== dataIndex) {
          hasDefaultValues= true
        }
      }     
    }                
    this.items = [(dialog.form = new Ext.form.FormPanel({
      frame: true,
      region: 'center',
      labelAlign: 'top',
      height: 40,
      items: [{
        xtype : 'compositefield',
        anchor: '-20',
        msgTarget: 'side',
        fieldLabel: 'Select Highlight Criteria',
        items: [{      
          xtype: 'combo',
          typeAhead: true,
          triggerAction: 'all',
          mode: 'local',
          forceSelection: true,
          editable:       false,
          store: new Ext.data.JsonStore({
            fields: [
            'dataIndex',
            'displayText'
            ],
            data: recordArray
          }),
          emptyText: 'Select Column',
          name:           'field',
          hiddenName:     'field',
          valueField: 'dataIndex',
          displayField: 'displayText',
          allowBlank: false,
          value: (hasDefaultValues ? this.highlightDef.field : undefined)
        },{
          width:          75,
          xtype:          'combo',
          mode:           'local',
          value:          (hasDefaultValues ? this.highlightDef.comp : '<'),
          triggerAction:  'all',
          forceSelection: true,
          editable:       false,
          name:           'comp',
          hiddenName:     'comp',
          displayField:   'name',
          valueField:     'value',
          store:          new Ext.data.JsonStore({
            fields : ['name', 'value'],
            data: [{
              name : '<',   
              value: '<'
            },{
              name : '>',  
              value: '>'
            }, {
              name : '=', 
              value: '='
            }, {
              name : '<>', 
              value: '<>'
            }, {
              name : 'Contains', 
              value: 'c'
            }, {
              name : 'Starts With', 
              value: 's'
            }, {
              name : 'Ends With', 
              value: 'e'
            }
            ]
          }),
          allowBlank: false
        },
        {
          xtype: 'textfield',
          flex : 1,
          emptyText: 'Enter Compare Value',
          name : 'compareValue',
          fieldLabel: 'Value',
          allowBlank: false,
          value: (hasDefaultValues ? this.highlightDef.compareValue : undefined)
        }]
      }]
    }))]
        
    this.buttons = [{
      text: 'OK',
      handler: function(){
        if (!dialog.form.getForm().isValid()) {
          return
        }
        var values= dialog.form.getForm().getValues()
        var highlightDef= {
          field: values.field,
          comp: values.comp,
          compareValue: values.compareValue          
        }
        if (Ext.isFunction(dialog.handler)) {
          dialog.handler.call(dialog.scope, highlightDef)
        }
        dialog.close();
      },
      scope: this
    }, {
      text: 'Cancel',
      handler: function(){
        dialog.close();
      }
    }]
    RNAi.ConditionalHighlight.superclass.initComponent.call(this);
  }  
});

