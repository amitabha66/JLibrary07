/**
 * @author jemcdowe
 */
RNAi.Dialog.LogMonitor = Ext.extend(Ext.Window, {  
  layout: 'border',  
  closeable: true,
  resizable: true,
  initComponent: function(){
    var dialog = this
    Ext.applyIf(this, {
      title: 'Log Monitor',
      width: 450,
      height: 400,      
      refresh: 5,
      lastLineNumber: 0
    })    
    this.items= [(this.logPanel= new Ext.Panel({
      region: 'center',
      autoScroll:true
    }))]
    this.on('render', function() {      
      dialog.logUpdateTask= Ext.TaskMgr.start({
        run : dialog.updateLog,
        interval : dialog.refresh * 1000 || 5000,
        scope: dialog
      });
    })
    this.on('close', function() {      
      Ext.TaskMgr.stop(dialog.logUpdateTask);
    })    
    RNAi.Dialog.LogMonitor.superclass.initComponent.call(this);
  },
  updateLog: function(){    
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, options){
        var logResponse = null
        try {
          logResponse= Ext.decode(response.responseText, true)
        } catch(e) {}
        
        if (logResponse) {
          if (this.lastLineNumber!= logResponse.lastLineNumber) {
            this.lastLineNumber= logResponse.lastLineNumber
            if (logResponse && logResponse.lines) {
              for(var i=0; i< logResponse.lines.length; i++) {
                this.logPanel.body.insertHtml('beforeEnd', "<SPAN class='x-logline'>"+logResponse.lines[i]+"</BR></SPAN>")
              }
            }
            if (this.noScroll!== true) {
              var offset = this.logPanel.body.dom.scrollHeight - (0 + this.logPanel.body.dom.clientHeight) + (this.lastLineNumber*6);
              this.logPanel.body.scrollTo.defer(200, this.logPanel.body, ["scrollTop", offset, true])
            }
          }
          if (Ext.isObject(logResponse.analysisFinished)) {
            Ext.TaskMgr.stop(this.logUpdateTask);         
            this.setTitle(this.title + " (Finished)")
            if (Ext.isFunction(this.analysisComplete)) {
              this.analysisComplete.call(this.scope, logResponse.analysisFinished)
            }
          }
        }
      },
      failure: function(response, options){
      },
      scope: this,
      params: {
        req:'amgen.ri.rnai.analyze.RNAiAnalysisResponder',        
        rx: 'READLOG',
        analysisKey: this.analysisKey,
        lastLineNumber: this.lastLineNumber
      }
    })
  }
});

