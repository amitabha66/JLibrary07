
RNAi.Dialog.GeneHistograms= Ext.extend(Ext.Window, {
  layout: 'border',  
  maximizable: true,
  iconCls:'ix-v0-16-column-chart', 
  initComponent:function() {    
    var title= 'Experiment Plots- '+ this.geneRecord.data.gene_symbol + "," + 
    this.geneRecord.data.gene_name 
    Ext.applyIf(this, {
      title: title,
      layout: 'border',
      width:520,
      height:527,
      closeable: true,
      closeAction: 'close'
    })    
    this.tabPanelItems= []    
    for(var name in this.plotDetails) {    
      this.tabPanelItems.push(new RNAi.Dialog.GeneHistogramNestedTabPanel({
        title: name,
        region: 'center',
        dataProxy: this.dataProxy,
        parentWin: this,
        plotDetails: this.plotDetails[name]
      }))
    }
    this.items= (this.tabPanel= new Ext.TabPanel({
      region: 'center',
      activeTab: 0,
      resizeTabs:true, 
      minTabWidth: 115,
      tabWidth:135,
      enableTabScroll:true,
      defaults: {
        autoScroll:true
      },
      plugins: new Ext.ux.TabCloseMenu(),
      items: this.tabPanelItems
    }))
    
    this.tbar= ['->', this.downloadButton= new Ext.Button({
      iconCls: 'ix-v0-16-import2',
      text: 'Download',
      disabled: (this.dataProxy ? true : false),
      handler: function() {
        this.tabPanel.getActiveTab().downloadPlotImage()
      },
      scope: this
    })
    ]    
    RNAi.Dialog.GeneHistograms.superclass.initComponent.call(this); 
  }
})  


RNAi.Dialog.GeneHistogramNestedTabPanel= Ext.extend(Ext.TabPanel, {
  autoScroll: true,
  width: 480,
  height: 960,
  activeTab: 0,
  tabPosition: 'bottom',
  region: 'center',
  initComponent:function() { 
    this.items= []
    for(var i=0; i< this.plotDetails.length; i++) {
      this.items.push(new RNAi.Dialog.GeneHistogramPanel({
        region: 'center',
        plotDetails: this.plotDetails[i]
      })
      )
    }
    RNAi.Dialog.GeneHistogramNestedTabPanel.superclass.initComponent.call(this); 
  },
  downloadPlotImage: function() {    
    RNAi.showMessage('Download Started', 'Download')
    new RNAi.TabPanelLoader().downloadFile('/RNAi/export2png.go', {
      name: 'ExperimentHistogram',
      pngURL: this.getActiveTab().plotDetails.imgFile 
    })     
  }
}) 



RNAi.Dialog.GeneHistogramPanel= Ext.extend(Ext.Panel, {
  autoScroll: true,
  layout: 'fit',
  initComponent:function() {   
    this.title= this.plotDetails.name
    this.width= this.plotDetails.width || 1000
    this.height= this.plotDetails.height || 1000
    this.on('render', function(panel) {
      panel.setPlotImage.defer(100, panel)
    })
    RNAi.Dialog.GeneHistogramPanel.superclass.initComponent.call(this); 
  },
  setPlotImage: function() {
    var slideAnchor= 'l'    
    if (!this.plotEl) {
      var bd = this.body;
      bd.update('').setStyle('background','#fff');
      this.plotEl = bd.createChild(); 
    }
    var url= '/RNAi/rnaicache.go?pngURL='+this.plotDetails.imgFile    
    var dom= {
      tag: 'img', 
      src: Ext.BLANK_IMAGE_URL,
      width: this.plotDetails.width || 1000,
      height: this.plotDetails.height || 1000,
      style: 'background: url('+url+') no-repeat !important;'
    }
    this.plotEl.hide().update(Ext.DomHelper.markup(dom)).slideIn(slideAnchor, {
      stopFx: true,
      duration: 0.2
    });
  }
}) 
