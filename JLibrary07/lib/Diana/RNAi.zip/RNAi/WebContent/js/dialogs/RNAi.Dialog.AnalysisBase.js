RNAi.Dialog.AnalysisBase= Ext.extend(Ext.Window, {  
  buttonAlign: 'center',
  layout: 'border',
  initComponent: function() {
    var me= this
    Ext.applyIf(this,{
      title: 'OGA Analysis On Experiments',
      width: 300,
      height: 400,
      minWidth: 300,
      minHeight: 200,
      modal: true
    })
    
    this.items= [
    me.expListView= new Ext.list.ListView({
      title: 'Experiments',
      region: 'center',
      singleSelect: false,
      store: new Ext.data.Store({          
        autoLoad: false,
        reader :new Ext.data.JsonReader({
          idProperty: 'experiment_id',
          root :"experiments"
        }, RNAi.Record.Experiment)                     
      }),
      emptyText: 'No experiments to display',
      reserveScrollOffset: true,
      columns: [{
        header: 'Experiment Name',
        dataIndex: 'experiment_name'
      }]
    })]
  
    if (me.fields) {
      this.items.push(
        me.formPanel= new Ext.form.FormPanel({                   
          region: 'south',
          height: '50%',
          labelAlign: 'top',
          labelWidth: 55,
          frame: true,
          items: me.fields
        }))
    }
    
    this.buttons= [{
      text: me.analyzeLabel || 'Analyze',
      handler: function() {
        if (Ext.isFunction(me.handler)) {
          var values= me.formPanel.getForm().getValues()          
          me.handler.call(me.scope, me.expListView.getSelectedRecords(), values)                                      
        }
        me.close()
      }
    },{
      text: 'Cancel',
      handler: function() {
        me.close()
      }
    }]
  
    me.expListView.store.add(this.expRecords)
    RNAi.Dialog.AnalysisBase.superclass.initComponent.call(this)
  }
})