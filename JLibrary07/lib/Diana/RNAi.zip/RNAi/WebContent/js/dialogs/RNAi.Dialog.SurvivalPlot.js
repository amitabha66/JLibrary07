
RNAi.Dialog.SurvivalPlot = Ext.extend(Ext.Window, {
  layout: 'border',
  maximizable: true,
  iconCls: 'ix-v0-16-gantt-chart',
  initComponent: function() {
    var win = this
    Ext.applyIf(this, {
      title: 'Survival Plot- ' + this.expRecord.data.experiment_name,
      layout: 'border',
      width: 520,
      height: 527,
      closeable: true,
      closeAction: 'close'
    })
    this.items = (this.plotPanel = new RNAi.Dialog.SurvivalPlotPanel({
      region: 'center',
      layout: 'fit',
      dataProxy: this.dataProxy,
      parentWin: this,
      query: this.query
    }))

    this.tbar = [this.leftButton = new Ext.Button({
        iconCls: 'ix-v0-16-arrow_left_green',
        text: 'Previous',
        handler: function() {
          this.plotPanel.setPlotImage('-')
        },
        scope: this
      }), this.rightButton = new Ext.Button({
        iconCls: 'ix-v0-16-arrow_right_green',
        text: 'Next',
        handler: function() {
          this.plotPanel.setPlotImage('+')
        },
        scope: this
      }),
      '->', this.downloadButton = new Ext.Button({
        iconCls: 'ix-v0-16-import2',
        text: 'Download',
        disabled: (this.dataProxy ? true : false),
        handler: function() {
          this.plotPanel.downloadPlotImage()
        },
        scope: this
      })
    ]

    this.plotPanel.on('render', function(panel) {
      new Ext.dd.DropTarget(this.plotPanel.body.dom, {
        ddGroup: 'geneDDGroup',
        notifyEnter: function(ddSource, e, data) {
          if (!data.record) {
            return this.dropNotAllowed
          }
          return this.dropAllowed
        },
        notifyDrop: function(ddSource, e, data) {
          if (!data.record) {
            return false
          }
          var records = data.record
          if (!Ext.isArray(data.record)) {
            records = [data.record]
          }
          win.plotPanel.updatePlot(records)
          return true;
        }
      });
    }, this)
    this.on('render', function(win) {
      win.updateToolbar()
    })

    RNAi.Dialog.SurvivalPlot.superclass.initComponent.call(this);
  },
  updateToolbar: function() {
    var plotPanel = this.plotPanel
    if (plotPanel.plotURLs.length <= 0) {
      this.leftButton.setDisabled(true)
      this.rightButton.setDisabled(true)
      this.downloadButton.setDisabled(true)
    } else {
      this.downloadButton.setDisabled(false)
      this.leftButton.setDisabled(plotPanel.plotIndex == 0)
      this.rightButton.setDisabled(plotPanel.plotIndex >= plotPanel.plotURLs.length - 1)
    }
  }
})

RNAi.Dialog.SurvivalPlotPanel = Ext.extend(RNAi.ResultsPanel, {
  autoScroll: true,
  width: 480,
  height: 960,
  plotIndex: 0,
  initComponent: function() {
    this.plotURLs = []
    RNAi.Dialog.SurvivalPlotPanel.superclass.initComponent.call(this);

  },
  updatePlot: function(newGeneRecords) {
    var geneRecordCount = this.geneRecords.length
    for (var i = 0; i < newGeneRecords.length; i++) {
      var newGeneRecord = newGeneRecords[i]
      var newGeneID = newGeneRecord.data.gene_id
      var alreadyInPlot = false
      for (var j = 0; j < this.geneRecords; j++) {
        var geneID = this.geneRecords[j].data.gene_id
        if (newGeneID == geneID) {
          alreadyInPlot = true
        }
      }
      if (!alreadyInPlot) {
        this.geneRecords.push(newGeneRecord)
      }
    }

    if (this.geneRecords.length > geneRecordCount) {
      this.handleSearch()
    }
  },
  handleSearch: function(query) {
    var panel = this
    panel.getEl().mask('Loading...', 'x-mask-loading')
    
    if (query) {
      this.expRecord = (query.expRecord || (this.expRecord || null))
      this.geneRecords = (Ext.isArray(query.geneRecords) ? query.geneRecords : [query.geneRecords])
      this.refGeneSymbols = query.refGeneSymbols
    }
    var geneIDs = []
    var geneMixtureIDs = []
    for (var i = 0; i < this.geneRecords.length; i++) {
      if (this.geneRecords[i].get('is_mixture')) {
        geneMixtureIDs.push(this.geneRecords[i].get('gene_mixture_id') || this.geneRecords[i].get('gene_id'))
      } else {
        geneIDs.push(this.geneRecords[i].get('gene_id'))
      }
    }

    var storeProxy = (panel.dataProxy ? panel.dataProxy : new Ext.data.HttpProxy({
      url: '/RNAi/rnai.go'
    }));

    Ext.Ajax.request({
      url: storeProxy.url,
      success: function(response, opts) {
        panel.getEl().unmask()
        if (!RNAi.checkForErrorResponse(response)) {
          var results = Ext.decode(response.responseText)
          panel.loadResults(results)
        }
      },
      failure: function() {
        panel.getEl().unmask()
      },
      params: {
        req: 'amgen.ri.rnai.analyze.RNAiAnalysisResponder',
        rx: 'RUN_SURVIVAL_PLOT',
        experiment_id: this.expRecord.get('experiment_id'),
        control_gene_symbols: this.refGeneSymbols,
        gene_id: geneIDs.join(','),
        gene_mixture_id: geneMixtureIDs.join(',')
      }
    });
  },
  loadResults: function(results) {
    if (Ext.isObject(results) && results.key) {
      var url = '/RNAi/rnaicache.go?imgKey=' + results.key
      this.plotURLs.push({
        url: url
      })
      this.plotIndex = this.plotURLs.length - 1
      this.setPlotImage()
    }
  },
  setPlotImage: function(plotIndexInc) {
    var slideAnchor = 'l'
    if (plotIndexInc && plotIndexInc == '+') {
      if (this.plotIndex >= this.plotURLs.length - 1) {
        return
      }
      this.plotIndex++
    } else if (plotIndexInc && plotIndexInc == '-') {
      if (this.plotIndex <= 0 || this.plotURLs.length <= 0) {
        return
      }
      slideAnchor = 'r'
      this.plotIndex--
    }
    if (!this.plotEl) {
      var bd = this.body;
      bd.update('').setStyle('background', '#fff');
      this.plotEl = bd.createChild(); //create default empty div    
    }
    var dom = {
      tag: 'img',
      src: Ext.BLANK_IMAGE_URL,
      width: 480,
      height: 960,
      style: 'background: url(' + this.plotURLs[this.plotIndex].url + ') no-repeat !important;'
    }
    this.plotEl.hide().update(Ext.DomHelper.markup(dom)).slideIn(slideAnchor, {
      stopFx: true,
      duration: 0.2
    });
    this.parentWin.updateToolbar()
  },
  downloadPlotImage: function() {
    if (this.plotURLs.length == 0) {
      return
    }
    var pngURL = this.plotURLs[this.plotIndex].url
    if (pngURL.match(/.*imgKey=(.*)/).length == 2) {
      var imgKey = RegExp.$1
      RNAi.showMessage('Download Started', 'Download')
      new RNAi.TabPanelLoader().downloadFile('/RNAi/export2png.go', {
        name: 'SurvivalPlot',
        imgKey: imgKey
      })
    }
  }
}) 