/**
 * @author jemcdowe
 */
RNAi.ExcelAnalysisDialog = Ext.extend(Ext.Window, {
  title: 'Run OGA Analysis on Experiment Data File',
  width: 450,
  height: 400,
  fileLoaded: false,
  layout: 'border',
  initComponent: function(){
    var dialog = this
        
    this.columnMapStore = new Ext.data.Store({
      autoLoad: true,
      proxy: new Ext.data.MemoryProxy([]),
      reader: new Ext.data.JsonReader({
        root: 'columns',
        id: 'name'
      }, Ext.data.Record.create([{
        name: 'name'
      }, {
        name: 'type'
      }, {
        name: 'types'
      }]))
    })
        
    this.items = [(dialog.form = new Ext.form.FormPanel({
      frame: true,
      region: 'center',
      fileUpload: true,
      height: 40,
      items: [new Ext.form.FileUploadField({
        fieldLabel: 'Experiment File',
        name: 'import_data_file',
        emptyText: 'Select a file',
        width: 300,
        buttonText: 'Browse',
        listeners: {
          fileselected: function(input, file){
            dialog.processFile()
          }
        }
      })]
    })), (dialog.columnMapGrid = new Ext.grid.EditorGridPanel({
      title: 'Column Mappings',
      region: 'south',
      split: true,
      height: 270,
      clicksToEdit: 1,
      enableHdMenu: false,
      enableDragDrop: false,
      enableColumnMove: false,
      enableColumnHide: false,
      store: this.columnMapStore,
      columns: [{
        dataIndex: 'name',
        header: 'Column',
        sortable: false,
        editable: false,
        width: 200
      }, {
        header: 'Type',
        dataIndex: 'type',
        editable: true,
        sortable: false,
        width: 200,
        editor: new Ext.form.ComboBox({
          width: 200,
          resizable: true,
          listWidth: 150,
          store: new Ext.data.SimpleStore({
            autoDestroy: true,
            idIndex: 0,
            fields: ['column_type']
          }),
          valueField: 'column_type',
          displayField: 'column_type',
          triggerAction: 'all',
          mode: 'local'
        })
      }],
      listeners: {
        beforeedit: function(evt){
          var grid = evt.grid
          var record = evt.record
          var colIndex = evt.column
          var rowIndex = evt.row
          var editor = grid.colModel.getCellEditor(colIndex, rowIndex)
          if (Ext.type(record.data.types) != 'array' || record.data.types.length == 0) {
            return false
          }
          editor.field.store.loadData(record.data.types)
        }
      }
    }))]
        
    this.buttons = [{
      text: 'OK',
      handler: function(){
        dialog.runAnalysis()
      },
      scope: this
    }, {
      text: 'Cancel',
      handler: function(){
        dialog.close();
      }
    }]
    RNAi.ExcelAnalysisDialog.superclass.initComponent.call(this);
  },
  processFile: function(){
    this.getEl().mask('Loading File')
    this.fileLoaded = false
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, options){
        this.getEl().unmask()
        var columnJSON = Ext.decode(response.responseText)
        this.columnMapStore.loadData(columnJSON)
        this.fileLoaded = true
      },
      failure: function(response, options){
        this.getEl().unmask()
        this.fileLoaded = false
        this.form.getForm().reset()
        this.columnMapStore.loadData({
          columns: []
        })
        showMessageDialog(options.status.msg, "Unable To Process Experiment File")
      },
      scope: this,
      form: this.form.getForm().getEl(),
      params: {
        req:'amgen.ri.rnai.analyze.RNAiAnalysisResponder',        
        rx: 'PROCESS_EXP_FILE'
      }
    })
  },
  runAnalysis: function(){
    if (!this.fileLoaded) {
      return
    }
    this.columnMapGrid.stopEditing()
    var colMapValues ={}
    var colMapGridRecords = this.columnMapGrid.getStore().getRange()
    
    if (Ext.type(colMapGridRecords) != 'array' || colMapGridRecords.length == 0) {
      return
    }
    for(var i=0; i< colMapGridRecords[0].data.types.length; i++) {
      var type= colMapGridRecords[0].data.types[i][0]
      if (type) {      
        var isTypeSelected= false
        for (var j = 0; j < colMapGridRecords.length; j++) {
          var selectedType= colMapGridRecords[j].data.type
          if (selectedType && selectedType== type) {
            isTypeSelected= true
            colMapValues[type]= j
          }
        }
        if (!isTypeSelected) {
          showMessageDialog('Must select a column for '+type, 'Unable to Run Analysis')
          return
        }
      }
    }    
    RNAi.showMessage('Analysis Started', 'Running...')

    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      success: function(response, options){
        RNAi.checkForErrorResponse(response, 'Error Running Analysis')  
      },
      failure: function(response, options){
        RNAi.checkForErrorResponse(response, 'Error Running Analysis')  
      },
      scope: this,
      form: this.form.getForm().getEl(),
      params: {
        req:'amgen.ri.rnai.analyze.RNAiAnalysisResponder',        
        rx: 'ANALYZE_EXP_FILE',
        columnMapping: Ext.encode(colMapValues)
      }
    })   
    this.close.defer(250, this)
  },
  resetForm: function(importType){
    this.form.getForm().reset()
    this.fileLoaded = false
    this.columnMapGrid.getStore().loadData({
      columns: []
    })
    try {
      Ext.fly(this.form.body.id).dom.reset()
    } catch(e) {}
        
    this.form.items.each(function(item){
      if (Ext.type(item.reset) == 'function') {
        item.reset()
      }
      if (item.getName() == 'type') {
        item.setValue(importType)
      }
    }, this)
  }    
});

