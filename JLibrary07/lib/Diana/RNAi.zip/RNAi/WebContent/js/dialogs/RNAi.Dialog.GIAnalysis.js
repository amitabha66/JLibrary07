RNAi.Dialog.GIAnalysis= Ext.extend(RNAi.Dialog.AnalysisBase, {
  title: 'Genetic Interaction Analysis',
  height: 300,
  fields: [{
    xtype: 'checkbox',
    fieldLabel: 'Existing Analyses',
    boxLabel: 'Overwrite?',
    name: 'overwrite',
    checked: true
  },{
    xtype: 'label',
    text: 'If checked, any existing genetic interaction comparisons between selected experiments will be overwritten. ' +
          'Otherwise, any existing genetic interaction comparisons will not be re-analyzed.'
  }]   
})