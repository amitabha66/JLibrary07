/**
 * @author jemcdowe
 */
RNAi.Dialog.LogsDialog = Ext.extend(Ext.Window, {  
  iconCls:'ix-v0-16-scroll',  
  layout: 'border',  
  closeable: true,
  resizable: true,
  maximizable: true,
  initComponent: function(){
    var me = this
    Ext.applyIf(this, {
      title: 'Log Viewer',
      width: 600,
      height: 500
    })    
    
    this.tree=new Ext.tree.TreePanel({
      title: 'Available Logs',
      region: 'west',
      width: 230,
      autoScroll: true,
      animate: true,
      rootVisible: false,
      split:true,
      collapsible :true,
      collapseMode :'mini',   
      hideCollapseTool: true,
      root: {
        nodeType: 'async',
        text: 'Logs',
        draggable: false,
        id: 'logs',
        expanded: true
      },
      loader: new Ext.tree.TreeLoader({
        url: '/RNAi/rnai.go',
        baseParams: {
          req:'amgen.ri.rnai.search.LogViewResponder',
          experiment_id: RNAi.joinFields(me.expRecords)
        },
        processResponse : function(response, node, callback, scope){
          var json = response.responseText;
          try {
            var nodes=  Ext.decode(json)
            response.responseData= nodes.nodes
          }catch(e){
          }
          Ext.tree.TreeLoader.prototype.processResponse.call(this, response, node, callback, scope)
        },
        createNode: function(attr) {
          if (attr.leaf) {
            attr.iconCls = 'tree-icon-24 ix-v0-24-scroll'
          }
          return Ext.tree.TreeLoader.prototype.createNode.call(this, attr)
        }    
      })
    });   
    
    this.items= [this.tree, (this.logPanel= new Ext.Panel({
      title: 'Log',
      region: 'center',
      autoScroll:true
    }))]    
  
  
    this.tree.on('click', me.logSelected.createDelegate(me))
    RNAi.Dialog.LogsDialog.superclass.initComponent.call(this);
  },
  logSelected: function(node) {
    if (!node.leaf) {
      return
    }
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      params: {
        req:'amgen.ri.rnai.search.LogViewResponder',
        rx: 'LOG_CONTENTS',
        log_id: node.id
      },      
      success: function(response, options){
        var logResponse = null
        try {
          logResponse= Ext.decode(response.responseText, true)
        } catch(e) {}
        
        if (logResponse && Ext.isArray(logResponse.logs) && logResponse.logs.length> 0 && logResponse.logs[0].log_data) {
          var log= logResponse.logs[0]
          this.logPanel.setTitle('Log- '+node.text)
          this.logPanel.body.update("<SPAN class='x-logline'><PRE>"+log.log_data+"</PRE></BR></SPAN>")
        }
      },
      failure: function(response, options){
      },
      scope: this
    })
  }
});

