RNAi.Dialog.CreateSuvivalPlot = Ext.extend(Ext.Window, {
  width: 300,
  height: 400,
  minWidth: 300,
  minHeight: 200,
  modal: true,
  buttonAlign: 'center',
  layout: 'border',
  initComponent: function() {
    var me = this
    this.title = 'Create Survival Plot',
            this.items = [
              me.geneListView = new Ext.list.ListView({
                title: 'Genes',
                region: 'center',
                singleSelect: false,
                store: new Ext.data.Store({
                  autoLoad: false,
                  reader: new Ext.data.JsonReader({
                    idProperty: 'gene_id',
                    root: "genes"
                  }, RNAi.Record.Gene)
                }),
                emptyText: 'No genes to display',
                reserveScrollOffset: true,
                columns: [{
                    header: 'Gene',
                    dataIndex: 'gene_symbol',
                    tpl: new Ext.XTemplate('{gene_symbol:this.processSymMixture}', {
                      processSymMixture: function(val) {
                        return val.replace(/\$\$/g, ',')
                      }
                    })
                  }, {
                    header: 'Name',
                    dataIndex: 'gene_name',
                    tpl: new Ext.XTemplate('{gene_name:this.processNameMixture}', {
                      processNameMixture: function(val) {
                        return val.replace(/\$\$/g, ',')
                      }
                    })
                  }]
              }),
              me.formPanel = new Ext.form.FormPanel({
                region: 'south',
                height: '50%',
                labelAlign: 'top',
                labelWidth: 55,
                frame: true,
                store: new Ext.data.Store({
                  url: '/RNAi/rnai.go',
                  baseParams: {
                    req: 'amgen.ri.rnai.screener.CollectionResponder',
                    action_id: 'GET_EXP_COLLECTION_REFERENCE_GENES',
                    experiment_id: me.expRecord.get('experiment_id')
                  },
                  autoLoad: false,
                  reader: new Ext.data.JsonReader({
                    idProperty: 'gene_id',
                    root: "genes"
                  }, RNAi.Record.Gene),
                  listeners: {
                    beforeload: function() {
                      me.formPanel.el.mask('Loading...')
                    },
                    load: function(store, records) {
                      me.formPanel.el.unmask()
                      var refGeneSymbols = []
                      store.each(function(geneRecord) {
                        refGeneSymbols.push(geneRecord.get('gene_symbol'))
                      })
                      me.formPanel.find('name', 'ref_gene_symbols')[0].setValue(refGeneSymbols.join('\n'))
                    }
                  }
                }),
                items: [{
                    xtype: 'fieldset',
                    title: 'Reference Genes',
                    baseCls: 'x-plain',
                    items: [{
                        xtype: 'textarea',
                        hideLabel: true,
                        name: 'ref_gene_symbols',
                        allowBlank: false,
                        blankText: 'Please enter at least one control gene symbol',
                        flex: 1,
                        height: 100,
                        width: '100%'
                      }]
                  }]
              })]

    this.buttons = [{
        text: 'Analyze',
        handler: function() {
          if (Ext.isFunction(me.handler)) {
            var form = me.formPanel.getForm()
            if (!form.isValid()) {
              return
            }
            var values = form.getValues()
            me.handler.call(me.scope, me.geneListView.getSelectedRecords(), values.ref_gene_symbols)
          }
          me.close()
        }
      }, {
        text: 'Cancel',
        handler: function() {
          me.close()
        }
      }]

    me.geneListView.store.add(this.geneRecords)

    this.on('render', function() {
      me.formPanel.store.load.defer(100, me.formPanel.store)
    })

    RNAi.Dialog.CreateSuvivalPlot.superclass.initComponent.call(this)
  }
})