
RNAi.BufferedGridPanel = Ext.extend(Ext.grid.GridPanel, {
  constructor: function(config) {
    RNAi.BufferedGridPanel.superclass.constructor.call(this, config);
  },  
  initComponent: function() {    
    RNAi.BufferedGridPanel.superclass.initComponent.call(this);  
  }
})
