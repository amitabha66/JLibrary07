/**
 * @author jemcdowe
 */
/**
 * Ext.ux.Notify
 * @version 1.0
 * Copyright(c) 2009 nXgen Web Solutions
 * http://www.nxgenwebsolutions.com
 *  
 * ---------------------------------------------------------------------------
 * 
 * This library is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library.  If not, see http://www.gnu.org/licenses/.
 * 
 * ---------------------------------------------------------------------------
 * 
 * This extension is based on the work of efattal from the ExtJS forums.
 * http://extjs.com/forum/showthread.php?t=32365
 * 
 * This extension provides an easy and simple notification system for web
 * applications. It supports a notification title and message with optional
 * icons associated with each. Please read through the configuration options 
 * in Ext.ux.NotifyMgr and Ext.ux.Notify to learn how to work with this extension.
 * 
 * To create a new notification window, use the following code:
 * 
 *	 new Ext.ux.Notify({
 * 			title: 'Hi',
 *			msg: 'Hello, world!'
 *		}).show(document);
 *
 * The above code will create a notification window that is 200px wide and
 * fades out in 2 seconds.
 * 
 * Please note: You must set 'overflow:hidden' to the body element if you are
 * bottom aligning the notifications to prevent scrollbars from being created.
 * 
 */

/**
 * Ext.ux.ToastWindow
 *
 * @author  Edouard Fattal
 * @date	March 14, 2008
 *
 * @class Ext.ux.ToastWindow
 * @extends Ext.Window
 */

Ext.namespace("Ext.ux");


Ext.ux.NotificationMgr = {
	positions: []
};

Ext.ux.Notification = Ext.extend(Ext.Window, {
	initComponent: function(){
		Ext.apply(this, {
			iconCls: this.iconCls || 'titleicon-info',
			cls: 'x-notification',
			width: 200,
			autoHeight: true,
			plain: false,
			draggable: this.draggable || false
		});
		if(this.autoDestroy) {
			this.task = new Ext.util.DelayedTask(this.hide, this);
		} else {
			this.closable = true;
		}
		Ext.ux.Notification.superclass.initComponent.call(this);
	},
	setMessage: function(msg){
		this.body.update(msg);
	},
	setTitle: function(title, iconCls){
		Ext.ux.Notification.superclass.setTitle.call(this, title, iconCls||this.iconCls);
	},
	onRender:function(ct, position) {
		Ext.ux.Notification.superclass.onRender.call(this, ct, position);
	},
	onDestroy: function(){
		Ext.ux.NotificationMgr.positions.remove(this.pos);
		Ext.ux.Notification.superclass.onDestroy.call(this);
	},
	cancelHiding: function(){
		this.addClass('fixed');
		if(this.autoDestroy) {
			this.task.cancel();
		}
	},
	afterShow: function(){
		Ext.ux.Notification.superclass.afterShow.call(this);
		Ext.fly(this.body.dom).on('click', this.cancelHiding, this);
		if(this.autoDestroy) {
			this.task.delay(this.hideDelay || 5000);
	   }
	},
	animShow: function(){
		this.pos = 0;
		while(Ext.ux.NotificationMgr.positions.indexOf(this.pos)>-1)
			this.pos++;
		Ext.ux.NotificationMgr.positions.push(this.pos);
		this.setSize(200,100);
		this.el.alignTo(document, "br-br", [ -20, -20-((this.getSize().height+10)*this.pos) ]);
		this.el.slideIn('b', {
			duration: 1,
			callback: this.afterShow,
			scope: this
		});
	},
	animHide: function(){
	  Ext.ux.NotificationMgr.positions.remove(this.pos);
    this.el.disableShadow();
		this.el.ghost("b", {
			duration: 1,
			remove: true
		});
	},

	focus: Ext.emptyFn 

}); 

Ext.ux.Notify= Ext.ux.Notification