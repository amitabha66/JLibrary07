
RNAi.ExperimentGridExpander = Ext.extend(RNAi.GridRowExpander, {
  tpl : new Ext.XTemplate(
    '<tpl for="headers">',
    '<table class="x-rnai-exp-dd">',     
    '<tr>',
    '<th valign= "top" nowrap="Y" colspan="2" class="x-rnai-exp-dd x-rnai-exp-dd-section">{name}</th>',
    '</tr>',
    '<tpl for="parent.data[values.name]">',
    '<tr>',
    '<th valign= "top" nowrap="Y" class="x-rnai-exp-dd x-rnai-exp-dd-subsection">{name}</th>',
    '<td class="x-rnai-exp-dd x-rnai-exp-dd-subsection">{value}</td>',
    '</tr>',
    '</tpl>',
    '</tpl>'
    ),
  getExpandedRecord: function(rowRecord, cb, scope) {
    this.rowRecord= rowRecord
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'SEARCH',    
        searchType: 'EXPERIMENT_IDS',
        searchResponse: 'ANNOTATIONS',
        query: rowRecord.data.experiment_id
      },
      success: function(response, opts) {
        var records= []
        try {
          var annotations= Ext.decode(response.responseText).annotations
          if (Ext.isArray(annotations)) {
            for(var i=0; i< annotations.length; i++) {
              records.push(new RNAi.Record.Annotation(annotations[i]))
            }
          }
        } catch(e) {}
        if (Ext.isFunction(cb)) {
          cb.call(scope, records)
        }
      }, 
      failure: function(response, opts) {        
      }
    }) 

    return rowRecord
  },/*
  getRowClass : function(record, rowIndex, p, ds){
    var cls= RNAi.GeneGridExpander.prototype.getRowClass.call(this, record, rowIndex, p, ds)
    if (record.data["OGA METHOD V2:CORRECTED_PVALUE"] && record.data["OGA METHOD V2:CORRECTED_PVALUE"]< 0.05) { 
      return cls+' ' + 'x-genehit-row'
    } else {
      return cls
    }
  },*/
  getBodyContent : function(records, index){
    var headers= []
    var data= {}
    
    headers.push({
      name: 'Experiment'
    })
    data['Experiment']= []
    data['Experiment'].push({
      name: 'Name',
      value: this.rowRecord.data.experiment_name,
      order: data['Experiment'].length
    })    
    data['Experiment'].push({
      name: 'Experiment ID',
      value: this.rowRecord.data.experiment_id,
      order: data['Experiment'].length
    })    
    data['Experiment'].push({
      name: 'Uploaded By',
      value: this.rowRecord.data.uploaded_by,
      order: data['Experiment'].length
    })    
    data['Experiment'].push({
      name: 'Uploaded Date',
      value: this.rowRecord.data.experiment_date.format('m/d/Y'),
      order: data['Experiment'].length
    })     
    
    for(var i=0; i< records.length; i++) {
      var r= records[i]
      if (!data[r.data.annotation_group_name]) {
        data[r.data.annotation_group_name]= []
        headers.push({
          name: r.data.annotation_group_name
        })
      }
      data[r.data.annotation_group_name].push({
        name: r.data.annotation,
        value: r.data.value || '&nbsp;',
        order: r.data.display_order
      })
    }
    var content = this.tpl.apply({
      headers: headers, 
      data: data
    });
    return content;
  }  
})

