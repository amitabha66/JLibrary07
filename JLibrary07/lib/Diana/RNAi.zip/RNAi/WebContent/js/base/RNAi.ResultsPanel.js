RNAi.ResultsPanel = Ext.extend(Ext.Panel, {
  constructor: function(config) {
    Ext.applyIf(config, {
      layout: 'border',
      border: false
    })    
    RNAi.ResultsPanel.superclass.constructor.call(this, config);   
  }, 
  initComponent:function() {               
    this.on('render', function(panel) {      
      if ((panel.callSearch===true ||  Ext.isObject(panel.query)) && Ext.isFunction(panel.handleSearch)) {
        panel.handleSearch.defer(100, panel, [panel.query])
      } else if (panel.resultsLoaded) {
        panel.loadResults.defer(100, panel)
      }     
    })
    RNAi.ResultsPanel.superclass.initComponent.call(this); 
  },
  selectById: function(id) {
    if (this.contentGrid) {
      var record= this.contentGrid.getStore().getById(id)
      if (record) {
        if (Ext.isFunction(this.contentGrid.getSelectionModel().selectRecords)) {
          this.contentGrid.getSelectionModel().selectRecords([record], false)
        }
      }

    }
  }

})