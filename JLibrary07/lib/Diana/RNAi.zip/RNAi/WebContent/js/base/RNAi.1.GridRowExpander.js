/**
 * Defines the Grid Row expander
 */

RNAi.GridRowExpander = Ext.extend(Ext.ux.grid.RowExpander, {
  expandOnDblClick: false,
  beforeExpand: function(record, body, rowIndex) {
    this.getExpandedRecord(record, function(expandedRecord) {
      if (expandedRecord) {
        if (this.tpl && this.lazyRender) {
          var displayedRecord= expandedRecord
          if (Ext.isFunction(this.beforeShow)) {
            displayedRecord= this.beforeShow.call(this, expandedRecord)
          }
          var row = this.grid.view.getRow(rowIndex)
          body.innerHTML = this.getBodyContent(displayedRecord, rowIndex);
          this.state[record.id] = true;
          Ext.fly(row).replaceClass('x-grid3-row-collapsed', 'x-grid3-row-expanded');
          this.fireEvent('expand', this, record, body, row.rowIndex);
        }
      }
    }, this)
    return false
  },
  getExpandedRecord: function(rowRecord, cb, scope) {
    if (Ext.isFunction(cb)) {
      cb.call(scope, rowRecord)
    }
  },
  getRowClass: function(record, rowIndex, p, ds) {
    var cls = RNAi.GridRowExpander.superclass.getRowClass.call(this, record, rowIndex, p, ds)
    if (Ext.isFunction(this.grid.isHighlightedRecord) && this.grid.isHighlightedRecord(record)) {
      return cls + ' ' + 'x-genehit-row'
    }
    return cls
  },
  openAsWindow: function(record, title) {
    this.getExpandedRecord(record, function(expandedRecord) {
      if (expandedRecord) {
        if (this.tpl && this.lazyRender) {
          new Ext.Window({
            title: (title || '') + ' Properties',
            layout: 'border',
            maximizable: true,
            closeable: true,
            resizable: true,
            items: {
              region: 'center',
              autoScroll: true,
              bodyCssClass: 'x-rnai-exp-dd',
              padding: '0 0 0 5',
              html: this.getBodyContent(expandedRecord)
            },
            width: Math.min(600, Ext.getBody().getWidth() * 0.75),
            height: Math.min(600, Ext.getBody().getHeight() * 0.75)
          }).show()
        }
      }
    }, this)


  }
})
