/**
 * @class RG.rx.UserSelectorCombo
 * @extends Ext.form.ComboBox
 * Provides single lookup combo for people
 * @param {Object} config
 */
RNAi.UserSelectorCombo = Ext.extend(Ext.form.ComboBox,  {	
  initComponent : function(){
    Ext.applyIf(this, {
      hiddenName: this.name
    })
    // Set up the options
    Ext.apply(this, {
      store :new Ext.data.Store({
      url: '/RNAi/rnai.go',
        baseParams: {
          req: 'amgen.ri.rnai.ui.PersonSearchResponder'
        },           
        reader: new Ext.data.JsonReader({
          root: "persons",
          idProperty: 'person_id'
        }, RNAi.Record.Person)
      }),
      triggerClass :'x-form-clear-trigger',
      displayField :'ledger_name',
      valueField :'amgen_login',
      typeAhead :false,
      emptyText :'Type Person (Last,First) min. 3 characters)',
      loadingText :'Retrieving...',
      resizable :true,
      minChars :3,
      handleHeight :10,
      height :10,
      hideTrigger :true,
      forceSelection :true,
      listeners: {
        beforequery : function(qe) {
          delete qe.combo.lastQuery;
        }
      }
    })     
    
    this.store.on('load', function(store) {
      if (store.getCount()>=100) {
        RNAi.showMessage('Results limited to 100 names. Consider refining input.', 'Showing Only First 100 Names')
      }
    })
    this.on('select', function(combo, record) {
      combo.selectedRecord= record
    })
    RNAi.UserSelectorCombo.superclass.initComponent.call(this);    
  }
});
Ext.reg('userselectorcombo', RNAi.UserSelectorCombo);
