
RNAi.RNAiGridExpander = Ext.extend(RNAi.GridRowExpander, {
  tpl_standard: new Ext.XTemplate(
          '<table class="x-rnai-gene-dd">',
          //Basic Details
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section">Basic Details</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Compound ID:</th><td>{compound_id}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Vendor:</th><td>{vendor}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Vendor ID:</th><td>{vendor_product_id}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Sequence:</th><td>{sequence}</td></tr>',
          //Primary Target
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section">Primary Target</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Official Symbol:</th><td>{primary_gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{primary_gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{primary_gene_description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{primary_gene_organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">EntrezGene:</th><td><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.primary_entrezgene_id]}">{[values.primary_entrezgene_id]}</a></td></tr>',
          //Vendor Target
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section">Vendor Specified Target</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Official Symbol:</th><td>{vendor_gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{vendor_gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{vendor_gene_description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{vendor_gene_organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">EntrezGene:</th><td><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.vendor_entrezgene_id]}">{[values.vendor_entrezgene_id]}</a></td></tr>',
          //Secondary Targets
          '<tpl if="secondary_gene_targets.length!=0" >',
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section">Secondary Targets</th>',
          '<tpl for="secondary_gene_targets">',
          '<tr><th valign= "top" nowrap="Y" >Official Symbol:</th><td>{gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y" class="x-rnai-gene-dd-subsection">EntrezGene:</th><td class="x-rnai-gene-dd-subsection"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.entrezgene_id]}">{[values.entrezgene_id]}</a></td></tr>',
          '</tpl>',
          '</tpl>',
          '</table>',
          '</tpl></p>'
          ),
  tpl_mixture: new Ext.XTemplate(
          '<table class="x-rnai-gene-dd">',
          //Mixture Details
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section">Mixture Details</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Compound ID:</th><td>{compound_id}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Vendor:</th><td>{vendor}</td></tr>',
          '<tr><th colspan="2" valign= "top" nowrap="Y" class="x-rnai-gene-dd-section2-header">Components ({[values.components.length]})</th></tr>',
          
          '<tr><td colspan="2" class="">',
          '<tpl for="components">',
          '<table class="x-rnai-gene-dd x-rnai-gene-dd-section2 x-rnai-gene-dd-section2-border">',
          //Basic Details
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section x-rnai-gene-dd-section2">Component {[xindex]} Details</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Compound ID:</th><td>{compound_id}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Vendor:</th><td>{vendor}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Vendor ID:</th><td>{vendor_product_id}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Sequence:</th><td>{sequence}</td></tr>',
          //Primary Target
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section x-rnai-gene-dd-section2">Primary Target</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Official Symbol:</th><td>{primary_gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{primary_gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{primary_gene_description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{primary_gene_organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">EntrezGene:</th><td><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.primary_entrezgene_id]}">{[values.primary_entrezgene_id]}</a></td></tr>',
          //Vendor Target
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section x-rnai-gene-dd-section2">Vendor Specified Target</th></tr>',
          '<tr><th valign= "top" nowrap="Y">Official Symbol:</th><td>{vendor_gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{vendor_gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{vendor_gene_description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{vendor_gene_organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">EntrezGene:</th><td><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.vendor_entrezgene_id]}">{[values.vendor_entrezgene_id]}</a></td></tr>',
          //Secondary Targets
          '<tpl if="secondary_gene_targets.length!=0" >',
          '<tr><th valign= "top" nowrap="Y" colspan="2" class="x-rnai-gene-dd x-rnai-gene-dd-section x-rnai-gene-dd-section2">Secondary Targets</th>',
          '<tpl for="secondary_gene_targets">',
          '<tr><th valign= "top" nowrap="Y" >Official Symbol:</th><td>{gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y" class="x-rnai-gene-dd-subsection">EntrezGene:</th><td class="x-rnai-gene-dd-subsection x-rnai-gene-dd-section2"><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{[values.entrezgene_id]}">{[values.entrezgene_id]}</a></td></tr>',
          '</tpl>',
          '</tpl>',
          '</table>',
          '</tpl></p>',
          '</tpl>',
          '</td></tr></table>'          
          ),
  constructor: function(config) {
    Ext.apply(this, config);
    this.tpl_standard.compile()
    this.tpl_mixture.compile()
    this.tpl = this.tpl_standard
    RNAi.RNAiGridExpander.superclass.constructor.call(this);
  },
  getExpandedRecord: function(rowRecord, cb, scope) {
    var me = this
    Ext.Ajax.request({
      url: '/RNAi/rnai.go',
      params: {
        req: 'amgen.ri.rnai.search.SearchResponder',
        rx: 'SEARCH',
        searchType: 'RNAI_IDS',
        searchResponse: 'RNAI_DETAILS',
        query: rowRecord.data.rnai_id
      },
      success: function(response, opts) {
        var record
        //try {
        record = new RNAi.Record.RNAi(Ext.decode(response.responseText).rnai[0])
        if (record.get('is_mixture') === true || record.get('is_mixture') == 'true') {
          me.tpl = me.tpl_mixture
        } else {
          me.tpl = me.tpl_standard
        }
        //} catch(e) {}
        if (Ext.isFunction(cb)) {
          cb.call(scope, record)
        }
      },
      failure: function(response, opts) {
      }
    })

    return rowRecord
  }
})

