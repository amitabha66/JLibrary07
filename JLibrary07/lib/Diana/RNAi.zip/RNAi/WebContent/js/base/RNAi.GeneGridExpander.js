/**
 * Defines the Grid Row expander for GeneRecords
 */

RNAi.GeneGridExpander = Ext.extend(RNAi.GridRowExpander, {
  tpl: new Ext.Template(
          '<table class="x-rnai-gene-dd">',
          '<tr><th valign= "top" nowrap="Y">Official Symbol:</th><td>{gene_symbol}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Name:</th><td>{gene_name}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Description:</th><td>{description}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">Organism:</th><td>{organism}</td></tr>',
          '<tr><th valign= "top" nowrap="Y">EntrezGene:</th><td><a target="_blank" href="http://www.ncbi.nlm.nih.gov/gene/{entrezgene_id}">{entrezgene_id}</a></td></tr>',
          '</table>'
          ),
  beforeShow: function(geneRecord) {
    var updatedGeneRecord = geneRecord.copy()
    if (updatedGeneRecord.get('is_mixture')) {

      if (geneRecord.get('gene_symbols') && geneRecord.get('gene_symbols').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('gene_symbol', geneRecord.get('gene_symbols').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('gene_names') && geneRecord.get('gene_names').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('gene_name', geneRecord.get('gene_names').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('descriptions') && geneRecord.get('descriptions').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('description', geneRecord.get('descriptions').toString().replace(/\$\$/g, '<br/>'))
      }
      if (geneRecord.get('organisms') && geneRecord.get('organisms').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('organism', geneRecord.get('organisms').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('entrezgene_ids') && geneRecord.get('entrezgene_ids').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('entrezgene_id', geneRecord.get('entrezgene_ids').toString().replace(/\$\$/g, ','))
      } else if (geneRecord.get('entrezgene_ids') && Ext.isArray(geneRecord.get('entrezgene_ids'))) {
        updatedGeneRecord.set('entrezgene_id', geneRecord.get('entrezgene_ids').join(','))
      }

      if (geneRecord.get('gene_symbol') && geneRecord.get('gene_symbol').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('gene_symbol', geneRecord.get('gene_symbol').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('gene_name') && geneRecord.get('gene_name').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('gene_name', geneRecord.get('gene_name').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('description') && geneRecord.get('description').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('description', geneRecord.get('description').toString().replace(/\$\$/g, '<P/>'))
      }
      if (geneRecord.get('organism') && geneRecord.get('organism').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('organism', geneRecord.get('organism').toString().replace(/\$\$/g, ','))
      }
      if (geneRecord.get('entrezgene_id') && geneRecord.get('entrezgene_id').toString().indexOf('$$') > 0) {
        updatedGeneRecord.set('entrezgene_id', geneRecord.get('entrezgene_id').toString().replace(/\$\$/g, ','))
      }

    }
    return updatedGeneRecord

  }
})