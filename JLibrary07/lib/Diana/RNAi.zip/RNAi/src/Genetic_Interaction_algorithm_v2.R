## support function which calculates running function (e.g. running mean) excluding the center value

args <- commandArgs();
input = paste(args[5],sep="");
outfile = paste(args[6], sep="");
ref = paste(args[7], sep="");
test = paste(args[8], sep="");

neighborhood.run <- function(x, order.by=NULL, FN="mean", window=10, ...)
{
    if (window == 1) return(x)
    if (window > length(x)) {
    	warning("window is greater than data length")
    	return(NA)
    }
    FN=match.fun(FN)
    len <- length(x)
    reorder <- F
    
    if (! missing(order.by)) {
        if (length(x) != length(order.by)) {    
            warning("length(x) != length(order.by)")
            return(x)
        }
        o <- order(order.by)
        x <- x[o]
        orig_order <- order( (1:len)[o] )
        reorder <- T
    }       
    
    before <- window %/% 2
    after <- window - before
    
    ranges <- lapply(1:length(x), function(x1) {
    	range.here <- (x1-before):(x1+after)
    	if (min(range.here) < 1)
    		range.here <- range.here - min(range.here) + 1
    		
    	if (max(range.here) > length(x)) {
    		range.here <- range.here - (max(range.here) - length(x))
    		if (min(range.here) < 1) range.here <- range.here[ range.here > 1 ]
    	}
    	range.here[ range.here != x1 ]
    })

    
	out <- sapply(ranges, function(r) FN( x[r], ... ))    

    # construct matrix where 1 row = neighborhood of given spot
    if (reorder)
        out <- out[orig_order]

    return(out)
}

#-----------------------

##manual processing
AllData <- read.delim(input, header=T, sep="\t", as.is=T);


a=AllData$value_a
b=AllData$value_b
gene_id = AllData$gene_id
gene_symbol = AllData$gene_symbol

df_g <- unique(data.frame(gene_id, gene_symbol))

##set window size
w=length(gene_id)/4
if(w>200){
	w = 200;
}
if(w<80){
	w = 80;
}

genes = unique(AllData$gene_id)
n = length(genes)

si.per.gene <- lapply(genes, function(g) which(AllData$gene_id == g))
test.data <- data.frame(a,b)

ranked <- apply(test.data,2,rank)
rank.frac <- ranked / (nrow(ranked)+1)
rank.frac.z <- qnorm(rank.frac)

## enhancer
rank.frac.z.diff <- rank.frac.z[,2] - rank.frac.z[,1]
rank.frac.z.diff.iqr <- neighborhood.run(rank.frac.z.diff, rowMeans(rank.frac.z,na.rm=T), FN="IQR", window=w, na.rm=T)
rank.frac.z.diff.median <- neighborhood.run(rank.frac.z.diff, rowMeans(rank.frac.z,na.rm=T), FN="median", window=w, na.rm=T)
rank.frac.z.diff.iqr.z <-(rank.frac.z.diff - rank.frac.z.diff.median) / rank.frac.z.diff.iqr
rank.frac.z.diff.iqr.z.rank <- rank( (rank.frac.z.diff - rank.frac.z.diff.median)/ rank.frac.z.diff.iqr )
rank.frac.z.diff.iqr.z.rank.frac <- rank.frac.z.diff.iqr.z.rank / (length(rank.frac.z.diff.iqr.z.rank)+1)
rfzdizrf.z <- qnorm(rank.frac.z.diff.iqr.z.rank.frac)
pvals <- sapply(si.per.gene, function(the.gene) pnorm(sqrt(length(the.gene))*mean(rfzdizrf.z[the.gene],na.rm=T)))
pvals.enhancer <- pvals
pvals.enhancer.adj <- p.adjust(pvals.enhancer, "fdr")

## suppressor
rank.frac.z.diff <- -rank.frac.z.diff
rank.frac.z.diff.iqr <- neighborhood.run(rank.frac.z.diff, apply(rank.frac.z,1,mean), FN="IQR", window=w, na.rm=T)
rank.frac.z.diff.median <- neighborhood.run(rank.frac.z.diff, apply(rank.frac.z,1,mean), FN="median", window=w, na.rm=T)
rank.frac.z.diff.iqr.z <-(rank.frac.z.diff - rank.frac.z.diff.median) / rank.frac.z.diff.iqr
rank.frac.z.diff.iqr.z.rank <- rank( (rank.frac.z.diff - rank.frac.z.diff.median) / rank.frac.z.diff.iqr )
rank.frac.z.diff.iqr.z.rank.frac <- rank.frac.z.diff.iqr.z.rank / (length(rank.frac.z.diff.iqr.z.rank)+1)
rfzdizrf.z <- qnorm(rank.frac.z.diff.iqr.z.rank.frac)
pvals2 <- sapply(si.per.gene, function(the.gene) pnorm(sqrt(length(the.gene))*mean(rfzdizrf.z[the.gene],na.rm=T)))
pvals.suppressor <- pvals2
pvals.suppressor.adj <- p.adjust(pvals.suppressor, "fdr")

pvals <- pmin(pvals2, pvals) * 2
pvals.adj <- p.adjust(pvals, "fdr")

##output
Results<-data.frame(gene_id=genes, pvalue=pvals, pvals.adj, pvals.suppressor, pvals.suppressor.adj, pvals.enhancer, pvals.enhancer.adj, ref, test);
Results<-merge(Results, df_g);

##manual processing
write.table(Results[ , c("gene_symbol", "gene_id", "pvalue", "pvals.adj","pvals.suppressor", "pvals.suppressor.adj","pvals.enhancer", "pvals.enhancer.adj","ref","test")],file=outfile, sep="\t", row.names=FALSE) 

