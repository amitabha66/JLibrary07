library(survival);

args <- commandArgs();
symbol = args[5];
name   = args[6];
input = paste(args[7],sep="");
outfile = paste(args[8], sep="");
idfile = paste(args[9], sep="");
#print (symbol);
#print (name);
#print (input);
#print (outfile);

sidata <- read.delim(input, header=T, sep="\t", as.is=T);

POC = sidata$POC;
totalsi = length(POC);
GENE = sidata$GENE;
allsym = unique(GENE);
##POC = ceiling( POC/max(POC) * 1000 );
##POC = POC / median(POC) * 100;
gene_id_sort <- read.table(idfile,header = TRUE);
allData <- data.frame(POC, 1, GENE);
allDataID <- merge(gene_id_sort,allData, by ="GENE");

data.fit <- survfit(Surv(POC, X1) ~ ID_SORT, data=allDataID);


print(gene_id_sort);

print(names(data.fit));

print(class(data.fit));

print(data.fit);

letext = allsym;

title <- paste(symbol, "in", name, "vs ref siRNAs", sep=" ");



##output graph
##print ("Output graph");
colrange = length(allsym);
bitmap(outfile, type="png256", res=160, height=6, width=3);
layout(matrix(c(1,2)));

xmin=min(POC);
if (max(POC)>100){
        xmax=100;
} else {
        xmax=max(POC);
}

plot(data.fit,xlim=c(xmin,xmax),main=title,xlab="POC",ylab="Fraction of siRNA in group",col=c(1:colrange));
legend("topright", letext, text.col=c(1:colrange), bty='n');


##output histogram
numbreak = ceiling(totalsi/20);
if      (numbreak > 100) {
  numbreak = 100
} else if (numbreak < 10 ) {
  numbreak = 10
}
step = 0;

hist(POC, breaks=numbreak, col='beige',xlab=paste(name, "POC",sep=" "), border='grey',main=paste(name, "POC distribution",sep=" "));
for (i in 2:colrange) {
  pocs = POC[GENE==letext[i]];
  y = rep(step, length(pocs));
  points(pocs, y, type="p", col=c(i), pch=19);
  step = step + numbreak / 5;
}
legend("topleft", letext[2:colrange], text.col=c(2:colrange), bty='n');
graphics.off();
