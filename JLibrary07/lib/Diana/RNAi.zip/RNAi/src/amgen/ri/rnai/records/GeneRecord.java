package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.xml.ExtXMLElement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import org.jdom.Element;

/**
 * Encapsulates a JSONObject for a GeneRecord
 *
 * @author jemcdowe
 */
public class GeneRecord extends AbstractRecord {
  static final long serialVersionUID = 7895777543380205163L;

  public GeneRecord(JSONObject obj) throws JSONException {
    super(obj, "gene_id");
  }

  /**
   * This constructor only used for transient comparisons
   * @param geneID 
   */
  public GeneRecord(int geneID) {
    super(geneID + "");
    setGeneID(geneID);
  }

  /**
   * This constructor only used for transient comparisons
   * @param geneID 
   */
  public GeneRecord(JSONObject source, String idField) throws JSONException {
    super(source, idField);
    setGeneID(getInt(idField));
  }

  public GeneRecord(int geneID, int entrezgeneID, String geneName, String geneSymbol, String geneAlias, String geneType,
          String description, String organism, int organismID) {
    super(geneID + "");
    setGeneID(geneID);
    setEntrezgeneID(entrezgeneID);
    setGeneName(geneName);
    setGeneSymbol(geneSymbol);
    setGeneAlias(geneAlias);
    setGeneType(geneType);
    setDescription(description);
    setOrganism(organism);
    setOrganismID(organismID);
  }

  /**
   * Pulls the number of distinct experiments for this GeneRecord from the RNAi
   * database
   */
  public void setExperimentsCount(Connection conn) throws SQLException {
    long geneID = getGeneID();
    ResultSet rset = ResourceFactory.runQuery(conn, "count_experiments_by_geneid", "gene_id:" + geneID);
    if (rset.next()) {
      add("exp_count", rset.getInt(1));
    }
    rset.getStatement().close();
  }

  /**
   * Get the value of organismID
   *
   * @return the value of organismID
   */
  public int getOrganismID() {
    return getNumber("organism_id").intValue();
  }

  /**
   * Set the value of organismID
   *
   * @param organismID new value of organismID
   */
  public final void setOrganismID(int organismID) {
    add("organism_id", organismID);
  }

  /**
   * Get the value of organism
   *
   * @return the value of organism
   */
  public String getOrganism() {
    return getString("organism");
  }

  /**
   * Set the value of organism
   *
   * @param organism new value of organism
   */
  public final void setOrganism(String organism) {
    add("organism", organism);
  }

  /**
   * Get the value of description
   *
   * @return the value of description
   */
  public String getDescription() {
    return getString("description");
  }

  /**
   * Set the value of description
   *
   * @param description new value of description
   */
  public final void setDescription(String description) {
    add("description", description);
  }

  /**
   * Get the value of geneAlias
   *
   * @return the value of geneAlias
   */
  public String getGeneAlias() {
    return getString("alias");
  }

  /**
   * Set the value of geneAlias
   *
   * @param geneAlias new value of geneAlias
   */
  public final void setGeneAlias(String geneAlias) {
    add("alias", geneAlias);
  }

  /**
   * Get the value of geneType
   *
   * @return the value of geneType
   */
  public String getGeneType() {
    return getString("gene_type");
  }

  /**
   * Set the value of geneType
   *
   * @param geneType new value of geneType
   */
  public final void setGeneType(String geneType) {
    add("gene_type", geneType);
  }

  /**
   * Get the value of geneSymbol
   *
   * @return the value of geneSymbol
   */
  public String getGeneSymbol() {
    return getString("gene_symbol");
  }

  /**
   * Set the value of geneSymbol
   *
   * @param geneSymbol new value of geneSymbol
   */
  public final void setGeneSymbol(String geneSymbol) {
    add("gene_symbol", geneSymbol);
  }

  /**
   * Get the value of geneName
   *
   * @return the value of geneName
   */
  public String getGeneName() {
    return getString("gene_name");
  }

  /**
   * Set the value of geneName
   *
   * @param geneName new value of geneName
   */
  public final void setGeneName(String geneName) {
    add("gene_name", geneName);
  }

  /**
   * Get the value of entrezgeneID
   *
   * @return the value of entrezgeneID
   */
  public int getEntrezgeneID() {
    return getNumber("entrezgene_id").intValue();
  }

  /**
   * Set the value of entrezgeneID
   *
   * @param entrezgeneID new value of entrezgeneID
   */
  public final void setEntrezgeneID(int entrezgeneID) {
    add("entrezgene_id", entrezgeneID);
  }

  /**
   * Get the value of geneID
   *
   * @return the value of geneID
   */
  public int getGeneID() {
    return getNumber("gene_id").intValue();
  }

  /**
   * Set the value of geneID
   *
   * @param geneID new value of geneID
   */
  public final void setGeneID(int geneID) {
    add("gene_id", geneID);
  }

  /**
   * Adds a POCRecord result
   *
   * @param pocRecord
   */
  public void addPOCResult(ExperimentRecord expRecord, POCRecord pocRecord) {
    addToArray(expRecord.getRecordID() + ".pocs", pocRecord);
  }

  /**
   * Returns a List of POCRecord results
   *
   * @return
   */
  public List<POCRecord> getPOCResults(ExperimentRecord expRecord) {
    return getList(expRecord.getRecordID() + ".pocs");
  }

  @Override
  public Element asXML() {
    Element el = super.asXML();
    ExtXMLElement.addAttribute(el, "gene_id", getGeneID() + "");
    return el;
  }
}
