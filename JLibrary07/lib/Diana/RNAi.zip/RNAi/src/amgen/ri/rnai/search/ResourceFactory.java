/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.aldi.merlin.net.ws.MerlinServicesLocator;
import amgen.ri.aldi.merlin.net.ws.MerlinServicesSoap_PortType;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.oracle.OraConnectionManagerFactory;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.dao.PersonRecord;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneMixtureRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.records.POCRecord;
import amgen.ri.rnai.records.PlateInfo;
import amgen.ri.sql.GenericSQLProvider;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.io.*;
import java.net.URL;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import javax.naming.Context;
import oracle.jdbc.OraclePreparedStatement;
import oracle.sql.BLOB;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 *
 * @author jemcdowe
 */
public abstract class ResourceFactory {
  public static final String RNAI_SQL_PROPERTIES = "/rnai_sql.xml";
  public static final String RG_SERVICEACCOUNT_PROPERTIES = "/rg.serviceaccount.properties";

  protected enum ConnectionPoolType {
    RNAI_INDEX,
    SQUID
  };
  private boolean useOraSQLManager = true;
  private Context envContext;
  private SQLProvider sqlProvider;
  private SessionCache sessionCache;

  protected ResourceFactory() {
    this.sqlProvider = new GenericSQLProvider(getClass().getClassLoader().getResourceAsStream(RNAI_SQL_PROPERTIES));
    if (sqlProvider == null) {
      throw new IllegalArgumentException("Unable to load SQL XML");
    }
  }

  protected ResourceFactory(SessionCache sessionCache) {
    this();
    this.sessionCache = sessionCache;
  }

  /**
   * Returns the RG_SERVICEACCOUNT_PROPERTIES as a Properties object
   *
   * @return
   */
  public Properties getRGServiceAccountProperties() {
    try {
      Properties serviceAccountProperties = new Properties();
      serviceAccountProperties.load(this.getClass().getResourceAsStream(RG_SERVICEACCOUNT_PROPERTIES));
      return serviceAccountProperties;
    } catch (IOException ex) {
      Logger.getLogger(this.getClass().getName()).log(Level.SEVERE, null, ex);
    }
    return null;
  }

  public SQLProvider getSqlProvider() {
    return sqlProvider;
  }

  public SessionCache getSessionCache() {
    return sessionCache;
  }

  public Connection getRNAiConnection() throws SQLException {
    return getConnection(ConnectionPoolType.RNAI_INDEX);
  }

  public Connection getSQUIDConnection() throws SQLException {
    return getConnection(ConnectionPoolType.SQUID);
  }

  /**
   * Retrieves a list of ExperimentRecords using the Experiment IDs
   */
  public List<ExperimentRecord> getExperiments(Collection<Integer> experimentIDs, PersonRecordIF requestedBy) {
    List<ExperimentRecord> experimentRecords = new ArrayList<ExperimentRecord>();
    if (!experimentIDs.isEmpty()) {
      RNAiSearch search = new RNAiSearch(null, null, null, null, new ArrayList<Integer>(experimentIDs), RNAiSearchOutputType.EXPERIMENTS, null, requestedBy);
      try {
        experimentRecords.addAll(search.getResponse().getJSONArray("experiments").asList());
      } catch (Exception ex) {
      }
    }
    return experimentRecords;
  }

  protected List<POCRecord> getPOCResults(Collection<GeneRecord> geneRecords, ExperimentRecord expRecord, PersonRecordIF requestedBy) throws JSONException {
    List<Integer> geneIDs = new ArrayList<Integer>();
    Map<Integer, GeneRecord> geneMap = new HashMap<Integer, GeneRecord>();
    for (GeneRecord geneRecord : geneRecords) {
      geneIDs.add(geneRecord.getGeneID());
      geneMap.put(geneRecord.getGeneID(), geneRecord);
    }
    List<POCRecord> pocRecords = new ArrayList<POCRecord>();

    int pageCount = ExtArray.getPages(geneIDs, 1000);
    
    for (int i = 0; i < pageCount; i++) {
      List<Integer> pageGeneIDs= ExtArray.getPage(geneIDs, i, 1000);
      RNAiSearch rawResultSearch = new RNAiSearch(null, null, pageGeneIDs, null, Arrays.asList(expRecord.getExperimentID()), RNAiSearchOutputType.RAWRESULTS, null, requestedBy);

      for (JSONObject result : rawResultSearch) {
        POCRecord pocRecord = new POCRecord(result);
        pocRecords.add(new POCRecord(result));
        GeneRecord geneRecord = geneMap.get(pocRecord.getPrimaryGeneID());
        geneRecord.addPOCResult(expRecord, pocRecord);
      }
    }

    return pocRecords;
  }

  /**
   * Retrieves an ExperimentRecord for an Experiment ID. null if it does not
   * exist
   */
  public ExperimentRecord getExperiment(int experimentID, PersonRecordIF requestedBy) {
    List<ExperimentRecord> expRecords = getExperiments(Arrays.asList(new Integer[]{experimentID}), requestedBy);
    return (expRecords.isEmpty() ? null : expRecords.get(0));
  }

  /**
   * Retrieves a list of Plates using barcodes
   */
  protected List<PlateInfo> getPlates(Collection<String> barcodes) {
    List<PlateInfo> plateRecords = new ArrayList<PlateInfo>();
    if (!barcodes.isEmpty()) {
      PlateMapSearch search = new PlateMapSearch(null, barcodes);
      try {
        for (AbstractRecord r : search.asList()) {
          plateRecords.add((PlateInfo) r);
        }
      } catch (Exception ex) {
      }
    }
    return plateRecords;
  }

  /**
   * Retrieves a list of Plates using a barcode. Null if it does not exist.
   */
  protected PlateInfo getPlates(String barcode) {
    List<PlateInfo> plateRecords = getPlates(Arrays.asList(barcode));
    return (plateRecords.isEmpty() ? null : plateRecords.get(0));
  }

  /**
   * Returns a List of GeneRecord for a List of gene IDs
   *
   * @param geneIDs
   * @param requestedBy
   * @return
   */
  public List<GeneRecord> getGenes(Collection<Integer> geneIDs, PersonRecordIF requestedBy) {
    try {
      RNAiSearch search = new RNAiSearch(null, null, new ArrayList<Integer>(geneIDs), null, null, RNAiSearchOutputType.GENES, null, requestedBy);
      return search.getResponse().getJSONArray("genes").asList();
    } catch (Exception ex) {
    }
    return new ArrayList<GeneRecord>();
  }

  /**
   * Returns a List of GeneMixtureRecord for a List of gene IDs
   *
   * @param geneIDs
   * @param requestedBy
   * @return
   */
  public List<GeneMixtureRecord> getGeneMixtures(Collection<Integer> geneMixtureIDs, PersonRecordIF requestedBy) {
    try {
      RNAiSearch search = new RNAiSearch(null, null, null, new ArrayList<Integer>(geneMixtureIDs), null, RNAiSearchOutputType.GENE_MIXTURES, null, requestedBy);
      return search.getResponse().getJSONArray("genes").asList();
    } catch (Exception ex) {
    }
    return new ArrayList<GeneMixtureRecord>();
  }

  /**
   * Returns a List of GeneRecords for a Set of gene symbols
   *
   * @param geneSymbols
   * @param requestedBy
   * @return
   */
  public List<GeneRecord> getGenesBySymbol(Collection<String> geneSymbols, PersonRecordIF requestedBy) {
    try {
      RNAiSearch search = new RNAiSearch(ExtString.join(new ArrayList(geneSymbols), '\n'), RNAiSearchInputType.GENE_SYMBOLS, RNAiSearchOutputType.GENES, null, requestedBy);
      return search.getResponse().getJSONArray("genes").asList();
    } catch (Exception ex) {
    }
    return new ArrayList<GeneRecord>();
  }

  /**
   * Returns a Set of gene IDs for a Set of gene symbols
   *
   * @param geneSymbols
   * @param requestedBy
   * @return
   */
  public Set<Integer> getGeneIDsBySymbol(Collection<String> geneSymbols, PersonRecordIF requestedBy) {
    Set<Integer> geneIDs = new LinkedHashSet<Integer>();
    List<GeneRecord> geneRecords = getGenesBySymbol(geneSymbols, requestedBy);
    for (GeneRecord geneRecord : geneRecords) {
      geneIDs.add(geneRecord.getGeneID());
    }
    return geneIDs;
  }

  public List<Integer> getGeneIDsByKeyword(String query) {
    Set<Integer> geneIDs = new LinkedHashSet<Integer>();
    Connection conn = null;
    try {
      conn = getRNAiConnection();
      String sql = getSqlProvider().getSQLQuery("geneid_by_keyword").getSql();
      OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      stmt.setStringAtName("query", query);
      ResultSet rset = stmt.executeQuery();
      while (rset.next()) {
        geneIDs.add(rset.getInt(1));
      }
      close(stmt);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(conn);
    }
    return new ArrayList<Integer>(geneIDs);
  }

  protected PersonRecord getPersonRecord(String amgenLogin) {
    Map<String, PersonRecord> map = getPersonRecords(Arrays.asList(amgenLogin));
    return map.get(amgenLogin);
  }

  protected Map<String, PersonRecord> getPersonRecords(Collection<String> amgenLogins) {
    Map<String, PersonRecord> personRecordMap = new HashMap<String, PersonRecord>();
    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      List<PersonRecord> personRecords = sqlSession.getMapper(Mapper.class).selectPersons(new ArrayList<String>(amgenLogins));
      for (PersonRecord personRecord : personRecords) {
        personRecordMap.put(personRecord.getAmgen_login(), personRecord);
      }
    } finally {
      close(sqlSession);
    }
    return personRecordMap;
  }

  protected List<PersonRecord> searchPersonRecords(String query) {
    List<PersonRecord> persons = new ArrayList<PersonRecord>();
    SqlSession sqlSession = null;
    try {
      query = query.toLowerCase();
      sqlSession = getRNAiSqlSession();
      if (query.indexOf(',') > -1) {
        String[] split = query.split(",", 2);
        String lastName = split[0].trim();
        String firstName = split[1].trim();
        persons.addAll(sqlSession.getMapper(Mapper.class).searchPersonsByLastFirst(lastName + "%", firstName + "%"));
      } else {
        persons.addAll(sqlSession.getMapper(Mapper.class).searchPersons(query + "%"));
      }
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return persons;
  }

  /**
   * Does a lookup of a person record using a query which can either be
   * 1. Last Name, First Name
   * 2. Amgen Login
   *
   * If no match is found, this return null
   *
   * @param query
   * @return
   */
  protected PersonRecord lookupPersonRecord(String query) {
    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      query = query.toLowerCase();
      if (query.indexOf(',') > -1) {
        String[] fields = query.split(",", 2);
        String lastName = fields[0].trim();
        String firstName = fields[1].trim();
        PersonRecord personRecord = sqlSession.getMapper(Mapper.class).lookupPersonByLastFirst(lastName, firstName);
        if (personRecord == null) {
          System.err.println("Unable to find " + query);
          return null;
        }
        return personRecord;
      }
      Map<String, PersonRecord> personRecords = getPersonRecords(Arrays.asList(query));
      return (personRecords.size() > 0 ? personRecords.values().iterator().next() : null);
    } catch (Throwable t) {
      System.err.println("Unable to find " + query + "\n" + t);
    } finally {
      close(sqlSession);
    }
    return null;
  }

  /**
   * Creates a String of ids from the given List of AbstractRecords delimiter by
   * the given delimited
   *
   * @param records
   * @return
   */
  public String joinIDs(List<? extends AbstractRecord> records, char delimiter) {
    return ExtString.join(join(records, null), delimiter);
  }

  /**
   * Creates a List of ids from the given List of AbstractRecords
   *
   * @param records
   * @return
   */
  public List<String> joinIDs(List<? extends AbstractRecord> records) {
    return join(records, null);
  }

  /**
   * Creates a List of key values from the given List of AbstractRecords
   *
   * @param records
   * @param key
   * @return
   */
  public List<String> join(List<? extends AbstractRecord> records, String key) {
    List<String> keyValues = new ArrayList<String>();
    for (AbstractRecord record : records) {
      if (key == null) {
        keyValues.add(record.getRecordID());
      } else if (record.has(key)) {
        keyValues.add(record.getString(key));
      }
    }
    return keyValues;
  }

  /**
   * Creates a String of key values from the given List of AbstractRecords
   * delimited by the given character
   *
   * @param records
   * @param key
   * @return
   */
  public String join(List<? extends AbstractRecord> records, String key, char delimiter) {
    return ExtString.join(join(records, key), delimiter);
  }

  public MerlinServicesSoap_PortType getMerlinServices() {
    try {
      return new MerlinServicesLocator().getMerlinServicesSoap(new URL("http://usto-papp-aldi1:81/MerlinServices.asmx?WSDL"));
    } catch (Exception ex) {
      Logger.getLogger(ResourceFactory.class.getName()).log(Level.SEVERE, null, ex);
    }
    return null;
  }

  public void testAllConnectionPools() {
    for (ConnectionPoolType poolName : ConnectionPoolType.values()) {
      Connection c = null;
      try {
        c = getConnection(poolName);
      } catch (Exception e) {
      } finally {
        if (c != null) {
          try {
            c.close();
          } catch (Exception ex) {
          }
        }
      }
    }
  }

  public String getJProcQuery(Connection conn, String queryName) throws SQLException {
    OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT QUERY from RNAI_INDEX.JPROC_QUERIES where QUERY_NAME= :query_name");
    stmt.setStringAtName("query_name", queryName);
    ResultSet rset = null;
    try {
      rset = stmt.executeQuery();
      if (rset.next()) {
        String query = rset.getString(1);
        return query;
      }
    } finally {
      close(rset);
      close(stmt);
    }
    return null;
  }

  protected JSONObject createResponseJSON(String resultField, Collection<? extends AbstractRecord> records) {
    JSONObject jResults = new JSONObject();
    for (AbstractRecord record : records) {
      try {
        jResults.append(resultField, record);
      } catch (JSONException ex) {
        Logger.getLogger(RNAiSearch.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    return jResults;
  }

  protected BLOB createBLOB(Connection conn, Object obj) throws SQLException {
    BLOB tempBlob = null;
    try {
      tempBlob = BLOB.createTemporary(conn, true, BLOB.DURATION_SESSION);
      OutputStream blobOutStream = tempBlob.setBinaryStream(0);
      ObjectOutputStream oop = new ObjectOutputStream(blobOutStream);
      oop.writeObject(obj);
      oop.flush();
      oop.close();
      blobOutStream.close();
    } catch (Exception exp) {
      tempBlob.freeTemporary();
      throw new SQLException(exp);
    }
    return tempBlob;
  }

  protected JSONObject fromBlob(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      return (JSONObject) objIN.readObject();
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new JSONObject();
  }

  public OraclePreparedStatement getJProcQueryAsStatement(Connection conn, String queryName) throws SQLException {
    return (OraclePreparedStatement) conn.prepareStatement(getJProcQuery(conn, queryName));
  }

  private Connection getConnection(ConnectionPoolType jndiTypeName) throws SQLException {
    return OraConnectionManagerFactory.getFactory().getOracleConnectionManager().getConnection(jndiTypeName.toString());
  }

  /**
   * Function to create connection with database and to read the xml files used
   * for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "batisConfig.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public SqlSession getRNAiSqlSession() {
    return getRNAiSqlSession(ExecutorType.SIMPLE);
  }  

  public SqlSession getRNAiSqlSession(ExecutorType executorType) {
    return getSqlSessionFactory("rnai").openSession(executorType);
  }  

  public ResultSet executeQuery(Connection conn, String queryName, String[] replacements) throws SQLException {
    return OraSQLManager.executeQuery(conn, sqlProvider, queryName, replacements);
  }

  public ResultSet executeQuery(Connection conn, String queryName, String replacement) throws SQLException {
    return OraSQLManager.executeQuery(conn, sqlProvider, queryName, new String[]{replacement});
  }

  public static ResultSet runQuery(Connection conn, String queryName, String[] replacements) throws SQLException {
    class GenericOracleResourceFactory extends ResourceFactory {
      public GenericOracleResourceFactory() {
        super(null);
      }
    };
    return new GenericOracleResourceFactory().executeQuery(conn, queryName, replacements);
  }

  public static ResultSet runQuery(Connection conn, String queryName, String replacement) throws SQLException {
    return runQuery(conn, queryName, new String[]{replacement});
  }

  public void closeResources(Connection conn) {
    try {
      conn.close();
    } catch (Exception e) {
    }
  }

  //DEBUG STUFF
  protected void writeQuery(RNAiSearchInputType inputType, RNAiSearchOutputType outputType, List<Map<String, String>> query, JSONObject response) {
    PrintWriter writer = null;
    try {
      File outDir = new File("/temp", inputType + "." + outputType + "-" + System.currentTimeMillis());
      outDir.mkdirs();
      writer = new PrintWriter(new FileWriter(new File(outDir, "query.txt")));

      writer.println("IN: " + inputType);
      writer.println("OUT: " + outputType);

      if (query != null) {
        int counter = 1;
        for (Map<String, String> queryTerm : query) {
          writer.println("Q: " + (counter++));
          for (String key : queryTerm.keySet()) {
            writer.println("\t" + key + " = " + queryTerm.get(key));
          }
        }
      }
      writer.close();

      if (response != null) {
        writer = new PrintWriter(new FileWriter(new File(outDir, "response.js")));
        writer.println(response.toString(2));
        writer.close();
      }
    } catch (Exception ex) {
    } finally {
      writer.close();
    }
  }

  public static void close(SqlSession sqlSession) {
    if (sqlSession != null) {
      try {
        sqlSession.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(Statement stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(Connection conn) {
    if (conn != null) {
      try {
        conn.close();
      } catch (Throwable t) {
      }
    }
  }

  public static void close(ResultSet rset) {
    if (rset != null) {
      try {
        rset.close();
      } catch (Throwable t) {
      }
    }
  }
}
