package amgen.ri.rnai.util;

import java.io.*;

public class RuntimeUtil {
  public static int systemCallWithReaderThreads(String command) throws IOException, InterruptedException {
    Runtime rt = Runtime.getRuntime();
    int exitCode = -1;
    Process p = rt.exec(command);
    SystemCallReader out = new SystemCallReader(p.getInputStream());
    SystemCallReader err = new SystemCallReader(p.getErrorStream());
    out.start();
    err.start();
    p.waitFor();
    exitCode = p.exitValue();
    return exitCode;
  }

  public static int systemCall(String command) {
    Runtime rt = Runtime.getRuntime();
    int exitCode = -1;
    System.out.println("commands is\t" + command);
    try {
      Process p = rt.exec(command);
      p.waitFor();
      exitCode = p.exitValue();
      BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));

      String result = "";
      System.out.println("Input stream: \n\n");
      while ((result = br.readLine()) != null) {
        System.out.println(result);
      }

      BufferedReader br1 = new BufferedReader(new InputStreamReader(p.getErrorStream()));

      System.out.println("Error stream: \n\n");
      while ((result = br1.readLine()) != null) {
        System.out.println(result);
      }

      System.out.println("exitCode is\t" + exitCode);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return exitCode;
  }

  /**
   * This method uses Runtime to do system call. It throws exception to caller,
   * rather than handles it by itself.
   */
  public static int systemCallThrowsException(String command) throws Exception {
    Runtime rt = Runtime.getRuntime();
    int exitCode = 0;
    System.out.println("commands is\t" + command);
    try {
      Process p = rt.exec(command);
      p.waitFor();
      exitCode = p.exitValue();
      System.out.println("exitCode is\t" + exitCode);
    } catch (Exception ex) {
      throw ex;
    }
    return exitCode;
  }

  /////////////////////////////////////////////////////
  public static int systemCall(String command, String path) {
    Runtime rt = Runtime.getRuntime();
    int exitCode = 0;
    int ch;
    System.out.println("commands is\t" + command);
    try {
      File outputFile = new File(path);
      FileWriter out = new FileWriter(outputFile);
      Process p = rt.exec(command);
      InputStreamReader myIStreamReader = new InputStreamReader(p.getInputStream());
      while ((ch = myIStreamReader.read()) != -1) {
        // System.out.println((char)ch);
        out.write((char) ch);
      }
      out.close();
      p.waitFor();
      exitCode = p.exitValue();
      System.out.println("exitCode is\t" + exitCode);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return exitCode;
  }

  /////////////////////////////////////////////////////
  /**
   * This method changes a file or folder's perssion on UNIX system
   */
  public static void chmod(String fileFullPath, String permission) {
    String chmod = "chmod " + permission + " " + fileFullPath;
    RuntimeUtil.systemCall(chmod);
  }

  /**
   * This method changes a file or folder's perssion on UNIX system. It throws
   * exception to caller.
   */
  public static void chmodThrowsException(String fileFullPath, String permission) throws Exception {
    String chmod = "chmod " + permission + " " + fileFullPath;
    try {
      RuntimeUtil.systemCallThrowsException(chmod);
    } catch (Exception ex) {
      throw ex;
    }
  }

  /**
   * This method does rm $fileName. It first check if the file exists.
   */
  public static int remove(String fileFullPath) {
    int exitCode = 0;
    if (new File(fileFullPath).exists()) {
      String remove = "rm " + fileFullPath;
      exitCode = RuntimeUtil.systemCall(remove);
    }
    return exitCode;
  }

  /**
   * This method does rm $dirName. It first checks if the dirFullPath exists.
   */
  public static int removeDir(String dirFullPath) {
    int exitCode = 0;
    if (new File(dirFullPath).exists()) {
      String remove = "rm -rf " + dirFullPath;
      exitCode = RuntimeUtil.systemCall(remove);
    }
    return exitCode;
  }

  public static void main(String[] args) {
    RuntimeUtil.chmod("/loch/assays/GPR88_AGN_CaFLUX_S/GPR88_11142001_p1/analysis.sh", "755");
  }
}
