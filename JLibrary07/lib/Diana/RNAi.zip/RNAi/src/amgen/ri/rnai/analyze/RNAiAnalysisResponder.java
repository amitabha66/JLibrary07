/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.csv.CSVReader;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.analyze.geneticinteraction.*;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.graphs.HistogramGeneCollection;
import amgen.ri.rnai.graphs.SurvivalPlot;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneMixtureRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.search.RNAiSearch;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.FileResponderIF;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.sirna.oga.io.input.ExcelInputSource.ColumnType;
import amgen.ri.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleCallableStatement;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.jcs.access.exception.CacheException;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

/**
 * @author jemcdowe
 */
public class RNAiAnalysisResponder extends AbstractResponder implements JSONResponderIF, FileResponderIF {
  private SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");

  enum RNAiAnalysisResponderRequest {
    PROCESS_EXP_FILE,
    ANALYZE_EXP_FILE,
    RUN_ANALYSIS,
    RUN_ANALYSIS2EXCEL,
    READLOG,
    RUN_GI_ANALYSIS,
    PREV_RUN_ANALYSIS_NODES,
    GI_RESULTS,
    GI_DELETE,
    POC_RESULTS,
    RUN_SURVIVAL_PLOT,
    RUN_GENE_EXP_HISTOGRAM_PLOT;

    public static RNAiAnalysisResponderRequest toRequest(String s) {
      try {
        return RNAiAnalysisResponderRequest.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return RUN_ANALYSIS;
    }

    public static RNAiAnalysisResponderRequest toRequest(AbstractResponder responder) {
      try {
        return RNAiAnalysisResponderRequest.toRequest(responder.getServletBase().getParameter("rx"));
      } catch (Exception e) {
      }
      return RUN_ANALYSIS;
    }
  };

  public RNAiAnalysisResponder(MainUI servletBase) {
    super(servletBase);
  }

  public boolean isFileResponse() {
    switch (RNAiAnalysisResponderRequest.toRequest(this)) {
      case RUN_ANALYSIS2EXCEL:
      case ANALYZE_EXP_FILE:
        return true;
      default:
        return false;
    }
  }

  public FileResponse getFileResponse() {
    try {
      OGAAnalysis oga;
      File ogaFile = null;
      List<ExperimentRecord> experimentRecords = null;
      FileResponse fileResponse = new FileResponse();

      switch (RNAiAnalysisResponderRequest.toRequest(this)) {
        case ANALYZE_EXP_FILE:
          Workbook wb = getWorkbookFromRequest("import_data_file");
          JSONObject jColumnMapping = new JSONObject(getParameter("columnMapping"));
          Map<Integer, ColumnType> columnMapping = new HashMap<Integer, ColumnType>();
          for (String type : JSONObject.getNames(jColumnMapping)) {
            ColumnType columnType = ColumnType.fromString(type);
            if (columnType != null) {
              int columnIndex = jColumnMapping.getInt(type);
              columnMapping.put(columnIndex, columnType);
            }
          }
          oga = new OGAAnalysis(getServletBase());
          ogaFile = oga.execute(wb, columnMapping);
          break;
        case RUN_ANALYSIS2EXCEL:
          List<Integer> expIDs = getParameterIntegers("experiment_ids");
          if (!expIDs.isEmpty()) {
            RNAiSearch search = new RNAiSearch(null, null, null, null, expIDs, RNAiSearchOutputType.EXPERIMENTS, null, getServletBase().getPersonRecord());
            experimentRecords = search.getResponse().getJSONArray("experiments").asList();
            oga = new OGAAnalysis(getServletBase());
            ogaFile = oga.execute2Excel(experimentRecords);
          }
          break;
      }
      if (ogaFile.isDirectory()) {
        File zipOGAFile = new File(ogaFile.getParentFile(), "oga_analysis.zip");
        ExtZip.zip(ogaFile, zipOGAFile);
        fileResponse.setResponseFile(zipOGAFile);
      } else {
        fileResponse.setResponseFile(ogaFile);
        if (experimentRecords != null && experimentRecords.size() == 1) {
          fileResponse.setFileName(experimentRecords.get(0).getExperimentName().replaceAll("\\s+", "_") + ".xlsx");
        } else {
          fileResponse.setFileName("oga.xlsx");
        }
      }
      return fileResponse;
    } catch (Exception ex) {
      ex.printStackTrace();
      throw new IllegalArgumentException(ex.getMessage());
    }
  }

  @Override
  public JSONObject getResponse() {
    try {
      switch (RNAiAnalysisResponderRequest.toRequest(this)) {
        case RUN_GENE_EXP_HISTOGRAM_PLOT:
          return runGeneExpHistogramPlot();
        case RUN_SURVIVAL_PLOT:
          return runSurvivalPlot();
        case GI_RESULTS:
          return getGIResults();
        case GI_DELETE:
          return deleteGIAnalysis();
        case POC_RESULTS:
          return getPOCExpResults(getExperimentRecordsFromParameter());
        case PREV_RUN_ANALYSIS_NODES:
          return getExecutedAnalysisNodes();
        case READLOG:
          return readLog();
        case RUN_GI_ANALYSIS:
          return runGIAnalysis();
        case PROCESS_EXP_FILE:
          Workbook wb = getWorkbookFromRequest("import_data_file");

          JSONObject jColumns = new JSONObject();
          JSONArray jTypes = new JSONArray();

          JSONArray jType = new JSONArray();
          jType.put("Plate ID");
          jTypes.put(jType);

          jType = new JSONArray();
          jType.put("Plate Row");
          jTypes.put(jType);

          jType = new JSONArray();
          jType.put("Plate Column");
          jTypes.put(jType);

          jType = new JSONArray();
          jType.put("Compound ID");
          jTypes.put(jType);

          jType = new JSONArray();
          jType.put("Reference Set");
          jTypes.put(jType);

          jType = new JSONArray();
          jType.put("POC");
          jTypes.put(jType);

          if (wb != null) {
            Sheet sheet = wb.getSheetAt(0);
            List<String> columnNames = ExcelUtils.getColumnHeaders(sheet);
            for (int i = 0; i < columnNames.size(); i++) {
              String columnName = columnNames.get(i);
              JSONObject jColumn = new JSONObject();
              jColumn.put("name", columnName);
              jColumns.append("columns", jColumn);
              jColumn.put("types", jTypes);

              if (ExtString.anyAlphaNumericsEqualIgnoreCase(new String[]{"barcode", "plate", "plate id"}, columnName)
                      || columnName.toLowerCase().contains("barcode")) {
                jColumn.put("type", "Plate ID");
              } else if (ExtString.anyAlphaNumericsEqualIgnoreCase(new String[]{"row", "plate row"}, columnName)
                      || columnName.toLowerCase().contains("row")) {
                jColumn.put("type", "Plate Row");
              } else if (ExtString.anyAlphaNumericsEqualIgnoreCase(new String[]{"column", "plate column"}, columnName)
                      || columnName.toLowerCase().contains("column")) {
                jColumn.put("type", "Plate Column");
              } else if (ExtString.anyAlphaNumericsEqualIgnoreCase(new String[]{"compound id", "compound", "amgen name", "root#lot"}, columnName)) {
                jColumn.put("type", "Compound ID");
              } else if (ExtString.anyAlphaNumericsEqualIgnoreCase(new String[]{"poc"}, columnName)) {
                jColumn.put("type", "POC");
              }
            }
          }
          return jColumns;
        case RUN_ANALYSIS:
        default:
          RNAiSearch search = new RNAiSearch(null, null, null, null, getParameterIntegers("experiment_ids"), RNAiSearchOutputType.EXPERIMENTS, null, getServletBase().getPersonRecord());
          List<ExperimentRecord> experimentRecords = search.getResponse().getJSONArray("experiments").asList();
          OGAAnalysis oga = new OGAAnalysis(getServletBase());
          OGAAnalysisDetails analysisDetails = oga.execute(experimentRecords);
          JSONObject jAnalysisDetails = new JSONObject();
          jAnalysisDetails.put("analysisKey", analysisDetails.getKey());
          return jAnalysisDetails;
      }
    } catch (Exception ex) {
      throw new IllegalArgumentException(ex.getMessage());
    }
  }

  /**
   * Gets a Workbook object from a multipart Request
   *
   * @param parameterName String
   * @return Workbook
   */
  public Workbook getWorkbookFromRequest(String parameterName) {
    Workbook wb = null;
    try {
      String fileName = getParameter(parameterName);
      if (fileName.endsWith(".csv")) {
        wb = CSVReader.toWorkbook(getServletBase().getParameterInputStream(parameterName), Charset.forName("UTF-8"), SpreadsheetVersion.EXCEL2007);
      } else {
        byte[] bytes = ExtFile.readStream(getServletBase().getParameterInputStream(parameterName));
        wb = ExcelUtils.readWorkbook(bytes);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return wb;
  }

  private JSONObject readLog() throws JSONException {
    JSONObject jLogEntries = new JSONObject();

    int lastLine = getParameterNumber("lastLineNumber", 0).intValue();
    int lineCounter = lastLine;
    String analysisKey = getParameter("analysisKey");
    OGAAnalysisDetails analysisDetails = (OGAAnalysisDetails) getSessionCache().get(SessionCache.CacheType.ANALYSIS, analysisKey);

    if (analysisDetails == null) {
      Map<String, AnalysisDetailsIF> analysisDetailsMap = getAnalysisDetails();
      analysisDetails = (OGAAnalysisDetails) analysisDetailsMap.get(analysisKey);
    }
    if (analysisDetails == null) {
      return jLogEntries;
    }
    File logFile = analysisDetails.getLog();
    if (logFile.exists()) {
      BufferedReader reader = null;
      try {
        reader = new BufferedReader(new FileReader(logFile));
        for (int i = 0; i < lastLine; i++) {
          reader.readLine();
        }
        String line;
        while ((line = reader.readLine()) != null) {
          jLogEntries.append("lines", line);
          lineCounter++;
        }
      } catch (Exception ex) {
        Logger.getLogger(RNAiAnalysisResponder.class.getName()).log(Level.SEVERE, null, ex);
      } finally {
        if (reader != null) {
          try {
            reader.close();
          } catch (IOException ex) {
          }
        }
      }
      jLogEntries.put("lastLineNumber", lineCounter);
      if (analysisDetails.hasFinished()) {
        JSONObject jStartEnd = new JSONObject();
        jStartEnd.put("start", dateFormat.format(analysisDetails.getStartTime()));
        jStartEnd.put("end", dateFormat.format(analysisDetails.getEndTime()));
        jLogEntries.put("analysisFinished", jStartEnd);
      }
    }
    return jLogEntries;
  }

  private JSONObject getGIResults() throws JSONException, CacheException {
    SessionCache sessionCache = new SessionCache(getServletBase());
    JSONObject jGIResults = new JSONObject();

    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      String analysisKey = getParameter("analysisKey");
      int giID = new Integer(analysisKey.replaceFirst("gi", ""));

      GIAnalysis giAnalysis = sqlSession.getMapper(Mapper.class).getGIAnalysisByID(giID);
      List<ExperimentRecord> expRecords = getExperiments(Arrays.asList(giAnalysis.getExperiment_a_id(), giAnalysis.getExperiment_b_id()), getServletBase().getPersonRecord());

      giAnalysis.loadResults(this, this.getServletBase().getPersonRecord());

      JSONObject jGIResult = new JSONObject();
      jGIResults.append("results", jGIResult);
      jGIResult.put("giID", giID);
      jGIResult.put("dataID", UUID.randomUUID().toString());

      jGIResult.put("expA", expRecords.get(0));
      jGIResult.put("expB", expRecords.get(1));

      JSONObject jColumn = new JSONObject();
      JSONObject jField = new JSONObject();
      jGIResult.append("columns", jColumn);
      jGIResult.append("fields", jField);

      jField.put("name", "gene_symbol");
      jColumn.put("dataIndex", "gene_symbol");
      jColumn.put("header", "Gene Symbol");
      jColumn.put("sortable", true);
      jColumn.put("filterType", "string");

      jField.put("name", "gene_name");
      jColumn.put("dataIndex", "gene_name");
      jColumn.put("header", "Gene Name");
      jColumn.put("sortable", true);
      jColumn.put("filterType", "string");

      for (String column : Arrays.asList("pvalue", "pvalueAdj", "pvalueSuppressor", "pvalueSuppressorAdj", "pvalueEnhancer", "pvalueEnhancerAdj")) {
        jColumn = new JSONObject();
        jField = new JSONObject();
        jGIResult.append("columns", jColumn);
        jGIResult.append("fields", jField);
        jField.put("name", column);
        jColumn.put("dataIndex", column);
        jColumn.put("header", column);
        jColumn.put("sortable", true);
        jField.put("type", "float");
        jColumn.put("filterType", "numeric");
        jColumn.put("format", "scientific");
        jColumn.put("precision", 5);
      }

      JSONObject jGeneResults = new JSONObject();
      for (GIResult giResult : giAnalysis.getResultList()) {
        GeneRecord geneRecord = giResult.getGeneRecord();
        List<String> names = geneRecord.names().asList();
        for (String name : names) {
          giResult.putOnce(name, geneRecord.opt(name));
        }
        jGeneResults.append("genes", giResult);
      }
      JSONObjectCacheItem jCachedResults = new JSONObjectCacheItem(jGIResult.getString("dataID"), jGeneResults);

      jGIResult.put("total", jCachedResults.getResultCount());
      sessionCache.put(SessionCache.CacheType.RESULTS, jGIResult.getString("dataID"), jCachedResults);

      JSONObject jResultsDetails = new JSONObject();
      jResultsDetails.put("total", jCachedResults.getResultCount());
      jResultsDetails.append("results", jGIResult);

      return jResultsDetails;
    } catch (IOException e) {
      e.printStackTrace();
    } finally {
      close(sqlSession);
    }
    return null;
  }

  private JSONObject getExecutedAnalysisNodes() throws JSONException {
    JSONObject jAnalysisNodes = new JSONObject();
    List<JSONObject> analysisNodes = new ArrayList<JSONObject>();
    Map<String, AnalysisDetailsIF> analysisDetailsMap = getAnalysisDetails();

    for (String key : analysisDetailsMap.keySet()) {
      AnalysisDetailsIF analysisDetails = analysisDetailsMap.get(key);
      if (analysisDetails.isValid()) {
        JSONObject jAnalysisNode = new JSONObject();
        analysisNodes.add(jAnalysisNode);
        jAnalysisNode.put("id", analysisDetails.getKey());
        jAnalysisNode.put("type", "analysis");
        jAnalysisNode.put("analysis", analysisDetails.getAnalysisType());
        jAnalysisNode.put("leaf", analysisDetails.getExperimentRecords().isEmpty());
        jAnalysisNode.put("start", dateFormat.format(analysisDetails.getStartTime()));
        jAnalysisNode.put("text", analysisDetails.getAnalysisName() + " [" + dateFormat.format(analysisDetails.getStartTime()) + "]");
        jAnalysisNode.put("finished", analysisDetails.hasFinished());

        String tip = String.format(
                "<TABLE style='font: normal 10px tahoma,arial,verdana,sans-serif'>"
                + "<TR><TD style='font-weight: bold'>Start:</TD><TD>%s</TD></TR>"
                + "<TR><TD style='font-weight: bold'>End:</TD><TD>%s</TD></TR>"
                + "<TR><TD style='font-weight: bold'>Elapsed:</TD><TD>%s</TD></TR>"
                + "</TABLE>", new Object[]{
                  dateFormat.format(analysisDetails.getStartTime()),
                  dateFormat.format(analysisDetails.getEndTime()),
                  analysisDetails.getElapsedTime()
                });

        jAnalysisNode.put("qtip", tip);

        for (ExperimentRecord expRecord : analysisDetails.getExperimentRecords()) {
          JSONObject jExpNode = new JSONObject();
          jExpNode.put("experiment_id", expRecord.getExperimentID());
          jExpNode.put("type", "experiment");
          jExpNode.put("leaf", true);
          jExpNode.put("text", expRecord.getExperimentName());
          jAnalysisNode.append("children", jExpNode);
        }
      }
    }
    List<JSONObject> sortAnalysisNodes = ExtArray.sort(analysisNodes, new Comparator() {
      public int compare(Object o1, Object o2) {
        try {
          JSONObject analysisNode1 = (JSONObject) o1;
          JSONObject analysisNode2 = (JSONObject) o2;
          Date d1 = dateFormat.parse(analysisNode1.getString("start"));
          Date d2 = dateFormat.parse(analysisNode2.getString("start"));
          return -d1.compareTo(d2);
        } catch (Exception ex) {
          Logger.getLogger(RNAiAnalysisResponder.class.getName()).log(Level.SEVERE, null, ex);
        }
        return 0;
      }
    });
    jAnalysisNodes.put("nodes", new JSONArray(sortAnalysisNodes));
    return jAnalysisNodes;
  }

  private Map<String, AnalysisDetailsIF> getAnalysisDetails() {
    SqlSession sqlSession = null;
    Map<String, AnalysisDetailsIF> analysisDetailsMap = new LinkedHashMap<String, AnalysisDetailsIF>();
    try {
      List<File> analysisDetailsFiles = ExtFile.list(getServletBase().getSessionWorkDir(), new String[]{"bin"});
      for (File analysisDetailsFile : analysisDetailsFiles) {
        try {
          AbstractAnalysisDetails analysisDetails = AbstractAnalysisDetails.loadObject(analysisDetailsFile);
          analysisDetailsMap.put(analysisDetails.getKey(), analysisDetails);
        } catch (IOException ex) {
          Logger.getLogger(RNAiAnalysisResponder.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
          Logger.getLogger(RNAiAnalysisResponder.class.getName()).log(Level.SEVERE, null, ex);
        }
      }

      sqlSession = getRNAiSqlSession();
      List<GIAnalysis> giAnalyses = sqlSession.getMapper(Mapper.class).getGIAnalysisForUser(getServletBase().getPersonRecord().getUsername());

      for (GIAnalysis giAnalysis : giAnalyses) {
        GIAnalysisDetails giAnalysisDetails = new GIAnalysisDetails(giAnalysis, this);
        analysisDetailsMap.put(giAnalysisDetails.getKey(), giAnalysisDetails);
      }
    } finally {
      close(sqlSession);
    }
    return analysisDetailsMap;
  }

  private JSONObject runGIAnalysis() throws Exception {
    String all_experiment_ids = this.getParameter("experiment_ids");
    boolean overwriteExistingAnalysis = StringUtils.equalsIgnoreCase(getParameter("overwrite"), "true");
    JSONObject jResponse = new JSONObject();
    GIAnalysisDetailsListener giAnalysisDetailsListener = new GIAnalysisDetailsListener();
    GeneticInteractionAnalysis giAnalysis = new GeneticInteractionAnalysis(getServletBase(), overwriteExistingAnalysis, giAnalysisDetailsListener);
    giAnalysis.addListener(new GIOracleInsertListener(giAnalysis));
    giAnalysis.addListener(new GIEmailNotifierListener(this.getServletBase().getPersonRecord()));
    giAnalysis.executeGIAnalyses(all_experiment_ids);
    return jResponse;
  }

  private JSONObject deleteGIAnalysis() throws JSONException {
    SqlSession sqlSession = null;
    JSONObject jResponse = new JSONObject();
    try {
      sqlSession = getRNAiSqlSession();
      String analysisKey = getParameter("analysisKey");
      int giID = new Integer(analysisKey.replaceFirst("gi", ""));
      GIAnalysis giAnalysis = sqlSession.getMapper(Mapper.class).getGIAnalysisByID(giID);
      sqlSession.getMapper(Mapper.class).deleteGIResultsByID(giAnalysis);
      sqlSession.getMapper(Mapper.class).deleteGIAnalysisByID(giAnalysis);
      sqlSession.commit();
    } catch (Exception ex) {
      jResponse.put("message", ex.getMessage());
    } finally {
      close(sqlSession);
    }
    return jResponse;
  }

  private JSONObject getPOCExpResults(List<ExperimentRecord> experimentRecords) {
    JSONObject jResults = new JSONObject();
    if (experimentRecords.size() == 2) {
      Connection conn = null;
      try {
        conn = getRNAiConnection();
        String RNAi_QUERY = "begin ? := RNAIQUERY.getGeneticInteractionResults(?,?,?); end;";
        OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RNAi_QUERY);
        cs.registerOutParameter(1, Types.CLOB);
        cs.setInt(2, experimentRecords.get(0).getExperimentID());
        cs.setInt(3, experimentRecords.get(1).getExperimentID());
        cs.setString(4, "POC");
        cs.execute();
        String results = cs.getString(1);
        int count = 0;
        for (String line : results.split("[\\r\\n]+")) {
          count++;
          String[] fields = line.split("\\t+");
          if (fields.length == 5 && ExtString.isAInteger(fields[3])) {
            try {
              JSONObject jResult = new JSONObject();
              jResult.put("data1", new Double(fields[0]));
              jResult.put("data2", new Double(fields[1]));
              jResult.put("gene_symbol", fields[2]);
              jResult.put("gene_id", new Integer(fields[3]));
              jResult.put("rnai_id", new Integer(fields[4]));
              jResults.append("results", jResult);
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        close(conn);
      }
    }
    return jResults;
  }

  private JSONObject runSurvivalPlot() throws JSONException, SQLException, IOException, CacheException, RAnalysisFailureException {
    JSONObject jResponse = new JSONObject();
    ExperimentRecord experimentRecord = getExperimentRecordFromParameter("experiment_id");
    List<GeneRecord> targetGeneRecords = getGeneRecordsFromParameter("gene_id");
    List<GeneMixtureRecord> targetGeneMixtureRecords = getGeneMixtureRecordsFromParameter("gene_mixture_id");
    targetGeneRecords.addAll(targetGeneMixtureRecords);

    List<GeneRecord> controlGeneRecords = getGeneRecordsFromGeneSymbolParameter("control_gene_symbols");
    SurvivalPlot survivalPlot = new SurvivalPlot(getServletBase());
    SurvivalAnalysisDetails survivalAnalysisDetails = survivalPlot.process(experimentRecord, targetGeneRecords, controlGeneRecords);
    getSessionCache().put(SessionCache.CacheType.ANALYSIS, survivalAnalysisDetails.getKey(), survivalAnalysisDetails);
    jResponse.put("key", survivalAnalysisDetails.getKey());
    return jResponse;
  }

  private JSONObject runGeneExpHistogramPlot() throws JSONException, IOException {
    JSONObject jResponse = new JSONObject();
    GeneRecord geneRecord = getGeneRecordFromParameter("gene_id");
    HistogramGeneCollection histogramGeneCollection = new HistogramGeneCollection(getServletBase());
    try {
      jResponse = histogramGeneCollection.process(geneRecord);
    } catch (RAnalysisFailureException re) {
      jResponse.put("message", re.getMessage());
    }
    return jResponse;
  }
}
