/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractPermissionRule implements PermissionRuleIF {
  private PermissionType permissionType;
  private PersonRecordIF requestedBy;

  protected AbstractPermissionRule(PermissionType permissionType, PersonRecordIF requestedBy) {
    this.permissionType = permissionType;
    this.requestedBy = requestedBy;
    if (requestedBy == null)  {
      throw new SecurityException("Request user can not be null");
    }
  }

  /**
   * Returns whether the requestedBy user is in the administrators group
   *
   * @return
   */
  public boolean isAdministrator() {
    return Boolean.valueOf(requestedBy.getAttribute("ADMINISTRATOR"));
  }

  /**
   * Get the value of requestedBy
   *
   * @return the value of requestedBy
   */
  public PersonRecordIF getRequestedBy() {
    return requestedBy;
  }

  /**
   * Get the value of permissionType
   *
   * @return the value of permissionType
   */
  public PermissionType getPermissionType() {
    return permissionType;
  }

  /**
   * Returns whether the given username matches the username in the requestedBy
   * user
   *
   * @param username
   * @return
   */
  protected boolean isRequestedBy(String username) {
    return requestedBy.getUsername().equalsIgnoreCase(username);
  }
}
