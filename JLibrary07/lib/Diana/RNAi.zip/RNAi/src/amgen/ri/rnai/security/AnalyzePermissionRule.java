/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtString;

/**
 *
 * @author jemcdowe
 */
public class AnalyzePermissionRule extends AbstractPermissionRule implements PermissionRuleIF {
  
  public AnalyzePermissionRule(PersonRecordIF requestedBy) {
    super(PermissionType.ANALYZE, requestedBy);
  }

  /**
   * Check whether the requestedBy user can analyze the record
   * Throws a SecurityException if not true
   *
   * @param record
   * @throws SecurityException
   */
  public void checkPermission(AbstractRecord record) throws SecurityException {
    if (record== null ||  !(record instanceof ExperimentRecord)) {
      throw new IllegalArgumentException("Permission requires experiment record");
    }
    ExperimentRecord expRecord = (ExperimentRecord) record;    
    if (isAdministrator()) {
      return;
    }
    if (isRequestedBy(expRecord.getUploadedByUsername())) {
      return;
    }
    throw new SecurityException("User does not have sufficient privilege to analyze record");
  }

}
