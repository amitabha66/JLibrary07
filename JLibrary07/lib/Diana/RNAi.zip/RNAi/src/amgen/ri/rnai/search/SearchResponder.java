package amgen.ri.rnai.search;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.CacheFilterSet;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.screener.CollectionResponder;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.util.List;
import java.util.UUID;
import org.apache.jcs.access.exception.CacheException;

/**
 *
 * @author jemcdowe
 */
public class SearchResponder extends AbstractResponder implements JSONResponderIF {
  enum SearchResponderRequest {
    SEARCH, ALL_EXPERIMENTS, CACHE, DELETE_CACHE_ITEM, EXPERIMENT_SEARCH, ANALYSIS_TYPES, RESULT_TYPES, PLATE_UTILITIES, UNKOWN;

    public static SearchResponderRequest toRequest(String s) {
      try {
        return SearchResponderRequest.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return SEARCH;
    }

    public static SearchResponderRequest toRequest(AbstractResponder responder) {
      try {
        return SearchResponderRequest.toRequest(responder.getServletBase().getParameter("rx"));
      } catch (Exception e) {
      }
      return SEARCH;
    }
  };

  public SearchResponder(MainUI servletBase) {
    super(servletBase);
  }

  public JSONObject getResponse() {
//    getServletBase().printRequest(Logger.getLogger("rnai"));
    //getServletBase().printRequest();
    String dataID = getParameter("dataID");
    SessionCache sessionCache = new SessionCache(getServletBase());
    try {
      switch (SearchResponderRequest.toRequest(this)) {
        case SEARCH:
          switch (RNAiSearchOutputType.fromString(getParameter("searchResponse"))) {
            case RESULTS:
              dataID = (ExtString.hasLength(dataID) ? dataID : UUID.randomUUID().toString());
              int geneID = getParameterNumber("gene_id", -1).intValue();
              int geneMixtureID = getParameterNumber("gene_mixture_id", -1).intValue();
              int experimentID = getParameterNumber("experiment_id", -1).intValue();
              AnalysisResultsSearch resultSearch = new AnalysisResultsSearch(getParameter("searchType"), getParameter("searchResponse"), geneID, geneMixtureID, experimentID,
                      getParameter("analyses"), getParameter("resultTypes"), sessionCache, getServletBase().getPersonRecord());
              JSONObject jResultSearchResponse = resultSearch.getResponse();

              JSONObjectCacheItem jResultSearchCachedResults = new JSONObjectCacheItem(dataID, jResultSearchResponse);
              jResultSearchResponse.put("total", jResultSearchCachedResults.getResultCount());
              sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jResultSearchCachedResults);
              JSONObject jResultsSearchDetails = new JSONObject();
              jResultsSearchDetails.put("total", jResultSearchCachedResults.getResultCount());
              jResultsSearchDetails.put("dataID", dataID);
              jResultsSearchDetails.put("analysis", resultSearch.getAnalysisTypes());
              jResultsSearchDetails.put("result_types", resultSearch.getResultTypes());
              return jResultsSearchDetails;
            case RAWRESULTS:
              List<Integer> geneIDs = getParameterIntegers("gene_ids");
              List<Integer> geneMixtureIDs = getParameterIntegers("gene_mixture_ids");

              RNAiSearch rawResultSearch = null;
              if (ExtArray.hasLength(geneMixtureIDs)) {
                rawResultSearch = new RNAiSearch(null, null, null, geneMixtureIDs, getParameterIntegers("experiment_ids"),
                        RNAiSearchOutputType.RAWRESULTS, sessionCache, getServletBase().getPersonRecord());
              } else if (ExtArray.hasLength(geneIDs)) {
                rawResultSearch = new RNAiSearch(null, null, geneIDs, null, getParameterIntegers("experiment_ids"),
                        RNAiSearchOutputType.RAWRESULTS, sessionCache, getServletBase().getPersonRecord());
              } else {
                throw new IllegalArgumentException("No provided IDs");
              }
              if (ExtString.hasLength(dataID)) {
                JSONObject jResults = rawResultSearch.getResponse();
                JSONObjectCacheItem jCachedResults = new JSONObjectCacheItem(dataID, jResults);
                jResults.put("total", jCachedResults.getResultCount());
                sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jCachedResults);
                JSONObject jResultsDetails = new JSONObject();
                jResultsDetails.put("total", jCachedResults.getResultCount());
                return jResultsDetails;
              } else {
                return rawResultSearch.getResponse();
              }
            default:
              RNAiSearch search = new RNAiSearch(getParameter("query"), getParameter("searchType"), getParameter("searchResponse"), sessionCache, getServletBase().getPersonRecord());
              if (ExtString.hasLength(dataID)) {
                JSONObject jResults = search.getResponse();
                JSONObjectCacheItem jCachedResults = new JSONObjectCacheItem(dataID, jResults);
                jResults.put("total", jCachedResults.getResultCount());
                sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jCachedResults);
                JSONObject jResultsDetails = new JSONObject();
                jResultsDetails.put("total", jCachedResults.getResultCount());
                return jResultsDetails;
              } else {
                return search.getResponse();
              }
          }
        case ALL_EXPERIMENTS:
          RNAiSearch search = new RNAiSearch(null, RNAiSearchInputType.ALL + "", RNAiSearchOutputType.EXPERIMENTS + "", sessionCache, getServletBase().getPersonRecord());
          if (ExtString.hasLength(dataID)) {
            JSONObject jResults = search.getResponse();
            JSONObjectCacheItem jCachedResults = new JSONObjectCacheItem(dataID, jResults);
            jResults.put("total", jCachedResults.getResultCount());
            sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jCachedResults);
            JSONObject jResultsDetails = new JSONObject();
            jResultsDetails.put("total", jCachedResults.getResultCount());
            return jResultsDetails;
          } else {
            return search.getResponse();
          }
        case CACHE:
          return handleCacheResultRequest(sessionCache);
        case DELETE_CACHE_ITEM:
          if (ExtString.hasLength(dataID)) {
            sessionCache.remove(SessionCache.CacheType.RESULTS, dataID);
          }
          return new JSONObject();
        case ANALYSIS_TYPES:
          AnalysisResultsSearch analysisResultsSearch1 = new AnalysisResultsSearch(sessionCache, getServletBase().getPersonRecord());
          JSONObject jAnalysis = new JSONObject();
          JSONObject jAnalysisMap = analysisResultsSearch1.getAnalysisTypeMap();
          for (String key : JSONObject.getNames(jAnalysisMap)) {
            jAnalysis.append("analysis", jAnalysisMap.getJSONObject(key));
          }
          return jAnalysis;
        case RESULT_TYPES:
          AnalysisResultsSearch analysisResultsSearch2 = new AnalysisResultsSearch(sessionCache, getServletBase().getPersonRecord());
          JSONObject jResultTypes = new JSONObject();

          JSONObject jResultTypeMap = analysisResultsSearch2.getResultTypeMap();
          for (String key : JSONObject.getNames(jResultTypeMap)) {
            jResultTypes.append("result_types", jResultTypeMap.getJSONObject(key));
          }
          return jResultTypes;
        case PLATE_UTILITIES:
          CollectionResponder collectionResponder = new CollectionResponder(this.getServletBase());
          JSONObject jPlateLineageResults = collectionResponder.getResponse();
          if (ExtString.hasLength(dataID)) {
            JSONObjectCacheItem jCachedResults = new JSONObjectCacheItem(dataID, jPlateLineageResults);
            jPlateLineageResults.put("total", jCachedResults.getResultCount());
            sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jCachedResults);
            JSONObject jResultsDetails = new JSONObject();
            jResultsDetails.put("total", jCachedResults.getResultCount());
            return jResultsDetails;
          } else {
            return jPlateLineageResults;
          }
        default:
          throw new Exception("Unknown request- " + SearchResponderRequest.toRequest(this));
      }
    } catch (Exception e) {
      //e.printStackTrace();
      throw new IllegalArgumentException(e.getMessage());
    }
  }

  private JSONObject handleCacheResultRequest(SessionCache sessionCache) throws CacheException, JSONException {
    //getServletBase().printRequest();
    JSONObject jPageResults = new JSONObject();
    String dataID = getParameter("dataID");
    if (!ExtString.hasLength(dataID)) {
      throw new IllegalStateException("Cache request without a data ID provided");
    }
    int start = getParameterNumber("start", 0).intValue();
    int page = getParameterNumber("limit", 25).intValue();
    final String sort = getParameter("sort");
    final String dir = getParameter("dir", "ASC");

    CacheFilterSet filterSet = new CacheFilterSet(this.getServletBase());

    JSONObjectCacheItem jCachedResults = (JSONObjectCacheItem) sessionCache.get(SessionCache.CacheType.RESULTS, dataID);
    JSONObject jResults = jCachedResults.getSortedFilteredData(sort, dir, filterSet);
    List results = jResults.getJSONArray(jCachedResults.getResultName()).asList();
    int end = Math.min(start + page, results.size());
    List subResults = results.subList(start, end);
    jPageResults.put("total", results.size());
    jPageResults.put(jCachedResults.getResultName(), new JSONArray(subResults));
    return jPageResults;
  }
}
