/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.jawr.JAWRLinkRenderer;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.analyze.FileResponse;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.security.IdentityIF;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.File;
import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Constructor;
import java.text.SimpleDateFormat;
import java.util.UUID;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

/**
 *
 * @author jemcdowe - modified by jayanthi
 */
@WebServlet(name = "MainUI", urlPatterns = {"/rnai.go", "/rnai"})
public class MainUI extends ServletBase {
  public SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
  private PermissionManager permissionManager;

  /**
   *
   */
  public MainUI() {
    super();
  }

  /**
   * @param req
   * @param resp
   */
  public MainUI(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /*
   * (non-Javadoc)
   *
   * @see
   * amgen.ri.servlet.ServletBase#getServlet(javax.servlet.http.HttpServletRequest,
   * javax.servlet.http.HttpServletResponse)
   */
  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new MainUI(req, resp);
  }

  /*
   * (non-Javadoc)
   *
   * @see amgen.ri.servlet.ServletBase#getServletMimeType()
   */
  @Override
  protected String getServletMimeType() {
    return "text/html";
  }

  public String getInstanceInitParameter() {
    return "RNAI_VERSION";
  }

  public PermissionManager getSecurityManager() {
    if (permissionManager == null) {
      permissionManager = new PermissionManager(this);
    }
    return permissionManager;
  }

  /**
   * Function to create connection with database and to read the xml files used
   * for mapping.
   */
  public SqlSessionFactory getSqlSessionFactory(String factoryID) {
    SqlSessionFactory sqlSessionFactory = null;
    try {
      String resource = "batisConfig.xml";
      Reader reader = Resources.getResourceAsReader(resource);
      sqlSessionFactory = new SqlSessionFactoryBuilder().build(reader, factoryID);
    } catch (IOException ioe) {
      ioe.printStackTrace();
    }
    return sqlSessionFactory;
  }

  public SqlSession getRNAiSqlSession() {
    return getRNAiSqlSession(ExecutorType.SIMPLE);
  }

  public SqlSession getRNAiSqlSession(ExecutorType executorType) {
    return getSqlSessionFactory("rnai").openSession(executorType);
  }

  /*
   * (non-Javadoc)
   *
   * @see amgen.ri.servlet.ServletBase#performRequest()
   */
  @Override
  protected void performRequest() throws Exception {
    try {
      //System.out.println("User in session: " + this.getFASFIdentity().getUsername());
      JSONResponderIF jsonResponse = null;
      FileResponderIF fileResponder = null;
      HTMLElement htmlResponse = null;
      String className = getParameter("req");
      if (!ExtString.hasLength(className) || className.equalsIgnoreCase("null")) {
        htmlResponse = createMainWindow();
      } else {
        Class responderClass = Class.forName(className);
        Class[] parameterTypes = {this.getClass()};
        Object[] initArgs = {this};
        Constructor constructor = responderClass.getConstructor(parameterTypes);
        Object responder = constructor.newInstance(initArgs);
        if (responder instanceof FileResponderIF) {
          fileResponder = (FileResponderIF) responder;
        }
        if (responder instanceof JSONResponderIF) {
          jsonResponse = (JSONResponderIF) responder;
        }
      }
      if (fileResponder != null && fileResponder.isFileResponse()) {
        FileResponse responseFile = fileResponder.getFileResponse();
        response.setContentType(responseFile.getMimetype());
        response.addHeader("Content-disposition",
                "attachment; filename=" + responseFile.getFileName());
        ExtFile.writeFile(responseFile.getResponseFile(), response.getOutputStream());
        response.getOutputStream().flush();
      } else if (jsonResponse != null) {
        response.getWriter().println(jsonResponse.getResponse());
      } else if (htmlResponse != null) {
        response.getWriter().println(htmlResponse);
      }
    } catch (Throwable e) {
      if (e.getMessage() != null) {
        if (isMultipartContent()) {
          JSONObject jError = new JSONObject();
          jError.put("error_mesg", e.getMessage());
          response.getWriter().println(jError);
        } else {
          response.addHeader("error_mesg", e.getMessage());
          response.sendError(510, e.getMessage());
        }
      }
    }
  }

  protected HTMLElement createMainWindow() throws IOException, JSONException {
    JAWRLinkRenderer jawrLinkRenderer = new JAWRLinkRenderer(this, false);
    HTMLElement html = new GenericHTMLElement("HTML");
    HTMLElement head = html.addMemberElement("HEAD");
    HTMLElement titleEl = head.addMemberElement("TITLE");

    IdentityIF sessionIdentity = getFASFIdentity();
    JSONObject jPerson = sessionIdentity.asPersonRecord();
    jPerson.put("ADMINISTRATOR", isAdministrator());

    titleEl.setText("RNAi v1.3- (" + sessionIdentity.getUserPreferredDisplayName() + (isAdministrator() ? "- Administrator" : "") + ")");

    FileSetManager fileSetMgr = new FileSetManager(request);
    fileSetMgr.appendStyles(head, "ext3css");
    fileSetMgr.appendStyles(head, "ext4js_sandboxcss");
    fileSetMgr.appendStyles(head, "rnaicss");

    head.addMemberElement("STYLE").appendContent(".rvml { behavior: url(#default#VML);} .x4-reset .rvml { behavior: url(#default#VML);}");

    fileSetMgr.appendScripts(head, "ext3js");
    fileSetMgr.appendScripts(head, "ext4js_sandbox");
    fileSetMgr.appendScripts(head, "rnaijs");
    head.addMemberElement("SCRIPT").appendContent("var sessionIdentity= new RNAi.User(" + jPerson + ");");

    @SuppressWarnings("unused")
    HTMLElement bodyEL = html.addMemberElement("BODY");

    HTMLElement loadingParentDivEl = bodyEL.addMemberElement("DIV");
    loadingParentDivEl.setClassName("init-loading");

    HTMLElement loadingSpanEl = loadingParentDivEl.addMemberElement("SPAN");
    loadingSpanEl.setClassName("init-loading-indicator");

    HTMLElement loadingImgEl = loadingSpanEl.addMemberElement("IMG");
    loadingImgEl.addAttribute("width", "32");
    loadingImgEl.addAttribute("height", "32");
    loadingImgEl.addAttribute("src", "http://ussf-papp-dweb1.amgen.com:9090/extjs/ext3/resources/images/default/s.gif");

    HTMLElement loadingSpan1El = loadingParentDivEl.addMemberElement("SPAN");
    loadingSpan1El.setClassName("init-loading-indicator");
    loadingSpan1El.setText("Loading RNAi v1.3 ...");

    return html;
  }

  public String getRNAiAdministratorsGroup() {
    return session.getServletContext().getInitParameter("RNAI_ADMIN_GROUP");
  }

  public boolean isAdministrator() {
    return getFASFIdentity().getActiveDirectoryEntry().isMemberOf(getRNAiAdministratorsGroup());
  }

  /**
   * Returns the user identity as a PersonRecord
   *
   * @return
   */
  public PersonRecordIF getPersonRecord() {
    PersonRecordIF personRecord = super.getPersonRecord();
    personRecord.setAttribute("ADMINISTRATOR", isAdministrator() + "");
    return personRecord;
  }

  public SessionCache getSessionCache() {
    return new SessionCache(this);
  }

  /**
   * A work directory used for storing temporary files.
   * This gets removed when the session is destroyed
   *
   * @return
   */
  public File getSessionWorkDir() {
    if (session.getAttribute("WORK_DIR") == null) {
      File tempBaseDir
              = new File(context.getInitParameter("WORK_DIR")
                      + "/RNAi"
                      + "/" + context.getInitParameter("RNAI_VERSION").toLowerCase()
                      + "/" + getFASFIdentity().getUsername()
                      + "/" + UUID.randomUUID());
      session.setAttribute("WORK_DIR", tempBaseDir);
    }
    File workDir = (File) session.getAttribute("WORK_DIR");
    if (!workDir.isDirectory()) {
      workDir.mkdirs();
    }
    return workDir;
  }

  /**
   * A global directory that is maintained across sessions.
   * This is removed when the servlet context is destroyed
   *
   * @return
   */
  public File getCrossSessionDir() {
    if (session.getAttribute("GLOBAL_WORK_DIR") == null) {
      File tempBaseDir
              = new File(context.getInitParameter("WORK_DIR")
                      + "/RNAi"
                      + "/" + context.getInitParameter("RNAI_VERSION").toLowerCase()
                      + "/" + getFASFIdentity().getUsername());
      session.setAttribute("GLOBAL_WORK_DIR", tempBaseDir);
    }
    File workDir = (File) session.getAttribute("GLOBAL_WORK_DIR");
    if (!workDir.isDirectory()) {
      workDir.mkdirs();
    }
    return workDir;
  }

  public SimpleDateFormat getDateFormat() {
    return dateFormat;
  }
}
