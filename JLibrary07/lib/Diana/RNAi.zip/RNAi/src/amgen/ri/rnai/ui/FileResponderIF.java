/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

import amgen.ri.rnai.analyze.FileResponse;
import java.io.File;

/**
 *
 * @author jemcdowe
 */
public interface FileResponderIF {
  /**
   * Returns whether this responder will return a File
   * @return 
   */
  public boolean isFileResponse();
  /**
   * Returns the encapsulated File response
   * @return 
   */
  public FileResponse getFileResponse();
}
