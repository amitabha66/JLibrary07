package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.rnai.records.ExperimentRecord;
import java.util.Collection;

/**
 *
 * @author jemcdowe
 */
public interface GeneticInteractionListenerIF {
  public void processBegan(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments);
  public void analysisStarted(GeneticInteractionAnalysis giAnalysis, GIExperiments gie);
  public void analysisComplete(GeneticInteractionAnalysis giAnalysis, GIExperiments gie);
  public void processEnded(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments);
}
