/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.R;

/**
 *
 * @author jemcdowe
 */
public class RAnalysisFailureException extends Exception {

  public RAnalysisFailureException(Throwable cause) {
    super(cause);
  }

  public RAnalysisFailureException(String message, Throwable cause) {
    super(message, cause);
  }

  public RAnalysisFailureException(String message) {
    super(message);
  }

  public RAnalysisFailureException() {
  }
  
}
