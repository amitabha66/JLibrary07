/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener;

import amgen.ri.rnai.ui.*;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.SessionCache;

import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.AnnotationRecord;
import amgen.ri.rnai.search.AbstractSearch;
import java.util.*;
import java.util.logging.Level;

public class AnnotationResponder extends AbstractResponder implements JSONResponderIF {
  public AnnotationResponder(MainUI servletBase) {
    super(servletBase);
  }

  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    try {

      AnnotationUpdater up = new AnnotationUpdater(new SessionCache(getServletBase()));

      String action_id = this.getParameter("action_id");
      //System.out.println("action_id.." + action_id);
      if (action_id.equalsIgnoreCase("add-annotation")) {
        String annotation_json = this.getParameter("annotation_json");
        String table_name = this.getParameter("table_name");
        return up.processAddAnnotation(getLogger(), table_name, annotation_json);
      } else if (action_id.equalsIgnoreCase("edit-annotation")) {
        String annotation_json = this.getParameter("annotation_json");
        //System.out.println("edit json: " + annotation_json);
        String table_name = this.getParameter("table_name");
        return up.processUpdateAnnotation(getLogger(), table_name, annotation_json);
      } else if (action_id.equalsIgnoreCase("delete-annotation")) {
        String deleteIds = this.getParameter("deleteIds");
        String table_name = this.getParameter("table_name");
        return up.processDeleteAnnotation(getLogger(), table_name, deleteIds);
      } else if (action_id.equalsIgnoreCase("get-annotation-group")) {
        return up.processGetAnnotationGroup(getLogger());
      } else if (action_id.equalsIgnoreCase("get-annotation")) {
        return up.processGetAnnotation(getLogger());
      } else if (action_id.equalsIgnoreCase("get-annotation-option")) {
        String annotation_id = this.getParameter("annotation_id");
        //System.out.println("annotation_id: " + annotation_id);
        return up.processGetAnnotationOption(getLogger(), annotation_id);
      } else if (action_id.equalsIgnoreCase("get-celllines")) {
        List annotationRecords = new AnnotationSearchClass(this, RNAiSearchInputType.ALL_WITHDATA, RNAiSearchOutputType.CELLLINE_ANNOTATIONS).asList();
        return createResponseJSON("annotation", new HashSet<AnnotationRecord>(annotationRecords));
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

    getLogger().debug(jResponse);
    return jResponse;
  }
}

/**
 * A local version of the AbstractSearch class specific for searching for
 * Collections and Members
 *
 * @author jemcdowe
 */
class AnnotationSearchClass extends AbstractSearch {
  List<AnnotationRecord> annotationRecords;
  RNAiSearchInputType inputType;
  RNAiSearchOutputType outputType;
  private int experimentID = -1;

  public AnnotationSearchClass(AbstractResponder responder) {
    this(responder, -1);
  }

  public AnnotationSearchClass(AbstractResponder responder, int experimentID) {
    super(responder);
    this.experimentID = experimentID;
    inputType = (experimentID > 0 ? RNAiSearchInputType.EXPERIMENT_IDS : RNAiSearchInputType.UNKNOWN);
  }

  public AnnotationSearchClass(AbstractResponder responder, RNAiSearchInputType inputType, RNAiSearchOutputType outputType) {
    super(responder);
    this.inputType = inputType;
    this.outputType = outputType;
  }

  @Override
  protected List<Map<String, String>> getQuery() {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value = new HashMap<String, String>();
    query.add(value);
    value.put("experiment_id", experimentID + "");
    return query;
  }

  @Override
  public List<? extends AbstractRecord> asList() {
    if (annotationRecords == null) {
      try {
        annotationRecords = new ArrayList<AnnotationRecord>();
        JSONObject jResults = executeQuery(inputType, outputType, getQuery());
        List<JSONObject> results = new ArrayList<JSONObject>();
        if (jResults.has("results")) {
          results = jResults.getJSONArray("results").asList();
        }
        for (JSONObject result : results) {
          annotationRecords.add(new AnnotationRecord(result));
        }
      } catch (Exception ex) {
        java.util.logging.Logger.getLogger(CollectionSearchClass.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    return annotationRecords;
  }

  @Override
  public int getCount() {
    return asList().size();
  }
}