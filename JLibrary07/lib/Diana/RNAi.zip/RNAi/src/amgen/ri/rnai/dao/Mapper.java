/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.dao;

import amgen.ri.rnai.analyze.geneticinteraction.GIAnalysis;
import amgen.ri.rnai.analyze.geneticinteraction.GIAnalysisDetails;
import amgen.ri.rnai.analyze.geneticinteraction.GIExperiments;
import amgen.ri.rnai.analyze.geneticinteraction.GIResult;
import amgen.ri.rnai.log.LogEntry;
import amgen.ri.rnai.records.OperationLogRecord;
import amgen.ri.rnai.records.ResultType;
import java.util.List;

/**
 *
 * @author jemcdowe
 */
public interface Mapper {
  public List<OperationLogRecord> getExperimentOperationLogs(int experimentID);

  public OperationLogRecord getOperationLog(int logID);

  public void getGeneticInteractionResults(GIExperiments gie);

  public List<ResultType> getResultTypes();

  public List<GIAnalysis> getGIAnalysisForUser(String createdBy);

  public GIAnalysis getGIAnalysisByID(int giID);

  public GIAnalysis getGIAnalysis(GIAnalysis giAnalysis);

  public void deleteGIAnalysis(GIAnalysis giAnalysis);

  public void deleteGIResults(GIAnalysis giAnalysis);

  public void deleteGIAnalysisByID(GIAnalysis giAnalysis);
  
  public void deleteGIResultsByID(GIAnalysis giAnalysis);

  public void insertGIAnalysis(GIAnalysis giAnalysis);

  public void updateGIAnalysisElapsedMillis(GIAnalysis giAnalysis);

  public void insertGIResults(GIResult giResult);

  public String getGeneticInteractionAnalysisResults(GIAnalysis giAnalysis);

  public void getGICompareResults(GIAnalysisDetails giAnalysisDetails);
  
  public void runNamedQuery(NamedQuery namedQuery);
  
  public void insertLogEntry(LogEntry logEntry);
  
  public List<PersonRecord> selectPersons(List<String> amgenLogins);
  public List<PersonRecord> searchPersons(String query);  
  public List<PersonRecord> searchPersonsByLastFirst(String lastName, String firstName);    
  public PersonRecord lookupPersonByLastFirst(String lastName, String firstName);    
}
