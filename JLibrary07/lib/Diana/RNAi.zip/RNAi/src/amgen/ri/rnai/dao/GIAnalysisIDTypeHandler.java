/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.dao;

import amgen.ri.rnai.analyze.geneticinteraction.GIAnalysisDetails;
import amgen.ri.rnai.records.ExperimentRecord;
import java.sql.CallableStatement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

/**
 *
 * @author jemcdowe
 */
public class GIAnalysisIDTypeHandler extends BaseTypeHandler<Object> {
  public GIAnalysisIDTypeHandler() {
    super();
  }

  @Override
  public void setNonNullParameter(final PreparedStatement ps, final int i, final Object parameter, final JdbcType jdbcType)
          throws SQLException {
    List<Integer> giAnalysisIDs= (List<Integer>) parameter;   
    ArrayDescriptor numberArrayDesc = ArrayDescriptor.createDescriptor("NUMBER_ARRAY", ps.getConnection());
    ARRAY numberArray = new ARRAY(numberArrayDesc, ps.getConnection(), (Integer[]) giAnalysisIDs.toArray(new Integer[0]));
    ps.setArray(i, numberArray);
  }

  @Override
  public Object getNullableResult(ResultSet rs, String string) throws SQLException {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Override
  public Object getNullableResult(ResultSet rs, int i) throws SQLException {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Override
  public Object getNullableResult(CallableStatement cs, int i) throws SQLException {
    throw new UnsupportedOperationException("Not supported yet.");
  }
}