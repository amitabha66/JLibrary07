/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.services;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.search.AnalysisResultsSearch;
import amgen.ri.rnai.search.RNAiSearch;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import org.jdom.CDATA;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.transform.JDOMResult;
import org.jdom.transform.JDOMSource;

/**
 *
 * @author jemcdowe
 */
@WebServlet(name = "RNAiService", urlPatterns = {"/rnaiservice.go"})
public class RNAiServiceHandler extends ServletBase {
  public enum Request {
    RNAIBYGENEID,
    EXPBYGENEID,
    EXPBYID,
    RNAI,
    GENEBYEXPID,
    GENEHITSBYEXPID,
    RESULTS,
    AUTO;

    public static Request fromString(String s) {
      try {
        return Request.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return AUTO;
      }
    }
  };

  public RNAiServiceHandler(HttpServletRequest req, HttpServletResponse resp, String responseEncoding) {
    super(req, resp, responseEncoding);
  }

  public RNAiServiceHandler(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  public RNAiServiceHandler() {
    super();
  }

  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new RNAiServiceHandler(req, resp);
  }

  @Override
  protected void performRequest() throws Exception {
    try {
      Request req = Request.fromString(getParameter("req"));
      if (req.equals(Request.AUTO)) {
        if (doesParameterExist("rnai_ids", true)) {
          req = Request.RNAI;
        } else if (doesParameterExist("gene_ids", true)) {
          req = Request.RNAIBYGENEID;
        }
      }
      ExtXMLElement.write(getRNADocument(req, null, new SessionCache(this)), response.getWriter());
    } catch (Exception e) {
      ExtXMLElement.write(new Document(new Element("RNAiData")), response.getWriter());
    }
  }

  @Override
  protected String getServletMimeType() {
    return "text/xml";
  }

  private Document getRNADocument(Request req, String parameter, SessionCache sessionCache) throws Exception {
    List<AbstractRecord> rnaiRecords = new ArrayList<AbstractRecord>();
    Element rnaiMoleculesEl = new Element("RNAiData");
    String geneIDParam = (parameter == null ? getParameter("gene_ids") : parameter);
    String rnaiIDParam = (parameter == null ? getParameter("rnai_ids") : parameter);
    String expIDParam = (parameter == null ? getParameter("experiment_ids") : parameter);

    switch (req) {
      case RNAIBYGENEID:
        if (ExtString.hasLength(geneIDParam)) {
          List<Integer> geneIDs = new ArrayList<Integer>();
          List<String> geneIDList = Arrays.asList(geneIDParam.split("\\D+"));
          for (String geneID : geneIDList) {
            if (ExtString.isAInteger(geneID)) {
              geneIDs.add(ExtString.toInteger(geneID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(null, null, geneIDs, null, null, RNAiSearchOutputType.RNAI, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case EXPBYGENEID:
        if (ExtString.hasLength(geneIDParam)) {
          List<Integer> geneIDs = new ArrayList<Integer>();
          List<String> geneIDList = Arrays.asList(geneIDParam.split("\\D+"));
          for (String geneID : geneIDList) {
            if (ExtString.isAInteger(geneID)) {
              geneIDs.add(ExtString.toInteger(geneID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(null, null, geneIDs, null, null, RNAiSearchOutputType.EXPERIMENTS, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case EXPBYID:
        if (ExtString.hasLength(expIDParam)) {
          List<Integer> expIDs = new ArrayList<Integer>();
          List<String> expIDList = Arrays.asList(expIDParam.split("\\D+"));
          for (String expID : expIDList) {
            if (ExtString.isAInteger(expID)) {
              expIDs.add(ExtString.toInteger(expID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(null, null, null, null, expIDs, RNAiSearchOutputType.EXPERIMENTS, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case GENEBYEXPID:
        if (ExtString.hasLength(expIDParam)) {
          List<Integer> expIDs = new ArrayList<Integer>();
          List<String> expIDList = Arrays.asList(expIDParam.split("\\D+"));
          for (String expID : expIDList) {
            if (ExtString.isAInteger(expID)) {
              expIDs.add(ExtString.toInteger(expID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(null, null, null, null, expIDs, RNAiSearchOutputType.GENES, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case GENEHITSBYEXPID:
        if (ExtString.hasLength(expIDParam)) {
          List<Integer> expIDs = new ArrayList<Integer>();
          List<String> expIDList = Arrays.asList(expIDParam.split("\\D+"));
          for (String expID : expIDList) {
            if (ExtString.isAInteger(expID)) {
              expIDs.add(ExtString.toInteger(expID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(null, null, null, null, expIDs, RNAiSearchOutputType.GENEHITS, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case RNAI:
        if (ExtString.hasLength(rnaiIDParam)) {
          List<Integer> rnaiIDs = new ArrayList<Integer>();
          List<String> rnaiIDList = Arrays.asList(rnaiIDParam.split("\\D+"));
          for (String rnaiID : rnaiIDList) {
            if (ExtString.isAInteger(rnaiID)) {
              rnaiIDs.add(ExtString.toInteger(rnaiID));
            }
          }
          RNAiSearch rnaiSearch = new RNAiSearch(rnaiIDs, null, null, null, null, RNAiSearchOutputType.RNAI, sessionCache, getPersonRecord());
          rnaiRecords.addAll(rnaiSearch.asList());
        }
        break;
      case RESULTS:
        String dataID = UUID.randomUUID().toString();
        int geneID = getParameterNumber("gene_id", -1).intValue();
        int experimentID = getParameterNumber("experiment_id", -1).intValue();
        String inputType = (geneID > -1 ? RNAiSearchInputType.GENE_IDS : RNAiSearchInputType.EXPERIMENT_IDS) + "";

        AnalysisResultsSearch resultSearch = new AnalysisResultsSearch(inputType, RNAiSearchOutputType.RESULTS + "", geneID, -1, experimentID,
                getParameter("analyses"), getParameter("resultTypes"), sessionCache, getPersonRecord());
        JSONObject jResultSearchResponse = resultSearch.getResponse();
        JSONObjectCacheItem jResultSearchCachedResults = new JSONObjectCacheItem(dataID, jResultSearchResponse);
        jResultSearchResponse.put("total", jResultSearchCachedResults.getResultCount());

        sessionCache.put(SessionCache.CacheType.RESULTS, dataID, jResultSearchCachedResults);

        URL hostURL = new URL(request.getScheme(), request.getServerName(), request.getServerPort(), request.getContextPath());
        ExtXMLElement.addTextElement(rnaiMoleculesEl, "Host", hostURL + "");
        ExtXMLElement.addTextElement(rnaiMoleculesEl, "ResultCount", jResultSearchCachedResults.getResultCount() + "");
        ExtXMLElement.addTextElement(rnaiMoleculesEl, "InputType", inputType);
        ExtXMLElement.addTextElement(rnaiMoleculesEl, "DataID", dataID);
        ExtXMLElement.addTextElement(rnaiMoleculesEl, "CacheID", sessionCache.getCacheID());
        ExtXMLElement.addElement(rnaiMoleculesEl, "Analysis").addContent(new CDATA(new JSONArray(resultSearch.getAnalysisTypes()).toString()));
        ExtXMLElement.addElement(rnaiMoleculesEl, "ResultTypes").addContent(new CDATA(new JSONArray(resultSearch.getResultTypes()).toString()));
        if (resultSearch.getExperimentRecord() != null) {
          ExtXMLElement.addElement(rnaiMoleculesEl, "ExperimentRecord").addContent(new CDATA(resultSearch.getExperimentRecord().toString()));
        } else {
          ExtXMLElement.addElement(rnaiMoleculesEl, "ExperimentRecord").addContent(new CDATA(new JSONObject().toString()));

        }

        break;
    }
    for (AbstractRecord record : rnaiRecords) {
      rnaiMoleculesEl.addContent(record.asXML());      
    }
    return new Document(rnaiMoleculesEl);
  }

  public PersonRecordIF getPersonRecord() {
    return super.getPersonRecord();
  }

}
