/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ChartRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.Debug;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.Types;
import java.util.*;
import java.util.logging.Level;
import oracle.jdbc.OracleCallableStatement;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class AvailableChartResponder extends AbstractResponder implements JSONResponderIF, Iterable<JSONObject> {
  private JSONObject jChartResults;

  public AvailableChartResponder(MainUI requestor) {
    super(requestor);
  }

  @Override
  public JSONObject getResponse() {
    if (jChartResults == null) {
      try {
        Set<ChartRecord> chartResults = new HashSet<ChartRecord>(executeQuery());
        jChartResults= createResponseJSON("charts", chartResults);
      } catch (Exception ex) {
        java.util.logging.Logger.getLogger(AvailableChartResponder.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    return jChartResults;
  }

  public List<ChartRecord> executeQuery() throws Exception {
    List<ChartRecord> chartRecords = new ArrayList<ChartRecord>();
    Connection conn = null;
    try {
      conn = getRNAiConnection();
      String sql = "begin ? := RNAIQUERY.getCharts; end;";
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(sql);
      cs.registerOutParameter(1, Types.BLOB);
      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      JSONObject jResults = (JSONObject) fromBlob(resultBlob);
      if (jResults.has("results")) {
        List<JSONObject> jObjs = jResults.getJSONArray("results").asList();
        for (JSONObject jObj : jObjs) {
          chartRecords.add(new ChartRecord(jObj));
        }

      }
    } finally {
      conn.close();
    }
    return chartRecords;
  }

  @Override
  public Iterator<JSONObject> iterator() {
    JSONObject jChartResults = null;
    try {
      jChartResults = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jChartResults != null) {
      try {
        return jChartResults.getJSONArray("charts").asList().iterator();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return new ArrayList<JSONObject>().iterator();
  }
}