/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.CollectionRecord;
import amgen.ri.rnai.records.PlateParentage;
import amgen.ri.rnai.search.AbstractSearch;
import amgen.ri.rnai.search.RNAiSearch;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtString;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.*;
import java.util.logging.Level;
import oracle.jdbc.OracleCallableStatement;
import oracle.sql.ARRAY;
import oracle.sql.ArrayDescriptor;
import org.apache.log4j.Logger;

public class CollectionResponder extends AbstractResponder implements JSONResponderIF {
  private PermissionManager permissionManager;

  enum Action {
    GET_COLLECTION,
    GET_COLLECTION_MEMBERS,
    GET_EXP_COLLECTION_REFERENCE_GENES,
    UPDATE_COLLECTION,
    CREATE_COLLECTION,
    DELETE_COLLECTION,
    PLATE_LINEAGE,
    COLLECTION_COMPARISON,
    ALL_EXP_COLLECTIONS,
    UNKNOWN;

    public static Action fromString(String s) {
      try {
        return Action.valueOf(s.toUpperCase().replaceAll("\\W+", "_"));
      } catch (Exception e) {
      }
      return UNKNOWN;
    }
  };

  public CollectionResponder(MainUI servletBase) {
    super(servletBase);
    permissionManager = new PermissionManager(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    try {
      List collectionRecords;
      int collection_id = this.getParameterNumber("collection_id", -1).intValue();
      int experiment_id = this.getParameterNumber("experiment_id", -1).intValue();
      String collection_name = this.getParameter("collection_name", "").trim();
      String collection_desc = this.getParameter("collection_desc", "").trim();
      String collection_members = this.getParameter("collection_members", "").trim();

      switch (Action.fromString(getParameter("action_id"))) {
        case GET_COLLECTION:
          collectionRecords = new CollectionSearchClass(this).asList();
          return createResponseJSON("collection", new HashSet<CollectionRecord>(collectionRecords));
        case GET_COLLECTION_MEMBERS:
          List<? extends AbstractRecord> collectionMemberRecords = new CollectionSearchClass(this, collection_id).asList();
          return (collectionMemberRecords.size() > 0 ? collectionMemberRecords.get(0) : new JSONObject());
        case GET_EXP_COLLECTION_REFERENCE_GENES:
          List<? extends AbstractRecord> collectionReferenceGenes = new RNAiSearch(experiment_id + "",
                  RNAiSearchInputType.EXPERIMENT_IDS,
                  RNAiSearchOutputType.COLLECTION_REFERENCE_GENES, null, getServletBase().getPersonRecord()).asList();
          return createResponseJSON("genes", new HashSet<AbstractRecord>(collectionReferenceGenes));
        case UPDATE_COLLECTION:
          if (collection_id > 0) {
            return updateCollection(getLogger(), collection_id, collection_name, collection_desc, collection_members);
          }
          break;
        case CREATE_COLLECTION:
          collection_name = this.getParameter("collection_name", "New Collection").trim();
          return createCollection(getLogger(), collection_name, collection_desc);
        case DELETE_COLLECTION:
          return deleteCollection(getLogger(), collection_id);
        case PLATE_LINEAGE:
          return getPlateLineage(getParameters("barcodes"));
        case COLLECTION_COMPARISON:
          return getCollectionComparison(collection_id, getParameters("barcodes", "\\W+"));
        case ALL_EXP_COLLECTIONS:
          collectionRecords = new CollectionSearchClass(this, RNAiSearchInputType.ALL).asList();
          return createResponseJSON("collection", new HashSet<CollectionRecord>(collectionRecords));
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    getLogger().debug(jResponse);
    return jResponse;
  }

  /**
   * Handles Updates to existing Collections- including name, description,
   * members
   *
   * @param logger
   * @param collectionID
   * @param collectionName
   * @param collectionDesc
   * @param members
   * @return
   * @throws Exception
   */
  private JSONObject updateCollection(Logger logger, int collectionID, String collectionName, String collectionDesc, String members) throws Exception {
    permissionManager.checkPermission(PermissionType.PUBLISH, null);
    JSONObject jResponse = new JSONObject();
    Connection conn = null;
    try {
      conn = getRNAiConnection();
      String[] collectionMembers = (ExtString.hasLength(members) ? members.split("[\\s,;]++") : new String[0]);
      String runQuerySQL = "BEGIN ? := COLLECTIONS_UTIL.UPDATECOLLECTION(?, ?, ?, ?); END;";
      ArrayDescriptor descriptor = ArrayDescriptor.createDescriptor("VARCHAR2_T", conn);
      ARRAY oraCollectionMembers = new ARRAY(descriptor, conn, collectionMembers);

      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(runQuerySQL);
      cs.registerOutParameter(1, Types.INTEGER);
      cs.setInt(2, collectionID);
      if (ExtString.hasLength(collectionName)) {
        cs.setString(3, collectionName);
      } else {
        cs.setNull(3, Types.VARCHAR);
      }
      if (ExtString.hasLength(collectionDesc)) {
        cs.setString(4, collectionDesc);
      } else {
        cs.setNull(4, Types.VARCHAR);
      }
      cs.setARRAY(5, oraCollectionMembers);
      cs.execute();
      int updateCount = cs.getInt(1);

      if (updateCount > 0) {
        jResponse.put("message", "Passed");
        jResponse.put("collectionID", collectionID);
      } else {
        jResponse.put("message", "No updates");
      }
      //System.out.println(jResponse);
      logger.debug(jResponse);
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return jResponse;
  }

  /**
   * Creates an empty Collection with the given name/description
   *
   * @param logger
   * @param collectionName
   * @param collectionDesc
   * @return
   * @throws Exception
   */
  private JSONObject createCollection(Logger logger, String collectionName, String collectionDesc) throws Exception {
    permissionManager.checkPermission(PermissionType.PUBLISH, null);
    JSONObject jResponse = new JSONObject();
    Connection conn = null;
    try {
      conn = getRNAiConnection();
      String runQuerySQL = "BEGIN ? := COLLECTIONS_UTIL.CREATECOLLECTION(?, ?, ?); END;";

      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(runQuerySQL);
      cs.registerOutParameter(1, Types.INTEGER);
      cs.setString(2, collectionName);
      if (ExtString.hasLength(collectionDesc)) {
        cs.setString(3, collectionDesc);
      } else {
        cs.setNull(3, Types.VARCHAR);
      }
      cs.setString(4, getServletBase().getFASFIdentity().getUsername());
      cs.execute();
      int collectionID = cs.getInt(1);

      if (collectionID > 0) {
        jResponse.put("message", "Passed");
        jResponse.put("collectionID", collectionID);
      } else {
        jResponse.put("message", "No updates");
      }
      logger.debug(jResponse);
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return jResponse;
  }

  /**
   * Deletes the given collection
   *
   * @param logger
   * @param collectionID
   * @return
   * @throws Exception
   */
  private JSONObject deleteCollection(Logger logger, int collectionID) throws Exception {
    permissionManager.checkPermission(PermissionType.PUBLISH, null);
    JSONObject jResponse = new JSONObject();
    Connection conn = null;
    try {
      conn = getRNAiConnection();
      String runQuerySQL = "BEGIN ? := COLLECTIONS_UTIL.DELETECOLLECTION(?); END;";
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(runQuerySQL);
      cs.registerOutParameter(1, Types.INTEGER);
      cs.setInt(2, collectionID);
      cs.execute();
      int updateCount = cs.getInt(1);

      if (updateCount > 0) {
        jResponse.put("message", "Passed");
        jResponse.put("collectionID", collectionID);
      } else {
        jResponse.put("message", "No updates");
      }
      //System.out.println(jResponse);
      logger.debug(jResponse);
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return jResponse;
  }

  public JSONObject getPlateLineage(List<String> barcodes) throws SQLException, JSONException {
    JSONObject jResponse = new JSONObject();
    String runQuerySQL = "begin ? := RNAIQUERY.runQuery(?, ?, ?); end;";
    Connection conn = null;
    try {
      List<Map<String, String>> query = new ArrayList<Map<String, String>>();
      Map<String, String> value = new HashMap<String, String>();
      query.add(value);
      value.put("barcodes", ExtString.join(barcodes, ','));

      conn = getRNAiConnection();
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(runQuerySQL);
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, RNAiSearchInputType.BARCODES.toString());
      cs.setString(3, RNAiSearchOutputType.PLATELINEAGE.toString());
      cs.setBLOB(4, createBLOB(conn, query));
      cs.execute();
      Blob resultBlob = cs.getBlob(1);
      List<JSONObject> results = optList(fromBlob(resultBlob), "results");
      for (JSONObject result : results) {
        jResponse.append("plates", new PlateParentage(result));
      }
    } finally {
      OraSQLManager.closeResources(conn);
    }
    return jResponse;
  }

  public JSONObject getCollectionComparison(int collectionID, List<String> barcodes) throws JSONException, SQLException {
    Map<String, Set<String>> associations = new HashMap<String, Set<String>>();
    JSONObject jResponse = new JSONObject();
    List<? extends AbstractRecord> collectionMemberRecords = new CollectionSearchClass(this, collectionID).asList();
    if (collectionMemberRecords.isEmpty()) {
      return jResponse;
    }
    CollectionRecord collectionRecord = (CollectionRecord) collectionMemberRecords.get(0);
    Set<String> members = collectionRecord.getMembers();

    List<PlateParentage> plateParentageList = optList(getPlateLineage(barcodes), "plates");
    Map<String, Set<String>> parentBarcodeMap = new HashMap<String, Set<String>>();
    for (PlateParentage plateParentage : plateParentageList) {
      parentBarcodeMap.put(plateParentage.getBarcode(), new HashSet<String>(plateParentage.getParents()));
    }

    for (String barcode : barcodes) {
      Set<String> parentBarcodes = parentBarcodeMap.get(barcode);
      boolean hasParent = false;
      for (String parentBarcode : parentBarcodes) {
        if (members.contains(parentBarcode)) {
          if (!associations.containsKey(parentBarcode)) {
            associations.put(parentBarcode, new HashSet<String>());
          }
          associations.get(parentBarcode).add(barcode);
          hasParent = true;
        }
      }
      if (!hasParent) {
        if (!associations.containsKey("NONE")) {
          associations.put("NONE", new HashSet<String>());
        }
        associations.get("NONE").add(barcode);
      }
    }
    for (String member : members) {
      if (!associations.containsKey(member)) {
        JSONObject jPlate = new JSONObject();
        jPlate.put("barcode", member);
        jPlate.put("flag", false);
        jResponse.append("plates", new PlateParentage(jPlate));
      }
    }

    for (String member : associations.keySet()) {
      if (member.equals("NONE")) {
        for (String barcode : associations.get(member)) {
          JSONObject jPlate = new JSONObject();
          jPlate.put("barcode", "NONE." + barcode);
          jPlate.put("descendants", barcode);
          jPlate.put("flag", false);
          jResponse.append("plates", new PlateParentage(jPlate));
        }
      } else {
        JSONObject jPlate = new JSONObject();
        jPlate.put("barcode", member);
        jPlate.put("descendants", ExtString.join(associations.get(member), ','));
        jPlate.put("flag", true);
        jResponse.append("plates", new PlateParentage(jPlate));
      }
    }
    return jResponse;
  }
}

/**
 * A local version of the AbstractSearch class specific for searching for
 * Collections and Members
 *
 * @author jemcdowe
 */
class CollectionSearchClass extends AbstractSearch {
  List<CollectionRecord> collectionRecords;
  RNAiSearchInputType inputType;
  private int collectionID = -1;

  public CollectionSearchClass(AbstractResponder responder) {
    this(responder, -1);
  }

  public CollectionSearchClass(AbstractResponder responder, int collectionID) {
    super(responder);
    this.collectionID = collectionID;
    inputType = (collectionID > 0 ? RNAiSearchInputType.COLLECTION_IDS : RNAiSearchInputType.ALL);
  }

  public CollectionSearchClass(AbstractResponder responder, RNAiSearchInputType inputType) {
    super(responder);
    this.inputType = inputType;
  }

  @Override
  protected List<Map<String, String>> getQuery() {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value = new HashMap<String, String>();
    query.add(value);
    value.put("collection_id", collectionID + "");
    return query;
  }

  @Override
  public List<? extends AbstractRecord> asList() {
    if (collectionRecords == null) {
      try {
        collectionRecords = new ArrayList<CollectionRecord>();
        JSONObject jResults = executeQuery(inputType, RNAiSearchOutputType.COLLECTIONS, getQuery());
        List<JSONObject> results = new ArrayList<JSONObject>();
        if (jResults.has("results")) {
          results = jResults.getJSONArray("results").asList();
        }
        for (JSONObject result : results) {
          collectionRecords.add(new CollectionRecord(result));
        }
      } catch (Exception ex) {
        java.util.logging.Logger.getLogger(CollectionSearchClass.class.getName()).log(Level.SEVERE, null, ex);
      }
    }
    return collectionRecords;
  }

  @Override
  public int getCount() {
    return asList().size();
  }
}