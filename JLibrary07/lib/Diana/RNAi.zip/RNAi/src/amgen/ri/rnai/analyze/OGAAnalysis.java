/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.sirna.oga.io.input.ExcelInputSource.ColumnType;
import amgen.ri.sys.SystemCommand;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.util.ExtZip;
import java.io.*;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.jcs.access.exception.CacheException;
import org.apache.poi.ss.usermodel.Workbook;

/**
 *
 * @author jemcdowe
 */
public class OGAAnalysis {
  private MainUI requestor;
  private OGAAnalysisDetails analysisDetails;
  private String stdout;
  private String stderr;

  public OGAAnalysis(MainUI requestor) throws IOException {
    this.requestor = requestor;
    File tempDirParent = requestor.getSessionWorkDir();
    File tempDir = new File(tempDirParent, UUID.randomUUID().toString());
    if (!tempDir.exists() && !tempDir.mkdirs()) {
      throw new IOException("Unable to create temp directory " + tempDir);
    }
    analysisDetails = new OGAAnalysisDetails(tempDir);
    try {
      requestor.getSessionCache().put(SessionCache.CacheType.ANALYSIS, analysisDetails.getKey(), analysisDetails);
    } catch (CacheException ex) {
      Logger.getLogger(OGAAnalysis.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  public OGAAnalysisDetails execute(List<ExperimentRecord> experimentRecords) throws IOException, InterruptedException, OGAAnalysisException {
    PermissionManager permissionManager = new PermissionManager(requestor);
    if (!permissionManager.hasPermission(PermissionType.ANALYZE, experimentRecords)) {
      throw new IllegalArgumentException("You do not have sufficient permission to analyze the experiment(s).");
    }

    List<Integer> experimentIDs = toIDList(experimentRecords);
    if (experimentIDs.isEmpty()) {
      throw new IllegalArgumentException("No experiments provided");
    }

    analysisDetails.addOGAProperty("analysis_key", analysisDetails.getKey());
    analysisDetails.addOGAProperty("amgen_login", requestor.getFASFIdentity().getUsername());
    analysisDetails.addOGAProperty("instance", requestor.getInitParameter("RNAI_VERSION"));
    analysisDetails.addOGAProperty("email_notifications", "true");
    analysisDetails.addOGAProperty("save", "true");
    analysisDetails.addOGAProperty("debug_mode", "false");
    analysisDetails.addOGAProperty("input_exp_ids", ExtString.join(experimentIDs, ','));
    if (requestor.doesParameterExist("masked_compound_ids", true)) {
      Set<String> maskedCompoundIDs = new HashSet<String>();
      String[] pMaskedCompoundIDs = requestor.getParameter("masked_compound_ids", "").split("[^0-9#]+");
      for (String pMaskedCompoundID : pMaskedCompoundIDs) {
        if (pMaskedCompoundID.matches("[0-9]+#[0-9]+")) {
          maskedCompoundIDs.add(pMaskedCompoundID);
        }
      }
      if (!maskedCompoundIDs.isEmpty()) {
        analysisDetails.addOGAProperty("masked_compound_ids", ExtString.join(maskedCompoundIDs, ','));
      }
    }

    analysisDetails.addOGAProperty("log_file", analysisDetails.getLog().getAbsolutePath());
    analysisDetails.addOGAProperty("log_to_console", "false");
    for (ExperimentRecord expRecord : experimentRecords) {
      analysisDetails.addOGAProperty("experiment_name." + expRecord.getRecordID(), expRecord.getExperimentName());
      analysisDetails.addExperimentRecord(expRecord);
    }
    analysisDetails.setStartTime(new Date());

    int ret = executeOGAProcess(analysisDetails.getAnalysisProperties());
    if (ret != 0) {
      throw new OGAAnalysisException(stderr);
    }
    analysisDetails.saveObject();

    return analysisDetails;
  }

  public File execute2Excel(List<ExperimentRecord> experimentRecords) throws IOException, InterruptedException, OGAAnalysisException {
    List<Integer> experimentIDs = toIDList(experimentRecords);
    if (experimentIDs.isEmpty()) {
      throw new IllegalArgumentException("No experiments provided");
    }
    File outputDirFile = new File(analysisDetails.getWorkingDir(), "output");

    analysisDetails.addOGAProperty("analysis_key", analysisDetails.getKey());
    analysisDetails.addOGAProperty("amgen_login", requestor.getFASFIdentity().getUsername());
    analysisDetails.addOGAProperty("instance", requestor.getInitParameter("RNAI_VERSION"));
    analysisDetails.addOGAProperty("email_notifications", "false");
    analysisDetails.addOGAProperty("out_file_dir", outputDirFile + "");
    analysisDetails.addOGAProperty("input_exp_ids", ExtString.join(experimentIDs, ','));
    if (requestor.doesParameterExist("masked_compound_ids", true)) {
      Set<String> maskedCompoundIDs = new HashSet<String>();
      String[] pMaskedCompoundIDs = requestor.getParameter("masked_compound_ids", "").split("[^0-9#]+");
      for (String pMaskedCompoundID : pMaskedCompoundIDs) {
        if (pMaskedCompoundID.matches("[0-9]+#[0-9]+")) {
          maskedCompoundIDs.add(pMaskedCompoundID);
        }
      }
      if (!maskedCompoundIDs.isEmpty()) {
        analysisDetails.addOGAProperty("masked_compound_ids", ExtString.join(maskedCompoundIDs, ','));
      }
    }

    analysisDetails.addOGAProperty("log_file", analysisDetails.getLog().getAbsolutePath());
    analysisDetails.addOGAProperty("log_to_console", "false");
    for (ExperimentRecord expRecord : experimentRecords) {
      analysisDetails.addOGAProperty("experiment_name." + expRecord.getRecordID(), expRecord.getExperimentName());
      analysisDetails.addExperimentRecord(expRecord);
    }

    int ret = executeOGAProcess(analysisDetails.getAnalysisProperties());
    if (ret != 0) {
      throw new OGAAnalysisException(stderr);
    }
    return outputDirFile;
  }

  public File execute(Workbook wb, Map<Integer, ColumnType> columnMapping) throws JSONException, IOException, SQLException, InterruptedException, OGAAnalysisException {
    File excelInFile = new File(analysisDetails.getWorkingDir(), "in.xlsx");
    FileOutputStream out = new FileOutputStream(excelInFile);
    wb.write(out);
    out.close();


    File excelFile = new File(analysisDetails.getWorkingDir(), "out");
    Properties ogaProperties = new Properties();
    ogaProperties.put("amgen_login", requestor.getFASFIdentity().getUsername());
    ogaProperties.put("instance", requestor.getInitParameter("RNAI_VERSION"));
    ogaProperties.put("email_notifications", "false");
    ogaProperties.put("out_file_dir", excelFile + "");
    ogaProperties.put("overwrite_excel", "true");
    ogaProperties.put("Excel.File", excelInFile + "");

    for (Integer columnIndex : columnMapping.keySet()) {
      ogaProperties.put("Excel.Column." + columnMapping.get(columnIndex).toString(), columnIndex + "");
    }

    ogaProperties.put("log_file", analysisDetails.getLog().getAbsolutePath());
    ogaProperties.put("log_to_console", "false");

    int ret = executeOGAProcess(ogaProperties);
    if (ret != 0) {
      throw new OGAAnalysisException(stderr);
    }
    return excelFile;
  }

  private int executeOGAProcess(Properties ogaProperties) throws IOException, InterruptedException {
    String ogaExecutable;
    if (ogaProperties.containsKey("log_file")) {
      ogaExecutable = requestor.getInitParameter("OGA_EXECUTABLE");
    } else {
      ogaExecutable = requestor.getInitParameter("OGA_EXECUTABLE_BACKGROUND");
    }
    File ogaPropertiesFile = new File(analysisDetails.getWorkingDir(), "oga.properties");
    FileWriter ogaPropertiesWriter = new FileWriter(ogaPropertiesFile);
    ogaProperties.store(ogaPropertiesWriter, "Auto-generated OGA Properties File");
    ogaPropertiesWriter.close();
    String command = ogaExecutable + " " + ogaPropertiesFile.getAbsolutePath().replaceAll("\\\\", "/");
    SystemCommand sysCommand = new SystemCommand(command);
    int ret = sysCommand.execute();
    stdout = sysCommand.getStdout();
    stderr = sysCommand.getStderr();
    return ret;
  }

  public String getStderr() {
    return stderr;
  }

  public String getStdout() {
    return stdout;
  }

  private List<Integer> toIDList(Collection<? extends AbstractRecord> records) {
    List<Integer> IDs = new ArrayList<Integer>();
    for (AbstractRecord record : records) {
      String id = record.getRecordID();
      if (ExtString.isAInteger(id)) {
        IDs.add(ExtString.toInteger(id));
      }
    }
    return IDs;
  }
}
