/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import static amgen.ri.rnai.jproc.AbstractJProc.close;
import static amgen.ri.rnai.jproc.AbstractJProc.getConnection;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleTypes;
import oracle.sql.CLOB;

/**
 *
 * @author jemcdowe
 */
public class RNAiSearchJProc extends AbstractJProc {
  public static final String GENE_MIX_DELIMITER = "$$";
  private Pattern geneSymbolMixturePattern = Pattern.compile("\\[(\\w+)\\s*,\\s*(\\w+)\\]");

  public RNAiSearchJProc() {
    this.geneSymbolMixturePattern = Pattern.compile("\\[(\\w+)\\s*,\\s*(\\w+)\\]");
  }

  /*
   * Statuc methods exposed through the PL/SQL
   */
  public static Blob runQuery2JSON(String sql, Blob query) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.executeGeneralQuery2JSON(sql, query);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  /*
   * Statuc methods exposed through the PL/SQL
   */
  public static Blob runQuery(String inputType, String outputType, Blob query) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.executeQuery(inputType, outputType, query);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  /*
   * Statuc methods exposed through the PL/SQL
   */
  public static Blob runQuery2Tabs(String inputType, String outputType, Blob query) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.executeQuery2Tabs(inputType, outputType, query);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  /*
   * Statuc methods exposed through the PL/SQL
   */
  public static Blob runNamedQuery2Tabs(String queryName, Blob query) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.executeNamedQuery2Tabs(queryName, query);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  public static Clob getExperimentResults(int experimentID) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.getExpResults(experimentID);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  public static Clob getExperimentResults4Mixtures(int experimentID) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.getExpResults4Mixtures(experimentID);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  public static Clob getExperimentRNAiMixtureComponentDetails(int experimentID) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      return jProc.getExpRNAiMixtureComponentDetails(experimentID);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  public static Blob getExperimentPValueResults(int geneID, String experimentIDs) throws SQLException {
    RNAiSearchJProc jProc = new RNAiSearchJProc();
    try {
      List<Integer> expIDs = new ArrayList<Integer>();
      if (experimentIDs != null && experimentIDs.trim().length() > 0) {
        for (String expID : experimentIDs.split("\\D+")) {
          int expIntID = new Integer(expID);
          if (expIntID > 0) {
            expIDs.add(expIntID);
          }
        }
      }
      return jProc.getExpPValueResults(expIDs, geneID);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      String msg = str.toString();
      if (jProc.getLastSQL() != null) {
        msg = msg + "\nLast SQL: " + jProc.getLastSQL();
      }
      insertErrorLog(t.getMessage() + "\n" + msg);
    }
    return null;
  }

  public static int runAndSaveQuery(String inputType, String outputType, Blob query) throws SQLException {
    try {
      return new RNAiSearchJProc().executeAndSaveQuery(inputType, outputType, query);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      insertErrorLog(t.getMessage() + "\n" + str);
    }
    return -1;
  }

  public static Blob runAnalysisInsert(Blob input) throws SQLException {
    try {
      return new RNAiSearchJProc().executeAnalysisInsert(input);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      insertErrorLog(t.getMessage() + "\n" + str);
    }
    return null;
  }

  public static Blob getCharts() throws SQLException {
    try {
      return new RNAiSearchJProc().getAvailableCharts();
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      insertErrorLog(t.getMessage() + "\n" + str);
    }
    return null;
  }

  /*
   * Methods called from the PL/SQL exposed static methods
   */
  private Blob executeQuery(String inputType, String outputType, Blob query) throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      Blob rResults = executeQuery(conn, inputType, outputType, query);
      return rResults;
    } finally {
      close(conn);
    }
  }

  /*
   * Methods called from the PL/SQL exposed static methods
   */
  private Blob executeGeneralQuery2JSON(String sql, Blob queryTerms) throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      JSONObject jResults;
      if (queryTerms == null) {
        jResults = executeBasicQuery2JSON(conn, sql, null, new JSONObject(), "results");
      } else {
        jResults = executeBasicQuery2JSON(conn, sql, fromBlob(queryTerms), new JSONObject(), "results");
      }
      return createBLOB(conn, jResults);
    } finally {
      close(conn);
    }
  }

  /*
   * Methods called from the PL/SQL exposed static methods
   */
  private Blob executeQuery2Tabs(String inputType, String outputType, Blob query) throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      Blob rResults = executeQuery2Tabs(conn, inputType, outputType, query);
      return rResults;
    } finally {
      close(conn);
    }
  }

  /*
   * Executes a named query using the given query terms returns a Blob
   */
  private Blob executeNamedQuery2Tabs(String queryName, Blob queryTerms) throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      String results = executeBasicNamedQuery2Tabs(conn, queryName, fromBlob(queryTerms), true);
      return createBLOB(conn, results);
    } finally {
      close(conn);
    }
  }

  private Blob getAvailableCharts() throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = getConnection();
      Object response = getAvailableCharts(conn);
      Blob bResults = createBLOB(conn, response);
      return bResults;
    } finally {
      close(conn);
    }
  }

  private Clob getExpResults(int experimentID) throws SQLException {
    Connection conn = null;
    try {
      conn = getConnection();
      return executeBasicQuery2Tabs2(conn, "RAWRESULTSBYEXPID", "experiment_id", experimentID + "", true);
    } finally {
      close(conn);
    }
  }

  private Clob getExpResults4Mixtures(int experimentID) throws SQLException {
    Connection conn = null;
    try {
      conn = getConnection();
      return executeBasicQuery2Tabs2(conn, "RAWRESULTS4MIXTURESBYEXPID", "experiment_id", experimentID + "", true);
    } finally {
      close(conn);
    }
  }

  private Clob getExpRNAiMixtureComponentDetails(int experimentID) throws SQLException {
    Connection conn = null;
    try {
      conn = getConnection();
      return executeBasicQuery2Tabs2(conn, "RNAIMIXTURECOMPONENTDETAILSEXPID", "experiment_id", experimentID + "", true);
    } finally {
      close(conn);
    }
  }

  private Blob getExpPValueResults(List<Integer> experimentIDs, int geneID) throws SQLException {
    Connection conn = null;
    try {
      conn = getConnection();
      StringBuffer results = new StringBuffer();
      if (experimentIDs.isEmpty()) {
        String response = executeBasicNamedQuery2Tabs(conn, "PVALUERESULTSBYGENEID", "gene_id", geneID + "", false);
        if (results.length() > 0) {
          results.append("\n");
        }
        results.append(response);
      } else {
        for (int expID : experimentIDs) {
          List<Map<String, String>> query = new ArrayList<Map<String, String>>();
          Map<String, String> value = new HashMap<String, String>();
          query.add(value);
          value.put("experiment_id", expID + "");
          value.put("gene_id", geneID + "");
          String response = executeBasicNamedQuery2Tabs(conn, "PVALUERESULTSBYGENEIDEXPID", query, false);
          if (results.length() > 0) {
            results.append("\n");
          }
          results.append(response);
        }
      }
      return createBLOB(conn, results);
    } finally {
      close(conn);
    }
  }

  private int executeAndSaveQuery(String inputType, String outputType, Blob query) throws SQLException, JSONException {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      Blob rResults = executeQuery(conn, inputType, outputType, query);

      int id = getNextSeqVal(conn, "QUERY_RESULTS_ID_SEQ");

      OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement("INSERT INTO QUERY_RESULTS(QUERY_RESULTS_ID, RESULTS) VALUES (:id, :results)");
      stmt.setIntAtName("id", id);
      stmt.setBlobAtName("results", rResults);
      stmt.executeUpdate();
      close(stmt);
      return id;
    } finally {
      close(conn);
    }
  }

  private Blob executeAnalysisInsert(Blob input) throws Exception {
    Connection conn = null;
    try {
      conn = DriverManager.getConnection("jdbc:default:connection:");
      JSONObject jUpdateDetails = executeAnalysisInsert(conn, createJSONFromBlob(input));
      return createBLOB(conn, jUpdateDetails);
    } catch (Throwable t) {
      StringWriter str = new StringWriter();
      PrintWriter writer = new PrintWriter(str);
      t.printStackTrace(writer);
      writer.close();
      insertErrorLog(t.getMessage() + "\n" + str);
      if (conn != null) {
        JSONObject jUpdateDetails = new JSONObject();
        jUpdateDetails.put("failed", t.getMessage());
        return createBLOB(conn, jUpdateDetails);
      }
      return null;
    } finally {
      close(conn);
    }
  }

  public JSONObject executeAnalysisInsert(Connection conn, JSONObject jResults) throws Exception {
    JSONObject jUpdateDetails = new JSONObject();
    Map<String, Integer> resultCounts = new HashMap<String, Integer>();
    int analysisID = getNextSeqVal(conn, "RNAI_INDEX.ANALYSIS_ID_SEQ");
    int expID = jResults.getInt("EXPERIMENT_ID");
    String analysisType = jResults.getString("ANALYSIS").toUpperCase();
    String analyzedBy = jResults.getString("ANALYZED_BY").toLowerCase();

    String details = jResults.optString("DETAILS", "");
    OraclePreparedStatement stmt = null;
    try {
      JSONObject analysisTypes = getAnalysisTypes(conn);
      int analysisTypeID = -1;
      if (analysisTypes.has(analysisType)) {
        analysisTypeID = analysisTypes.getJSONObject(analysisType).getInt("analysis_type_id");
      }
      if (analysisTypeID < 0) {
        throw new IllegalArgumentException("Invalid analysis type");
      }
      //Delete Previous Analysis Results for experiment
      stmt = getQueryAsStatement(conn, "DELETEANALYSISRESULTSBYEXPID");
      stmt.setIntAtName("experiment_id", expID);
      stmt.executeUpdate();
      close(stmt);

      //Delete Previous Analysis for experiment
      stmt = getQueryAsStatement(conn, "DELETEANALYSISBYEXPID");
      stmt.setIntAtName("experiment_id", expID);
      stmt.executeUpdate();
      close(stmt);

      stmt = getQueryAsStatement(conn, "INSERTANALYSIS");
      stmt.setIntAtName("analysis_id", analysisID);
      stmt.setIntAtName("experiment_id", expID);
      stmt.setStringAtName("analyzed_by", analyzedBy);
      stmt.setIntAtName("analysis_type_id", analysisTypeID);

      if (details.length() > 0) {
        if (details.length() > 2000) {
          details = details.substring(0, 1999);
        }
        stmt.setStringAtName("details", details);
      } else {
        stmt.setNullAtName("details", OracleTypes.VARCHAR);
      }
      if (stmt.executeUpdate() <= 0) {
        throw new SQLException("Error inserting new analysis");
      }
    } finally {
      close(stmt);
    }
    JSONObject resultTypes = getResultTypes(conn);

    JSONArray jGeneResults = jResults.getJSONArray("GENE_RESULTS");
    try {
      int geneCount = 0;
      stmt = getQueryAsStatement(conn, "INSERTANALYSISRESULT");

      for (int i = 0; i < jGeneResults.length(); i++) {
        JSONObject jGeneResult = jGeneResults.optJSONObject(i);
        int geneID = jGeneResult.getInt("GENE_ID");
        if (geneID > 0) {
          geneCount++;
          Map<String, Object> results = jGeneResult.asMap();
          for (String resultType : results.keySet()) {
            if (resultTypes.has(resultType)) {
              int resultTypeID = resultTypes.getJSONObject(resultType).getInt("result_type_id");
              Object result = results.get(resultType);
              if (result != null && result instanceof Number) {
                int insertCount;
                double resultValue = ((Number) result).doubleValue();
                stmt.setIntAtName("analysis_id", analysisID);
                stmt.setIntAtName("gene_id", geneID);
                stmt.setIntAtName("result_type_id", resultTypeID);
                stmt.setDoubleAtName("result_value", resultValue);
                insertCount = stmt.executeUpdate();
                if (!resultCounts.containsKey(resultType)) {
                  resultCounts.put(resultType, 0);
                }
                resultCounts.put(resultType, resultCounts.get(resultType) + insertCount);
              }
            }
          }
        }
      }
      jUpdateDetails.put("analysis_id", analysisID);
      jUpdateDetails.put("experiment_id", expID);
      int total = 0;
      for (String resultType : resultCounts.keySet()) {
        int resultCount = resultCounts.get(resultType);
        total += resultCount;
        jUpdateDetails.put(resultType, resultCount);
      }
      jUpdateDetails.put("total genes", geneCount);
      jUpdateDetails.put("total results", total);

    } finally {
      close(stmt);
    }
    return jUpdateDetails;
  }

  public Blob executeQuery(Connection conn, String inputType, String outputType, Blob query) throws SQLException, JSONException {
    Object response = new JSONObject();
    RNAiSearchInputType in = RNAiSearchInputType.fromString(inputType);
    RNAiSearchOutputType out = RNAiSearchOutputType.fromString(outputType);

    if (!out.equals(RNAiSearchOutputType.UNKNOWN)) {
      switch (out) {
        case GENES:
          response = getGenes(conn, in, fromBlob(query));
          break;
        case GENE_MIXTURES:
          response = getGeneMixtures(conn, in, fromBlob(query));
          break;
        case COLLECTION_REFERENCE_GENES:
          response = getCollectionReferenceGenes(conn, in, fromBlob(query));
          break;
        case GENEHITS:
          response = getGeneHits(conn, in, fromBlob(query));
          break;
        case RNAI:
          response = getRNAi(conn, in, fromBlob(query));
          break;
        case RNAI_DETAILS:
          response = getRNAiDetails(conn, in, fromBlob(query));
          break;
        case PLATES:
          response = getPlates(conn, in, fromBlob(query));
          break;
        case PLATEMAP:
          response = getPlateMap(conn, in, fromBlob(query));
          break;
        case PLATELINEAGE:
          response = getPlateLineage(conn, in, fromBlob(query));
          break;
        case EXPERIMENTS:
          response = getExperiments(conn, in, fromBlob(query));
          break;
        case RESULTS:
          response = getResults(conn, in, fromBlob(query), new JSONObject());
          break;
        case RAWRESULTS:
          response = getRawResults(conn, in, fromBlob(query), new JSONObject());
          break;
        case POCGENE:
          response = getPOCGeneResults(conn, in, fromBlob(query));
          break;
        case RESULT_TYPES:
          response = getResultTypes(conn);
          break;
        case ANALYSIS_TYPES:
          response = getAnalysisTypes(conn);
          break;
        case COLLECTIONS:
          response = getCollections(conn, in, fromBlob(query));
          break;
        case ANNOTATIONS:
          response = getAnnotations(conn, in, fromBlob(query));
          break;
        case CELLLINE_ANNOTATIONS:
          response = getCellLines(conn);
          break;
      }
    }
    Blob bResults = createBLOB(conn, response);
    return bResults;
  }

  public Blob executeQuery2Tabs(Connection conn, String inputType, String outputType, Blob query) throws SQLException, JSONException {
    Object response = new JSONObject();
    RNAiSearchInputType in = RNAiSearchInputType.fromString(inputType);
    RNAiSearchOutputType out = RNAiSearchOutputType.fromString(outputType);

    if (!out.equals(RNAiSearchOutputType.UNKNOWN)) {
      switch (out) {
        case GENES:
          //response = getGenes(conn, in, fromBlob(query));
          break;
        case COLLECTION_REFERENCE_GENES:
          //response = getCollectionReferenceGenes(conn, in, fromBlob(query));
          break;
        case GENEHITS:
          //response = getGeneHits(conn, in, fromBlob(query));
          break;
        case RNAI:
          response = getRNAi2Tabs(conn, in, fromBlob(query));
          break;
        case RNAI_DETAILS:
          //response = getRNAiDetails(conn, in, fromBlob(query));
          break;
        case PLATES:
          //response = getPlates(conn, in, fromBlob(query));
          break;
        case PLATEMAP:
          //response = getPlateMap(conn, in, fromBlob(query));
          break;
        case PLATELINEAGE:
          //response = getPlateLineage(conn, in, fromBlob(query));
          break;
        case EXPERIMENTS:
          //response = getExperiments(conn, in, fromBlob(query));
          break;
        case RESULTS:
          //response = getResults(conn, in, fromBlob(query), new JSONObject());
          break;
        case RAWRESULTS:
          //response = getRawResults(conn, in, fromBlob(query), new JSONObject());
          break;
        case POCGENE:
          //response = getPOCGeneResults(conn, in, fromBlob(query));
          break;
        case RESULT_TYPES:
          //response = getResultTypes(conn);
          break;
        case ANALYSIS_TYPES:
          //response = getAnalysisTypes(conn);
          break;
        case COLLECTIONS:
          //response = getCollections(conn, in, fromBlob(query));
          break;
        case ANNOTATIONS:
          //response = getAnnotations(conn, in, fromBlob(query));
          break;
        case CELLLINE_ANNOTATIONS:
          //response = getCellLines(conn);
          break;
      }
    }
    Blob bResults = createBLOB(conn, response);
    return bResults;
  }

  private JSONObject getGenes(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case GENE_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYID", query, new JSONObject(), "results");
      case RNAI_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYRNAIID", query, new JSONObject(), "results");
      case GENE_SYMBOLS:
        List<Map<String, String>> geneSymbolMixtureQuery = new ArrayList<Map<String, String>>();
        List<Map<String, String>> geneSymbolQuery = new ArrayList<Map<String, String>>();
        for (Map<String, String> q : query) {
          if (q.containsKey("gene_symbol") && geneSymbolMixturePattern.matcher(q.get("gene_symbol")).matches()) {
            geneSymbolMixtureQuery.add(q);
          } else {
            geneSymbolQuery.add(q);
          }
        }
        JSONObject jResults = getGeneMixtures(conn, RNAiSearchInputType.GENE_SYMBOLS, geneSymbolMixtureQuery);
        return executeBasicNamedQuery2JSON(conn, "GENEBYSYM", geneSymbolQuery, jResults, "results");
      case ENTREZGENE_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYEG", query, new JSONObject(), "results");
      case BARCODES:
        return executeBasicNamedQuery2JSON(conn, "GENEBYBARCODE", query, new JSONObject(), "results");
      case COMPOUND_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYROOTLOT", query, new JSONObject(), "results");
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYEXPID", query, new JSONObject(), "results");
      case COLLECTION_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEBYCOLLECTIONID", query, new JSONObject(), "results");
      case SEQUENCES:
        return executeBasicNamedQuery2JSON(conn, "GENEBYSEQUENCE", query, new JSONObject(), "results");
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  private JSONObject getGeneMixtures(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    JSONObject jResults = new JSONObject();
    switch (inputType) {
      case GENE_MIXTURE_IDS:
        executeBasicNamedQuery2JSON(conn, "GENEMIXTUREBYID", query, jResults, "results");
        break;
      case GENE_IDS:
        executeBasicNamedQuery2JSON(conn, "GENEMIXTUREBYGENEIDS", query, jResults, "results");
        break;
      case GENE_SYMBOLS:
        for (Map<String, String> q : query) {
          if (q.containsKey("gene_symbol")) {
            String geneSymbol = q.get("gene_symbol");
            Matcher geneSymbolMatcher = geneSymbolMixturePattern.matcher(geneSymbol);
            if (geneSymbolMatcher.matches()) {
              String geneSymbol1 = geneSymbolMatcher.group(1);
              String geneSymbol2 = geneSymbolMatcher.group(2);

              JSONObject jResults1 = executeBasicNamedQuery2JSON(conn, "GENEBYSYM", "gene_symbol", geneSymbol1, new JSONObject(), "results");
              JSONObject jResults2 = executeBasicNamedQuery2JSON(conn, "GENEBYSYM", "gene_symbol", geneSymbol2, new JSONObject(), "results");
              if (jResults1.has("results") && jResults2.has("results")) {
                List<JSONObject> geneResults1 = getResultsAsList(jResults1);
                List<JSONObject> geneResults2 = getResultsAsList(jResults2);
                for (JSONObject jGeneResult1 : geneResults1) {
                  int geneID1 = jGeneResult1.getInt("gene_id");
                  for (JSONObject jGeneResult2 : geneResults2) {
                    int geneID2 = jGeneResult2.getInt("gene_id");
                    if (geneID1 != geneID2) {
                      List<Map<String, String>> subQuery = new ArrayList<Map<String, String>>();
                      Map<String, String> subQueryFields = new HashMap<String, String>();
                      subQuery.add(subQueryFields);
                      subQueryFields.put("gene_id1", geneID1 + "");
                      subQueryFields.put("gene_id2", geneID2 + "");
                      JSONObject jSubQueryResults = getGeneMixtures(conn, RNAiSearchInputType.GENE_IDS, subQuery);
                      if (jSubQueryResults.has("results")) {
                        List<JSONObject> subQueryResults = getResultsAsList(jSubQueryResults);
                        for (JSONObject jSubQueryResult : subQueryResults) {
                          jSubQueryResult.put("is_mixture", true);
                          jResults.append("results", jSubQueryResult);
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        break;
      case RNAI_IDS:
      case ENTREZGENE_IDS:
      case BARCODES:
      case COMPOUND_IDS:
      case EXPERIMENT_IDS:
      case COLLECTION_IDS:
      case SEQUENCES:
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
    List<JSONObject> results = getResultsAsList(jResults);
    for (JSONObject jResult : results) {
      for (String key : (List<String>) jResult.names().asList()) {
        String pluralKey = (key.endsWith("s") ? key + "es" : key + "s");
        String value = jResult.getString(key);
        if (!jResult.has(pluralKey) && value.indexOf(GENE_MIX_DELIMITER) > 0) {
          String[] splitValues = value.split("\\$\\$");
          if (splitValues.length >= 2) {
            for (String splitValue : splitValues) {
              jResult.append(pluralKey, splitValue);
            }
          }
        }
      }
    }

    return jResults;
  }

  private JSONObject getCollectionReferenceGenes(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2JSON(conn, "REFGENESBYEXPID", query, new JSONObject(), "results");
      case COLLECTION_IDS:
        return executeBasicNamedQuery2JSON(conn, "REFGENESBYCOLLECTIONID", query, new JSONObject(), "results");
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  public JSONObject getGeneHits(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2JSON(conn, "GENEHITBYEXPID", query, new JSONObject(), "results");
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  private JSONObject getRNAi(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    JSONObject jResults = null;
    List<Map<String, String>> geneMixtureRNAiIDQuery;
    List<JSONObject> geneMixtureIDResults;

    switch (inputType) {
      case RNAI_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYRNAIID", query, new JSONObject(), "results");
        break;
      case GENE_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYGENEID", query, new JSONObject(), "results");
        break;
      case GENE_MIXTURE_IDS:
        geneMixtureRNAiIDQuery = new ArrayList<Map<String, String>>();
        geneMixtureIDResults = getResultsAsList(executeBasicNamedQuery2JSON(conn, "RNAIIDBYGENEMIXTUREID", query, new JSONObject(), "results"));
        for (JSONObject jGeneMixtureIDResult : geneMixtureIDResults) {
          Map<String, String> rnaiID = new HashMap<String, String>();
          geneMixtureRNAiIDQuery.add(rnaiID);
          rnaiID.put("rnai_id", jGeneMixtureIDResult.getString("rnai_id"));
        }
        if (!geneMixtureRNAiIDQuery.isEmpty()) {
          jResults = getRNAi(conn, RNAiSearchInputType.RNAI_IDS, geneMixtureRNAiIDQuery);
        }
        break;
      case GENE_SYMBOLS:
        jResults = new JSONObject();
        List<Map<String, String>> geneSymbolMixtureQuery = new ArrayList<Map<String, String>>();
        List<Map<String, String>> geneMixtureIDQuery = new ArrayList<Map<String, String>>();
        geneMixtureRNAiIDQuery = new ArrayList<Map<String, String>>();
        List<Map<String, String>> geneSymbolQuery = new ArrayList<Map<String, String>>();
        for (Map<String, String> q : query) {
          if (q.containsKey("gene_symbol") && geneSymbolMixturePattern.matcher(q.get("gene_symbol")).matches()) {
            geneSymbolMixtureQuery.add(q);
          } else {
            geneSymbolQuery.add(q);
          }
        }
        List<JSONObject> geneMixturesResults = getResultsAsList(getGeneMixtures(conn, RNAiSearchInputType.GENE_SYMBOLS, geneSymbolMixtureQuery));
        for (JSONObject geneMixturesResult : geneMixturesResults) {
          Map<String, String> geneMixtureID = new HashMap<String, String>();
          geneMixtureIDQuery.add(geneMixtureID);
          geneMixtureID.put("gene_mixture_id", geneMixturesResult.getString("gene_mixture_id"));
        }
        if (!geneMixtureIDQuery.isEmpty()) {
          geneMixtureIDResults = getResultsAsList(executeBasicNamedQuery2JSON(conn, "RNAIIDBYGENEMIXTUREID", geneMixtureIDQuery, new JSONObject(), "results"));
          for (JSONObject jGeneMixtureIDResult : geneMixtureIDResults) {
            Map<String, String> rnaiID = new HashMap<String, String>();
            geneMixtureRNAiIDQuery.add(rnaiID);
            rnaiID.put("rnai_id", jGeneMixtureIDResult.getString("rnai_id"));
          }
          if (!geneMixtureRNAiIDQuery.isEmpty()) {
            jResults = getRNAi(conn, RNAiSearchInputType.RNAI_IDS, geneMixtureRNAiIDQuery);
          }
        }
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYGENESYM", geneSymbolQuery, jResults, "results");
        break;
      case ENTREZGENE_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYEG", query, new JSONObject(), "results");
        break;
      case BARCODES:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYBARCODE", query, new JSONObject(), "results");
        break;
      case COMPOUND_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYROOTLOT", query, new JSONObject(), "results");
        break;
      case EXPERIMENT_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYEXPID", query, new JSONObject(), "results");
        break;
      case COLLECTION_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYCOLLECTIONID", query, new JSONObject(), "results");
        break;
      case SEQUENCES:
        jResults = executeBasicNamedQuery2JSON(conn, "RNAIBYSEQUENCE", query, new JSONObject(), "results");
        break;
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }

    if (jResults != null && jResults.has("results")) {
      List<JSONObject> jRNAIs = jResults.getJSONArray("results").asList();
      addComponentRNAi(conn, jRNAIs, false);
    }
    return jResults;
  }

  private void addComponentRNAi(Connection conn, List<JSONObject> jRNAIs, boolean addDetails) throws JSONException, SQLException {
    for (JSONObject jRNAi : jRNAIs) {
      addComponentRNAi(conn, jRNAi, addDetails);
    }
  }

  private List<JSONObject> addComponentRNAi(Connection conn, JSONObject jRNAi, boolean addDetails) throws JSONException, SQLException {
    if (jRNAi.optBoolean("is_mixture", false)) {
      JSONObject jComponentResults = executeBasicNamedQuery2JSON(conn, "RNAIMIXTURECOMPONENTSBYRNAIID", "rnai_id", jRNAi.getInt("rnai_id"), new JSONObject(), "results");
      if (jComponentResults != null && jComponentResults.has("results")) {
        List<JSONObject> jComponents = jComponentResults.getJSONArray("results").asList();
        if (addDetails) {
          for (JSONObject jComponent : jComponents) {
            JSONObject jResults = executeBasicNamedQuery2JSON(conn, "RNAIDETAILSBYRNAIID", "rnai_id", jComponent.getInt("rnai_id"), new JSONObject(), "results");
            if (jResults.has("results")) {
              List<JSONObject> jRNAiResults = jResults.getJSONArray("results").asList();
              if (!jRNAiResults.isEmpty()) {
                jRNAi.append("components", jRNAiResults.get(0));
              }
            }
          }
        } else {
          jRNAi.put("components", jComponents);
        }
        return jRNAi.getJSONArray("components").asList();
      }
    }
    return new ArrayList<JSONObject>();
  }

  private String getRNAi2Tabs(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case RNAI_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYRNAIID", query, true);
      case GENE_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYGENEID", query, true);
      case GENE_SYMBOLS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYGENESYM", query, true);
      case ENTREZGENE_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYEG", query, true);
      case BARCODES:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYBARCODE", query, true);
      case COMPOUND_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYROOTLOT", query, true);
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYEXPID", query, true);
      case COLLECTION_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYCOLLECTIONID", query, true);
      case SEQUENCES:
        return executeBasicNamedQuery2Tabs(conn, "RNAIBYSEQUENCE", query, true);
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  private JSONObject getRNAiDetails(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case RNAI_IDS:
        JSONObject jResults = executeBasicNamedQuery2JSON(conn, "RNAIDETAILSBYRNAIID", query, new JSONObject(), "results");
        if (jResults.has("results")) {
          List<JSONObject> jRNAiResults = jResults.getJSONArray("results").asList();
          for (JSONObject jRNAiResult : jRNAiResults) {
            jRNAiResult.put("secondary_gene_targets", new JSONArray());
            executeBasicNamedQuery2JSON(conn, "SECONDARYGENESBYRNAIID", "rnai_id", jRNAiResult.getString("rnai_id"), jRNAiResult, "secondary_gene_targets");
            List<JSONObject> componentRNAIs = addComponentRNAi(conn, jRNAiResult, true);
            for (JSONObject jComponentRNAI : componentRNAIs) {
              jComponentRNAI.put("secondary_gene_targets", new JSONArray());
              executeBasicNamedQuery2JSON(conn, "SECONDARYGENESBYRNAIID", "rnai_id", jComponentRNAI.getString("rnai_id"), jComponentRNAI, "secondary_gene_targets");
            }
          }
        }
        //SECONDARYGENESBYRNAIID
        return jResults;
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  private JSONObject getPlates(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    if (inputType.equals(RNAiSearchInputType.BARCODES)) {
      for (Map<String, String> q : query) {
        String barcode = q.get("barcode");
        q.remove("barcode");
        String barcodes = q.get("barcodes");
        Set<String> barcodeSet = new LinkedHashSet<String>();
        if (barcode != null) {
          barcodeSet.add(barcode);
        }
        if (barcodes != null) {
          barcodeSet.addAll(Arrays.asList(barcodes.split(",")));
        }
        q.put("barcodes", encloseAndJoin(barcodeSet, ","));
      }
      return executeInClauseNamedQuery(conn, "PLATEBYBARCODE", query, "barcodes", new JSONObject(), "results");
    }
    JSONObject jResults = null;

    switch (inputType) {
      case RNAI_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYRNAIID", query, new JSONObject(), "results");
        break;
      case GENE_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYGENEID", query, new JSONObject(), "results");
        break;
      case ENTREZGENE_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYEG", query, new JSONObject(), "results");
        break;
      case GENE_SYMBOLS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYGENESYM", query, new JSONObject(), "results");
        break;
      case COMPOUND_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYROOTLOT", query, new JSONObject(), "results");
        break;
      case EXPERIMENT_IDS:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYEXPID", query, new JSONObject(), "results");
        break;
      case SEQUENCES:
        jResults = executeBasicNamedQuery2JSON(conn, "BARCODESBYSEQUENCE", query, new JSONObject(), "results");
        break;
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
    Set<String> barcodes = new HashSet<String>();
    if (jResults.has("results")) {
      List<JSONObject> jBarcodes = jResults.getJSONArray("results").asList();
      for (JSONObject jBarcode : jBarcodes) {
        barcodes.add(jBarcode.getString("barcode"));
      }
    }
    List<Map<String, String>> barcodeQuery = new ArrayList<Map<String, String>>();
    Map<String, String> value = new HashMap<String, String>();
    barcodeQuery.add(value);
    value.put("barcodes", join(barcodes, ","));
    return getPlates(conn, RNAiSearchInputType.BARCODES, barcodeQuery);
  }

  private JSONObject getPlateMap(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    if (!inputType.equals(RNAiSearchInputType.BARCODES)) {
      throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
    JSONObject jPlateMapResults = new JSONObject();
    JSONObject jWellResults = executeBasicNamedQuery2JSON(conn, "PLATEMAPBYBARCODE", query, new JSONObject(), "results");
    JSONObject jPlates = getPlates(conn, RNAiSearchInputType.BARCODES, query);

    if (jPlates.has("results") && jWellResults.has("results")) {
      List<JSONObject> jWellList = jWellResults.getJSONArray("results").asList();
      List<JSONObject> jPlateList = jPlates.getJSONArray("results").asList();
      for (JSONObject jPlate : jPlateList) {
        String barcode = jPlate.getString("barcode");
        jPlateMapResults.append("results", jPlate);
        for (JSONObject jWell : jWellList) {
          String wellBarcode = jWell.optString("barcode", "-");
          if (barcode.equals(wellBarcode)) {
            jWell.remove("barcode");
            jPlate.append("wells", jWell);
          }
        }
      }
    }
    return jPlateMapResults;
  }

  private JSONObject getPlateLineage(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case BARCODES:
        for (Map<String, String> q : query) {
          String barcodes = q.get("barcodes");
          if (barcodes != null) {
            StringBuffer barcodeTerm = new StringBuffer();
            String[] fields = barcodes.split(",");
            for (String field : fields) {
              if (barcodeTerm.length() > 0) {
                barcodeTerm.append(",");
              }
              barcodeTerm.append("'" + field.trim() + "'");
            }
            q.put("barcodes", barcodeTerm.toString());
          }
        }
        //Create 2 Maps which hold the parent and child barcodes for each barcode
        Map<String, Set<String>> parentMap;
        Map<String, Set<String>> childrenMap;

        //Accumulate the parent barcodes
        parentMap = new HashMap<String, Set<String>>();
        List<JSONObject> parentResults = optList(executeInClauseNamedQuery(conn, "PLATEPARENTSBYBARCODES", query, "barcodes", new JSONObject(), "results"), "results");
        for (JSONObject jParent : parentResults) {
          String barcode = jParent.getString("barcode");
          String parentBarcode = jParent.getString("parent_barcode");
          if (!parentMap.containsKey(barcode)) {
            parentMap.put(barcode, new HashSet<String>());
          }
          parentMap.get(barcode).add(parentBarcode);
        }

        //Accumulate the parent barcodes
        childrenMap = new HashMap<String, Set<String>>();
        List<JSONObject> childResults = optList(executeInClauseNamedQuery(conn, "PLATECHILDRENBYBARCODES", query, "barcodes", new JSONObject(), "results"), "results");
        for (JSONObject jChild : childResults) {
          String barcode = jChild.getString("barcode");
          String childBarcode = jChild.getString("child_barcode");
          if (!childrenMap.containsKey(barcode)) {
            childrenMap.put(barcode, new HashSet<String>());
          }
          childrenMap.get(barcode).add(childBarcode);
        }

        //Combine the barcodes into a single Set
        Set<String> resultBarcodes = new HashSet<String>(parentMap.keySet());
        resultBarcodes.addAll(childrenMap.keySet());

        //Build the final JSONObject result from the Set and 2 Maps
        JSONObject jResults = new JSONObject();
        for (String barcode : resultBarcodes) {
          JSONObject jBarcodeResults = new JSONObject();
          jResults.append("results", jBarcodeResults);
          jBarcodeResults.put("barcode", barcode);
          if (parentMap.containsKey(barcode)) {
            jBarcodeResults.put("parents", parentMap.get(barcode));
          }
          if (childrenMap.containsKey(barcode)) {
            jBarcodeResults.put("descendants", childrenMap.get(barcode));
          }
        }
        return jResults;
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  public JSONObject getExperiments(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException, JSONException {
    switch (inputType) {
      case ALL:
        return executeBasicNoVariableNamedQuery2JSON(conn, "EXPALL", new JSONObject(), "results");
      case RNAI_IDS:
        return executeBasicNamedQuery2JSON(conn, "EXPBYRNAIID", query, new JSONObject(), "results");
      case GENE_IDS:
        JSONObject jExpFromGeneIDResults = executeBasicNamedQuery2JSON(conn, "EXPBYGENEID", query, new JSONObject(), "results");
        if (query.size() == 1) {
          try {
            String geneID = query.get(0).get("gene_id");
            addGeneResults(conn, jExpFromGeneIDResults.getJSONArray("results"), new Integer(geneID), jExpFromGeneIDResults);
          } catch (Exception e) {
          }
        }
        return jExpFromGeneIDResults;
      case GENE_SYMBOLS:
        JSONObject jExpFromGeneSymResults = executeBasicNamedQuery2JSON(conn, "EXPBYGENESYM", query, new JSONObject(), "results");
        if (query.size() == 1) {
          try {
            List<JSONObject> genes = getResultsAsList(getGenes(conn, RNAiSearchInputType.GENE_SYMBOLS, query));
            if (genes.size() == 1) {
              JSONObject jGene = genes.get(0);
              if (!jGene.has("is_mixture") || !jGene.getBoolean("is_mixture")) {
                int geneID = jGene.getInt("gene_id");
                addGeneResults(conn, jExpFromGeneSymResults.getJSONArray("results"), geneID, jExpFromGeneSymResults);
              }
            }
          } catch (Exception e) {
            e.printStackTrace();
          }
        }
        return jExpFromGeneSymResults;
      case ENTREZGENE_IDS:
        return executeBasicNamedQuery2JSON(conn, "EXPBYEG", query, new JSONObject(), "results");
      case BARCODES:
        return executeBasicNamedQuery2JSON(conn, "EXPBYBARCODE", query, new JSONObject(), "results");
      case COMPOUND_IDS:
        return executeBasicNamedQuery2JSON(conn, "EXPBYROOTLOT", query, new JSONObject(), "results");
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2JSON(conn, "EXPBYEXPID", query, new JSONObject(), "results");
      case AMGEN_LOGIN:
        return executeBasicNamedQuery2JSON(conn, "EXPBYUPLOADPERSON", query, new JSONObject(), "results");
      case COLLECTION_IDS:
        return executeBasicNamedQuery2JSON(conn, "EXPBYCOLLECTIONID", query, new JSONObject(), "results");
      case CELLLINE_RTF_TERMID:
        return executeBasicNamedQuery2JSON(conn, "EXPBYCELLLINETERMID", query, new JSONObject(), "results");
      case TISSUE_RTF_TERMID:
        return executeBasicNamedQuery2JSON(conn, "EXPBYTISSUETERMID", query, new JSONObject(), "results");
      case SEQUENCES:
        return executeBasicNamedQuery2JSON(conn, "EXPBYSEQUENCE", query, new JSONObject(), "results");
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  public JSONObject addGeneResults(Connection conn, JSONArray jExpResults, int geneID, JSONObject jResults) throws SQLException, JSONException {
    JSONObject resultTypes = getResultTypes(conn);
    JSONObject analysisTypes = getAnalysisTypes(conn);

    String analysisID = analysisTypes.getJSONObject("OGA METHOD V2").getString("analysis_type_id");
    String resultTypeID = resultTypes.getJSONObject("CORRECTED_PVALUE").getString("result_type_id");

    JSONObject analysis = new JSONObject();
    jResults.put("analysis", analysisTypes.getJSONObject("OGA METHOD V2"));
    analysis.put("name", "OGA METHOD V2");
    jResults.append("result_types", resultTypes.getJSONObject("CORRECTED_PVALUE"));

    for (int i = 0; i < jExpResults.length(); i++) {
      JSONObject jExpResult = jExpResults.getJSONObject(i);
      int expID = jExpResult.getInt("experiment_id");
      if (geneID > 1) {
        JSONObject jGeneExpResults = getExpResultsForGeneID(conn, expID, geneID, resultTypeID, analysisID, null);
        if (jGeneExpResults.has("results")) {
          jExpResult.put("analysis_results", jGeneExpResults.getJSONArray("results"));
        }
      }
    }
    return jResults;
  }

  public JSONObject getExpResultsForGeneID(Connection conn, int experimentID, int geneID, String resultTypeIDs, String analysisTypeID, JSONObject jResults) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    Map<Integer, JSONObject> resultTypesMap = getResultTypesMap(conn);
    Map<Integer, JSONObject> analysisTypesMap = getAnalysisTypesMap(conn);

    Map<String, String> pivotTermsColumnName2FieldNameMap = new HashMap<String, String>();
    StringBuffer pivotTerm = new StringBuffer();
    int qAnalysisTypeID = new Integer(analysisTypeID);
    JSONObject qAnalysisType = analysisTypesMap.get(qAnalysisTypeID);
    if (qAnalysisType != null) {
      for (String qResultTypeFieldID : Arrays.asList(resultTypeIDs.split(","))) {
        int qResultTypeID = new Integer(qResultTypeFieldID);
        JSONObject qResultType = resultTypesMap.get(qResultTypeID);
        if (qResultType != null) {
          if (pivotTerm.length() > 0) {
            pivotTerm.append(',');
          }
          String pivotTermColumnName = "C" + pivotTermsColumnName2FieldNameMap.size();
          String pivotTermFieldName = qAnalysisType.getString("analysis_type") + ":" + qResultType.getString("result_type");
          String pivotElement = qResultTypeID + " AS \"" + pivotTermColumnName + "\" ";
          pivotTermsColumnName2FieldNameMap.put(pivotTermColumnName, pivotTermFieldName);
          pivotTerm.append(pivotElement);
        }
      }
    }
    List<Map<String, String>> resultsQuery = new ArrayList<Map<String, String>>();
    Map<String, String> queryTerm = new HashMap<String, String>();
    resultsQuery.add(queryTerm);
    queryTerm.put("analysis_type_id", qAnalysisTypeID + "");
    queryTerm.put("gene_id", geneID + "");
    queryTerm.put("experiment_id", experimentID + "");
    executeNamedQueryWithPivotTerm(conn, "RESULTSFOREXPBYGENEIDPIVOT", resultsQuery, pivotTerm.toString(), pivotTermsColumnName2FieldNameMap, null, jResults, "results");

    return jResults;
  }

  public JSONObject getResults(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query, JSONObject jResults) throws SQLException, JSONException {
    //SplitTimer t = new SplitTimer();

    //StringBuilder timer = new StringBuilder();
    //timer.append(t.toString()+"\n");
    if (jResults == null) {
      jResults = new JSONObject();
    }
    Map<Integer, JSONObject> resultTypesMap = getResultTypesMap(conn);
    Map<Integer, JSONObject> analysisTypesMap = getAnalysisTypesMap(conn);

    switch (inputType) {
      case GENE_IDS:
        for (Map<String, String> queryTerms : query) {
          Map<String, String> pivotTermsColumnName2FieldNameMap = new HashMap<String, String>();
          String pivotColumnNameSort = null;
          StringBuffer pivotTerm = new StringBuffer();
          int qAnalysisTypeID = new Integer(queryTerms.get("analysis_type_id"));
          JSONObject qAnalysisType = analysisTypesMap.get(qAnalysisTypeID);
          if (qAnalysisType != null) {
            for (String qResultTypeFieldID : Arrays.asList(queryTerms.get("result_type_ids").split(","))) {
              int qResultTypeID = new Integer(qResultTypeFieldID);
              JSONObject qResultType = resultTypesMap.get(qResultTypeID);
              if (qResultType != null) {
                if (pivotTerm.length() > 0) {
                  pivotTerm.append(',');
                }
                int isPrimarySort = qResultType.optInt("primary_sort", 0);
                String pivotTermColumnName = "C" + pivotTermsColumnName2FieldNameMap.size();
                String pivotTermFieldName = qAnalysisType.getString("analysis_type") + ":" + qResultType.getString("result_type");
                String pivotElement = qResultTypeID + " AS \"" + pivotTermColumnName + "\" ";
                pivotTermsColumnName2FieldNameMap.put(pivotTermColumnName, pivotTermFieldName);
                if (isPrimarySort == 1) {
                  pivotColumnNameSort = pivotTermColumnName;
                }
                pivotTerm.append(pivotElement);
              }
            }
          }
          List<Map<String, String>> resultsQuery = new ArrayList<Map<String, String>>();
          Map<String, String> queryTerm = new HashMap<String, String>();
          resultsQuery.add(queryTerm);
          queryTerm.put("analysis_type_id", qAnalysisTypeID + "");
          queryTerm.put("gene_id", queryTerms.get("gene_id"));
          executeNamedQueryWithPivotTerm(conn, "RESULTSBYGENEIDPIVOT", resultsQuery, pivotTerm.toString(), pivotTermsColumnName2FieldNameMap, pivotColumnNameSort, jResults, "results");
        }
        break;
      case GENE_MIXTURE_IDS:
        for (Map<String, String> queryTerms : query) {
          Map<String, String> pivotTermsColumnName2FieldNameMap = new HashMap<String, String>();
          String pivotColumnNameSort = null;
          StringBuffer pivotTerm = new StringBuffer();
          int qAnalysisTypeID = new Integer(queryTerms.get("analysis_type_id"));
          JSONObject qAnalysisType = analysisTypesMap.get(qAnalysisTypeID);
          if (qAnalysisType != null) {
            for (String qResultTypeFieldID : Arrays.asList(queryTerms.get("result_type_ids").split(","))) {
              int qResultTypeID = new Integer(qResultTypeFieldID);
              JSONObject qResultType = resultTypesMap.get(qResultTypeID);
              if (qResultType != null) {
                if (pivotTerm.length() > 0) {
                  pivotTerm.append(',');
                }
                int isPrimarySort = qResultType.optInt("primary_sort", 0);
                String pivotTermColumnName = "C" + pivotTermsColumnName2FieldNameMap.size();
                String pivotTermFieldName = qAnalysisType.getString("analysis_type") + ":" + qResultType.getString("result_type");
                String pivotElement = qResultTypeID + " AS \"" + pivotTermColumnName + "\" ";
                pivotTermsColumnName2FieldNameMap.put(pivotTermColumnName, pivotTermFieldName);
                if (isPrimarySort == 1) {
                  pivotColumnNameSort = pivotTermColumnName;
                }
                pivotTerm.append(pivotElement);
              }
            }
          }
          List<Map<String, String>> resultsQuery = new ArrayList<Map<String, String>>();
          Map<String, String> queryTerm = new HashMap<String, String>();
          resultsQuery.add(queryTerm);
          queryTerm.put("analysis_type_id", qAnalysisTypeID + "");
          queryTerm.put("gene_mixture_id", queryTerms.get("gene_mixture_id"));
          executeNamedQueryWithPivotTerm(conn, "RESULTSBYGENEMIXTUREIDPIVOT", resultsQuery, pivotTerm.toString(), pivotTermsColumnName2FieldNameMap, pivotColumnNameSort, jResults, "results");
        }
        break;
      case EXPERIMENT_IDS:
        for (Map<String, String> queryTerms : query) {
          Map<String, String> pivotTermsColumnName2FieldNameMap = new HashMap<String, String>();
          String pivotColumnNameSort = null;
          StringBuffer pivotTerm = new StringBuffer();
          int qAnalysisTypeID = new Integer(queryTerms.get("analysis_type_id"));
          JSONObject qAnalysisType = analysisTypesMap.get(qAnalysisTypeID);
          if (qAnalysisType != null) {
            for (String qResultTypeFieldID : Arrays.asList(queryTerms.get("result_type_ids").split(","))) {
              int qResultTypeID = new Integer(qResultTypeFieldID);
              JSONObject qResultType = resultTypesMap.get(qResultTypeID);
              if (qResultType != null) {
                if (pivotTerm.length() > 0) {
                  pivotTerm.append(',');
                }
                int isPrimarySort = qResultType.optInt("primary_sort", 0);
                String pivotTermColumnName = "C" + pivotTermsColumnName2FieldNameMap.size();
                String pivotTermFieldName = qAnalysisType.getString("analysis_type") + ":" + qResultType.getString("result_type");
                String pivotElement = qResultTypeID + " AS \"" + pivotTermColumnName + "\" ";
                pivotTermsColumnName2FieldNameMap.put(pivotTermColumnName, pivotTermFieldName);
                if (isPrimarySort == 1) {
                  pivotColumnNameSort = pivotTermColumnName;
                }
                pivotTerm.append(pivotElement);
              }
            }
          }
          List<Map<String, String>> resultsQuery = new ArrayList<Map<String, String>>();
          Map<String, String> queryTerm = new HashMap<String, String>();
          resultsQuery.add(queryTerm);
          queryTerm.put("analysis_type_id", qAnalysisTypeID + "");
          queryTerm.put("experiment_id", queryTerms.get("experiment_id"));
          executeNamedQueryWithPivotTerm(conn, "RESULTSBYEXPIDPIVOT", resultsQuery, pivotTerm.toString(), pivotTermsColumnName2FieldNameMap, pivotColumnNameSort, jResults, "results");
          executeNamedQueryWithPivotTerm(conn, "RESULTS4MIXTURESBYEXPPIVOT", resultsQuery, pivotTerm.toString(), pivotTermsColumnName2FieldNameMap, pivotColumnNameSort, jResults, "results");
        }
        break;

      case RNAI_IDS:
      case GENE_SYMBOLS:
      case ENTREZGENE_IDS:
      case BARCODES:
      case COMPOUND_IDS:
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
    //  timer.append(t.toString()+"\n");

    //for (String selectedAnalysisType : selectedAnalysisTypes) {
    //  jResults.append("analysis", jAnalysisTypes.getJSONObject(selectedAnalysisType));
    //}
    //  timer.append(t.toString()+"\n");
    // for (String selectedResultType : selectedResultTypes) {
    //   jResults.append("result_types", jResultTypes.getJSONObject(selectedResultType));
    // }
    //   timer.append(t.toString()+"\n");
    //   timer.append(t.getMaxSplit()+"\n");
    //  insertErrorLog(timer.toString());
    return jResults;
  }

  public Object getRawResults(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query, JSONObject jResults) throws SQLException, JSONException {
    switch (inputType) {
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2Tabs(conn, "RAWRESULTSBYEXPID", query, false);
      case EXPERIMENT_GENE_IDS:
        return executeInClauseNamedQuery(conn, "RAWRESULTSBYGENEIDEXPID", query, "gene_ids", jResults, "results");
      case EXPERIMENT_GENE_MIXTURE_IDS:
        executeInClauseNamedQuery(conn, "RAWRESULTS4MIXTURESBYGENEMIXIDEXPID", query, "gene_mixture_ids", jResults, "results");
        if (jResults != null && jResults.has("results")) {
          List<JSONObject> jRNAIs = jResults.getJSONArray("results").asList();
          addComponentRNAi(conn, jRNAIs, false);
        }
        return jResults;
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  public String getPOCGeneResults(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> query) throws SQLException {
    switch (inputType) {
      case EXPERIMENT_IDS:
        return executeBasicNamedQuery2Tabs(conn, "POCGENEBYEXPID", query, false);
      default:
        throw new IllegalArgumentException("Input type not supported- " + inputType);
    }
  }

  private JSONObject executeBasicNamedQuery2JSON(Connection conn, String queryName, List<Map<String, String>> valueList, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    return executeBasicQuery2JSON(conn, sql, valueList, jResults, resultKey);
  }

  private JSONObject executeBasicQuery2JSON(Connection conn, String sql, List<Map<String, String>> valueList, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      if (sql.indexOf(":gene_mixture_delim") > -1) {
        stmt.setStringAtName("gene_mixture_delim", GENE_MIX_DELIMITER);
      }
      if (valueList == null) {
        ResultSet rset = stmt.executeQuery();
        processResults(rset, jResults, null, resultKey);
        close(rset);
      } else {
        for (int i = 0; i < valueList.size(); i++) {
          Map<String, String> values = valueList.get(i);
          for (String valName : values.keySet()) {
            stmt.setStringAtName(valName, values.get(valName));
          }
          ResultSet rset = stmt.executeQuery();
          processResults(rset, jResults, null, resultKey);
          close(rset);
        }
      }
    } finally {
      close(stmt);
    }
    return jResults;
  }

  private JSONObject executeBasicNamedQuery2JSON(Connection conn, String queryName, String valueName, String value, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      stmt.setStringAtName(valueName, value);
      ResultSet rset = stmt.executeQuery();
      processResults(rset, jResults, null, resultKey);
      close(rset);
    } finally {
      close(stmt);
    }
    return jResults;
  }

  private JSONObject executeBasicNamedQuery2JSON(Connection conn, String queryName, String valueName, int value, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      stmt.setIntAtName(valueName, value);
      ResultSet rset = stmt.executeQuery();
      processResults(rset, jResults, null, resultKey);
      close(rset);
    } finally {
      close(stmt);
    }
    return jResults;
  }

  private JSONObject executeBasicNoVariableNamedQuery2JSON(Connection conn, String queryName, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (jResults == null) {
      jResults = new JSONObject();
    }
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      ResultSet rset = stmt.executeQuery();
      processResults(rset, jResults, null, resultKey);
      close(rset);
    } finally {
      close(stmt);
    }
    return jResults;
  }

  private String executeBasicNamedQuery2Tabs(Connection conn, String queryName, List<Map<String, String>> valueList, boolean includeHeaders) throws SQLException {
    StringBuilder results = new StringBuilder();
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      insertErrorLog(valueList + "");

      for (int i = 0; i < valueList.size(); i++) {
        Map<String, String> values = valueList.get(i);
        for (String valName : values.keySet()) {
          stmt.setStringAtName(valName, values.get(valName));
        }
        ResultSet rset = stmt.executeQuery();
        ResultSetMetaData md = rset.getMetaData();
        if (includeHeaders) {
          StringBuilder row = new StringBuilder();
          for (int j = 1; j <= md.getColumnCount(); j++) {
            String columnName = md.getColumnLabel(j);
            if (row.length() > 0) {
              row.append('\t');
            }
            row.append(columnName);
          }
          results.append(row);
        }

        while (rset.next()) {
          if (results.length() > 0) {
            results.append('\n');
          }
          StringBuilder row = new StringBuilder();
          for (int j = 1; j <= md.getColumnCount(); j++) {
            String columnName = md.getColumnLabel(j);
            int columnType = md.getColumnType(j);
            String value;

            switch (columnType) {
              //Integers
              case Types.BIGINT:
              case Types.INTEGER:
              case Types.SMALLINT:
              case Types.TINYINT:
                value = rset.getInt(columnName) + "";
                break;

              //Doubles
              case Types.DECIMAL:
              case Types.DOUBLE:
              case Types.FLOAT:
              case Types.NUMERIC:
              case Types.REAL:
                value = rset.getDouble(columnName) + "";
                break;

              //Dates
              case Types.DATE:
              case Types.TIME:
              case Types.TIMESTAMP:
                //record.put(fieldName, dateFormat.format(rset.getDate(columnName)));
                value = dateFormat.format(rset.getDate(columnName));
                break;

              //Boolean
              case Types.BIT:
              case Types.BOOLEAN:
                value = rset.getBoolean(columnName) + "";
                break;

              //Everything else- String
              default:
                value = rset.getString(columnName);
                break;
            }

            if (row.length() > 0) {
              row.append('\t');
            }
            if (value != null) {
              row.append(value);
            } else {
              row.append("");
            }
          }
          results.append(row);
        }
        close(rset);
      }
    } finally {
      close(stmt);
    }
    return results.toString();
  }

  private String executeBasicNamedQuery2Tabs(Connection conn, String queryName, String valueName, String value, boolean includeHeaders) throws SQLException {
    StringBuilder results = new StringBuilder();
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    OraclePreparedStatement stmt = null;
    try {
      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      stmt.setStringAtName(valueName, value);

      ResultSet rset = stmt.executeQuery();
      ResultSetMetaData md = rset.getMetaData();
      if (includeHeaders) {
        StringBuilder row = new StringBuilder();
        for (int j = 1; j <= md.getColumnCount(); j++) {
          String columnName = md.getColumnLabel(j);
          if (row.length() > 0) {
            row.append('\t');
          }
          row.append(columnName);
        }
        results.append(row);
      }
      while (rset.next()) {
        if (results.length() > 0) {
          results.append('\n');
        }
        StringBuilder row = new StringBuilder();
        for (int j = 1; j <= md.getColumnCount(); j++) {
          String columnName = md.getColumnLabel(j);
          String colValue = rset.getString(columnName);
          if (row.length() > 0) {
            row.append('\t');
          }
          if (colValue != null) {
            row.append(colValue);
          } else {
            row.append("");
          }
        }
        results.append(row);
      }
      close(rset);
    } finally {
      close(stmt);
    }
    return results.toString();
  }

  private JSONObject executeInClauseNamedQuery(Connection conn, String queryName, List<Map<String, String>> valueList, String inClauseField, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (inClauseField == null || inClauseField.length() == 0) {
      return executeBasicNamedQuery2JSON(conn, queryName, valueList, jResults, resultKey);
    }
    //JSONObject results = new JSONObject();
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0 || sql.indexOf(":" + inClauseField) == -1) {
      throw new SQLException("Valid query for '" + queryName + "' not found");
    }
    for (int i = 0; i < valueList.size(); i++) {
      OraclePreparedStatement stmt = null;
      try {
        Map<String, String> values = valueList.get(i);
        String inClauseValue = values.get(inClauseField);
        if (inClauseValue != null) {
          String sqlWithIn = sql.replace(":" + inClauseField, inClauseValue);
          stmt = (OraclePreparedStatement) conn.prepareStatement(sqlWithIn);
          for (String valName : values.keySet()) {
            if (inClauseField == null || !valName.equals(inClauseField)) {
              stmt.setStringAtName(valName, values.get(valName));
            }
          }

          if (sql.indexOf(":gene_mixture_delim") > -1) {
            stmt.setStringAtName("gene_mixture_delim", GENE_MIX_DELIMITER);

          }
          ResultSet rset = stmt.executeQuery();
          processResults(rset, jResults, null, resultKey);
          close(rset);
        }
      } finally {
        close(stmt);
      }
    }
    return jResults;
  }

  private JSONObject executeNamedQueryWithPivotTerm(Connection conn, String queryName, List<Map<String, String>> valueList, String pivotTerm, Map<String, String> columnName2FieldNameMap, String pivotColumnNameSort, JSONObject jResults, String resultKey) throws SQLException, JSONException {
    if (pivotTerm == null || pivotTerm.length() == 0) {
      return executeBasicNamedQuery2JSON(conn, queryName, valueList, jResults, resultKey);
    }
    if (jResults == null) {
      jResults = new JSONObject();
    }
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0 || sql.indexOf(":pivot_term") == -1) {
      throw new SQLException("Valid query for '" + queryName + "' not found");
    }
    for (int i = 0; i < valueList.size(); i++) {
      OraclePreparedStatement stmt = null;
      try {
        Map<String, String> values = valueList.get(i);
        String sqlWithIn = sql.replace(":pivot_term", pivotTerm);
        if (pivotColumnNameSort != null && columnName2FieldNameMap.containsKey(pivotColumnNameSort)) {
          sqlWithIn = sqlWithIn + " ORDER BY \"" + pivotColumnNameSort + "\"";
        }
        //System.out.println(sqlWithIn);
        stmt = (OraclePreparedStatement) conn.prepareStatement(sqlWithIn);
        for (String valName : values.keySet()) {
          stmt.setStringAtName(valName, values.get(valName));
        }
        if (sql.indexOf(":gene_mixture_delim") > -1) {
          stmt.setStringAtName("gene_mixture_delim", GENE_MIX_DELIMITER);
        }
        ResultSet rset = stmt.executeQuery();
        processResults(rset, jResults, columnName2FieldNameMap, resultKey);
        close(rset);
      } finally {
        close(stmt);
      }
    }
    return jResults;
  }

  private JSONObject createJSONFromBlob(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new ByteArrayInputStream(bytesOut.toByteArray()));
      return (JSONObject) objIN.readObject();
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new JSONObject();
  }

  private int getNextSeqVal(Connection conn, String seqName) throws SQLException {
    Statement stmt = null;
    try {
      stmt = conn.createStatement();
      ResultSet rset = stmt.executeQuery("SELECT " + seqName + ".NEXTVAL FROM DUAL");
      if (rset.next()) {
        return rset.getInt(1);
      }
    } finally {
      close(stmt);
    }
    throw new SQLException("Unable to get next value from sequence " + seqName);

  }

  private List<Map<String, String>> fromBlob(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();

      ObjectInputStream objIN = new ObjectInputStream(new ByteArrayInputStream(bytesOut.toByteArray()));
      return (List<Map<String, String>>) objIN.readObject();
    } catch (Exception e) {
      insertErrorLog(e + " " + bytesOut.size());
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new ArrayList<Map<String, String>>();
  }

  /**
   * Returns Collections
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getCollections(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> valueList) throws SQLException, JSONException {
    JSONObject jCollections = new JSONObject();
    OraclePreparedStatement stmt = null;
    ResultSet rset = null;
    try {
      switch (inputType) {
        case COLLECTION_IDS:
          executeBasicNamedQuery2JSON(conn, "COLLECTIONBYCOLLECTIONIDS", valueList, jCollections, "results");
          List<JSONObject> jCollectionList = jCollections.getJSONArray("results").asList();
          for (JSONObject jCollection : jCollectionList) {
            List<Map<String, String>> secondaryQuery = new ArrayList<Map<String, String>>();
            Map<String, String> value = new HashMap<String, String>();
            secondaryQuery.add(value);
            value.put("collection_id", jCollection.getString("collection_id"));
            jCollection.put("members", new JSONArray());

            executeBasicNamedQuery2JSON(conn, "COLLECTIONMEMBERSBYCOLLECTIONID", secondaryQuery, jCollection, "members");
          }
          break;
        case ALL:
          stmt = getQueryAsStatement(conn, "COLLECTIONS");
          rset = stmt.executeQuery();
          processResults(rset, jCollections, null, "results");
          break;
        case ALL_WITHDATA:
        default:
          stmt = getQueryAsStatement(conn, "COLLECTIONSALLWITHDATA");
          rset = stmt.executeQuery();
          processResults(rset, jCollections, null, "results");
          break;
      }
      return jCollections;
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns Collections
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getAnnotations(Connection conn, RNAiSearchInputType inputType, List<Map<String, String>> valueList) throws SQLException, JSONException {
    OraclePreparedStatement stmt = null;
    try {
      switch (inputType) {
        case EXPERIMENT_IDS:
          return executeBasicNamedQuery2JSON(conn, "ANNOTATIONSBYEXPID", valueList, new JSONObject(), "results");
        default:
          throw new IllegalArgumentException("Input type not supported- " + inputType);
      }
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns cell lines with experimental results
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getCellLines(Connection conn) throws SQLException, JSONException {
    JSONObject cellLinesWithData = new JSONObject();
    OraclePreparedStatement stmt = null;
    try {
      stmt = getQueryAsStatement(conn, "CELLLINESWITHDATA");
      ResultSet rset = stmt.executeQuery();
      processResults(rset, cellLinesWithData, "results");
      return cellLinesWithData;
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns Analysis types
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getAnalysisTypes(Connection conn) throws SQLException, JSONException {
    JSONObject analysisTypes = new JSONObject();
    OraclePreparedStatement stmt = null;
    try {
      stmt = getQueryAsStatement(conn, "ANALYSISTYPES");
      ResultSet rset = stmt.executeQuery();
      processResults(rset, analysisTypes);
      return analysisTypes;
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns Charts
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getAvailableCharts(Connection conn) throws SQLException, JSONException {
    JSONObject jCharts = new JSONObject();
    OraclePreparedStatement stmt = null;
    try {
      stmt = getQueryAsStatement(conn, "CHARTS");
      ResultSet rset = stmt.executeQuery();
      processResults(rset, jCharts, null, "results");
      return jCharts;
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns Analysis types
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public Map<Integer, JSONObject> getAnalysisTypesMap(Connection conn) throws SQLException, JSONException {
    Map<Integer, JSONObject> analysisTypes = new HashMap<Integer, JSONObject>();
    JSONObject jAnalysisTypes = getAnalysisTypes(conn);
    for (String key : JSONObject.getNames(jAnalysisTypes)) {
      JSONObject jAnalysisType = jAnalysisTypes.getJSONObject(key);
      analysisTypes.put(jAnalysisType.getInt("analysis_type_id"), jAnalysisType);
    }
    return analysisTypes;
  }

  /**
   * Returns Result types
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public JSONObject getResultTypes(Connection conn) throws SQLException, JSONException {
    JSONObject resultTypes = new JSONObject();
    OraclePreparedStatement stmt = null;
    try {
      stmt = getQueryAsStatement(conn, "RESULTTYPES");
      ResultSet rset = stmt.executeQuery();
      processResults(rset, resultTypes);
      return resultTypes;
    } finally {
      close(stmt);
    }
  }

  /**
   * Returns Result types
   *
   * @param conn
   * @return
   * @throws SQLException
   */
  public Map<Integer, JSONObject> getResultTypesMap(Connection conn) throws SQLException, JSONException {
    Map<Integer, JSONObject> resultTypes = new HashMap<Integer, JSONObject>();
    JSONObject jResultTypes = getResultTypes(conn);
    for (String key : JSONObject.getNames(jResultTypes)) {
      JSONObject jResultType = jResultTypes.getJSONObject(key);
      resultTypes.put(jResultType.getInt("result_type_id"), jResultType);
    }
    return resultTypes;
  }

  private static void insertErrorLog(String details) {
    Connection conn = null;
    try {
      //conn = DriverManager.getConnection("jdbc:default:connection:");
      conn = getConnection();
      CLOB c = CLOB.createTemporary(conn, false, CLOB.DURATION_SESSION);
      c.setString(1, details);
      OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement("INSERT INTO ERROR_MESSAGES(ERROR_DATE, DETAILS) VALUES (SYSDATE, :details)");
      stmt.setClobAtName("details", c);
      stmt.executeUpdate();
      stmt.close();
      conn.commit();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(conn);
    }
  }

  private void insertSplitTimerLog(SplitTimer timer) {
    if (timer != null) {
      insertErrorLog(timer.getSplitsLog());
    }
  }

  private Clob executeBasicQuery2Tabs2(Connection conn, String queryName, String valueName, String value, boolean includeHeaders) throws SQLException {
    String sql = getQuery(conn, queryName);
    if (sql == null || sql.length() == 0) {
      throw new SQLException("Query " + queryName + " not found");
    }
    CLOB tempClob = null;

    OraclePreparedStatement stmt = null;
    try {
      tempClob = CLOB.createTemporary(conn, true, CLOB.DURATION_SESSION);
      Writer clobWriter = tempClob.setCharacterStream(1);

      stmt = (OraclePreparedStatement) conn.prepareStatement(sql);
      stmt.setStringAtName(valueName, value);

      ResultSet rset = stmt.executeQuery();
      ResultSetMetaData md = rset.getMetaData();
      if (includeHeaders) {
        StringBuilder row = new StringBuilder();
        for (int j = 1; j <= md.getColumnCount(); j++) {
          String columnName = md.getColumnLabel(j);
          if (row.length() > 0) {
            row.append('\t');
          }
          row.append(columnName);
        }
        clobWriter.append(row + "\n");
      }
      while (rset.next()) {
        StringBuilder row = new StringBuilder();
        for (int j = 1; j <= md.getColumnCount(); j++) {
          String columnName = md.getColumnLabel(j);
          String colValue = rset.getString(columnName);
          if (row.length() > 0) {
            row.append('\t');
          }
          if (colValue != null) {
            row.append(colValue);
          } else {
            row.append("");
          }
        }
        clobWriter.append(row + "\n");
      }
      close(rset);
      clobWriter.close();
    } catch (IOException io) {
      tempClob.freeTemporary();
    } finally {
      close(stmt);
    }
    return tempClob;
  }

  private List<JSONObject> getResultsAsList(JSONObject jResults) {
    List<JSONObject> results = new ArrayList<JSONObject>();
    try {
      if (jResults != null && jResults.has("results")) {
        results.addAll(jResults.getJSONArray("results").asList());
      }
    } catch (Exception e) {
    }
    return results;
  }
}

class SplitTimer {
  double start;
  double split;
  double maxSplit;
  Map<Double, String> splits = new LinkedHashMap<Double, String>();

  SplitTimer() {
    start = ((double) System.currentTimeMillis()) / 1000;
    split = start;
    maxSplit = -1;
  }

  public String setSplit(String msg) {
    double current = ((double) System.currentTimeMillis()) / 1000;
    double splitDiff = current - split;
    double elapsedDiff = current - start;
    split = current;

    splits.put(splitDiff, msg + " [" + getStackPosition(0) + "]");

    return "Split: " + String.format("%.4f", new Object[]{splitDiff}) + " s Elapsed: " + String.format("%.4f", new Object[]{elapsedDiff}) + "s. " + msg + " (" + getStackPosition(0) + ")";
  }

  public String getSplitsLog() {
    StringBuffer sb = new StringBuffer();

    for (Double splitDiff : splits.keySet()) {
      sb.append(String.format("%.4f", new Object[]{splitDiff}) + " s " + splits.get(splitDiff) + "\n");
    }
    return sb.toString();
  }

  public static String[] getStack() {
    try {
      ArrayList stack = new ArrayList();
      String thisClass = "SplitTimer";
      String dumpStack = dumpStack();
      BufferedReader reader = new BufferedReader(new StringReader(dumpStack));
      String line = null;
      int lineCount = 0;
      while ((line = reader.readLine()) != null) {
        line = line.trim();
        if (line.indexOf(thisClass) < 0 && lineCount > 0) {
          stack.add(line.substring(3));
        }
        lineCount++;
      }
      String[] stackArray = new String[stack.size()];
      stack.toArray(stackArray);
      return stackArray;
    } catch (Exception e) {
    }
    return null;
  }

  private String getStackPosition(int position) {
    String[] traces = getStack();
    List traceList = new ArrayList(traces.length);
    for (int i = 0; i < traces.length; i++) {
      if (traces[i].startsWith("a.lang.Exception")
              || traces[i].startsWith("amgen.ri.time.ElapsedTime") || traces[i].startsWith("amgen.ri.util.Debug")) {
        continue;
      }
      traceList.add(traces[i]);
    }
    return (position < traceList.size() ? (String) traceList.get(position) : "Unknown");
  }

  public static String dumpStack() {
    StringWriter sw = new StringWriter();
    PrintWriter writer = new PrintWriter(sw);
    Exception e = new Exception("Debug Stack trace");
    e.printStackTrace(writer);
    return sw.toString();
  }
}
