package amgen.ri.rnai.export;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.rdb.RdbDataArray;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.dao.NamedQuery;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.util.List;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringEscapeUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 * @version $id$
 *
 */
@WebServlet(name = "Export2Excel", urlPatterns = {"/export2excel.go"})
public class Export2Excel extends MainUI {

  enum Request {
    TABLEXPORT,
    POCANDPVALUES;

    public static Request fromString(String s) {
      try {
        return Request.valueOf(s);
      } catch (Exception e) {
        return TABLEXPORT;
      }
    }

    public static Request fromRequest(HttpServletRequest req) {
      try {
        return Request.valueOf(req.getParameter("rx"));
      } catch (Exception e) {
        return TABLEXPORT;
      }
    }
  };

  private class LocalResourceFactory extends ResourceFactory {
    public LocalResourceFactory() {
      super();
    }
  };

  private Request rx;
  private LocalResourceFactory resourceFactory = new LocalResourceFactory();

  public Export2Excel() {
    super();
  }

  public Export2Excel(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    resourceFactory = new LocalResourceFactory();
    rx = Request.fromRequest(req);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new Export2Excel(req, resp);
  }

  /**
   *
   * @return String @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected String getServletMimeType() {
    switch (rx) {
      case TABLEXPORT:
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
      case POCANDPVALUES:
        return "text/tab-separated-values";
    }
    return super.getServletMimeType();
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    switch (rx) {
      case TABLEXPORT:
        handleTableExport();
      case POCANDPVALUES:
        handlePOCPValueExport();
    }
  }

  private void handleTableExport() {
    String dataID = getParameter("dataID");
    String expID = getParameter("experimentID");
    if (StringUtils.isNotEmpty(dataID)) {
      try {
        SessionCache sessionCache = new SessionCache(this);
        if (!ExtString.hasLength(dataID)) {
          throw new IllegalStateException("Cache request without a data ID provided");
        }
        JSONObject table = new JSONObject(getParameter("table", "{}"));
        String sort = getParameter("sort", "");
        String dir = getParameter("dir", "ASC");

        JSONObjectCacheItem jCachedResults = (JSONObjectCacheItem) sessionCache.get(SessionCache.CacheType.RESULTS, dataID);
        JSONObject jResults = jCachedResults.getSortedData(sort, dir);
        List<JSONObject> results = jResults.getJSONArray(jCachedResults.getResultName()).asList();

        Workbook wb = new XSSFWorkbook();

        CellStyle columnHeaderXLStyle = wb.createCellStyle();
        Font columnHeaderXLFont = wb.createFont();
        columnHeaderXLFont.setBoldweight(Font.BOLDWEIGHT_BOLD);
        columnHeaderXLStyle.setFont(columnHeaderXLFont);

        Sheet sheet = wb.createSheet(ExtString.truncate(ExtString.getSafeFileName(table.optString("title", "Sheet 1")), 30, false));
        int rowCounter = 0;
        short cellCounter = 0;
        JSONArray jColumns = table.getJSONArray("columns");
        Row columnHeaderXLRow = sheet.createRow(rowCounter++);
        for (int i = 0; i < jColumns.length(); i++) {
          JSONObject jColumn = jColumns.getJSONObject(i);
          String header = jColumn.getString("header");
          Cell columnGroupXLCell = columnHeaderXLRow.createCell(cellCounter++);
          columnGroupXLCell.setCellStyle(columnHeaderXLStyle);
          columnGroupXLCell.setCellValue(StringEscapeUtils.unescapeXml(header));
        }

        for (JSONObject jResultRow : results) {
          Row xlRow = sheet.createRow(rowCounter++);
          xlRow.setHeightInPoints((float) 12.75);
          cellCounter = 0;
          for (int i = 0; i < jColumns.length(); i++) {
            Cell xlDataCell = xlRow.createCell(cellCounter++);
            JSONObject jColumn = jColumns.getJSONObject(i);
            String fieldName = jColumn.getString("dataIndex");
            String value = jResultRow.optString(fieldName, "");
            if (!ExtString.hasLength(value)) {
              value = "";
            }
            if (ExtString.isANumber(value)) {
              xlDataCell.setCellValue(ExtString.toDouble(value));
            } else {
              xlDataCell.setCellValue(StringEscapeUtils.unescapeXml(value.replaceAll("\\s+", " ")));
            }
          }
        }
        String filename = ExtString.toTitleCase(jCachedResults.getResultName()) + ".xlsx";
        response.addHeader("Content-disposition",
                "attachment; filename=" + filename.replaceAll("\\s+", "_"));
        wb.write(response.getOutputStream());
        response.getOutputStream().flush();
      } catch (Exception e) {
        e.printStackTrace();
      }
    } else if (StringUtils.isNotEmpty(expID)) {

    }
  }

  private void handlePOCPValueExport() {
    int expID = getParameterNumber("exp_id", -1).intValue();
    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      ExperimentRecord expRecord = resourceFactory.getExperiment(expID, getPersonRecord());
      if (expRecord != null) {
        NamedQuery namedQuery = new NamedQuery("COMBINED_POCS_PVALUESBYEXPID");
        namedQuery.addParameter("experiment_id", expRecord.getRecordID());
        sqlSession.getMapper(Mapper.class).runNamedQuery(namedQuery);
        String filename = ExtString.toTitleCase(expRecord.getExperimentName()) + ".tab";

        response.addHeader("Content-disposition",
                "attachment; filename=" + filename.replaceAll("\\s+", "_"));

        IOUtils.write(namedQuery.getResults(), response.getOutputStream(), "UTF-8");
        response.getOutputStream().flush();
      }
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      resourceFactory.close(sqlSession);
    }
  }

}
