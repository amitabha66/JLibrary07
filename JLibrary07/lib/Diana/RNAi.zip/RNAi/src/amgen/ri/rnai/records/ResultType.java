package amgen.ri.rnai.records;

import amgen.ri.json.record.AbstractRecord;

public final class ResultType extends AbstractRecord {
//result_type_id [int] 
//result_type [String] 
//format [String] 
//result_name [String] 
//view_bydefault [int] 
//primary_sort [int] 
  public ResultType(Integer result_type_id) {
    super(result_type_id+"");
    setResult_type_id(result_type_id);
  }

  /**
   * Get value for result_type_id
   */
  public int getResult_type_id() {
    return getNumber("result_type_id").intValue();
  }

  /**
   * Get value for result_type
   */
  public String getResult_type() {
    return getString("result_type");
  }

  /**
   * Get value for format
   */
  public String getFormat() {
    return getString("format");
  }

  /**
   * Get value for result_name
   */
  public String getResult_name() {
    return getString("result_name");
  }

  /**
   * Get value for view_bydefault
   */
  public int getView_bydefault() {
    return getNumber("view_bydefault").intValue();
  }

  /**
   * Get value for primary_sort
   */
  public int getPrimary_sort() {
    return getNumber("primary_sort").intValue();
  }

  /**
   * Set value for result_type_id
   */
  public void setResult_type_id(int result_type_id) {
    add("result_type_id", result_type_id);
  }

  /**
   * Set value for result_type
   */
  public void setResult_type(String result_type) {
    add("result_type", result_type);
  }

  /**
   * Set value for format
   */
  public void setFormat(String format) {
    add("format", format);
  }

  /**
   * Set value for result_name
   */
  public void setResult_name(String result_name) {
    add("result_name", result_name);
  }

  /**
   * Set value for view_bydefault
   */
  public void setView_bydefault(int view_bydefault) {
    add("view_bydefault", view_bydefault);
  }

  /**
   * Set value for primary_sort
   */
  public void setPrimary_sort(int primary_sort) {
    add("primary_sort", primary_sort);
  }
}