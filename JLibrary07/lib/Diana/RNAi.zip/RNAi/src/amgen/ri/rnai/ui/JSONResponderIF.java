/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

import amgen.ri.json.JSONObject;

public interface JSONResponderIF {
  public JSONObject getResponse() throws Exception;  
}
