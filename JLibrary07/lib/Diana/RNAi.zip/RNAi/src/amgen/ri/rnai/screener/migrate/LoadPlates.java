/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener.migrate;

import amgen.ri.aldi.merlin.net.ws.MerlinServicesLocator;
import amgen.ri.aldi.merlin.net.ws.MerlinServicesSoap_PortType;
import amgen.ri.aldi.merlin.net.ws.PlateInfo;
import amgen.ri.aldi.merlin.net.ws.PlateMap;
import amgen.ri.aldi.merlin.net.ws.PlateWellContents;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.rnai.util.FileUtil;
import amgen.ri.util.Debug;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author jayanthi
 */
public class LoadPlates extends ResourceFactory {

    private String validBarcodesStr = "";
    private ArrayList validBarcodes = new ArrayList();
    private ArrayList inValidBarcodes = new ArrayList();
    private HashMap mosaicBarcodes = new HashMap();
    private ArrayList mBarcodes = new ArrayList();
    private ArrayList mosaicOrphanBarcodes = new ArrayList();
    private ArrayList validBarcodeToNotLoad = new ArrayList();
    private ArrayList tempTables = new ArrayList();
    private String sessionId = "";

    public LoadPlates(SessionCache sessionCache) {
        super(sessionCache);
    }

    public AppServerReturnObject getRs3Barcode(Connection conn, String plate_id) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            String queryString = "select * from invrs3_map where map = '" + plate_id + "'" + "\n";
            Statement ps1 = conn.createStatement();
            ResultSet rs1 = ps1.executeQuery(queryString);
            if (rs1.next()) {
                asro.setCallSucceed(true);
                return asro;
            } else {
                System.out.println(queryString);
            }
            rs1.close();
            ps1.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
        return asro;
    }

    public AppServerReturnObject updateWells(Connection conn) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            Statement stmt = conn.createStatement();
            stmt.addBatch("update wells set wrow = 'A' where wrow = '1'");
            stmt.addBatch("update wells set wrow = 'B' where wrow = '2'");
            stmt.addBatch("update wells set wrow = 'C' where wrow = '3'");
            stmt.addBatch("update wells set wrow = 'D' where wrow = '4'");
            stmt.addBatch("update wells set wrow = 'E' where wrow = '5'");
            stmt.addBatch("update wells set wrow = 'F' where wrow = '6'");
            stmt.addBatch("update wells set wrow = 'G' where wrow = '7'");
            stmt.addBatch("update wells set wrow = 'H' where wrow = '8'");
            stmt.addBatch("update wells set wrow = 'I' where wrow = '9'");
            stmt.addBatch("update wells set wrow = 'J' where wrow = '10'");
            stmt.addBatch("update wells set wrow = 'K' where wrow = '11'");
            stmt.addBatch("update wells set wrow = 'L' where wrow = '12'");
            stmt.addBatch("update wells set wrow = 'M' where wrow = '13'");
            stmt.addBatch("update wells set wrow = 'N' where wrow = '14'");
            stmt.addBatch("update wells set wrow = 'O' where wrow = '15'");
            stmt.addBatch("update wells set wrow = 'P' where wrow = '16'");
            stmt.executeBatch();
            stmt.close();
            System.out.println("Updated wells");
            asro.setCallSucceed(true);
        } catch (Exception e) {
            e.printStackTrace();

        }
        return asro;
    }

    private AppServerReturnObject processBatchStmt(int count, PreparedStatement stmt, Connection conn) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            if (count>0 && count % 10 == 0) {
                //System.out.println("Mid commit for : " + count);
                stmt.executeBatch();
                conn.commit();
            }
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject addMosaicBarcode(String parent_barcode, String child_barcode) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            if (parent_barcode == null) {
                asro.setCallSucceed(false);
                asro.setComment("parent_barcode : child_barcode\t" + parent_barcode + " : " + child_barcode);
                return asro;
            }
            if (!this.validBarcodes.contains(parent_barcode)) {
                this.validBarcodes.add(parent_barcode);
                this.validBarcodesStr = validBarcodesStr + parent_barcode + "\n";
            }

            ArrayList values = null;
            if (this.mosaicBarcodes.containsKey(parent_barcode)) {
                values = (ArrayList) this.mosaicBarcodes.get(parent_barcode);
            } else {
                values = new ArrayList();
                this.mosaicBarcodes.put(parent_barcode, values);
            }
            if (child_barcode != null) {
                values.add(child_barcode);
                this.validBarcodes.add(child_barcode);
                this.validBarcodesStr = validBarcodesStr + child_barcode + "\n";
            }
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject segregateBarcodes1(Connection conn, List barcodes, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int person_id = 941778;
            for (int i = 0; i < barcodes.size(); i++) {
                String current_barcode = ((String) barcodes.get(i)).trim();
                String barcode = "";
                String parent_barcode = "";
                String source = "";
                //System.out.println("Match1: " + current_barcode.matches("\\d+"));
                if (current_barcode.matches("\\d+")) {
                    source = "MOSAIC";
                    String[] children = null;
                    try {
                        children = merlinServices.getChildPlateBarcodes(current_barcode, person_id);
                    } catch (Exception e) {
                    }
                    if (children == null || children.length == 0) {
                        String[] parents = null;
                        try {
                            parents = merlinServices.getParentPlateBarcodes(current_barcode);
                        } catch (Exception e) {
                        }
                        if (parents == null || parents.length == 0) {
                            PlateInfo[] infos = merlinServices.getPlateInfo(new String[]{current_barcode}, person_id);
                            if (infos != null && infos.length > 0) {
                                this.mosaicOrphanBarcodes.add(current_barcode);
                                this.validBarcodes.add(current_barcode);
                                this.validBarcodesStr = validBarcodesStr + current_barcode + "\n";
                            } else {
                                this.inValidBarcodes.add(current_barcode);
                            }
                        } else {
                            barcode = current_barcode;
                            for (int j = 0; j < parents.length; j++) {
                                parent_barcode = parents[j];
                                asro = addMosaicBarcode(parent_barcode, barcode);
                                if (!asro.isCallSucceed()) {
                                    return asro;
                                }
                            }
                        }
                    } else {
                        parent_barcode = current_barcode;
                        for (int j = 0; j < children.length; j++) {
                            barcode = children[j];
                            asro = addMosaicBarcode(parent_barcode, barcode);
                            if (!asro.isCallSucceed()) {
                                return asro;
                            }
                        }
                    }
                } else if (current_barcode.matches("M\\d+")) {
                    asro = this.getRs3Barcode(conn, current_barcode);
                    if (!asro.isCallSucceed()) {
                        this.inValidBarcodes.add(current_barcode);
                    } else {
                        source = "RS3";
                        barcode = current_barcode;
                        this.mBarcodes.add(current_barcode);
                        this.validBarcodes.add(current_barcode);
                        this.validBarcodesStr = validBarcodesStr + current_barcode + "\n";
                    }
                } else {
                    this.inValidBarcodes.add(current_barcode);
                }
            }
            System.out.println("Invalid:\n" + this.inValidBarcodes);
            System.out.println("mBarcodes:\n" + this.mBarcodes);
            System.out.println("mosaicBarcodes:\n" + this.mosaicBarcodes);
            System.out.println("validBarcodeToNotLoad:\n" + this.validBarcodeToNotLoad);
            System.out.println("validBarcodes:\n" + this.validBarcodes);
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    
    private AppServerReturnObject segregateBarcodes(Connection conn, List barcodes, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int person_id = 941778;
            for (int i = 0; i < barcodes.size(); i++) {
                String current_barcode = ((String) barcodes.get(i)).trim();
                if (current_barcode.equals("10000491983")) {
                  Debug.print();
                }
                String barcode = "";
                String parent_barcode = "";
                String source = "";
                //System.out.println("Match1: " + current_barcode.matches("\\d+"));
                if (current_barcode.matches("M\\d+")) {
                    asro = this.getRs3Barcode(conn, current_barcode);
                    if (!asro.isCallSucceed()) {
                        this.inValidBarcodes.add(current_barcode);
                    } else {
                        source = "RS3";
                        barcode = current_barcode;
                        this.mBarcodes.add(current_barcode);
                        this.validBarcodes.add(current_barcode);
                        this.validBarcodesStr = validBarcodesStr + current_barcode + "\n";
                    }
                }else {
                    source = "MOSAIC";
                    String[] children = null;
                    try {
                        children = merlinServices.getChildPlateBarcodes(current_barcode, person_id);
                    } catch (Exception e) {
                    }
                    if (children == null || children.length == 0) {
                        String[] parents = null;
                        try {
                            parents = merlinServices.getParentPlateBarcodes(current_barcode);
                        } catch (Exception e) {
                        }
                        if (parents == null || parents.length == 0) {
                            PlateInfo[] infos = merlinServices.getPlateInfo(new String[]{current_barcode}, person_id);
                            if (infos != null && infos.length > 0) {
                                this.mosaicOrphanBarcodes.add(current_barcode);
                                this.validBarcodes.add(current_barcode);
                                this.validBarcodesStr = validBarcodesStr + current_barcode + "\n";
                            } else {
                                this.inValidBarcodes.add(current_barcode);
                            }
                        } else {
                            barcode = current_barcode;
                            for (int j = 0; j < parents.length; j++) {
                                parent_barcode = parents[j];
                                asro = addMosaicBarcode(parent_barcode, barcode);
                                if (!asro.isCallSucceed()) {
                                    return asro;
                                }
                            }
                        }
                    } else {
                        parent_barcode = current_barcode;
                        for (int j = 0; j < children.length; j++) {
                            barcode = children[j];
                            asro = addMosaicBarcode(parent_barcode, barcode);
                            if (!asro.isCallSucceed()) {
                                return asro;
                            }
                        }
                    }
                } 
            }
            System.out.println("Invalid:\n" + this.inValidBarcodes);
            System.out.println("mBarcodes:\n" + this.mBarcodes);
            System.out.println("mosaicBarcodes:\n" + this.mosaicBarcodes);
            System.out.println("validBarcodeToNotLoad:\n" + this.validBarcodeToNotLoad);
            System.out.println("validBarcodes:\n" + this.validBarcodes);
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject insertMosaicBarcodes(Connection conn, PreparedStatement stmt_plates,
            PreparedStatement stmt_error_plates, PreparedStatement stmt_wells, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int pcount = 0;
            Iterator it = this.mosaicBarcodes.keySet().iterator();
            while (it.hasNext()) {
                String parent_barcode = (String) it.next();
                if (!this.validBarcodeToNotLoad.contains(parent_barcode)) {
                    pcount++;
                    stmt_plates.setString(1, parent_barcode);
                    stmt_plates.setString(2, null);
                    stmt_plates.setString(3, "MOSAIC");
                    stmt_plates.addBatch();

                    asro = this.processBatchStmt(pcount, stmt_plates, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    asro = this.insertMosaicWells(stmt_wells, parent_barcode, conn, merlinServices);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    asro = this.processBatchStmt(pcount, stmt_wells, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }

                }

                ArrayList children = (ArrayList) this.mosaicBarcodes.get(parent_barcode);
                for (int i = 0; i < children.size(); i++) {
                    String barcode = (String) children.get(i);
                    if (!this.validBarcodeToNotLoad.contains(barcode)) {
                        pcount++;
                        stmt_plates.setString(1, barcode);
                        stmt_plates.setString(2, parent_barcode);
                        stmt_plates.setString(3, "MOSAIC");
                        stmt_plates.addBatch();

                        asro = this.processBatchStmt(pcount, stmt_plates, conn);
                        if (!asro.isCallSucceed()) {
                            return asro;
                        }
                        asro = this.insertMosaicWells(stmt_wells, barcode, conn, merlinServices);
                        if (!asro.isCallSucceed()) {
                            return asro;
                        }
                        asro = this.processBatchStmt(pcount, stmt_wells, conn);
                        if (!asro.isCallSucceed()) {
                            return asro;
                        }
                    }
                }
            }
            asro.setReturnObject(Integer.toString(pcount));
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject insertOrphanMosaicBarcodes(Connection conn, PreparedStatement stmt_plates,
            PreparedStatement stmt_error_plates, PreparedStatement stmt_wells, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int pcount = 0;
            for (int i = 0; i < this.mosaicOrphanBarcodes.size(); i++) {
                String barcode = (String) this.mosaicOrphanBarcodes.get(i);
                if (!this.validBarcodeToNotLoad.contains(barcode)) {
                    pcount++;
                    stmt_plates.setString(1, barcode);
                    stmt_plates.setString(2, null);
                    stmt_plates.setString(3, "MOSAIC_ORPHAN");
                    stmt_plates.addBatch();

                    asro = this.processBatchStmt(pcount, stmt_plates, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    asro = this.insertMosaicWells(stmt_wells, barcode, conn, merlinServices);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    asro = this.processBatchStmt(pcount, stmt_wells, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                }

            }
            asro.setReturnObject(Integer.toString(pcount));
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject insertBarcodes(Connection conn, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int person_id = 941778;
            String plate_error_sql = "insert into tmp_error_plates(barcode, comments) "
                    + "values (?,?)";
            String plate_sql = "insert into plates(barcode, parent_barcode, source) "
                    + "values (?,?,?)";
            String well_sql = "insert into wells(well_id, barcode, wrow, wcol, substance_id) "
                    + "values (plate_well_Seq.nextval,?,?,?,?)";

            String mwell_sql = "insert into wells(well_id, barcode, wrow, wcol, substance_id) select plate_well_seq.nextval, barcode, mrow, mcol, substance_id from " + "\n"
                    + "( " + "\n"
                    + "select map as barcode, mrow, mcol, substance_id from invrs3_map p, invrs3_mapwell w " + "\n"
                    + "where " + "\n"
                    + "p.map_id = w.map_id " + "\n"
                    + "and map = ?"
                    + ")  a ";

            PreparedStatement stmt_plates = conn.prepareCall(plate_sql);
            PreparedStatement stmt_error_plates = conn.prepareCall(plate_error_sql);
            PreparedStatement stmt_wells = conn.prepareCall(well_sql);
            PreparedStatement stmt_mwells = conn.prepareCall(mwell_sql);

            asro = insertMosaicBarcodes(conn, stmt_plates, stmt_error_plates, stmt_wells, merlinServices);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            System.out.println("insertMosaicBarcodes");

            asro = insertOrphanMosaicBarcodes(conn, stmt_plates, stmt_error_plates, stmt_wells, merlinServices);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            System.out.println("insertOrphanMosaicBarcodes");
            asro = insertMBarcodesWells(conn, stmt_plates, stmt_error_plates, stmt_mwells);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            System.out.println("insertMBarcodesWells");

            stmt_plates.executeBatch();
            stmt_error_plates.executeBatch();
            stmt_wells.executeBatch();
            stmt_mwells.executeBatch();
            conn.commit();
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }
    
    public AppServerReturnObject callDeleteTempTable(Connection conn, String sessionId) {
        AppServerReturnObject asro = new AppServerReturnObject();
        try {

            String queryString = "";
            queryString =
                    "drop table " + sessionId;
            Statement tstmt = conn.createStatement();
            ResultSet rs = tstmt.executeQuery(queryString);

            asro.setCallSucceed(true);
        } catch (Exception e) {
            asro.setCallSucceed(false);
            asro.setComment("Problem in callRatToMouse");
            e.printStackTrace();
        } finally {
        }
        return asro;
    }

    private AppServerReturnObject filterInput(Connection conn) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            if (validBarcodesStr == null || validBarcodesStr.trim().length() == 0) {
                asro.setCallSucceed(false);
                asro.setComment("Input empty");
                return asro;
            }
            sessionId = "tmp_P_" + System.currentTimeMillis();


            InsertStrInputToTempOra ac = new InsertStrInputToTempOra();
            asro = ac.createStrInputTable("PlateLoad:Barcodes", sessionId, "", this.validBarcodesStr, conn);
            tempTables.add(sessionId);

            String queryString = "select barcode from plates p, " + sessionId + " i "
                    + "where "
                    + "P.BARCODE = str_input "
                    + "union "
                    + "select barcode from plates p, " + sessionId + " i "
                    + "where  "
                    + "p.parent_barcode = str_input ";
            System.out.println(queryString);
            Statement ps1 = conn.createStatement();
            ResultSet rs = ps1.executeQuery(queryString);
            while (rs.next()) {
                String barcode = rs.getString("barcode");
                this.validBarcodeToNotLoad.add(barcode);
            }
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject runBatch(List<String> inputBarcodes) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        Connection conn = null;
        try {
            System.out.println("readandload" + "\nSize: " + inputBarcodes.size() + "\n" + inputBarcodes);
            conn = getRNAiConnection();
            conn.setAutoCommit(false);
            MerlinServicesSoap_PortType merlin = new MerlinServicesLocator().getMerlinServicesSoap(new URL("http://usto-papp-aldi1:81/MerlinServices.asmx?WSDL"));

            asro = this.segregateBarcodes(conn, inputBarcodes, merlin);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            System.out.println("Plates segregated");
            asro = filterInput(conn);
            if (!asro.isCallSucceed()) {
                return asro;
            }

            System.out.println("filtered");

            asro = this.insertBarcodes(conn, merlin);
            if (!asro.isCallSucceed()) {
                return asro;
            }

            System.out.println("barcode inserted");
            asro = this.updateWells(conn);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            System.out.println("wells updated");

            conn.commit();
            
            asro = callDeleteTempTable(conn, this.sessionId);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);
        }
        return asro;
    }

    public AppServerReturnObject readandload(String input) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        Connection conn = null;
        try {


            List<String> inputBarcodes = null;
            String[] splitinput = input.split("\n");
            if (splitinput != null && splitinput.length > 0) {
                inputBarcodes = Arrays.asList(splitinput);
            }

            List<String> batchBarcodes = new ArrayList();
            for (int i = 0; i < inputBarcodes.size(); i++) {
                batchBarcodes.add(inputBarcodes.get(i));
                if (batchBarcodes.size() % 25 == 0) {
                    runBatch(batchBarcodes);
                    batchBarcodes = new ArrayList();
                }
            }
            if (batchBarcodes.size() > 0) {
                runBatch(batchBarcodes);
            }


            //update wells

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject insertMosaicWells(PreparedStatement stmt_wells, String barcode, Connection conn, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            PlateMap map = null;
            try {
                map = merlinServices.getPlateMap(barcode);
                PlateWellContents[] pwells = null;
                pwells = map.getNonEmptyWells();
                for (int i = 0; i < pwells.length; i++) {
                    PlateWellContents pwell = pwells[i];
                    stmt_wells.setString(1, barcode);
                    stmt_wells.setString(2, Integer.toString(pwell.getRow()));
                    stmt_wells.setString(3, Integer.toString(pwell.getCol()));
                    stmt_wells.setString(4, Integer.toString(pwell.getSubstanceID()));
                    //pwell.
                    stmt_wells.addBatch();
                }
            } catch (Exception e) {
                System.out.println("Plate map not found: " + barcode);
                asro.setCallSucceed(false);
                asro.setComment("Plate map not found: " + barcode);
                return asro;
            }
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject insertMBarcodesWells(Connection conn, PreparedStatement stmt_plates,
            PreparedStatement stmt_error_plates, PreparedStatement stmt_mwells) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            int pcount = 0;
            for (int i = 0; i < this.mBarcodes.size(); i++) {
                String barcode = (String) this.mBarcodes.get(i);
                if (!this.validBarcodeToNotLoad.contains(barcode)) {
                    pcount++;
                    stmt_plates.setString(1, barcode);
                    stmt_plates.setString(2, null);
                    stmt_plates.setString(3, "RS3");
                    stmt_plates.addBatch();

                    asro = this.processBatchStmt(pcount, stmt_plates, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }

                    stmt_mwells.setString(1, barcode);
                    stmt_mwells.addBatch();
                    asro = this.processBatchStmt(pcount, stmt_mwells, conn);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                }
            }
            asro.setReturnObject(Integer.toString(pcount));
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public static void main(String[] args) throws Exception {
        //OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-pdbx-ora09.amgen.com:1521:Wa0630p.amgen.com");
        LoadPlates lp = new LoadPlates(null);
        //String input = FileUtil.readFileAsString("H:\\projects\\RNAi\\plates\\tab2.txt");
        //String input = FileUtil.readFileAsString("H:\\projects\\RNAi\\plates\\tab1_m.txt");
        //String input = FileUtil.readFileAsString("H:\\projects\\RNAi\\plates\\tab1.txt");
        //String input = "M28380\nM28945\nM28946\nM28947\nM28948\nM28949\nM28950\nM28951\nM28953";
        //String input = "5467";
        //System.out.println(input);
        //String input = "10000364748";
        //String input = "10000392167";
        //String input = FileUtil.readFileAsString("H:\\projects\\RNAi\\plates\\arg1.txt");
        //String input = "1884-1U";
        //String input = "1884-1U\n1884-2U\n1884-3U\n4419619-1U\n4419619-2U\n4419619-3U";
        String input = FileUtil.readFileAsString("H:\\projects\\RNAi\\loadplates_0514.txt");
        //String input = "10000444851";
        System.out.println(input);
        lp.readandload(input);

    }
}
