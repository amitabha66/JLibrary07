/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.mail.SendMessage;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtString;
import java.util.*;
import org.apache.commons.lang.text.StrSubstitutor;

/**
 *
 * @author jemcdowe
 */
public class GIEmailNotifierListener implements GeneticInteractionListenerIF {
  private static final String EMAIL_TEMPLATE = "Genetic Interaction Analysis Completed<P/>Experiments: ${experiment_names}<P/>"
          + "Results are available in Analysis Results in the <A href='http://rnai-app'>RNAi Application</A>.";
  private PersonRecordIF personRecord;

  public GIEmailNotifierListener(PersonRecordIF personRecord) {
    this.personRecord = personRecord;
  }

  public void processBegan(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments) {
  }

  public void analysisStarted(GeneticInteractionAnalysis giAnalysis, GIExperiments gie) {
  }

  public void analysisComplete(GeneticInteractionAnalysis giAnalysis, GIExperiments gie) {
  }

  public void processEnded(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments) {
    try {
      List<String> names = new ArrayList<String>();
      for (ExperimentRecord experimentRecord : experiments) {
        names.add(experimentRecord.getExperimentName());
      }
      Map<String, String> replacements = new HashMap<String, String>();
      replacements.put("experiment_names", ExtString.join(names, ','));

      StrSubstitutor substitutor = new StrSubstitutor(replacements);

      String from = "global-rg-comm@amgen.com";
      String subject = "Genetic Interaction Analysis Completed";
      String to[] = {
        this.personRecord.getEmail()
      };
      SendMessage send = new SendMessage();
      send.sendHTMLMessage(to, null, null, from, subject, substitutor.replace(EMAIL_TEMPLATE));
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
