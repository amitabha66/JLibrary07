/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener.migrate;

/**
 *
 * @author jayanthi
 */
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.rnai.util.FileUtil;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

public class RNAiSeqRegCorrectTTtt extends ResourceFactory {

    public RNAiSeqRegCorrectTTtt(SessionCache sessionCache) {
        super(sessionCache);
    }

    public AppServerReturnObject makeCorrections() {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        Connection conn = null;
        try {

            

            conn = getRNAiConnection();
            conn.setAutoCommit(false);
            Statement udstmt = conn.createStatement();

            String path = "H:\\projects\\RNAi\\registration\\corrections_before_batch7.txt";
            String content = "";

            HashMap toCorrect = new HashMap();

            String queryString =
                    "select * from rnai_seq s," + "\n"
                    + "(select upper(rnai_sequence) as seq, rnai_seq_type, rnai_type_id, vendor_id " + "\n"
                    + "from rnai_seq" + "\n"
                    + "group by upper(rnai_sequence), rnai_seq_type, rnai_type_id, vendor_id" + "\n"
                    + "having count(*) > 1 and rnai_type_id = 1) d" + "\n"
                    + "where upper(s.rnai_sequence) = d.seq" + "\n"
                    + "and s.rnai_seq_type = d.rnai_seq_type" + "\n"
                    + "and s.rnai_type_id = d.rnai_type_id" + "\n"
                    + "and s.vendor_id = d.vendor_id" + "\n"
                    + "and s.rnai_type_id = 1";

            content = content + queryString + "\n";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(queryString);
            while (rs.next()) {
                String seq = rs.getString("seq");
                int rnai_seq_id = rs.getInt("rnai_seq_id");
                RNAiSeqC seqc = new RNAiSeqC();
                if (toCorrect.containsKey(seq)) {
                    seqc = (RNAiSeqC) toCorrect.get(seq);
                } else {
                    toCorrect.put(seq, seqc);
                }
                if (!seqc.getRnai_seq_ids().contains(new Integer(rnai_seq_id))) {
                    seqc.getRnai_seq_ids().add(new Integer(rnai_seq_id));
                    seqc.setAll_rnai_seq_ids_clause(seqc.getAll_rnai_seq_ids_clause() + rnai_seq_id + ", ");
                }
            }
            rs.close();
            stmt.close();

            Iterator seqit = toCorrect.keySet().iterator();
            while (seqit.hasNext()) {
                String cur_seq = (String) seqit.next();
                RNAiSeqC seqc = (RNAiSeqC) toCorrect.get(cur_seq);
                String clause = seqc.getAll_rnai_seq_ids_clause().substring(0, seqc.getAll_rnai_seq_ids_clause().lastIndexOf(","));
                queryString = "select * from rnai_seq_map where rnai_seq_id in (" + clause + ")";
                content = content + queryString + "\n";
                stmt = conn.createStatement();
                rs = stmt.executeQuery(queryString);
                int lowest_rnai_seq_id = 0;
                while (rs.next()) {
                    int rnai_id = rs.getInt("rnai_id");
                    int rnai_seq_id = rs.getInt("rnai_seq_id");
                    if (lowest_rnai_seq_id == 0 || lowest_rnai_seq_id > rnai_seq_id) {
                        lowest_rnai_seq_id = rnai_seq_id;
                    }

                    if (!seqc.getRnai_ids().contains(new Integer(rnai_id))) {
                        seqc.getRnai_ids().add(new Integer(rnai_id));
                        seqc.setAll_rnai_ids_clause(seqc.getAll_rnai_seq_ids_clause() + rnai_id + ", ");
                    }
                }
                rs.close();
                stmt.close();


                String update_seq_map_q = 
                        "update rnai_seq_map set rnai_seq_id = " + 
                        lowest_rnai_seq_id + 
                        " where rnai_seq_id in (" + 
                        "select distinct rnai_seq_id from rnai_seq_map where rnai_seq_id in (" +  clause + "))";
                content = content + update_seq_map_q + "\n\n";
                udstmt.addBatch(update_seq_map_q);
            }
FileUtil.writeStringFile(content, path);
            udstmt.executeBatch();
            conn.commit();

        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (Exception e1) {
            }
            e.printStackTrace();
        } finally {
            closeResources(conn);
        }
        return asro;
    }

    public static void main(String[] args) throws Exception {


        testCorrect();
    }

    public static void testCorrect() throws Exception {
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-pdbx-ora09:1521:wa0630p.amgen.com");
  

        RNAiSeqRegCorrectTTtt m = new RNAiSeqRegCorrectTTtt(null);
        m.makeCorrections();




    }
}
