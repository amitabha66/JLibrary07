/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public final class AlignmentRecord extends AbstractRecord {  

  public AlignmentRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public AlignmentRecord(String recordID) {
    super(recordID);
  }
  
  public AlignmentRecord(String compoundID, String rnaiID, String targetAccession) {
    super(compoundID);
    setCompoundID(compoundID);
    setRNAID(rnaiID);
    setTargetAccession(targetAccession);
  }
  

  /**
   * @return the compound_id
   */
  public String getCompoundID() {
    return getString("compound_id");
  }

  /**
   * @param compound_id the compound_id to set
   */
  public void setCompoundID(String seq_id) {
    add("compound_id", seq_id);
  }
  /**
   * @return the rnai_id
   */
  public String getRNAID() {
    return getString("rnai_id");
  }

  /**
   * @param rnai_id the rnai_id to set
   */
  public void setRNAID(String rnai_id) {
    add("rnai_id", rnai_id);
  }

  /**
   * @return the target_accession
   */
  public String getTargetAccession() {
    return getString("target_accession");
  }

  /**
   * @param target_accession the target_accession to set
   */
  public void setTargetAccession(String target_accession) {
    add("target_accession", target_accession);
  }
  
  
  public void addAlignmentPairRecord(AlignmentPairRecord alignmentPairRecord) {
    try {
      append("hsps", alignmentPairRecord);
    } catch (JSONException ex) {
    }
  }

}
