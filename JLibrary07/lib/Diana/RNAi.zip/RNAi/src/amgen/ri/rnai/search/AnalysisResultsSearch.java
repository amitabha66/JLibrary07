/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.*;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class AnalysisResultsSearch extends AbstractSearch implements JSONResponderIF, Iterable<JSONObject> {
  private JSONObject jRNAiResults;
  private RNAiSearchInputType searchType;
  private RNAiSearchOutputType searchResponse;
  private int geneID;
  private int geneMixtureID;
  private List<JSONObject> analysisTypes;
  private List<JSONObject> resultTypes;
  private JSONObject jResultTypeMap;
  private JSONObject jAnalysisTypeMap;
  private int expID;
  private ExperimentRecord experimentRecord;

  public AnalysisResultsSearch(SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
  }

  public AnalysisResultsSearch(String searchType, String searchResponse, int geneID, int geneMixtureID, int expID, String analysisTypes, String resultTypes, SessionCache sessionCache, PersonRecordIF sessionUser) {
    this(sessionCache, sessionUser);
    this.searchType = RNAiSearchInputType.fromString(searchType);
    this.searchResponse = RNAiSearchOutputType.fromString(searchResponse);
    this.geneID = geneID;
    this.geneMixtureID = geneMixtureID;
    this.expID = expID;
    this.analysisTypes = new ArrayList<JSONObject>();

    if (ExtString.hasLength(analysisTypes)) {
      List<String> analysisTypeNames = Arrays.asList(analysisTypes.split(","));
      for (String key : JSONObject.getNames(getAnalysisTypeMap())) {
        try {
          JSONObject jAnalysisType = getAnalysisTypeMap().getJSONObject(key);
          String analysisTypeName = jAnalysisType.getString("analysis_type");
          if (analysisTypeNames.contains(analysisTypeName)) {
            this.analysisTypes.add(jAnalysisType);
          }
        } catch (Exception e) {
        }
      }
    }
    if (this.analysisTypes.isEmpty()) {
      for (String key : JSONObject.getNames(getAnalysisTypeMap())) {
        try {
          JSONObject jAnalysisType = getAnalysisTypeMap().getJSONObject(key);
          if (jAnalysisType.getInt("view_bydefault") == 1) {
            this.analysisTypes.add(jAnalysisType);
          }
        } catch (Exception e) {
        }
      }
    }

    this.resultTypes = new ArrayList<JSONObject>();
    if (ExtString.hasLength(resultTypes)) {
      List<String> resultTypeNames = Arrays.asList(resultTypes.split(","));
      for (String key : JSONObject.getNames(getResultTypeMap())) {
        try {
          JSONObject jResultType = getResultTypeMap().getJSONObject(key);
          String resultTypeName = jResultType.getString("result_type");
          if (resultTypeNames.contains(resultTypeName)) {
            this.resultTypes.add(jResultType);
          }
        } catch (Exception e) {
        }
      }
    }
    if (this.resultTypes.isEmpty()) {
      for (String key : JSONObject.getNames(getResultTypeMap())) {
        try {
          JSONObject jResultType = getResultTypeMap().getJSONObject(key);
          if (jResultType.getInt("view_bydefault") == 1) {
            this.resultTypes.add(jResultType);
          }
        } catch (Exception e) {
        }
      }
    }

    if (this.analysisTypes.isEmpty()) {
      throw new IllegalArgumentException("No analysis types specified.");
    }

    if (this.resultTypes.isEmpty()) {
      throw new IllegalArgumentException("No result types specified.");
    }
  }

  /**
   * Returns all analysis types as a JSON Map of type name to JSONObject
   *
   * @return
   */
  public final JSONObject getAnalysisTypeMap() {
    if (jAnalysisTypeMap == null) {
      try {
        jAnalysisTypeMap = executeQuery(RNAiSearchInputType.UNKNOWN, RNAiSearchOutputType.ANALYSIS_TYPES, new ArrayList<Map<String, String>>());
      } catch (SQLException ex) {
      }
    }
    return jAnalysisTypeMap;
  }

  /**
   * Returns all result types as a JSON Map of type name to JSONObject
   *
   * @return
   */
  public final JSONObject getResultTypeMap() {
    if (jResultTypeMap == null) {
      try {
        jResultTypeMap = executeQuery(RNAiSearchInputType.UNKNOWN, RNAiSearchOutputType.RESULT_TYPES, new ArrayList<Map<String, String>>());
      } catch (SQLException ex) {
      }
    }
    return jResultTypeMap;
  }

  /**
   * Returns the result types included in the search
   *
   * @return
   */
  public List<JSONObject> getResultTypes() {
    return resultTypes;
  }

  /**
   * Returns the analysis types included in the search
   *
   * @return
   */
  public List<JSONObject> getAnalysisTypes() {
    return analysisTypes;
  }

  public ExperimentRecord getExperimentRecord() {
    if (expID > 0 && experimentRecord == null) {
      List<Integer> expIDs = new ArrayList<Integer>();
      expIDs.add(expID);
      RNAiSearch rnaiSearch = new RNAiSearch(null, null, null, null, expIDs, RNAiSearchOutputType.EXPERIMENTS, null, getSessionUser());
      List<AbstractRecord> expRecords = rnaiSearch.asList();
      if (!expRecords.isEmpty()) {
        experimentRecord = (ExperimentRecord) expRecords.get(0);
      }
    }
    return experimentRecord;
  }

  @Override
  public JSONObject getResponse() throws Exception {
    if (jRNAiResults == null) {
      JSONObject jResults = executeQuery(searchType, searchResponse);

      List<JSONObject> results = new ArrayList<JSONObject>();
      if (jResults.has("results")) {
        results = jResults.getJSONArray("results").asList();
      }
      switch (searchType) {
        case GENE_IDS:
        case GENE_MIXTURE_IDS:
          PermissionManager permissionManager = new PermissionManager(getSessionUser());

          Set<ExperimentRecord> expRecords = new LinkedHashSet<ExperimentRecord>();
          for (JSONObject result : results) {
            try {
              ExperimentRecord expRecord = new ExperimentRecord(result);
              if (permissionManager.hasPermission(PermissionType.VIEW, expRecord)) {
                permissionManager.setRecordPermissions(expRecord);
                expRecords.add(expRecord);
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          sortResults(expRecords);
          jRNAiResults = createResponseJSON("experiments", expRecords);
          break;
        case EXPERIMENT_IDS:
          Set<GeneRecord> geneRecords = new LinkedHashSet<GeneRecord>();
          for (JSONObject result : results) {
            try {
              if (result.has("gene_mixture_id")) {
                geneRecords.add(new GeneMixtureRecord(result));
              } else {
                geneRecords.add(new GeneRecord(result));
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("genes", sortResults(geneRecords));
          break;
      }
      if (jResults.has("analysis") && jResults.has("result_types")) {
        jRNAiResults.put("analysis", jResults.get("analysis"));
        jRNAiResults.put("result_types", jResults.get("result_types"));
      }
    }
    return jRNAiResults;
  }

  private Collection<? extends AbstractRecord> sortResults(Collection<? extends AbstractRecord> records) {
    String primarySortResultType = null;
    for (JSONObject jResultType : getResultTypes()) {
      if (jResultType.optInt("primary_sort", -1) == 1) {
        primarySortResultType = getAnalysisTypes().get(0).optString("analysis_name", "") + ":" + jResultType.optString("result_type", "");
      }
    }
    List<? extends AbstractRecord> sortedRecords = new ArrayList<AbstractRecord>(records);
    if (primarySortResultType != null) {
      final String primarySortResultTypeKey= primarySortResultType.toUpperCase();
      Collections.sort(sortedRecords, new Comparator<AbstractRecord>() {
        public int compare(AbstractRecord r1, AbstractRecord r2) {          
          double d1= r1.optDouble(primarySortResultTypeKey, 0);
          double d2= r2.optDouble(primarySortResultTypeKey, 0);
          return Double.compare(d1, d2);
        }
      });
    }
    return sortedRecords;
  }

  @Override
  protected List<Map<String, String>> getQuery() {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    try {
      Map<String, String> value;

      StringBuilder resultTypeIDsBuffer = new StringBuilder();
      for (JSONObject jResultType : resultTypes) {
        if (resultTypeIDsBuffer.length() > 0) {
          resultTypeIDsBuffer.append(",");
        }
        resultTypeIDsBuffer.append(jResultType.getInt("result_type_id"));
      }

      switch (searchType) {
        case GENE_IDS:
          for (JSONObject jAnalysisType : analysisTypes) {
            value = new HashMap<String, String>();
            query.add(value);
            value.put("gene_id", geneID + "");
            value.put("analysis_type_id", jAnalysisType.getInt("analysis_type_id") + "");
            value.put("result_type_ids", resultTypeIDsBuffer.toString());
          }
          break;
        case GENE_MIXTURE_IDS:
          for (JSONObject jAnalysisType : analysisTypes) {
            value = new HashMap<String, String>();
            query.add(value);
            value.put("gene_mixture_id", geneMixtureID + "");
            value.put("analysis_type_id", jAnalysisType.getInt("analysis_type_id") + "");
            value.put("result_type_ids", resultTypeIDsBuffer.toString());
          }
          break;
        case EXPERIMENT_IDS:
          for (JSONObject jAnalysisType : analysisTypes) {
            value = new HashMap<String, String>();
            query.add(value);
            value.put("experiment_id", expID + "");
            value.put("analysis_type_id", jAnalysisType.getInt("analysis_type_id") + "");
            value.put("result_type_ids", resultTypeIDsBuffer.toString());
          }
          break;
        default:
          throw new IllegalArgumentException("Input type not supported- " + searchType);
      }
    } catch (Exception ex) {
      java.util.logging.Logger.getLogger(AnalysisResultsSearch.class.getName()).log(Level.SEVERE, null, ex);
    }
    return query;
  }

  @Override
  public Iterator<JSONObject> iterator() {
    JSONObject jGenes = null;
    try {
      jGenes = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jGenes != null) {
      try {
        return jGenes.getJSONArray("genes").asList().iterator();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return new ArrayList<JSONObject>().iterator();
  }

  @Override
  public List<? extends AbstractRecord> asList() {
    JSONObject jExperiments = null;
    try {
      jExperiments = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jExperiments != null) {
      try {
        return jExperiments.getJSONArray("exps").asList();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return new ArrayList<ExperimentRecord>();
  }

  @Override
  public int getCount() {
    JSONObject jExperiments = null;
    try {
      jExperiments = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jExperiments != null) {
      try {
        return jExperiments.getJSONArray("exps").length();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return 0;
  }
}
