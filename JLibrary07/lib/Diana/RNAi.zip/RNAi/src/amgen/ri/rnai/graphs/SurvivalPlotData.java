/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.graphs;

import org.apache.commons.lang.StringUtils;

/**
 *
 * @author jemcdowe
 */
public class SurvivalPlotData {
  private int rnaiID;
  private int geneID;
  private boolean isMixture;
  private String primaryGeneSymbol;
  private String barcode;
  private int wellID;
  private int experimentID;
  private double poc;

  public SurvivalPlotData(Integer rnaiID, Integer geneID, String isMixture, String primaryGeneSymbol, String barcode, Integer wellID, Integer experimentID, Double poc) {
    this.rnaiID = rnaiID;
    this.geneID = geneID;
    this.isMixture = StringUtils.equalsIgnoreCase(isMixture, "Y");
    this.primaryGeneSymbol = primaryGeneSymbol;
    this.barcode = barcode;
    this.wellID = wellID;
    this.experimentID = experimentID;
    this.poc = poc;
  }

  /**
   * @return the rnaiID
   */
  public int getRnaiID() {
    return rnaiID;
  }

  /**
   * @return the geneID
   */
  public int getGeneID() {
    return geneID;
  }

  /**
   * @return the isMixture
   */
  public boolean isMixture() {
    return isMixture;
  }

  /**
   * @return the primaryGeneSymbol
   */
  public String getPrimaryGeneSymbol() {
    return primaryGeneSymbol;
  }

  /**
   * @return the barcode
   */
  public String getBarcode() {
    return barcode;
  }

  /**
   * @return the wellID
   */
  public int getWellID() {
    return wellID;
  }

  /**
   * @return the experimentID
   */
  public int getExperimentID() {
    return experimentID;
  }

  /**
   * @return the poc
   */
  public double getPoc() {
    return poc;
  }

}
