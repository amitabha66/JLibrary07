/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.asf.bio.FastaEntry;
import amgen.ri.asf.bio.NASequence;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.align.RNAiAlignment;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdom.Element;

/**
 * Encapsulates a RNAi Record
 *
 * @author jemcdowe
 */
public class RNAiRecord extends AbstractRecord {
  public RNAiRecord(JSONObject obj) throws JSONException {
    super(obj, "rnai_id");
    setCompoundID();
    setComponents();    
    setSecondaryGeneTargets();
  }

  protected RNAiRecord(JSONObject obj, String idField) throws JSONException {
    super(obj, idField);
    setCompoundID();
    setComponents();
    setSecondaryGeneTargets();
  }
  
  private void setComponents() {
    if (has("components")) {
      try {
        List<JSONObject> jComponents= getJSONArray("components").asList();
        remove("components");        
        for(JSONObject jComponent : jComponents) {
          addToArray("components", new RNAiRecord(jComponent));
        }        
      } catch (JSONException ex) {
      }
    }
  }

  /**
   * Get the Plate Barcodes RNAiRecord
   */
  public List<String> getPlateBarcodes() {
    try {
      return getJSONArray("barcodes").asList();
    } catch (JSONException ex) {
      return new ArrayList<String>();
    }
  }

  /**
   * Sets the Plate Barcodes RNAiRecord
   */
  public void setPlateBarcodes(Collection<String> barcodes) {
    add("barcodes", new JSONArray(barcodes));
  }

  /**
   * Adds a barcode to the RNAiRecord
   *
   * @param barcode
   */
  public void addPlateBarcode(String barcode) {
    List<String> barcodes = getPlateBarcodes();
    barcodes.add(barcode);
    setPlateBarcodes(barcodes);
  }

  /**
   * @return the rnaiID
   */
  public int getRnaiID() {
    return getNumber("rnai_id").intValue();
  }

  /**
   * @return the rnaiID
   */
  public int getPrimaryGeneID() {
    return getNumber("primary_gene_id").intValue();
  }

  /**
   * Get the value of entrezgeneID
   *
   * @return the value of entrezgeneID
   */
  public int getPrimaryEntrezgeneID() {
    return getNumber("primary_entrezgene_id").intValue();
  }

  /**
   * Returns the root#lot of the record
   */
  public final String getCompoundID() {
    return getRootNumber() + "#" + getLotNumber();
  }

  /**
   * @return the root_number
   */
  public int getRootNumber() {
    return getNumber("root_number").intValue();
  }

  /**
   * @return the lot_number
   */
  public int getLotNumber() {
    return getNumber("lot_number").intValue();
  }

  /**
   * @return the substance_id
   */
  public int getSubstanceID() {
    return getNumber("substance_id").intValue();
  }

  /**
   * @return the gene symbol
   */
  public String getPrimaryGeneName() {
    return getString("primary_gene_name");
  }

  /**
   * @return the gene symbol
   */
  public String getPrimaryGeneSymbol() {
    return getString("primary_gene_symbol");
  }

  public String getPrimaryGeneDescription() {
    return getString("primary_gene_description");
  }

  public String getPrimaryGeneOrganism() {
    return getString("primary_gene_organism");
  }

  private void setCompoundID() {
    add("compound_id", getRootNumber() + "#" + getLotNumber());
  }

  private void setSecondaryGeneTargets() {
    if (has("other_gene_targets")) {
    }
  }

  /**
   * @return the compoundID
   */
  public Date getRegisteredDate() {
    try {
      return new SimpleDateFormat(AbstractResponder.JSON_DATE_PATTERN).parse(getString("registered_date"));
    } catch (ParseException ex) {
      return null;
    }
  }

  /**
   * @param compoundID the compoundID to set
   */
  public final void setRegisteredDate(Date registeredDate) {
    if (registeredDate != null) {
      add("registered_date", new SimpleDateFormat(AbstractResponder.JSON_DATE_PATTERN).format(registeredDate));
    }
  }

  /**
   * Returns is the value is a Date
   *
   * @param key
   * @return
   */
  public boolean isDate(String key) {
    return (ExtString.equals(key, "registered_date"));
  }

  /**
   * @return the rnaiType
   */
  public String getRnaiType() {
    return getString("type");
  }

  /**
   * @return the vendor
   */
  public String getVendor() {
    return getString("vendor");
  }

  /**
   * Get the value of is_mixture
   *
   * @return the value of is_mixture
   */
  public boolean isMixture() {
    return optBoolean("is_mixture");
  }

  /**
   * Set the value of is_mixture
   *
   * @param is_mixture new value of is_mixture
   */
  public void setIsMixture(boolean is_mixture) {
    add("is_mixture", is_mixture);
  }

  /**
   * Returns the components of this mixture- if any exist.
   * Returns an empty List otherwise
   */
  public List<RNAiRecord> getMixtureComponents() {
    return getList("components");
  }

  /**
   * Adds mixture components to the components List
   *
   * @param components
   */
  public void addMixtureComponents(List<RNAiRecord> components) {
    addToArray("components", components);
  }

  /**
   * @return the vendorID
   */
  public String getVendorID() {
    return getString("vendor_id");
  }

  /**
   * @return the sequence
   */
  public String getSequence() {
    return getString("sequence");
  }

  public String getBarcode() {
    return getString("barcode");
  }

  public void setBarcode(String barcode) {
    add("barcode", barcode);
  }

  public int getWellcolumn() {
    return getNumber("wellcolumn").intValue();
  }

  public void setWellcolumn(int wellcolumn) {
    add("wellcolumn", wellcolumn);
  }

  public String getWellrow() {
    return getString("wellrow");
  }

  public void setWellrow(String wellrow) {
    add("wellrow", wellrow);
  }

  /**
   * Returns the RNAi sequence as a BioSequence
   *
   * @return the sequence
   */
  public NASequence getBioSequence() {
    if (getSequence() != null) {
      return new NASequence(getSequence());
    }
    return null;
  }

  /**
   * Returns the RNAi sequence reverse complement as a BioSequence
   *
   * @return the sequence
   */
  public NASequence getReverseCompBioSequence() {
    if (getSequence() != null) {
      return new NASequence(getSequence()).reverseComplement();
    }
    return null;
  }

  /**
   * @return the sequence
   */
  public AlignmentRecord getAlignmentRecord() {
    return (AlignmentRecord) getRecord("alignment");
  }

  /**
   * @param sequence the sequence to set
   */
  public final void setAlignmentRecord(AlignmentRecord alignmentRecord) {
    add("alignment", alignmentRecord);
  }

  public FastaEntry asFastaEntry() {
    return new FastaEntry(getRecordID(), "Targets " + getPrimaryGeneSymbol(), getSequence());
  }

  public Element asXML() {
    Element el = super.asXML();
    ExtXMLElement.addAttribute(el, "rnai_id", getRnaiID() + "");
    return el;
    /*
     * Element rnaiEl = new Element("RNAI"); ExtXMLElement.addAttribute(rnaiEl,
     * "rnai_id", getRnaiID() + ""); ExtXMLElement.addElement(rnaiEl,
     * "CompoundID", getCompoundID()); ExtXMLElement.addElement(rnaiEl,
     * "RootNumber", getRootNumber() + ""); ExtXMLElement.addElement(rnaiEl,
     * "LotNumber", getLotNumber() + ""); ExtXMLElement.addElement(rnaiEl,
     * "GeneID", getGeneID() + ""); ExtXMLElement.addElement(rnaiEl,
     * "EntrezGeneID", getEntrezgeneID() + ""); ExtXMLElement.addElement(rnaiEl,
     * "GeneSymbol", getGeneSymbol()); ExtXMLElement.addElement(rnaiEl,
     * "GeneName", getGeneName()); ExtXMLElement.addElement(rnaiEl,
     * "GeneDescription", getGeneDescription());
     * ExtXMLElement.addElement(rnaiEl, "Organism", getOrganism());
     * ExtXMLElement.addElement(rnaiEl, "Type", getRnaiType()); Element vendorEl
     * = ExtXMLElement.addElement(rnaiEl, "Vendor", getVendor());
     * ExtXMLElement.addAttribute(vendorEl, "vendor_id", getVendorID());
     * ExtXMLElement.addElement(rnaiEl, "Sequence", getSequence());
     * ExtXMLElement.addElement(rnaiEl, "RegisteredDate",
     * getString("registered_date")); return rnaiEl;
     *
     */
  }
}
