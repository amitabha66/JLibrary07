package amgen.ri.rnai.screener;

import amgen.ri.rnai.ui.*;
import amgen.ri.aldi.merlin.net.ws.MerlinServicesSoap_PortType;
import amgen.ri.asf.sa.security.SecurityTokenIF;
import amgen.ri.csv.CSVReader;
import amgen.ri.excel.ExcelUtils;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.servlet.SessionLogin;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.poi.ss.SpreadsheetVersion;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import amgen.ri.util.ExtFile;

public class ScreenerResponder extends AbstractResponder implements JSONResponderIF {
  public ScreenerResponder(MainUI servletBase) {
    super(servletBase);
  }

  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    try {
      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
      MerlinServicesSoap_PortType merlinServices = getMerlinServices();
      ScreenerUpdater up = new ScreenerUpdater();
      ShrnaUpdater sh = new ShrnaUpdater();
      String action_id = this.getParameter("action_id");
      String userName = SessionLogin.getSessionLogin(this.getServletBase().getHttpServletRequest()).getUsername();
      up.setUserName(userName);
      sh.setUserName(userName);
      //System.out.println("userName.." + userName);
      if (action_id.equalsIgnoreCase("exp-load-form-items")) {
        AppServerReturnObject asro = up.getExpLoadFormItems();

        if (asro.isCallSucceed()) {
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("exp-append-form-items")) {
        AppServerReturnObject asro = up.getExpAppendFormItems();

        if (asro.isCallSucceed()) {
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("shrna-exp-load-form-items")) {

        AppServerReturnObject asro = sh.getExpLoadFormItems();

        if (asro.isCallSucceed()) {
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("get-assay")) {
        Date fromDate = null;
        Date toDate = null;
        fromDate = (this.getParameter("fromDate") == null || this.getParameter("fromDate").trim().length() == 0) ? null : sdf.parse(this.getParameter("fromDate"));
        toDate = (this.getParameter("toDate") == null || this.getParameter("toDate").trim().length() == 0) ? null : sdf.parse(this.getParameter("toDate"));
        String site = this.getParameter("site");
        //System.out.println("fromDate.." + this.getParameter("fromDate") + ":" + fromDate.toString());
        //System.out.println("toDate.." + toDate.toString());
        AppServerReturnObject asro = up.getAssay(null, null, null, fromDate, toDate, site);
        if (asro.isCallSucceed()) {
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("get-qc")) {
        Date fromDate = null;
        Date toDate = null;
        fromDate = (this.getParameter("fromDate") == null || this.getParameter("fromDate").trim().length() == 0) ? null : sdf.parse(this.getParameter("fromDate"));
        toDate = (this.getParameter("toDate") == null || this.getParameter("toDate").trim().length() == 0) ? null : sdf.parse(this.getParameter("toDate"));
        String site = this.getParameter("site");
        String assay = this.getParameter("assay");
        AppServerReturnObject asro = up.getQC(null, null, null, fromDate, toDate, assay, site);
        if (asro.isCallSucceed()) {
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("get-layer")) {
        String qckey = this.getParameter("qcName");
        String site = this.getParameter("site");
        System.out.println("qckey1:" + qckey);
        if (qckey != null && qckey.length() > 0) {
          AppServerReturnObject asro = up.getLayers(qckey, site);
          if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
          } else {
            jResponse.put("message", asro.getReturnObject());
          }
        } else {
          jResponse.put("message", "invalid input");
        }

      } else if (action_id.equalsIgnoreCase("get-fieldlist")) {
        String dtype = this.getParameter("dtype");
        System.out.println("dtype:" + dtype);
        if (dtype != null && dtype.length() > 0) {
          AppServerReturnObject asro = up.getFieldList(dtype);
          if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
          } else {
            jResponse.put("message", asro.getReturnObject());
          }
        } else {
          jResponse.put("message", "invalid input");
        }

      } else if (action_id.equalsIgnoreCase("get-rdhta")) {
        SecurityTokenIF token = new amgen.ri.asf.sa.security.SiteMinderSessionSecurityToken(SessionLogin.getSessionLogin(this.getServletBase().getHttpServletRequest()));
        String session_token = token.getToken();
        //System.out.println("session_token: " + session_token);

        AppServerReturnObject asro = up.getAnnotationRDHTA(session_token);
        if (asro.isCallSucceed()) {
          //System.out.println("success1: " + jResponse);
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          //System.out.println("failed1: " + jResponse);
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("get-rtf")) {
        String inputtype = this.getParameter("inputtype");
        String input = this.getParameter("input");
        if (input == null || input.length() == 0) {
          jResponse.put("message", "");
        } else {
          //System.out.println("Lookup cell line: " + inputtype + ":" + input);
          AppServerReturnObject asro = up.getAnnotationRTFCellLine(inputtype, input);
          if (asro.isCallSucceed()) {
            //System.out.println("success1: " + jResponse);
            jResponse = (JSONObject) asro.getReturnObject();
          } else {
            //System.out.println("failed1: " + jResponse);
            jResponse.put("message", asro.getReturnObject());
          }
        }

      } else if (action_id.equalsIgnoreCase("add-experiment")) {
        String annotation_json = this.getParameter("experiment_json");
        String table_name = this.getParameter("table_name");
        //System.out.println(table_name);
        //System.out.println(annotation_json);
        if (table_name.equalsIgnoreCase("shrna")) {
          System.out.println(table_name);

          Workbook wb = getWorkbookFromRequest("import_data_file");
          return sh.processAddExperiment(super.getLogger(), table_name, annotation_json, wb);
        } else {
          return up.processAddExperiment(super.getLogger(), table_name, annotation_json, getMerlinServices());
        }
        //jResponse.put("message", "Passed");
        //return jResponse;
      } else if (action_id.equalsIgnoreCase("append-experiment")) {
        String annotation_json = this.getParameter("experiment_json");
        String table_name = this.getParameter("table_name");
        if (table_name.equalsIgnoreCase("shrna")) {
          jResponse.put("message", "Not Supported");
        } else {
          return up.processAddExperiment(super.getLogger(), table_name, annotation_json, getMerlinServices());
        }
        //jResponse.put("message", "Passed");
        //return jResponse;
      } else if (action_id.equalsIgnoreCase("delete-experiment")) {
        String deleteIds = this.getParameter("deleteIds");
        AppServerReturnObject asro = up.deleteExperiment(deleteIds);
        if (asro.isCallSucceed()) {
          jResponse.put("message", "Passed");
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("reload-experiment")) {
        String deleteIds = this.getParameter("deleteIds");
        AppServerReturnObject asro = up.deleteExperiment(deleteIds);
        if (asro.isCallSucceed()) {
          asro = up.getExpLoadFormItems();
          if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
          } else {
            jResponse.put("message", asro.getReturnObject());
          }
        } else {
          jResponse.put("message", asro.getReturnObject());
        }

      } else if (action_id.equalsIgnoreCase("get-experiments")) {
        String deleteIds = this.getParameter("deleteIds");
        AppServerReturnObject asro = up.getExperiments();
        if (asro.isCallSucceed()) {
          //System.out.println("success1: " + jResponse);
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          //System.out.println("failed1: " + jResponse);
          jResponse.put("message", asro.getReturnObject());
        }
      } else if (action_id.equalsIgnoreCase("get-filtered-experiments")) {
        AppServerReturnObject asro = up.getFilteredExperiments();
        if (asro.isCallSucceed()) {
          //System.out.println("success1: " + jResponse);
          jResponse = (JSONObject) asro.getReturnObject();
        } else {
          //System.out.println("failed1: " + jResponse);
          jResponse.put("message", asro.getReturnObject());
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

    //System.out.println(jResponse);
    return jResponse;
  }

  public Workbook getWorkbookFromRequest(String parameterName) {
    Workbook wb = null;
    try {
      //getServletBase().printRequest();
      //System.out.println(getServletBase().getParameterNames());
      //getServletBase().printRequest();
      String fileName = getParameter(parameterName);
      if (fileName.endsWith(".csv")) {
        wb = CSVReader.toWorkbook(getServletBase().getParameterInputStream(parameterName), Charset.forName("UTF-8"), SpreadsheetVersion.EXCEL2007);
      } else {
        byte[] bytes = ExtFile.readStream(getServletBase().getParameterInputStream(parameterName));
        wb = ExcelUtils.readWorkbook(bytes);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return wb;
  }
}
