/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtString;

/**
 *
 * @author jemcdowe
 */
public class DeletePermissionRule extends AbstractPermissionRule implements PermissionRuleIF  {

  public DeletePermissionRule(PersonRecordIF requestedBy) {
    super(PermissionType.DELETE, requestedBy);
  }  

  /**
   * Check whether the requestedBy user can delete the record
   * Throws a SecurityException if not true
   *
   * @param record
   * @throws SecurityException
   */
  public void checkPermission(AbstractRecord record) throws SecurityException {
    if (!(record instanceof ExperimentRecord)) {
      throw new IllegalArgumentException("Permission requires experiment record");
    }
    ExperimentRecord expRecord = (ExperimentRecord) record;    
    if (isAdministrator()) {
      return;
    }
    if (isRequestedBy(expRecord.getUploadedByUsername())) {
      return;
    }
    throw new SecurityException("User does not have sufficient privilege to delete record");
  }
  
}
