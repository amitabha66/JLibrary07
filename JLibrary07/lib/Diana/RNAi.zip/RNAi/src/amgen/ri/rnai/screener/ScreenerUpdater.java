/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener;

import amgen.ri.aldi.merlin.net.ws.MerlinServicesLocator;
import amgen.ri.aldi.merlin.net.ws.MerlinServicesSoap_PortType;
import amgen.ri.crypt.StringEncrypter;
import amgen.ri.crypt.StringEncrypter.EncryptionException;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.screener.migrate.InsertStrInputToTempOra;
import amgen.ri.rnai.screener.migrate.LoadPlates;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.util.Debug;
import genedata.screener.api.v5.query.dto.QCSessionOverview;
import genedata.screener.api.v5.query.dto.QCSessionOverviewProperty;
import genedata.screener.api.v5.query.dto.QCSessionReportKey;
import genedata.screener.api.v5.query.dto.RepositoryInformation;
import genedata.screener.api.v5.query.interfaces.QueryService;
import genedata.screener.api.v5.query.interfaces.QueryServiceFactory;
import genedata.screener.api.v5.query.net.KeepAliveImpl;
import genedata.screener.api.v5.shared.dto.LayerInformation;
import genedata.screener.api.v5.shared.dto.PlateLayout;
import genedata.screener.api.v5.shared.dto.PlateMapping;
import genedata.screener.api.v5.shared.dto.PlateMeasurement;
import genedata.screener.api.v5.shared.interfaces.QCSessionReport;
import genedata.screener.api.v5.shared.types.WellType;
import java.awt.Point;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;
import java.rmi.Naming;
import java.sql.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.*;
import java.util.logging.Level;
import oracle.jdbc.OracleCallableStatement;
import org.apache.log4j.Logger;

public class ScreenerUpdater extends ResourceFactory {
  public String userName = "";
  public static Properties connectionProperties;
  private QueryService queryService = null;
  private KeepAliveImpl keepAlive = null;
  private QueryServiceFactory queryServiceFactory = null;
  private static final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
  private ArrayList tempTables = new ArrayList();
  private ArrayList problemPlates = new ArrayList();
  private ArrayList experimentsProcessed = new ArrayList();

  public ScreenerUpdater() {
    Properties p = new Properties();
    p.setProperty("AMA_server_host", "usam-papp-ldi01.amgen.com");
    p.setProperty("ASF_server_host", "ussf-papp-ldi01.amgen.com");
    //p.setProperty("ASF_server_host", "usto-dapp-ldi01.amgen.com");
    p.setProperty("ATO_server_host", "usto-papp-ldi01.amgen.com");
    p.setProperty("ARG_server_host", "gerb-papp-ldi01.amgen.com");
    p.setProperty("svc-aldi", "ywxpNY4Ga8c=");
    this.connectionProperties = p;

  }

  public QueryService getQueryService() {
    return this.queryService;
  }

  private QueryServiceFactory getQueryServiceFactory(Properties connectionProperties, String site) throws Exception {
    // Read the host and port from the properties
    String host = connectionProperties.getProperty(site + "_server_host");
    int port = 8081;
    // Form the url for obtaining the QueryServiceFactory
    String queryServiceFactoryURL = "rmi://" + host + ":" + port + "/" + QueryServiceFactory.QUERY_SERVICE_FACTORY_NAME;
    System.out.println(("Attempting connection to " + queryServiceFactoryURL));
    QueryServiceFactory factory = (QueryServiceFactory) Naming.lookup(queryServiceFactoryURL);
    return factory;
  }

  private void openConnection(String site) throws Exception {
    int index = 0;
    if (site == null || site.trim().length() == 0) {
      site = "ASF";
    } else if (site.equalsIgnoreCase("USSF")) {
      site = "ASF";
    } else if (site.equalsIgnoreCase("USAM")) {
      site = "AMA";
    } else if (site.equalsIgnoreCase("USTO")) {
      site = "ATO";
    } else if (site.equalsIgnoreCase("GERB")) {
      site = "ARG";
    }

    //System.out.println("Site: " + site);
    queryServiceFactory = getQueryServiceFactory(connectionProperties, site);
    RepositoryInformation[] repositories = queryServiceFactory.getRepositories();
    RepositoryInformation repository = null;
    for (int i = 0; i < repositories.length; i++) {
      repository = repositories[index];
      if (repository.getRepositoryName().equalsIgnoreCase("Default")) {
        break;
      }
    }
    String username = "svc-aldi";
    StringEncrypter encrypter = new StringEncrypter();

    String password = encrypter.decrypt(connectionProperties.getProperty(username));
    keepAlive = new KeepAliveImpl();
    queryService = queryServiceFactory.createQueryServiceWithCredentials(repository, username, password, null, keepAlive);

  }

  private void closeConnection() throws Exception {

    //System.out.println("queryService: " + queryService);
    //System.out.println("keepAlive: " + keepAlive);
    if (queryService != null) {
      queryService.logout();
    }
    if (keepAlive != null) {
      keepAlive.cancel();
    }

    //System.out.println("queryService: " + queryService);
    //System.out.println("keepAlive: " + keepAlive);
  }

  private static Date parseDateSafe(String dateString) {
    try {
      if (dateString != null) {
        return DATE_FORMAT.parse(dateString);
      } else {
        return null;
      }
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }

  private static String convertDateToString(Date _inDate, String _format) {
    Date inDate = null;
    String outString = null;
    SimpleDateFormat inDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
    SimpleDateFormat outStringFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    String inString = null;
    Date outDate = null;
    try {
      outStringFormat = new SimpleDateFormat(_format);
      inDate = inDateFormat.parse(_inDate.toString());
      outString = outStringFormat.format(inDate);
    } catch (Exception e) {
      outString = null;
    }

    return outString;
  }

  private HashMap buildWellMap() {
    HashMap wellrowMap = new HashMap();
    wellrowMap.put("1", "A");
    wellrowMap.put("2", "B");
    wellrowMap.put("3", "C");
    wellrowMap.put("4", "D");
    wellrowMap.put("5", "E");
    wellrowMap.put("6", "F");
    wellrowMap.put("7", "G");
    wellrowMap.put("8", "H");
    wellrowMap.put("9", "I");
    wellrowMap.put("10", "J");
    wellrowMap.put("11", "K");
    wellrowMap.put("12", "L");
    wellrowMap.put("13", "M");
    wellrowMap.put("14", "N");
    wellrowMap.put("15", "O");
    wellrowMap.put("16", "P");
    return wellrowMap;
  }

  private AppServerReturnObject getId(Connection conn, String seqName) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
    try {
      String queryString = "";
      queryString = "select " + seqName + ".nextval from dual";
      String seqId = "";
      Statement stmtSeqId = conn.createStatement();
      ResultSet rsSeqId = stmtSeqId.executeQuery(queryString);
      if (rsSeqId.next()) {
        seqId = Integer.toString(rsSeqId.getInt(1));
        rsSeqId.close();
        stmtSeqId.close();
        asro.setReturnObject(seqId);
        asro.setCallSucceed(true);
        return asro;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject updateExperimentCounts(Connection conn, String experiment_id) throws SQLException, IOException {
    AppServerReturnObject asro = new AppServerReturnObject("Failed updateExperimentCounts", false, null);
    try {
      String RNAi_QUERY = "begin RNAI_UTILS.UPDATEEXPERIMENTCOUNTS(?); end;";
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RNAi_QUERY);
      cs.setString(1, experiment_id);
      cs.execute();
      asro.setCallSucceed(true);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getFieldDate(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "datefield");
      jCollection.put("fieldLabel", "From Date");
      jCollection.put("name", "fromDate");
      jCollection.put("format", "m/d/Y");

      SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

      Date now = new Date(System.currentTimeMillis());
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(now);
      calendar.add(Calendar.DAY_OF_YEAR, -7);
      Date newDate = calendar.getTime();
      String ndate = dateFormat.format(newDate);

      //jCollection.put("value", "01/06/2011");
      jCollection.put("value", ndate);
      jResponse.append("items", jCollection);

      jCollection = new JSONObject();
      jCollection.put("xtype", "datefield");
      jCollection.put("fieldLabel", "To Date");
      jCollection.put("name", "toDate");
      jCollection.put("format", "m/d/Y");
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldAssay(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * Assays
       */
      JSONObject assayStoreParams = new JSONObject();
      assayStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      assayStoreParams.put("action_id", "get-assay");
      assayStoreParams.put("fromDate", "01/06/2011");
      assayStoreParams.put("toDate", "");
      assayStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("assay");

      JSONObject assayStore = new JSONObject();
      assayStore.put("xtype", "jsonstore");
      assayStore.put("id", "assay");
      assayStore.put("root", "assays");
      assayStore.put("url", "/RNAi/rnai.go");
      assayStore.put("autoLoad", false);
      assayStore.put("baseParams", assayStoreParams);
      assayStore.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", "Assay");
      jCollection.put("hiddenName", "assay");
      jCollection.put("valueField", "assay");
      jCollection.put("displayField", "assay");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select Assay");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      //jCollection.put("lazyInit", false);
      //jCollection.put("lazyRender", true);            
      jCollection.put("mode", "remote");
      jCollection.put("store", assayStore);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldQC(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * QCs
       */
      JSONObject qcStoreParams = new JSONObject();
      qcStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      qcStoreParams.put("action_id", "get-qc");
      qcStoreParams.put("assay", "AA1");
      qcStoreParams.put("fromDate", "01/06/2011");
      qcStoreParams.put("toDate", "");
      qcStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("experiment_name");
      fields.add("qc_name");
      fields.add("insert_date");
      fields.add("folder");
      fields.add("keystr");
      fields.add("valstr");

      JSONObject qcStore = new JSONObject();
      qcStore.put("xtype", "jsonstore");
      qcStore.put("id", "keystr");
      qcStore.put("root", "qc");
      qcStore.put("url", "/RNAi/rnai.go");
      qcStore.put("autoLoad", false);
      qcStore.put("baseParams", qcStoreParams);
      qcStore.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("listWidth", "750");
      jCollection.put("fieldLabel", "QCName");
      jCollection.put("hiddenName", "qcName");
      jCollection.put("valueField", "keystr");
      jCollection.put("displayField", "valstr");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select QC");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("mode", "remote");
      jCollection.put("store", qcStore);

      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldLayer(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * Assays
       */
      JSONObject layerStoreParams = new JSONObject();
      layerStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      layerStoreParams.put("action_id", "get-layer");
      layerStoreParams.put("qc_name", "");
      layerStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("layerName");

      JSONObject layerStore = new JSONObject();
      layerStore.put("xtype", "jsonstore");
      layerStore.put("id", "layerName");
      layerStore.put("root", "layers");
      layerStore.put("url", "/RNAi/rnai.go");
      layerStore.put("autoLoad", false);
      layerStore.put("baseParams", layerStoreParams);
      layerStore.put("fields", fields);

      jCollection = new JSONObject();
      //jCollection.put("xtype", "combo");
      jCollection.put("xtype", "lovcombo");
      jCollection.put("listWidth", "750");
      jCollection.put("fieldLabel", "Layer");
      jCollection.put("hiddenName", "layerName");
      jCollection.put("valueField", "layerName");
      jCollection.put("displayField", "layerName");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select Layer");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("mode", "remote");
      jCollection.put("store", layerStore);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldExperiment(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * Assays
       */
      JSONObject expStoreParams = new JSONObject();
      expStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      expStoreParams.put("action_id", "get-filtered-experiments");
      expStoreParams.put("fromDate", "01/06/2011");
      expStoreParams.put("toDate", "");

      ArrayList fields = new ArrayList();
      fields.add("experiment_name");
      fields.add("experiment_id");

      JSONObject expStore = new JSONObject();
      expStore.put("xtype", "jsonstore");
      expStore.put("id", "experiment_id");
      expStore.put("root", "exps");
      expStore.put("url", "/RNAi/rnai.go");
      expStore.put("autoLoad", false);
      expStore.put("baseParams", expStoreParams);
      expStore.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("listWidth", "750");
      jCollection.put("fieldLabel", "Experiment to append");
      jCollection.put("hiddenName", "experiment_id");
      jCollection.put("valueField", "experiment_id");
      jCollection.put("displayField", "experiment_name");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select Experiment");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      //jCollection.put("lazyInit", false);
      //jCollection.put("lazyRender", true);            
      jCollection.put("mode", "remote");
      jCollection.put("store", expStore);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldList(String fieldName) throws Exception {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jResponse = new JSONObject();

      ArrayList<String> values = new ArrayList();
      if (fieldName.equalsIgnoreCase("visibility")) {
        values.add("Public");
        values.add("Private");
      } else if (fieldName.equalsIgnoreCase("status")) {
        values.add("Valid");
        values.add("Invalid");
      } else if (fieldName.equalsIgnoreCase("site")) {
        values.add("ARG");
        values.add("ASF");
      }
      for (String key : values) {
        JSONObject jCollection = new JSONObject();
        jCollection.put(fieldName, key.toString());
        jResponse.append("results", jCollection);
      }
      //System.out.println(jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }

    return asro;
  }

  public AppServerReturnObject getField(JSONObject jResponse, String fieldName) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-fieldlist");
      storeParams.put("dtype", fieldName);

      ArrayList fields = new ArrayList();
      fields.add(fieldName);

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", fieldName);
      store.put("root", "results");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", fieldName);
      jCollection.put("hiddenName", fieldName);
      jCollection.put("valueField", fieldName);
      jCollection.put("displayField", fieldName);
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select " + fieldName);
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getAnnotationCollectionSource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.CollectionResponder");
      storeParams.put("action_id", "get-collection");

      ArrayList fields = new ArrayList();
      fields.add("collection_id");
      fields.add("collection_name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "collection_id");
      store.put("root", "collection");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("listWidth", "250");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "collection_id");
      jCollection.put("displayField", "collection_name");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRDHTASource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-rdhta");

      ArrayList fields = new ArrayList();
      fields.add("value");
      fields.add("label");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "value");
      store.put("root", "options");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "value");
      jCollection.put("displayField", "label");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationOptionSource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.AnnotationResponder");
      storeParams.put("action_id", "get-annotation-option");
      storeParams.put("annotation_id", annotation_id);

      ArrayList fields = new ArrayList();
      fields.add("annotation_option_id");
      fields.add("annotation_option_name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "annotation_option_id");
      store.put("root", "annotationoptions");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "annotation_option_id");
      jCollection.put("displayField", "annotation_option_name");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRDHTA(String sessionToken) {
    //System.out.println("Coming here");
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      /*
       * InetAddress addr = InetAddress.getLocalHost();
       * System.out.println("Coming11 here");
       * String hostName = addr.getHostName();
       * ServiceDetails serviceDetail = null;
       * if (System.getProperty("os.name").indexOf("Windows") >= 0) {
       * System.out.println("Coming12 here");
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * System.out.println("Coming12end here" + serviceDetail);
       * } else {
       * if (hostName.indexOf("papp") > 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * } else if (hostName.indexOf("tapp") > 0 || hostName.indexOf("stampy")
       * >= 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.TEST_UDDIDETAILS,
       * "6045c732-0bb9-4ff4-9331-bb2ddfc2d241");
       * } else if (hostName.indexOf("dapp") > 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.DEV_UDDIDETAILS,
       * "19812123-2ad1-48c9-afcc-410a08029f4c");
       * } else {
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * }
       *
       * }
       * System.out.println("Coming1 here");
       *
       * serviceDetail.addSecurityToken(new
       * SiteMinderSessionSecurityToken(sessionToken));
       *
       * serviceDetail.setServiceCallTimeout(960000);
       * serviceDetail.setParameterValue("lookUpTableName", "TherapeuticArea");
       * serviceDetail.setParameterValue("lookUpValue", "%");
       * serviceDetail.setParameterValue("obsolete", "false");
       * Document doc = serviceDetail.executeService2JDocument("List XSD");
       * System.out.println("Coming2 here");
       * Element root = doc.getRootElement();
       * Element selection = root.getChild("Selection");
       * List options = selection.getChildren("Option");
       *
       * JSONObject jResponse = new JSONObject();
       * System.out.println("Options size: " + options.size());
       * for (int i = 0; i < options.size(); i++) {
       * Element curoption = (Element) options.get(i);
       * String label = curoption.getChild("Label").getText();
       * String value = curoption.getChild("Value").getText();
       * JSONObject jCollection = new JSONObject();
       * jCollection.put("value", value);
       * jCollection.put("label", label);
       * jResponse.append("options", jCollection);
       * }
       */
      ArrayList values = new ArrayList();
      values.add("Bone");
      values.add("General Medicine");
      values.add("Hematology");
      values.add("Hematology/Oncology");
      values.add("Inflammation");
      values.add("Metabolic Disorders");
      values.add("Nephrology");
      values.add("Oncology");
      values.add("Oncology Therapeutics");
      values.add("Oncology-Supportive");
      values.add("Unknown");
      values.add("Not Applicable");

      JSONObject jResponse = new JSONObject();
      for (int i = 0; i < values.size(); i++) {
        String label = (String) values.get(i);
        String value = (String) values.get(i);
        JSONObject jCollection = new JSONObject();
        jCollection.put("value", value);
        jCollection.put("label", label);
        jResponse.append("options", jCollection);
      }

      //System.out.println("jResponse: " + jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      System.out.println("Coming to exception");
      e.printStackTrace();

    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRTFCellLine(String inputtype, String input) {
    //System.out.println("Coming here");
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String result = "";
      if (inputtype.equalsIgnoreCase("cellline")) {
        Authenticator.setDefault(new Authenticator() {
          @Override
          public PasswordAuthentication getPasswordAuthentication() {
            try {
              Properties rgAccountProperties = getRGServiceAccountProperties();
              String username = rgAccountProperties.getProperty("http.serviceaccount.domain") + "\\" + rgAccountProperties.getProperty("http.serviceaccount.username");
              return new PasswordAuthentication(username, new StringEncrypter().decrypt(rgAccountProperties.getProperty("http.serviceaccount.password")).toCharArray());
            } catch (EncryptionException ex) {
              java.util.logging.Logger.getLogger(ScreenerUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
          }
        });
        String url = "http://rtf.amgen.com/rtf/REST/json/term/5806296/terms;suggest=" + input + "?max_results=500";
        URL link = new URL(url);
        URLConnection yc = link.openConnection();
        //System.out.println("Authentication: " + authinstance.getPasswordAuthentication().getUserName());

        //System.out.println("URL:" + url + "\nLink: " + link + "\nUConnection: " + yc.getInputStream());
        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        //System.out.println("in:" + in);
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
          result = result + inputLine;
        }

      }
      JSONObject jResponse = new JSONObject();
      if (ExtJSON.isJSON(result)) {
        jResponse = (JSONObject) ExtJSON.toJSON(result);
      } else {
        asro.setCallSucceed(false);
        return asro;
      }
      //System.out.println("jResponse: " + jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      System.out.println("Coming to exception");
      e.printStackTrace();

    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRTFCellLine(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {
      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-rtf");
      storeParams.put("inputtype", "cellline");
      storeParams.put("input", "");

      ArrayList fields = new ArrayList();
      fields.add("id");
      fields.add("name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "id");
      store.put("root", "term");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "id");
      jCollection.put("displayField", "name");
      jCollection.put("autoLoad", true);
      jCollection.put("triggerAction", "all");
      jCollection.put("minChars", "2");
      jCollection.put("forceSelection", true);
      jCollection.put("allowBlank", false);
      jCollection.put("emptyText", "Select ");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("editable", true);
      jCollection.put("mode", "remote");
      jCollection.put("typeAhead", true);
      jCollection.put("selectOnFocus", true);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationGroupFields(Connection conn, String annotation_group_name, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String queryString = "select * from annotation a, annotation_group ag " + "\n"
              + "where a.rnai_type_id = 1 and a.annotation_group_id = ag.annotation_group_id " + "\n"
              + "and annotation_group_name = '" + annotation_group_name + "' " + "\n"
              + "order by display_order asc";

      //System.out.println(queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        String annotation_name = rs.getString("annotation_name");
        String annotation_id = rs.getString("annotation_id");
        String source = rs.getString("source");
        String action = "";
        if (source == null || source.length() == 0 || source.equalsIgnoreCase("annotation_options")) {
          asro = this.getAnnotationOptionSource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("FREE_TEXT")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "textfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_DATE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "datefield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jCollection.put("format", "m/d/Y");
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_DOUBLE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "numberfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("allowDecimals", true);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_INTEGER")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "numberfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("allowDecimals", false);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("RTF_CELLLINE")) {
          asro = this.getAnnotationRTFCellLine(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("RTF_TISSUE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "field");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("disabled", true);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("COLLECTIONS")) {
          asro = this.getAnnotationCollectionSource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("RDH_TA")) {
          asro = this.getAnnotationRDHTASource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "field");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        }
      }
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getExpAppendFormItems() {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection("RNAI_INDEX");

      JSONObject jResponse = new JSONObject();

      JSONObject annotategroupAQC0 = new JSONObject();
      annotategroupAQC0.put("xtype", "fieldset");
      jResponse.append("items", annotategroupAQC0);

      JSONObject AQC = new JSONObject();
      AQC.put("xtype", "fieldset");
      AQC.put("title", "Screener Information");
      AQC.put("border", false);
      annotategroupAQC0.append("items", AQC);

      asro = this.getFieldDate(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getField(AQC, "Site");
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldAssay(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldQC(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldLayer(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldExperiment(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      System.out.println(jResponse);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public AppServerReturnObject getExpLoadFormItems() {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection("RNAI_INDEX");

      JSONObject jResponse = new JSONObject();

      JSONObject annotategroupAQC0 = new JSONObject();
      annotategroupAQC0.put("xtype", "fieldset");
      annotategroupAQC0.put("layout", "column");
      jResponse.append("items", annotategroupAQC0);

      JSONObject AQC = new JSONObject();
      AQC.put("xtype", "fieldset");
      AQC.put("title", "Screener Information");
      AQC.put("columnWidth", .5);
      AQC.put("border", false);
      annotategroupAQC0.append("items", AQC);

      asro = this.getFieldDate(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getField(AQC, "Site");
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldAssay(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldQC(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = this.getFieldLayer(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      /*
       * asro = this.getField(AQC, "Visibility");
       * if (!asro.isCallSucceed()) {
       * return asro;
       * }
       *
       * asro = this.getField(AQC, "Status");
       * if (!asro.isCallSucceed()) {
       * return asro;
       * }
       */
      JSONObject annotategroup0 = new JSONObject();
      annotategroup0.put("xtype", "fieldset");
      annotategroup0.put("title", "Transfection Conditions");
      annotategroup0.put("columnWidth", .5);
      annotategroup0.put("border", false);
      annotategroupAQC0.append("items", annotategroup0);

      asro = getAnnotationGroupFields(conn, "Transfection Conditions", annotategroup0);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      JSONObject annotategroup12 = new JSONObject();
      annotategroup12.put("xtype", "fieldset");
      annotategroup12.put("layout", "column");
      jResponse.append("items", annotategroup12);

      JSONObject annotategroup1 = new JSONObject();
      annotategroup1.put("xtype", "fieldset");
      annotategroup1.put("title", "Cell Line Information");
      annotategroup1.put("columnWidth", .5);
      annotategroup1.put("border", false);
      annotategroup12.append("items", annotategroup1);

      asro = getAnnotationGroupFields(conn, "Cell Line Information", annotategroup1);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      JSONObject annotategroup2 = new JSONObject();
      annotategroup2.put("xtype", "fieldset");
      annotategroup2.put("title", "Experiment Information");
      annotategroup2.put("columnWidth", .5);
      annotategroup2.put("border", false);
      annotategroup12.append("items", annotategroup2);

      asro = getAnnotationGroupFields(conn, "Experiment Information", annotategroup2);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      JSONObject annotategroup34 = new JSONObject();
      annotategroup34.put("xtype", "fieldset");
      annotategroup34.put("layout", "column");
      jResponse.append("items", annotategroup34);

      JSONObject annotategroup3 = new JSONObject();
      annotategroup3.put("xtype", "fieldset");
      annotategroup3.put("title", "Cryopreservation Information");
      annotategroup3.put("columnWidth", .5);
      annotategroup3.put("border", false);
      annotategroup34.append("items", annotategroup3);

      asro = getAnnotationGroupFields(conn, "Cryopreservation Information", annotategroup3);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      JSONObject annotategroup4 = new JSONObject();
      annotategroup4.put("xtype", "fieldset");
      annotategroup4.put("title", "Media Conditions");
      annotategroup4.put("columnWidth", .5);
      annotategroup4.put("border", false);
      annotategroup34.append("items", annotategroup4);

      asro = getAnnotationGroupFields(conn, "Media Conditions", annotategroup4);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      //System.out.println(jResponse);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public AppServerReturnObject getQC(String folderName, String experimentName,
          String targetCreator, Date targetDateMin, Date targetDateMax, String targetCorporateID, String isite) throws Exception {
    //System.out.println(folderName + "\n" + targetCorporateID);
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      if (isite == null || isite.length() == 0) {
        asro.setCallSucceed(false);
        return asro;
      }
      openConnection(isite);
      QCSessionOverview qcOverview = queryService.getQCSessionOverview();
      List<QCSessionReportKey> keys = new ArrayList<QCSessionReportKey>();
      List<QCSessionReportKey> allKeys = qcOverview.getHeadRevisionQCSessionReportKeys();
      for (QCSessionReportKey qcKey : allKeys) {

        if (experimentName != null) {
          String ename = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.EXPERIMENT_NAME);
          if (ename.equals(experimentName) == false) {
            continue;
          }
        }

        if (folderName != null) {
          String folder = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.PROJECT_FOLDER);
          //if (folder.equals(folderName) == false) {
          if (!folder.contains("siRNA")) {
            continue;
          }
        }
        if (targetCreator != null) {
          String creator = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CREATOR);
          if (creator.equals(targetCreator) == false) {
            continue;
          }
        }
        if (targetDateMin != null || targetDateMax != null) {
          Date dateOfCreation = (Date) qcOverview.getValue(qcKey, QCSessionOverviewProperty.DATE_OF_CREATION);
          if (targetDateMin != null && dateOfCreation.compareTo(targetDateMin) < 0) {
            continue;
          }
          if (targetDateMax != null && dateOfCreation.compareTo(targetDateMax) > 0) {
            continue;
          }
        }
        if (targetCorporateID != null) {
          String corporateId = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CORPORATE_ID);
          if (targetCorporateID.equals(corporateId) == false) {
            continue;
          }
        }

        String visibility = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.VISIBILITY);
        if (targetCreator != null && !visibility.equalsIgnoreCase("public")) {
          String creator = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CREATOR);
          if (creator.equals(targetCreator) == false
                  && !targetCreator.equalsIgnoreCase("jayanthi")
                  && !targetCreator.equalsIgnoreCase("nenkler")
                  && !targetCreator.equalsIgnoreCase("jannah")
                  && !targetCreator.equalsIgnoreCase("ingleh")
                  && !targetCreator.equalsIgnoreCase("donea")
                  && !targetCreator.equalsIgnoreCase("bharathr")) {
            continue;
          }
        }

        keys.add(qcKey);
      }

      Collections.sort(keys,
              new Comparator() {
                public int compare(Object left, Object right) {
                  QCSessionReportKey leftKey = (QCSessionReportKey) left;
                  QCSessionReportKey rightKey = (QCSessionReportKey) right;
                  String leftKeyStr = leftKey.getQCSessionName() + ":" + leftKey.getExperimentName() + ":" + leftKey.getInsertDate().getTime() + ":" + leftKey.getFolderName();
                  String rightKeyStr = rightKey.getQCSessionName() + ":" + rightKey.getExperimentName() + ":" + rightKey.getInsertDate().getTime() + ":" + rightKey.getFolderName();
                  return leftKeyStr.compareTo(rightKeyStr);

                }
              });

      JSONObject jResponse = new JSONObject();
      for (QCSessionReportKey key : keys) {
        String keystr = key.getExperimentName() + ":" + key.getQCSessionName() + ":" + key.getInsertDate().getTime() + ":" + key.getFolderName();
        //String valstr = key.getFolderName() + "/" + key.getExperimentName() + "/" + key.getQCSessionName() + "/" + key.getInsertDate();
        String valstr = key.getQCSessionName() + "/" + key.getExperimentName() + "/" + key.getFolderName() + "/" + key.getInsertDate().getTime();

        JSONObject jCollection = new JSONObject();
        jCollection.put("experiment_name", key.getExperimentName());
        jCollection.put("qc_name", key.getQCSessionName());
        jCollection.put("insert_date", key.getInsertDate().getTime());
        jCollection.put("folder", key.getFolderName());

        jCollection.put("keystr", keystr);
        jCollection.put("valstr", valstr);
        jResponse.append("qc", jCollection);
      }
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      closeConnection();
    }

    return asro;
  }

  public AppServerReturnObject getLayers(String qcKey, String site) throws Exception {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jResponse = new JSONObject();
      if (site == null || site.length() == 0) {
        asro.setCallSucceed(false);
        return asro;
      }
      this.openConnection(site);
      ArrayList<String> keys = new ArrayList();
      String[] pkeys = qcKey.split(":");
      if (pkeys.length == 4) {
        String experimentName = pkeys[0];
        String sessionName = pkeys[1];
        String dateLong = pkeys[2];
        String folderName = pkeys[3];
        System.out.println("InputKey: " + folderName + "/" + experimentName + "/" + sessionName + "/" + dateLong);
        QCSessionReportKey qckey = new QCSessionReportKey(experimentName, sessionName, new Date(Long.parseLong(dateLong)), folderName);
        QCSessionReport qcReport = getQueryService().getQCSessionReport(qckey);
        LayerInformation[] layers = qcReport.getLayerInformation();
        for (int i = 0; i < layers.length; i++) {
          keys.add(layers[i].getLayerName());
        }
        System.out.println("Layers added: " + keys.size());
        Collections.sort(keys);
        for (String key : keys) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("layerName", key.toString());
          jResponse.append("layers", jCollection);
        }

      }
      //System.out.println(jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        this.closeConnection();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }

    return asro;
  }

  public AppServerReturnObject getAssay(String folderName, String experimentName,
          String targetCreator, Date targetDateMin, Date targetDateMax, String isite) throws Exception {

    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      System.out.println("calling getAssay: " + isite);
      if (isite == null || isite.length() == 0) {
        asro.setCallSucceed(false);
        return asro;
      }
      openConnection(isite);
      QCSessionOverview qcOverview = queryService.getQCSessionOverview();
      List<Integer> keys = new ArrayList<Integer>();
      List<QCSessionReportKey> allKeys = qcOverview.getHeadRevisionQCSessionReportKeys();
      for (QCSessionReportKey qcKey : allKeys) {

        if (experimentName != null) {
          String ename = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.EXPERIMENT_NAME);
          if (ename.equals(experimentName) == false) {
            continue;
          }
        }

        if (folderName != null) {
          String folder = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.PROJECT_FOLDER);
          //if (folder.equals(folderName) == false) {
          if (!folder.contains("siRNA")) {
            continue;
          }
        }
        if (targetCreator != null) {
          String creator = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CREATOR);
          if (creator.equals(targetCreator) == false) {
            continue;
          }
        }
        if (targetDateMin != null || targetDateMax != null) {
          Date dateOfCreation = (Date) qcOverview.getValue(qcKey, QCSessionOverviewProperty.DATE_OF_CREATION);
          if (targetDateMin != null && dateOfCreation.compareTo(targetDateMin) < 0) {
            continue;
          }
          if (targetDateMax != null && dateOfCreation.compareTo(targetDateMax) > 0) {
            continue;
          }
        }

        String visibility = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.VISIBILITY);
        if (targetCreator != null && !visibility.equalsIgnoreCase("public")) {
          String creator = (String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CREATOR);
          if (creator.equals(targetCreator) == false
                  && !targetCreator.equalsIgnoreCase("jayanthi")
                  && !targetCreator.equalsIgnoreCase("nenkler")
                  && !targetCreator.equalsIgnoreCase("jannah")
                  && !targetCreator.equalsIgnoreCase("ingleh")
                  && !targetCreator.equalsIgnoreCase("donea")
                  && !targetCreator.equalsIgnoreCase("bharathr")) {
            continue;
          }
        }

        String code = ((String) qcOverview.getValue(qcKey, QCSessionOverviewProperty.CORPORATE_ID)).trim();
        String cc = code.substring(2);
        if (!keys.contains(new Integer(cc))) {
          keys.add(new Integer(cc));
        }
      }

      Collections.sort(keys);

      JSONObject jResponse = new JSONObject();
      for (Integer key : keys) {
        JSONObject jCollection = new JSONObject();
        jCollection.put("assay", "AA" + key.toString());
        jResponse.append("assays", jCollection);
      }
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      closeConnection();
    }

    return asro;
  }

  public JSONObject processAddExperiment(Logger logger, String tableName, String addJSONString, MerlinServicesSoap_PortType merlinServices) throws Exception {

    JSONObject jResponse = new JSONObject();
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    if (tableName.equalsIgnoreCase("screener")) {
      asro = addScreenerExperiment(addJSONString, merlinServices);
    }
    if (asro.isCallSucceed()) {
      jResponse.put("message", "Passed");
    } else {

      jResponse.put("message", asro.getComment());
    }
    //System.out.println(jResponse);
    logger.debug(jResponse);
    return jResponse;
  }

  private AppServerReturnObject addScreenerExperiment(String addJSONString, MerlinServicesSoap_PortType merlinServices) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;

    System.out.println("Loading data:\n" + addJSONString);
    try {
      if (!ExtJSON.isJSON(addJSONString)) {
        asro.setCallSucceed(false);
        asro.setComment("Invalid JSON string: " + addJSONString);
      }
      conn = new OraSQLManager().getConnection("RNAI_INDEX");

      JSONObject jo = (JSONObject) ExtJSON.toJSON(addJSONString);
      HashMap annotations = new HashMap();
      Map form_elements = jo.asMap();

      String visibility = (String) form_elements.get("Visibility");
      String status = (String) form_elements.get("Status");
      String site = (String) form_elements.get("Site");
      String append_experiment_id = null;
      if (form_elements.containsKey("experiment_id")) {
        append_experiment_id = (String) form_elements.get("experiment_id");
      }
      this.openConnection(site);

      String qcName = (String) form_elements.get("qcName");
      List layers = null;
      String layerName = (String) form_elements.get("layerName");
      if (layerName != null) {
        String[] layersStr = layerName.split(",");
        layers = Arrays.asList(layersStr);
      }
      Iterator it = form_elements.keySet().iterator();
      while (it.hasNext()) {
        String key = (String) it.next();
        System.out.println("key: " + key);
        String value = (String) form_elements.get(key);
        if (key.startsWith("AN__")) {
          annotations.put(key.substring(4), value);
        }
      }

      String[] pkeys = qcName.split(":");
      if (pkeys.length == 4) {
        String experimentName = pkeys[0];
        String sessionName = pkeys[1];
        String dateLong = pkeys[2];
        String folderName = pkeys[3];
        System.out.println("InputKey: " + folderName + "/" + experimentName + "/" + sessionName + "/" + dateLong);
        QCSessionReportKey qckey = new QCSessionReportKey(experimentName, sessionName, new Date(Long.parseLong(dateLong)), folderName);
        asro = Load(conn, site, append_experiment_id, qckey, layers, visibility, status, annotations, merlinServices);
        if (!asro.isCallSucceed()) {
          return asro;
        }

      } else {
        asro.setCallSucceed(false);
        asro.setComment("Invalid QC Identifier");
        return asro;
      }
      System.out.println("Loading completed");
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      asro.setCallSucceed(false);
      e.printStackTrace();
      try {
        conn.rollback();
      } catch (Exception e1) {
      }
    } finally {
      OraSQLManager.closeResources(conn);
      try {
        this.closeConnection();
      } catch (Exception e) {
        e.printStackTrace();
      }

    }
    return asro;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  private AppServerReturnObject Load(Connection conn, String site, String append_experiment_id, QCSessionReportKey qckey, List layers, String visibility, String status, HashMap annotations, MerlinServicesSoap_PortType merlinServices) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed in inserting data", false, null);

    try {
      System.out.println("Experiment to append to: " + append_experiment_id);
      conn.setAutoCommit(false);
      String psql_exp = "insert into experiment(experiment_id, EXPERIMENT_NAME, upload_person, upload_date, visibility, status) values (?,?,?,sysdate,?,?)";
      PreparedStatement pstmt_exp = conn.prepareStatement(psql_exp);

      String psql_exp_scr = "insert into experiment_screener(experiment_id, SITE, ASSAY_CODE, EXPERIMENT, FOLDER, QC_NAME, QC_DATE_LONG,QC_OWNER, QC_DATE, LAYER) values (?,?,?,?,?,?,?,?,?,?)";
      PreparedStatement pstmt_exp_scr = conn.prepareStatement(psql_exp_scr);

      Statement stmt_plate = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      Statement stmt_well = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      Statement stmt_annotations = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

      QCSessionReport qcReport = getQueryService().getQCSessionReport(qckey);

      asro = LoadExpPlateWell(conn, site, append_experiment_id, qckey, qcReport, layers, visibility, status, pstmt_exp, pstmt_exp_scr, stmt_plate, stmt_well, stmt_annotations, annotations, merlinServices);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      int[] updateCountsExp = null;
      if (append_experiment_id == null) {
        updateCountsExp = pstmt_exp.executeBatch();
        System.out.println("Experiment query executed: " + updateCountsExp.length);
      }

      int[] updateCountsExpScr = pstmt_exp_scr.executeBatch();
      System.out.println("Experiment Screener query executed: " + updateCountsExpScr.length);
      int[] updateCountsPlate = stmt_plate.executeBatch();
      System.out.println("Experiment Plate query executed: " + updateCountsPlate.length);
      int[] updateCountsAnnotations = null;
      if (append_experiment_id == null) {
        updateCountsAnnotations = stmt_annotations.executeBatch();
        System.out.println("Experiment Annotation query executed: " + updateCountsAnnotations.length);
      }
      int[] updateCountsWell = stmt_well.executeBatch();
      System.out.println("Experiment well query executed: " + updateCountsWell.length);

      pstmt_exp.close();
      pstmt_exp_scr.close();
      stmt_plate.close();
      stmt_annotations.close();
      stmt_well.close();

      if (updateCountsExp != null && updateCountsExp.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("No of experiments loaded is 0");
        return asro;
      } else if (updateCountsExpScr.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("No of Screener experiments loaded is 0");
        return asro;
      } else if (updateCountsPlate.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("No of Screener plates loaded is 0");
        return asro;
      } else if (updateCountsAnnotations != null && updateCountsAnnotations.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("No of annotaions loaded is 0, Collection annotation is a required annotation");
        return asro;
      } else if (updateCountsWell.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("No of wells loaded is 0");
        return asro;
      }

      conn.commit();
      for (int i = 0; i < this.experimentsProcessed.size(); i++) {
        String experiment_id = (String) experimentsProcessed.get(i);
        asro = this.updateExperimentCounts(conn, experiment_id);
        if (!asro.isCallSucceed()) {
          asro.setCallSucceed(false);
          asro.setComment("Experiment count update failed: " + experiment_id);
          return asro;
        }
      }

      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      asro.setCallSucceed(false);
      asro.setComment("Loading failed.");
      e.printStackTrace();
    } finally {
    }

    return asro;
  }

  private AppServerReturnObject LoadExpScreener(Connection conn, PreparedStatement pstmt_exp_scr, String site, String experiment_id, String layerName, String visibility, String status, QCSessionReportKey qckey, QCSessionReport qcReport) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);;

    try {

      String assay_code = qcReport.getQCSessionInformation().getCorporateIdentifier();
      String screener_experiment = qckey.getExperimentName();
      String screener_folder = qckey.getFolderName();
      String qc_session_name = qckey.getQCSessionName();
      long dateInLong = qckey.getInsertDate().getTime();
      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
      String dateInStr = sdf.format(qckey.getInsertDate());
      String qc_owner = qcReport.getQCSessionInformation().getOwner();

      pstmt_exp_scr.setString(1, experiment_id);
      pstmt_exp_scr.setString(2, site);
      pstmt_exp_scr.setString(3, assay_code);
      pstmt_exp_scr.setString(4, screener_experiment);
      pstmt_exp_scr.setString(5, screener_folder);
      pstmt_exp_scr.setString(6, qc_session_name);
      pstmt_exp_scr.setString(7, Long.toString(dateInLong));
      pstmt_exp_scr.setString(8, qc_owner);
      pstmt_exp_scr.setDate(9, new java.sql.Date(dateInLong));
      pstmt_exp_scr.setString(10, layerName);

      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject LoadExp(Connection conn, PreparedStatement pstmt_exp, String experiment_id, String layerName, String visibility, String status, QCSessionReportKey qckey, QCSessionReport qcReport) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);;

    try {
      String qc_session_name = qcReport.getQCSessionInformation().getQCSessionName();
      String assay_code = qcReport.getQCSessionInformation().getCorporateIdentifier();
      String qc_owner = qcReport.getQCSessionInformation().getOwner();
      String qc_date = convertDateToString(qcReport.getQCSessionInformation().getCreationDate(), "MM/dd/yyyy");
      String screener_folder = qcReport.getQCSessionInformation().getFolderName();
      String screener_experiment = qcReport.getQCSessionInformation().getExperimentName();

      pstmt_exp.setString(1, experiment_id);
      pstmt_exp.setString(2, qc_session_name + "_" + layerName);
      pstmt_exp.setString(3, this.userName);
      pstmt_exp.setString(4, "Private");
      pstmt_exp.setString(5, "Valid");

      asro.setCallSucceed(true);

      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject CheckScreenerExp(Connection conn, String site, String layerName, QCSessionReportKey qckey, QCSessionReport qcReport) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);;

    try {

      String qc_session_name = qckey.getQCSessionName();
      String assay_code = qcReport.getQCSessionInformation().getCorporateIdentifier();
      String screener_folder = qckey.getFolderName();
      String screener_experiment = qckey.getExperimentName();
      long dateInLong = qckey.getInsertDate().getTime();
      SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
      String dateInStr = sdf.format(qckey.getInsertDate());
      String queryString = "select * from experiment_screener where " + ""
              + "site = '" + site + "'"
              + " and assay_code = '" + assay_code + "'"
              + " and experiment = ?"
              + " and folder = ?"
              + " and qc_name = ?"
              + " and qc_date = to_date('" + dateInStr + "','MM/dd/yyyy')"
              + " and layer = ?";

      System.out.println("Check if already loaded: " + queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ps.setString(1, screener_experiment);
      ps.setString(2, screener_folder);
      ps.setString(3, qc_session_name);
      ps.setString(4, layerName);
      ResultSet rs = ps.executeQuery();
      String experiment_id = null;
      if (rs.next()) {
        experiment_id = rs.getString("experiment_id");
      }
      asro.setCallSucceed(true);
      asro.setReturnObject(experiment_id);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject LoadExpAnnotations(Connection conn, Statement stmt_annotations, String experiment_id, HashMap annotations) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {
      Iterator it = annotations.keySet().iterator();
      while (it.hasNext()) {
        asro = getId(conn, "RNAI_result");
        if (!asro.isCallSucceed()) {
          return asro;
        }
        String result_id = (String) asro.getReturnObject();
        String annotation_name = (String) it.next();
        String actual_annotation_name = annotation_name.replaceAll("_SPACE_", " ");
        String value = (String) annotations.get(annotation_name);
        String insert = "insert into EXPERIMENT_ANNOTATION_VALUE(EXPERIMENT_ANNOTATION_VALUE_id, experiment_id, annotation_id, value) "
                + "values(" + result_id + "," + experiment_id + ","
                + "(select annotation_id from annotation where rnai_type_id = 1  and annotation_name = '" + actual_annotation_name + "')" + ","
                + "'" + value + "')";
        System.out.println(insert);
        stmt_annotations.addBatch(insert);
      }
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject getParentBarcode(String child_barcode, MerlinServicesSoap_PortType merlinServices) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      System.out.println(merlinServices + "\n" + child_barcode);
      String[] parent_barcodes = merlinServices.getParentPlateBarcodes(child_barcode);
      if (parent_barcodes.length == 0) {
        asro.setCallSucceed(false);
        asro.setComment("Unable to find barcode for: " + child_barcode);
        return asro;
      } else if (parent_barcodes.length > 1) {
        asro.setCallSucceed(false);
        asro.setComment("More than one parent barcode for: " + child_barcode);
        return asro;
      } else {
        asro.setCallSucceed(true);
        asro.setReturnObject(parent_barcodes[0]);
        return asro;
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject deleteExperiment(String deleteIds) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      //System.out.println(tableName);
      //System.out.println(deleteIds);
      conn = new OraSQLManager().getConnection("RNAI_INDEX");
      Statement stmt_gruop_annotation = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      String updateQ = "";

      updateQ = "DELETE FROM RNAI_INDEX.ANALYSIS_RESULTS WHERE ANALYSIS_ID IN (SELECT ANALYSIS_ID FROM RNAI_INDEX.ANALYSIS WHERE EXPERIMENT_ID in (" + deleteIds + "))";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "DELETE FROM RNAI_INDEX.ANALYSIS WHERE EXPERIMENT_ID in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "delete from experiment_well_results where experiment_id in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "delete from experiment_plates where experiment_id in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "delete from experiment_annotation_value where experiment_id in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "delete from experiment_screener where experiment_id in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      updateQ = "delete from experiment where experiment_id in (" + deleteIds + ")";
      System.out.println(updateQ);
      stmt_gruop_annotation.addBatch(updateQ);

      int[] updateCountsExperiment = stmt_gruop_annotation.executeBatch();
      stmt_gruop_annotation.close();
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
      try {
        conn.rollback();
      } catch (Exception e1) {
      }
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public AppServerReturnObject getMosaicBarcode(Connection conn, String plate_id) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String queryString
              = "select * from invrs3_map where map = '" + plate_id + "'" + "\n";
      //"select * from SAMPLEBANK_SIRNA_MAP where map = '" + plate_id + "'" + "\n";
      //System.out.println(queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ResultSet rs = ps.executeQuery();
      if (rs.next()) {
        asro.setCallSucceed(true);
        return asro;
      }
    } catch (Exception e) {
      e.printStackTrace();

    }
    return asro;
  }

  public AppServerReturnObject getExperiments() {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection("RNAI_INDEX");
      String queryString
              = "select * from experiment se where upload_person = '" + this.userName + "' order by experiment_id desc" + "\n";
      //+ "(select experiment_id, count(*) as TotalPlates from experiment_plate sep group by experiment_id) pc, " + "\n"
      //+ "(select experiment_id, count(*) as TotalWells from experiment_well sep  group by experiment_id) wc " + "\n"
      //+ "where  " + "\n"
      //+ "SE.EXPERIMENT_ID = pc.experiment_id " + "\n"
      //+ "and SE.EXPERIMENT_ID = wc.experiment_id ";

      //System.out.println(queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ResultSet rs = ps.executeQuery();
      JSONObject jResponse = new JSONObject();
      while (rs.next()) {
        String experiment_id = rs.getString("experiment_id");
        String experiment_name = rs.getString("experiment_name");
        String upload_person = rs.getString("upload_person");
        String upload_date = rs.getString("upload_date");

        JSONObject jCollection = new JSONObject();
        jCollection.put("exp", experiment_id);
        jCollection.put("aexp", experiment_name + "(" + upload_person + ")" + ";" + "(" + upload_date + ")");

        jResponse.append("exps", jCollection);

      }
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public AppServerReturnObject getFilteredExperiments() {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection("RNAI_INDEX");
      String queryString
              = "select * from experiment se where upload_person = '" + this.userName + "' order by experiment_id desc" + "\n";

      System.out.println(queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ResultSet rs = ps.executeQuery();
      JSONObject jResponse = new JSONObject();
      while (rs.next()) {
        String experiment_id = rs.getString("experiment_id");
        String experiment_name = rs.getString("experiment_name");
        JSONObject jCollection = new JSONObject();
        jCollection.put("experiment_id", experiment_id);
        jCollection.put("experiment_name", experiment_name);
        jResponse.append("exps", jCollection);

      }
      System.out.println(jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public AppServerReturnObject CheckAndLoadPlates(Connection conn, String site, QCSessionReportKey qckey, QCSessionReport qcReport, List layers) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String sessionId = "tmp_P_" + System.currentTimeMillis();
      String plates = "";
      String invalidPlateMaps = "";

      LayerInformation[] layerInfos = qcReport.getLayerInformation();
      PlateLayout playout = qcReport.getPlateLayout();
      for (int l = 0; l < layerInfos.length; l++) {
        int count = 0;
        String layerName = layerInfos[l].getLayerName();
        if (layers != null && layers.size() > 0 && !layers.contains(layerName)) {
          continue;
        }

        String old_exp_key = (String) asro.getReturnObject();
        System.out.println("old_exp_key:" + old_exp_key);
        if (old_exp_key != null) {
          asro.setCallSucceed(false);
          asro.setComment("Experiment already loaded: " + qcReport.getQCSessionInformation().getCorporateIdentifier() + ":" + qcReport.getQCSessionInformation().getQCSessionName() + ":" + layerName);
          return asro;
        }
        if (layers != null && layers.size() > 0 && !layers.contains(layerName)) {
          continue;
        }
        PlateMeasurement[] pm = qcReport.getPlateMeasurementsForLayer(l);
        for (int j = 0; j < pm.length; ++j) {
          if (pm[j].getPlateMeasurementQuality() != 100) {
            continue;
          }
          String child_barcode = pm[j].getBarcode();
          PlateMapping pmap = qcReport.getPlateMapping(child_barcode);
          if (pmap == null) {
            invalidPlateMaps = invalidPlateMaps + child_barcode + "\t";
          }
          plates = plates + child_barcode + "\n";
        }
      }
      plates = plates.trim();

      if (invalidPlateMaps.length() > 0) {
        asro.setCallSucceed(false);
        asro.setComment("barcode with no PlateMap: " + invalidPlateMaps);
        return asro;
      }

      InsertStrInputToTempOra ac = new InsertStrInputToTempOra();
      asro = ac.createStrInputTable("PlateLoad:Barcodes", sessionId, "", plates, conn);
      tempTables.add(sessionId);

      String sql_plates = "select distinct str_input as barcode from " + sessionId + " minus select barcode from plates";
      PreparedStatement pse = conn.prepareStatement(sql_plates);
      ResultSet rse = pse.executeQuery();
      String input = "";
      while (rse.next()) {
        input = input + rse.getString("barcode") + "\n";
      }
      input = input.trim();
      System.out.println("To load: " + input);
      if (input.length() > 0) {
        LoadPlates lp = new LoadPlates(null);
        lp.readandload(input);
      }
      System.out.println("Done loading");
      rse.close();
      rse = pse.executeQuery();
      while (rse.next()) {
        this.problemPlates.add(rse.getString("barcode"));
      }
      System.out.println("problemPlates: " + problemPlates);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  private AppServerReturnObject LoadExpPlateWell(Connection conn, String site, String append_experiment_id, QCSessionReportKey qckey, QCSessionReport qcReport, List layers, String visibility, String status, PreparedStatement pstmt_exp, PreparedStatement pstmt_exp_scr, Statement stmt_plate, Statement stmt_well, Statement stmt_annotations, HashMap annotations, MerlinServicesSoap_PortType merlinServices) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      asro = CheckAndLoadPlates(conn, site, qckey, qcReport, layers);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      if (this.problemPlates.size() > 0) {
        asro.setCallSucceed(false);
        asro.setComment("Unrecognized plate identifiers: " + problemPlates);
        return asro;
      }
      HashMap wellrowMap = buildWellMap();
      DecimalFormat df = new DecimalFormat("###E0");
      DecimalFormat df1 = new DecimalFormat("##");
      LayerInformation[] layerInfos = qcReport.getLayerInformation();
      PlateLayout playout = qcReport.getPlateLayout();
      for (int l = 0; l < layerInfos.length; l++) {
        int count = 0;
        String layerName = layerInfos[l].getLayerName();
        if (layers != null && layers.size() > 0 && !layers.contains(layerName)) {
          continue;
        }
        System.out.println("Layer after: " + layerName);
        asro = this.CheckScreenerExp(conn, site, layerName, qckey, qcReport);
        if (!asro.isCallSucceed()) {
          return asro;
        }
        String old_exp_key = (String) asro.getReturnObject();
        System.out.println("old_exp_key:" + old_exp_key);
        if (old_exp_key != null) {
          asro.setCallSucceed(false);
          asro.setComment("Experiment already loaded: " + qcReport.getQCSessionInformation().getCorporateIdentifier() + ":" + qcReport.getQCSessionInformation().getQCSessionName() + ":" + layerName);
          return asro;
        }

        String experiment_id = null;
        if (append_experiment_id == null) {
          asro = getId(conn, "rnai_experiment");
          if (!asro.isCallSucceed()) {
            return asro;
          }
          experiment_id = (String) asro.getReturnObject();
        } else {
          experiment_id = append_experiment_id;
        }

        experimentsProcessed.add(experiment_id);
        System.out.println("Processing:" + qcReport.getQCSessionInformation().getQCSessionName());
        System.out.println("layerName: " + layerName);
        System.out.println("experiment_id: " + experiment_id);

        if (append_experiment_id == null) {
          asro = this.LoadExp(conn, pstmt_exp, experiment_id, layerName, visibility, status, qckey, qcReport);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        }

        asro = this.LoadExpScreener(conn, pstmt_exp_scr, site, experiment_id, layerName, visibility, status, qckey, qcReport);
        if (!asro.isCallSucceed()) {
          return asro;
        }

        if (append_experiment_id == null) {
          asro = LoadExpAnnotations(conn, stmt_annotations, experiment_id, annotations);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        }

        PlateMeasurement[] pm = qcReport.getPlateMeasurementsForLayer(l);
        for (int j = 0; j < pm.length; ++j) {
          String child_barcode = pm[j].getBarcode();
          String pstatus = pm[j].getPlateMeasurementQuality() == 100 ? "Screener" : "Failed";

          String plate_insert = "insert into experiment_plates(barcode, experiment_id) "
                  + "values('" + child_barcode + "',"
                  + experiment_id
                  + ")";

          if (child_barcode.equals("10000491983") || child_barcode.equals("10000491976")) {
            Debug.print();
          }

          System.out.println(plate_insert);
          stmt_plate.addBatch(plate_insert);
          if (pm[j].getPlateMeasurementQuality() == 100) {
            PlateMapping pmap = qcReport.getPlateMapping(child_barcode);
            if (pmap == null) {
              asro.setCallSucceed(false);
              asro.setComment("barcode has no PlateMap: " + child_barcode);
              return asro;
            }
            WellType[] wellTypes = pm[j].getAvailableWellTypes();
            float[] rawValues = pm[j].getRawValues();
            float[] correctedValues = pm[j].getCorrectedValues();
            short[] wellQuals = pm[j].getWellQualities();
            for (int k = 0; k < rawValues.length; ++k) {
              if (playout.getWellType(k).equals(WellType.COMPOUND)) {

                if (wellQuals[k] == 100) {
                  Point p = playout.getWellCoordinates(k);
                  if (pmap.getCompoundAt(k) == null) {
                    continue;
                  }
                  String compound = pmap.getCompoundAt(k);
                  if (compound == null || compound.equalsIgnoreCase("null") || compound.equalsIgnoreCase("EMPTY")) {
                    continue;
                  }

                  double x = p.getX() + 1;
                  double y = p.getY() + 1;
                  String column = Double.toString(p.getY());
                  if (Float.isNaN(correctedValues[k])) {
                    continue;
                  }
                  String well_insert = "insert into experiment_well_results(experiment_well_result_id, experiment_id, result_type_id, value, text_value, well_id)"
                          + "(select plate_well_seq.nextval, " + experiment_id + " as experiment_id,  11, " + correctedValues[k] + "," + correctedValues[k] + ", well_id "
                          + "from wells w "
                          + "where "
                          + "w.barcode = '" + child_barcode + "' "
                          + "and w.wrow = '" + wellrowMap.get(df1.format(y)) + "' "
                          + "and w.wcol = " + df1.format(x) + ")";
                  if (count < 1) {
                    System.out.println(well_insert);
                  }
                  stmt_well.addBatch(well_insert);
                  count++;

                }
              }
            }
          }
        }
        if (count > 0) {
          System.out.println("No of layers processed: " + count);
          if (append_experiment_id == null) {
            pstmt_exp.addBatch();
          }
          pstmt_exp_scr.addBatch();
        } else {
          asro.setCallSucceed(false);
          asro.setComment("No of layers processed is 0");
          return asro;
        }
      }
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public static void main(String[] args) throws Exception {
    //testListReturn();
    //testEncrypt();
    //testLoading();
    //testScreenerLoading();
    testScreenerQueries();
    //testJsonObject();
    System.out.println("Completed");
  }

  public static void testJsonObject() throws EncryptionException {
    ScreenerUpdater qcp = new ScreenerUpdater();
    JSONObject result = new JSONObject();
    AppServerReturnObject asro = qcp.getField(result, "Status");
    System.out.println(result);
  }

  public static void testEncrypt() throws EncryptionException {
    String passwd = "Ra1n1ng#";
    StringEncrypter st = new StringEncrypter();
    String encrypted = st.encrypt(passwd);
    String decrypted = st.decrypt(encrypted);
    System.out.println(encrypted + ":" + decrypted);
  }

  public static void testScreenerQueries() throws Exception {
    JSONObject jResponse = null;
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    ScreenerUpdater up = new ScreenerUpdater();
    AppServerReturnObject asro = up.getQC(null, null, null, sdf.parse("10/11/2012"), null, "AA23342", "ASF");
    if (asro.isCallSucceed()) {
      jResponse = (JSONObject) asro.getReturnObject();
    } else {
      jResponse.put("message", asro.getReturnObject());
    }
    System.out.println(jResponse);
  }

  public static void testScreenerLoading() throws Exception {
    //OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");
    OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-pdbx-ora09.amgen.com:1521:Wa0630p.amgen.com");
    MerlinServicesSoap_PortType merlin = new MerlinServicesLocator().getMerlinServicesSoap(new URL("http://usto-papp-aldi1:81/MerlinServices.asmx?WSDL"));
    //String rest = "{\"visibility\":\"Private\",\"status\":\"0\",\"fromDate\":\"01/06/2011\",\"toDate\":\"\",\"assay\":\"AA16943\",\"qcName\":\"AA16943_2:SF295_R025_10_MSD_Confirmations:1302035595765:/ONC_OTHER_siRNA\",\"AN__CellLine\":\"5807097\",\"AN__ModifiedCellLine\":\"\",\"AN__OncogenicState\":\"Normal\",\"AN__Culture\":\"Fresh\",\"AN__CellLineSource\":\"AMA-Cindy Wilson, constructed by Craig Strathdee\",\"AN__CellLineCatalog\":\"C-2501A\",\"AN__CellMorphology\":\"Adherent\",\"AN__CellsPerWell\":\"500\",\"AN__ScreenedBy\":\"mikhalr\",\"AN__ExperimentType\":\"Imaging\",\"AN__EndpointAssay\":\"CTG\",\"AN__Collection\":\"150\",\"AN__TherapeuticArea\":\"Bone\",\"AN__Algorithm\":\"OGA Method v2\",\"AN__AssayDevelopmentBy\":\"mikhalr\",\"AN__AssayDevelopmentDate\":\"01/03/2012\",\"AN__FreezeMedia\":\"70% RPMI (1%P/S/G), 10% DMSO, 20%FBS\",\"AN__PassageNumber\":\"4\",\"AN__StorageLocation\":\"siRNA Tank1 Tower2 Boxes 8/9\",\"AN__DateFrozen\":\"01/04/2012\",\"AN__FrozenBy\":\"liwong\",\"AN__Modifier\":\"\",\"AN__ModifierConcentration\":\"1000x\",\"AN__GrowthMedia\":\"DMEM\",\"AN__GrowthSerum\":\"10% FBS  2 mM L-glutamine  10 mM HEPES  1.0 mM sodium pyruvate  2 g/L glucose\",\"AN__ScreenMedia\":\"DMEM % FBS\",\"AN__ScreenSerum\":\"10% FBS\"}";
    //String rest = "{\"fromDate\":\"08/21/2012\",\"toDate\":\"\",\"Site\":\"ASF\",\"assay\":\"AA24945\",\"qcName\":\"GFP-p62_U2OS_Lamp2:20120823 GFP-p62_U2OS_Lamp2:1346026060547:/NEURO/OTHER/siRNA\",\"layerName\":\"Cells Analyzed\",\"Visibility\":\"Private\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/22/2012\",\"toDate\":\"\",\"Site\":\"ASF\",\"assay\":\"AA24945\",\"qcName\":\"GFP-p62_U2OS_Lamp2:20120823 GFP-p62_U2OS_Lamp2:1346026060547:/NEURO/OTHER/siRNA\",\"layerName\":\"Mean GFP-p62 Ring Inty\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/23/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA16852\",\"qcName\":\"AA16852:109169-68-1_V226:1346069309670:/ONC/PHOSPH/SMG1\",\"layerName\":\"Ratio,WL1,WL2\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/29/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA25043\",\"qcName\":\"AA25043_USP8_2:109166-87-1_P001:1346768377163:/ONC/siRNA/CIT_USP8\",\"layerName\":\"LUM\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"09/03/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA25043\",\"qcName\":\"AA25043_RANDOM2_4:109166-83-2_P002:1346846027663:/ONC/siRNA/CIT_USP8\",\"layerName\":\"LUM\",\"Status\":\"\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    String rest = "{\"fromDate\":\"09/04/2012\",\"toDate\":\"\",\"Site\":\"ASF\",\"assay\":\"AA22303\",\"qcName\":\"AA22303:H1734_R040_10_EDGv1_genecount_test:1347397855647:/ONC_OTHER_siRNA\",\"layerName\":\"Layer 1\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"288\",\"AN__SiRNA_SPACE_Concentration\":\"10nM\",\"AN__Incubation_SPACE_Length\":\"279\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"0.04\",\"AN__Plate_SPACE_Type\":\"555\",\"AN__Plate_SPACE_Format\":\"556\",\"AN__Cell_SPACE_Line\":[\"5808912\",\"\"],\"AN__Oncogenic_SPACE_State\":\"299\",\"AN__Culture\":\"301\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"330\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"11806\",\"AN__Cell_SPACE_Morphology\":\"350\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"354\",\"AN__Collection\":\"76266\",\"AN__Screened_SPACE_By\":\"511\",\"AN__Experiment_SPACE_Type\":\"258\",\"AN__Endpoint_SPACE_Assay\":\"259\",\"AN__Therapeutic_SPACE_Area\":\"Oncology\",\"AN__Algorithm\":\"302\",\"AN__Assay_SPACE_Development_SPACE_By\":\"524\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"11848\",\"AN__Passage_SPACE_Number\":\"11977\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"11920\",\"AN__Growth_SPACE_Serum\":\"12469\",\"AN__Screen_SPACE_Media\":\"11941\",\"AN__Screen_SPACE_Serum\":\"11971\"}";
    ScreenerUpdater qcp = new ScreenerUpdater();
    qcp.setUserName("jayanthi");
    AppServerReturnObject asro = qcp.addScreenerExperiment(rest, merlin);
    ///For MPlate: ONC_OTHER_siRNA/AA18143/108143-43-1_P001_SJSA1_0.06ul/well_30nM_DMSO_for0.8uM_YeastEssential_PDK/Wed Jan 11 14:58:28 PST 2012
  }

  public static void testListReturn() throws Exception {
    Properties p = new Properties();
    p.setProperty("AMA_server_host", "usam-papp-ldi01.amgen.com");
    p.setProperty("ASF_server_host", "ussf-papp-ldi01.amgen.com");
    p.setProperty("ATO_server_host", "usto-papp-ldi01.amgen.com");
    p.setProperty("ARG_server_host", "gerb-papp-ldi01.amgen.com");
    p.setProperty("svc-aldi", "ywxpNY4Ga8c=");
    ScreenerUpdater qcp = new ScreenerUpdater();
    String site = "ASF";
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    String fromDateStr = "12/01/2011";
    Date fromDate = null;
    fromDate = (fromDateStr == null || fromDateStr.trim().length() == 0) ? null : sdf.parse(fromDateStr);
    OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");
    //AppServerReturnObject asro = qcp.getQCJson(null, null, null, null, null, null, null, null, "AA18071", "USSF");
    //AppServerReturnObject asro = qcp.getQCJson(null, null, null, null, null, null, null, null, "AA17108", "USSF");
    //AppServerReturnObject asro = qcp.getQC("/ONC_OTHER_siRNA", null, null, null, null, "AA11045", "USSF");
    //AppServerReturnObject asro = qcp.getAssay(null, null, null, fromDate, null, site);
    //AppServerReturnObject asro = qcp.getExpLoadFormItems();
    AppServerReturnObject asro = qcp.getAnnotationRTFCellLine("cellline", "SCH");
    //AppServerReturnObject asro = null;
    if (!asro.isCallSucceed()) {
      System.out.println("Failed");
    }

    JSONObject res = (JSONObject) asro.getReturnObject();
    //System.out.println(res.getJSONArray("assays").length());
    //System.out.println(res.getJSONArray("items"));
    System.out.println(res);

    /*
     * HashMap results = (HashMap) asro.getReturnObject();
     * ArrayList<String> keys = new ArrayList();
     * HashMap values = new HashMap();
     * keys = (ArrayList) results.get("1");
     * values = (HashMap) results.get("2");
     * for (String key : keys) {
     * System.out.println(key);
     * String[] pkeys = key.split(":");
     * if (pkeys.length == 4) {
     * String experimentName = pkeys[0];
     * String sessionName = pkeys[1];
     * String dateLong = pkeys[2];
     * String folderName = pkeys[3];
     * System.out.println("InputKey: " + folderName + "/" + experimentName + "/"
     * + sessionName + "/" + dateLong);
     * QCSessionReportKey qckey = new QCSessionReportKey(experimentName,
     * sessionName, new Date(Long.parseLong(dateLong)), folderName);
     * QCSessionReport qcReport =
     * qcp.getQueryService().getQCSessionReport(qckey);
     * System.out.println("ActualKey: " + qckey.getFolderName() + "/" +
     * qckey.getExperimentName() + "/" + qckey.getQCSessionName() + "/" +
     * qckey.getInsertDate());
     * System.out.println(qcReport.getQCSessionInformation().getExperimentName());
     *
     *
     * }
     *
     * }
     */
    qcp.closeConnection();
  }
}
