/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.align;

import amgen.ri.asf.bio.FastaEntry;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.sys.SystemCommand;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletContext;

/**
 *
 * @author jemcdowe
 */
public class Alignment implements Iterable<AlignmentPair> {
  private File blastDir = new File("C:/Blast");
  private FastaEntry targetSeq;
  private FastaEntry querySeq;
  private boolean perfectMatch;
  private List<AlignmentPair> alignmentPairs;

  public Alignment(MainUI requestor, FastaEntry targetSeq, FastaEntry querySeq, boolean perfectMatch) {
    blastDir = new File(System.getenv("CATALINA_HOME"), "blast");
    this.targetSeq = targetSeq;
    this.querySeq = querySeq;
    this.perfectMatch = perfectMatch;
    alignmentPairs = new ArrayList<AlignmentPair>();
  }

  public void doAlignment() throws IOException {
    alignmentPairs.clear();

    File tempDir = new File(System.getProperty("java.io.tmpdir"), "RNAi_" + UUID.randomUUID().toString());
    if (!tempDir.mkdirs()) {
      throw new IOException("Unable to make temporary directory " + tempDir);
    }
    if (!tempDir.exists()) {
      throw new IOException("Unable to create temporary directory " + tempDir);
    }
    tempDir.deleteOnExit();

    File targetSeqFile = new File(tempDir, "target.fa");
    ExtFile.writeFile(targetSeqFile, getTargetSeq().toString().getBytes());

    File querySeqFile = new File(tempDir, "query.fa");
    ExtFile.writeFile(querySeqFile, getQuerySeq().toString().getBytes());

    File outFile = new File(tempDir, "blast2seqs.out");

    String blast2seqsCommand = blastDir + "/bin/bl2seq -i " + targetSeqFile + " -j " + querySeqFile + " -p blastn -D 1 -g F -F F -W 7 -o " + outFile;
    int status;
    try {
      status = SystemCommand.executeProcess(blast2seqsCommand);
    } catch (InterruptedException ex) {
      throw new IOException("Alignment command failed. " + ex.getMessage());
    }

    if (status != 0) {
      throw new IOException("Alignment command failed with status " + status);
    }

    BufferedReader reader = new BufferedReader(new FileReader(outFile));
    String line;
    while ((line = reader.readLine()) != null) {
      if (ExtString.hasTrimmedLength(line) && !line.startsWith("#")) {
        String[] fields = line.split("\\s+");
        if (fields.length == 12) {
          String target = fields[0];
          String query = fields[1];
          double identity = new Double(fields[2]);
          int alignment = new Integer(fields[3]);
          int mismatches = new Integer(fields[4]);
          int gaps = new Integer(fields[5]);
          int qStart = new Integer(fields[6]);
          int qEnd = new Integer(fields[7]);
          int sStart = new Integer(fields[8]);
          int sEnd = new Integer(fields[9]);
          double score = new Double(fields[10]);
          double bitScore = new Double(fields[11]);

          boolean matched = false;
          if (!perfectMatch) {
            matched = true;
          } else if (alignment == querySeq.getSequenceLength() && mismatches == 0 && gaps == 0) {
            matched = true;
          }
          if (matched) {
            alignmentPairs.add(new AlignmentPair(target,
                    query,
                    identity,
                    alignment,
                    mismatches,
                    gaps,
                    qStart,
                    qEnd,
                    sStart,
                    sEnd,
                    score,
                    bitScore));
          }
        }
      }
    }
    reader.close();
    tempDir.delete();
  }

  @Override
  public Iterator<AlignmentPair> iterator() {
    return getAlignmentPairs().iterator();
  }

  /**
   * @return the targetSeq
   */
  public FastaEntry getTargetSeq() {
    return targetSeq;
  }

  /**
   * @param targetSeq the targetSeq to set
   */
  public void setTargetSeq(FastaEntry targetSeq) {
    this.targetSeq = targetSeq;
  }

  /**
   * @return the querySeq
   */
  public FastaEntry getQuerySeq() {
    return querySeq;
  }

  /**
   * @param querySeq the querySeq to set
   */
  public void setQuerySeq(FastaEntry querySeq) {
    this.querySeq = querySeq;
  }

  /**
   * @return the alignmentPairs
   */
  public List<AlignmentPair> getAlignmentPairs() {
    if (alignmentPairs.isEmpty()) {
      try {
        doAlignment();
      } catch (IOException ex) {
        ex.printStackTrace();
      }
    }
    return alignmentPairs;
  }
}
