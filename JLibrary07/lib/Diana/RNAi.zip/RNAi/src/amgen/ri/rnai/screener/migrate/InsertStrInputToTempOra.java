/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener.migrate;

import amgen.ri.rnai.util.AppServerReturnObject;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertStrInputToTempOra {

    public InsertStrInputToTempOra() {
    }

    public synchronized AppServerReturnObject createStrInputTable(String serviceapp, String tableName, String tableType, String compounds, Connection dbMConnection) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed insertSearchstringToTemp", false, null);
        try {
            String queryString = "";
            String delimiter = "";
            if (compounds.indexOf(",") >= 0) {
                delimiter = ",";
            } else if (compounds.indexOf("\n") >= 0) {
                delimiter = "\n";
            } else if (compounds.indexOf("\t") >= 0) {
                delimiter = "\t";
            } else {
                delimiter = " ";
            }

            if (tableType != null && tableType.equalsIgnoreCase("TEMP")) {
                queryString = "CREATE GLOBAL TEMPORARY TABLE " + tableName + "(str_input varchar2(50), cindex number,session_id varchar2(20), serviceapp varchar2(20), servicehost varchar2(30)) ON COMMIT PRESERVE ROWS ";
            } else {
                queryString = "CREATE TABLE " + tableName + "(str_input varchar2(50), cindex number,session_id varchar2(20), serviceapp varchar2(20), servicehost varchar2(30))";
            }
            System.out.println(queryString);
            Statement stmt = dbMConnection.createStatement();
            int rowcnt = stmt.executeUpdate(queryString);

            Statement stmt1 = dbMConnection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String tc = compounds;
            int size = 3999;
            int batchno = 0;
            while (tc.length() > 0) {
                String temp = "";
                if (tc.length() < size) {
                    temp = tc;
                    tc = "";
                } else {
                    int lastIndex = tc.lastIndexOf(delimiter, size);

                    temp = tc.substring(0, lastIndex);
                    tc = tc.substring(lastIndex);
                }
                String insertQueryItem = "";
                insertQueryItem = "insert into " + tableName + " (str_input, cindex,session_id, serviceapp, servicehost) SELECT str_input, cindex,sys_context('USERENV','SESSIONID') as session_id,'" + serviceapp + "' as serviceapp, sys_context('USERENV','HOST') as servicehost FROM TABLE (create_str_input_type ('" + temp.trim() + "'," + (batchno * 500) + "))";

                System.out.println(insertQueryItem);
                stmt1.addBatch(insertQueryItem);
                batchno++;

            }
            int[] updateCounts1 = stmt1.executeBatch();
            dbMConnection.commit();

            asro.setCallSucceed(true);
        } catch (Exception e) {
            asro.setCallSucceed(false);
            asro.setComment("Problem in callSimilarstructureSearch");
            e.printStackTrace();
        } finally {
            try {
            } catch (Exception e) {
            }
        }
        return asro;
    }

    public static void main(String[] args) throws Exception {
        testCreateCompoundTableComma();

    }

    public static void testCreateCompoundTableComma() throws Exception {
        InsertStrInputToTempOra ac = new InsertStrInputToTempOra();
        String tableName = "";
        String tableType = "";
        String compounds = "";

        String session_user = "jayanthi";
        Connection dbMConnection = null;


        tableName = session_user + "_" + System.currentTimeMillis();
        tableType = "";
        //compounds = "2098055#1, 2098055#2, 2032#2";
        //compounds = "2630849\n2648715\n2652484";
        compounds = "2630849#1\n2648715#1\n2652484#1";

        AppServerReturnObject asro = ac.createStrInputTable("test", tableName, tableType, compounds, dbMConnection);
        if (asro.isCallSucceed()) {
            System.out.println("Table created: " + tableName);
        } else {
            System.out.println(asro.getComment());
        }

        dbMConnection.close();


    }
}
