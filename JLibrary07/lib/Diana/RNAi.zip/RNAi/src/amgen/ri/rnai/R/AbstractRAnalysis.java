/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.R;

import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.rnai.util.RuntimeUtil;
import amgen.ri.util.ExtFile;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.UUID;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.text.StrSubstitutor;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractRAnalysis extends ResourceFactory {
  private MainUI servletBase;
  private Properties rProperties;
  private File workDir;

  public AbstractRAnalysis(File workDir) throws IOException {
    super();
    this.workDir = workDir;
    rProperties = new Properties();
    rProperties.load(getClass().getResourceAsStream("/r.properties"));
  }

  public AbstractRAnalysis(MainUI servletBase) throws IOException {
    super(servletBase.getSessionCache());
    this.servletBase = servletBase;
    this.workDir= this.servletBase.getSessionWorkDir();
    rProperties = new Properties();
    rProperties.load(getClass().getResourceAsStream("/r.properties"));
  }

  /**
   * @return the servletBase
   */
  public MainUI getServletBase() {
    return servletBase;
  }

  public void runRCommand(String rArguments) throws RAnalysisFailureException {
    try {      
      String rScript = IOUtils.toString(getClass().getResourceAsStream("/"+getRCodeFileName()));      
      rScript = rScript.replace("$", "\\$");

      Map<String, String> rCommandReplacements = new HashMap<String, String>();
      rCommandReplacements.put("R_EXE", rProperties.getProperty("R.r_exe"));
      rCommandReplacements.put("ARGS", rArguments);
      rCommandReplacements.put("RCODE", rScript);

      String rCommandTemplate = rProperties.getProperty("R.command_template");
      StrSubstitutor rCommandSubstitutor = new StrSubstitutor(rCommandReplacements);
      File commandFile = new File(getWorkDir(), "/commandFile.R");

      FileUtils.write(commandFile, rCommandSubstitutor.replace(rCommandTemplate));

      int exitValue = RuntimeUtil.systemCallWithReaderThreads(rProperties.getProperty("R.sh_exe") + " " + commandFile);
      if (exitValue > 1) {
        throw new RAnalysisFailureException("No records found.");
      }
    } catch (Exception e) {
      throw new RAnalysisFailureException("R Analysis failed. Unable to run R command due to system error.");
    }
  }

  public abstract String getRCodeFileName();

  /**
   * @return the workDir
   */
  public File getWorkDir() {
    return workDir;
  }

  /**
   * @param workDir the workDir to set
   */
  public void setWorkDir(File workDir) {
    this.workDir = workDir;
  }
}
