
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.graphs;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.R.AbstractRAnalysis;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtFile;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.StringTokenizer;
import java.util.UUID;
import javax.imageio.ImageIO;
import oracle.jdbc.OracleCallableStatement;
import org.apache.commons.io.FilenameUtils;

/**
 *
 * @author jayanthi
 */
public class HistogramGeneCollection extends AbstractRAnalysis {
  public HistogramGeneCollection(MainUI servletBase) throws IOException {
    super(servletBase);
  }

  public void saveDataValues(GeneRecord geneRecord, File dataFile) throws SQLException, IOException {
    String RNAi_QUERY = "begin ? := RNAIQUERY.getResultPValuesforGene(?,?); end;";
    Connection conn = null;

    try {
      conn = getRNAiConnection();
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RNAi_QUERY);
      cs.registerOutParameter(1, Types.CLOB);
      cs.setInt(2, geneRecord.getGeneID());
      cs.setInt(3, 1);
      cs.execute();
      String results = cs.getString(1);
      results = "experiment_id\tcorrected_pval\traw_pval\texperiment_name\tcell_line\ttissue\tcollection\n" + results;
      ExtFile.writeTextFile(dataFile, results);
    } finally {
      close(conn);
    }
  }

  public JSONObject createJSONOutput(File outFile) {
    JSONObject jOutFiles = new JSONObject();
    try {
      BufferedReader br = new BufferedReader(new FileReader(outFile));

      String line = null;
      while ((line = br.readLine()) != null) {
        if (line.contains("#Images")) {
          continue;
        }
        StringTokenizer st = new StringTokenizer(line, "\t");
        String collection_name = st.nextToken();
        String file_type = st.nextToken();
        String imageFileName = st.nextToken().trim();
        File imageFile = new File(imageFileName);
        BufferedImage img = ImageIO.read(imageFile);

        JSONObject vals = new JSONObject();
        vals.put("name", file_type);
        vals.put("imgFile", "genehistogram/" + imageFile.getName());
        vals.put("width", img.getWidth());
        vals.put("height", img.getHeight());
        jOutFiles.append(collection_name, vals);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jOutFiles;
  }

  public JSONObject process(GeneRecord geneRecord) throws RAnalysisFailureException, JSONException {
    try {
      JSONObject jResponse = new JSONObject();
      String fileBaseName = "G" + geneRecord.getGeneID();
      File dataFile = new File(getServletBase().getSessionWorkDir(), fileBaseName + ".txt");
      File outDir = new File(getServletBase().getCrossSessionDir(), "genehistogram");
      outDir.mkdirs();
      File outFile = new File(outDir, UUID.randomUUID() + ".txt");
      saveDataValues(geneRecord, dataFile);
      String rArguments = " " + geneRecord.getGeneSymbol() + " "
              + FilenameUtils.separatorsToUnix(dataFile.getAbsolutePath()) + " "
              + FilenameUtils.separatorsToUnix(outFile.getParentFile().getAbsolutePath()) + "/" + " "
              + FilenameUtils.separatorsToUnix(outFile.getAbsolutePath() + " "
              + "R_GSCMD=/temp/gs9.07/bin/gswin32c.exe");

      runRCommand(rArguments);

      JSONObject outFiles = this.createJSONOutput(outFile);
      jResponse.append("CompositeHistograms", outFiles);
      return jResponse;
    } catch (Exception ex) {
      throw new RAnalysisFailureException("Analysis failed", ex);
    }

  }
  
  @Override
  public String getRCodeFileName() {
    return "HistogramGeneCollection_v1.R";
  }  
}
