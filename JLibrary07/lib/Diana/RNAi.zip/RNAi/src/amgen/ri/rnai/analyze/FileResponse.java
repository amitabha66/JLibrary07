/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import java.io.File;

/**
 *
 * @author jemcdowe
 */
public class FileResponse {
  private File responseFile;
  private String fileName;
  private String mimetype;

  public FileResponse() {
  }

  /**
   * Get the value of mimetype
   *
   * @return the value of mimetype
   */
  public String getMimetype() {
    if (mimetype != null) {
      return mimetype;
    }
    String fileName = getFileName();
    if (fileName.endsWith(".xlsx")) {
      return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    } else if (fileName.endsWith(".xls")) {
      return "application/vnd.ms-excel";
    } else if (fileName.endsWith(".zip")) {
      return "application/x-zip-compressed";
    }
    
    return "unknown";
  }

  /**
   * Get the value of fileName
   *
   * @return the value of fileName
   */
  public String getFileName() {
    return (fileName == null ? getResponseFile().getName() : fileName);
  }

  /**
   * Get the value of responseFile
   *
   * @return the value of responseFile
   */
  public File getResponseFile() {
    return responseFile;
  }

  public void setFileName(String fileName) {
    this.fileName = fileName;
  }

  public void setMimetype(String mimetype) {
    this.mimetype = mimetype;
  }

  public void setResponseFile(File responseFile) {
    this.responseFile = responseFile;
  }
}
