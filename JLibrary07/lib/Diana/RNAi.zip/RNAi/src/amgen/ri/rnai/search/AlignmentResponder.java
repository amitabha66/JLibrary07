/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONObject;
import amgen.ri.rnai.align.AlignmentPair;
import amgen.ri.rnai.align.RNAiAlignment;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.AlignmentPairRecord;
import amgen.ri.rnai.records.AlignmentRecord;
import amgen.ri.rnai.records.RNAiRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.Debug;
import amgen.ri.xml.ExtXMLElement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public class AlignmentResponder extends AbstractResponder implements JSONResponderIF {
  public AlignmentResponder(MainUI servletBase) {
    super(servletBase);
    //servletBase.printRequest();
  }

  public JSONObject getResponse() {
    JSONObject jAlignment = new JSONObject();

    try {
      String targetAccession = getParameter("target");
      String compoundIDs = getParameter("rnai_ids");

      RNAiSearch rnaiSearch = new RNAiSearch(getSessionCache(), getServletBase().getPersonRecord());
      List<RNAiRecord> rnaiRecords = null;// rnaiSearch.getRNAiRecordsFromCompoundIDs(Arrays.asList(compoundIDs.split(",")));

      //RNAiSearch rnaiSearch = new RNAiSearch("RET", "GENE_SYMBOLS", "RNAI");
      //List<RNAiRecord> rnaiRecords = new ArrayList<RNAiRecord>();

      //for (AbstractRecord record : rnaiSearch) {
      // rnaiRecords.add((RNAiRecord) record);
      //}
      RNAiAlignment alignment = new RNAiAlignment((MainUI)getServletBase(), targetAccession, rnaiRecords);

      jAlignment.put("target_id", alignment.getTargetSequenceRecord().getRecordID());
      jAlignment.put("target_length", alignment.getTargetSequenceRecord().asFastaEntry().getSequenceLength());

      for (RNAiRecord rnaiRecord : alignment) {
        jAlignment.append("rnai", rnaiRecord);
        List<AlignmentPair> alignmentPairs = alignment.getAlignmentPairs(rnaiRecord);
        AlignmentRecord alignmentRecord = null;

        if (alignmentPairs.size() > 0) {
          alignmentRecord = new AlignmentRecord(rnaiRecord.getRootNumber() + "#" + rnaiRecord.getLotNumber(), rnaiRecord.getRnaiID()+"", targetAccession);
          jAlignment.append("hits", alignmentRecord);
          
          rnaiRecord.setAlignmentRecord(alignmentRecord);
        }
        for (AlignmentPair alignmentPair : alignmentPairs) {
          int sStart = alignmentPair.getSubjectStart();
          int sEnd = alignmentPair.getSubjectEnd();
          int qStart = alignmentPair.getQueryStart();
          int qEnd = alignmentPair.getQueryEnd();

          if (qStart > qEnd) {
            int hold = qEnd;
            qEnd = qStart;
            qStart = hold;
          }
          AlignmentPairRecord alignmentPairRecord= new AlignmentPairRecord("", sStart, sEnd, qStart, qEnd);
          alignmentRecord.addAlignmentPairRecord(alignmentPairRecord);          
        }
      }
    } catch (Exception e) {
      e.printStackTrace();
      throw new IllegalArgumentException(e.getMessage());
    }

Debug.print(jAlignment);
    return jAlignment;
  }
}
