/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jemcdowe
 */
public class PermissionResponder extends AbstractResponder implements JSONResponderIF {
  public PermissionResponder(MainUI servletBase) {
    super(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    //getServletBase().printRequest();
    JSONObject jHasPermissions = new JSONObject();
    try {
      PermissionType permission = PermissionType.fromString(getParameter("permission"));
      PermissionManager permissionMgr = new PermissionManager(getServletBase().getPersonRecord());
      List<ExperimentRecord> expRecords = getExperimentRecordsFromParameter();
      boolean hasPermission = true;

      if (expRecords.isEmpty()) {
         if (!permissionMgr.hasPermission(permission, (AbstractRecord[])null)) {
          hasPermission = false;
        }
      }
      for (ExperimentRecord expRecord : expRecords) {
        if (!permissionMgr.hasPermission(permission, expRecord)) {
          hasPermission = false;
        }
      }

      jHasPermissions.put(permission + "", hasPermission);
    } catch (JSONException ex) {
      Logger.getLogger(PermissionResponder.class.getName()).log(Level.SEVERE, null, ex);
    }
    return jHasPermissions;
  }
}
