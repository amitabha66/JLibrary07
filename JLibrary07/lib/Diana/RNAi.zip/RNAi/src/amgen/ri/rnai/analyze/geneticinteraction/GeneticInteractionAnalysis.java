/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.crypt.StringEncrypter.EncryptionException;
import amgen.ri.csv.CSVReader;
import amgen.ri.json.JSONException;
import amgen.ri.ldap.ActiveDirectoryLookup;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.rnai.R.AbstractRAnalysis;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtString;
import java.io.*;
import java.sql.SQLException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.naming.NamingException;
import org.apache.commons.io.FilenameUtils;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jemcdowe
 */
public class GeneticInteractionAnalysis extends AbstractRAnalysis {
  private PersonRecordIF requestedBy;
  private Collection<GeneticInteractionListenerIF> giListeners = new ArrayList<GeneticInteractionListenerIF>();
  private boolean overwriteExistingAnalysis = true;

  public GeneticInteractionAnalysis(MainUI requestor, boolean overwriteExistingAnalysis, GeneticInteractionListenerIF... giListeners) throws IOException {
    super(requestor.getSessionWorkDir());
    requestedBy = requestor.getPersonRecord();
    this.overwriteExistingAnalysis = overwriteExistingAnalysis;
    if (giListeners != null) {
      this.giListeners.addAll(Arrays.asList(giListeners));
    }
  }

  public GeneticInteractionAnalysis(String amgenLogin, File workDir, GeneticInteractionListenerIF... giListeners) throws IOException, SQLException, NamingException, EncryptionException {
    super(workDir);
    requestedBy = new ActiveDirectoryLookup().lookup(amgenLogin);
    if (giListeners != null) {
      this.giListeners.addAll(Arrays.asList(giListeners));
    }
  }

  public void addListener(GeneticInteractionListenerIF giListener) {
    this.giListeners.add(giListener);
  }

  private File executeAnalysesAndCombine(String experimentIDs) throws IOException, SQLException, JSONException, RAnalysisFailureException {
    executeGIAnalyses(experimentIDs);
    return null;
  }

  public void executeGIAnalyses(String experimentIDs) throws IOException, SQLException, JSONException, RAnalysisFailureException {
    SqlSession sqlSession = null;

    try {
      sqlSession = getRNAiSqlSession();
      TreeSet<ExperimentRecord> experimentRecords = new TreeSet<ExperimentRecord>();
      Set<Integer> expIDs = new HashSet<Integer>();
      for (String expID : experimentIDs.split(",")) {
        if (ExtString.isAInteger(expID.trim())) {
          expIDs.add(new Integer(expID.trim()));
        }
      }
      experimentRecords.addAll(getExperiments(expIDs, getRequestedBy()));
      if (experimentRecords.size() < 2) {
        throw new RAnalysisFailureException("Invalid experiments in analysis");
      }

      //Fix any bad names and verify there is an analysis
      for (ExperimentRecord expRecord : experimentRecords) {
        expRecord.setExperimentName(expRecord.getExperimentName().replaceAll("[^a-zA-Z0-9]+", "_"));
        if (expRecord.getAnalysis_id() <= 0) {
          throw new RAnalysisFailureException("Invalid experiment: No analysis available for " + expRecord.getExperimentName()+".\nPlease run the OGA analysis on this experiment prior to doing the Genetic Interaction Analysis.");
        }
      }

      for (GeneticInteractionListenerIF listener : giListeners) {
        listener.processBegan(this, experimentRecords);
      }

      for (ExperimentRecord experimentRecordA : experimentRecords) {
        for (ExperimentRecord experimentRecordB : experimentRecords.tailSet(experimentRecordA, false)) {
          GIExperiments gie = new GIExperiments(experimentRecordA, experimentRecordB, getWorkDir(), new GIAnalysis(
                  experimentRecordA.getExperimentID(),
                  experimentRecordA.getAnalysis_id(),
                  experimentRecordB.getExperimentID(),
                  experimentRecordB.getAnalysis_id(), getRequestedBy().getUsername()));

          if (!overwriteExistingAnalysis) {
            GIAnalysis giAnalysis = sqlSession.getMapper(Mapper.class).getGIAnalysis(gie.getGIAnalysis());
            if (giAnalysis != null) {
              giAnalysis.loadResults(this, getRequestedBy());
              gie.setGIAnalysis(giAnalysis);
            }
          }
          if (gie.getGIAnalysis().isEmpty()) {
            saveDataValues(gie);
            String rArguments =
                    FilenameUtils.separatorsToUnix(gie.getDataFile().getAbsolutePath()) + " "
                    + FilenameUtils.separatorsToUnix(gie.getResultFile().getAbsolutePath()) + " "
                    + gie.getExperimentA().getExperimentName() + " "
                    + gie.getExperimentB().getExperimentName();

            for (GeneticInteractionListenerIF listener : giListeners) {
              listener.analysisStarted(this, gie);
            }
            runRCommand(rArguments);
            gie.setResultsFromResultFile(this, getRequestedBy());
            for (GeneticInteractionListenerIF listener : giListeners) {
              listener.analysisComplete(this, gie);
            }
          }
        }
      }

      for (GeneticInteractionListenerIF listener : giListeners) {
        listener.processEnded(this, experimentRecords);
      }
    } finally {
      close(sqlSession);
    }
  }

  @Override
  public SqlSession getRNAiSqlSession(ExecutorType executorType) {
    return getSqlSessionFactory("rnai-local").openSession(executorType);
  }

  private void saveDataValues(GIExperiments gie) throws SQLException, IOException {
    Set<Integer> geneIDs = new HashSet<Integer>();
    Pattern analysisIDPattern = Pattern.compile("ANALYSIS_A:\\s*(?<analysisa>\\d+)\\s*ANALYSIS_B:\\s*(?<analysisb>\\d+)");
    int analysisIDA = -1;
    int analysisIDB = -1;


    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      sqlSession.getMapper(Mapper.class).getGeneticInteractionResults(gie);

      PrintWriter giInputWriter = new PrintWriter(gie.getDataFile());
      Reader reader = new StringReader(gie.getGiInputResults());
      CSVReader giInputReader = new CSVReader(reader, '\t');
      giInputWriter.println("value_a\tvalue_b\tgene_symbol\tgene_id\trnai_id");

      while (giInputReader.readRecord()) {
        switch (giInputReader.getColumnCount()) {
          case 5:
            giInputWriter.printf("%s\t%s\t%s\t%s\t%s\n", (Object[]) giInputReader.getValues());
            geneIDs.add(new Integer(giInputReader.get(3)));
            break;
          case 2:
            Matcher lineMatcher = analysisIDPattern.matcher(giInputReader.getRawRecord());
            if (lineMatcher.matches()) {
              analysisIDA = new Integer(lineMatcher.group("analysisa"));
              analysisIDB = new Integer(lineMatcher.group("analysisb"));
            }
            break;
        }
      }
      giInputReader.close();
      giInputWriter.close();

      if (analysisIDA < 0 || analysisIDB < 0) {
        throw new IOException("Unable to identify analysis ID(s)");
      }

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      close(sqlSession);
    }
  }

  @Override
  public String getRCodeFileName() {
    return "Genetic_Interaction_algorithm_v2.R";
  }

  public void test() throws Exception {
    SqlSession sqlSession = null;

    try {
      sqlSession = getRNAiSqlSession();

      GIAnalysisDetails details = new GIAnalysisDetails();
      details.setGiAnalysisIDs(Arrays.asList(21, 22, 23));


      sqlSession.getMapper(Mapper.class).getGICompareResults(details);

      System.out.println(details.getResults().substring(0, 100));


    } finally {
      close(sqlSession);
    }
  }

  public static void main(String[] args) throws Throwable {
    OraConnectionManager.addConnectionPool(ConnectionPoolType.RNAI_INDEX + "",
            "jdbc:oracle:thin:rnai_index/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-pdbx-ora45.amgen.com:1771:Wa0630p.amgen.com");

    /*
     * File workDir = new File("/temp", UUID.randomUUID().toString());
     * workDir.mkdirs();
     * GeneticInteractionAnalysis gi = new
     * GeneticInteractionAnalysis("jemcdowe", workDir, new
     * GeneticInteractionListenerIF[0]);
     * gi.addListener(new GIOracleInsertListener(gi));
     * gi.executeAnalysesAndCombine("4260,4259,4258");
     * //gi.executeAnalysesAndCombine("4552,4258,4260,4259");
     *
     */
    File workDir = new File("/temp", UUID.randomUUID().toString());
    GeneticInteractionAnalysis gi = new GeneticInteractionAnalysis("jemcdowe", workDir, new GeneticInteractionListenerIF[0]);
    gi.test();


  }

  /**
   * @return the requestedBy
   */
  public PersonRecordIF getRequestedBy() {
    return requestedBy;
  }
}
