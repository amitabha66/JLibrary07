/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.rnai.dao;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.ExtOracle;
import amgen.ri.util.Debug;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.zip.GZIPOutputStream;
import oracle.sql.BLOB;
import org.apache.ibatis.type.BaseTypeHandler;
import org.apache.ibatis.type.JdbcType;

/**
 *
 * @author jemcdowe
 */
public class NamedQueryHandler extends BaseTypeHandler<NamedQuery> {

  @Override
  public void setNonNullParameter(PreparedStatement ps, int columnIndex, NamedQuery t, JdbcType jt) throws SQLException {
    switch(columnIndex) {
      case 1:
        break;
      case 2:
            ps.setString(columnIndex, t.getQueryName());
        break;
      case 3:
        ps.setBlob(columnIndex, createBLOB(ps.getConnection(), t.getParameters()));
        break;
    }
  }

  @Override
  public NamedQuery getNullableResult(ResultSet rs, String columnName) throws SQLException {
    throw new UnsupportedOperationException("Not supported");
  }

  @Override
  public NamedQuery getNullableResult(ResultSet rs, int columnIndex) throws SQLException {
    throw new UnsupportedOperationException("Not supported");
  }

  @Override
  public NamedQuery getNullableResult(CallableStatement cs, int columnIndex) throws SQLException {
    throw new UnsupportedOperationException("Not supported");
  }
  
  protected BLOB createBLOB(Connection conn, Object obj) throws SQLException {
    BLOB tempBlob = null;
    try {
      tempBlob = BLOB.createTemporary(conn, true, BLOB.DURATION_SESSION);
      OutputStream blobOutStream = tempBlob.setBinaryStream(0);
      ObjectOutputStream oop = new ObjectOutputStream(blobOutStream);
      oop.writeObject(obj);      
      oop.flush();
      oop.close();
      blobOutStream.close();
    } catch (Exception exp) {
      tempBlob.freeTemporary();
      throw new SQLException(exp);
    }
    return tempBlob;
  }
  
}
