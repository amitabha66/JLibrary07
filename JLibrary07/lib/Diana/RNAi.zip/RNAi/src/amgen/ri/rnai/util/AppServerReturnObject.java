/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.util;


import java.io.*;

public class AppServerReturnObject
    implements Serializable {
  private String comment;
  private String userErrorComment;
  private boolean callSucceed;
  private Object returnObject;
  public AppServerReturnObject() {
  }

  public AppServerReturnObject(String comment, boolean callSucceed,
                               Object returnObject) {
    this.comment = comment;
    this.callSucceed = callSucceed;
    this.returnObject = returnObject;
  }

  public String getComment() {
    return comment;
  }

  public void setComment(String comment) {
    this.comment = comment;
  }

  public void setCallSucceed(boolean callSucceed) {
    this.callSucceed = callSucceed;
  }

  public boolean isCallSucceed() {
    return callSucceed;
  }

  public void setReturnObject(Object returnObject) {
    this.returnObject = returnObject;
  }

  public void setUserErrorComment(String userErrorComment) {
    this.userErrorComment = userErrorComment;
  }

  public Object getReturnObject() {
    return returnObject;
  }

  public String getUserErrorComment() {
    return userErrorComment;
  }

}

