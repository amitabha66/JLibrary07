/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.sql.GenericSQLProvider;
import amgen.ri.sql.SQLProvider;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import amgen.ri.util.HashCodeGenerator;
import amgen.ri.xml.ExtXMLElement;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jdom.Element;

/**
 * A base class for all Record classes. This extends JSONObject which is used
 * for internal persistence and for proper marshaling to ExtJS client records
 *
 * @author jemcdowe
 */
public abstract class AbstractRecord extends JSONObject implements Serializable, Comparable<AbstractRecord> {
  static final long serialVersionUID = 3407123070045653783L;
  public SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
  public SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
  //public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat("dow mon dd hh:mm:ss zzz yyyy");
  //Defines a unique record ID intended only to establish identity
  private String recordID;
  private transient SQLProvider sqlProvider;
  private int fHashCode;

  public AbstractRecord(String recordID) {
    super();
    this.recordID = recordID;
  }

  /**
   * Copies the contents of one AbstractRecord to another
   *
   * @param record
   * @throws JSONException
   */
  protected AbstractRecord(AbstractRecord record) throws JSONException {
    super(record, JSONObject.getNames(record));
  }

  /**
   * Copies the contents of one AbstractRecord to another
   *
   * @param record
   * @throws JSONException
   */
  protected AbstractRecord(JSONObject source, String idField) throws JSONException {
    super(source, JSONObject.getNames(source));
    Object idValue = source.get(idField);
    if (idValue instanceof Integer) {
      this.recordID = source.getString(idField);
    } else {
      this.recordID = source.getString(idField);
    }
  }

  /**
   * Get the value of sqlProvider
   *
   * @return the value of sqlProvider
   */
  public SQLProvider getSqlProvider() {
    if (sqlProvider == null) {
      sqlProvider = new GenericSQLProvider(getClass().getClassLoader().getResourceAsStream("rnai_sql.xml"));
      if (sqlProvider == null) {
        throw new IllegalArgumentException("Unable to load SQL XML");
      }
    }
    return sqlProvider;
  }

  /**
   * Adds an Object to the internal Map
   *
   * @param key
   * @param obj
   */
  public void add(String key, Object obj) {
    try {
      //if (key.equals("rnai")) {
      //  System.out.println(key + ": " + obj.getClass());
      //}
      if (obj instanceof Date) {
        super.put(key, dateFormat.format((Date) obj));
      } else {
        super.put(key, obj);
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Adds an Object to a JSONArray in the internal Map
   *
   * @param key
   * @param obj
   */
  public void addToArray(String key, Object obj) {
    try {
      //if (key.equals("rnai")) {
      //  System.out.println(key + ": " + obj.getClass());
      //}
      super.append(key, obj);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
  }

  /**
   * Returns a value as a Number if possible. null if the key does not exists or
   * NaN if it is not a number
   *
   * @param key
   * @return
   */
  public Number getNumber(String key) {
    try {
      if (!has(key)) {
        return null;
      }
      return super.getDouble(key);
    } catch (JSONException ex) {
      return Double.NaN;
    }
  }

  /**
   * Returns the boolean value of the key or false if the value does not exists
   * or
   * is not a boolean
   *
   * @param key
   * @return
   */
  @Override
  public boolean getBoolean(String key) {
    return optBoolean(key, false);
  }

  /**
   * Returns a value as a String. null if the key does not exist
   *
   * @param key
   * @return
   */
  public String getString(String key) {
    try {
      return super.getString(key);
    } catch (Exception ex) {
      return null;
    }
  }

  /**
   * Returns a value as a JSONArray. null if the key does not exist
   *
   * @param key
   * @return
   */
  public JSONArray getArray(String key) {
    try {
      return super.getJSONArray(key);
    } catch (JSONException ex) {
      return null;
    }
  }

  /**
   * Returns a JSONArray value as a List.
   *
   * @param key
   * @return
   */
  public List getList(String key) {
    try {
      return super.getJSONArray(key).asList();
    } catch (JSONException ex) {
      return new ArrayList();
    }
  }

  /**
   * Returns a value as an AbstractRecord. null if the key does not exist
   *
   * @param key
   * @return
   */
  public AbstractRecord getRecord(String key) {
    try {
      return (AbstractRecord) super.get(key);
    } catch (JSONException ex) {
      return null;
    }
  }

  /**
   * Returns is the value is a Date
   *
   * @param key
   * @return
   */
  public boolean isDate(String key) {
    return false;
  }

  /**
   * Returns a value as a Date if the format is correct. null if the key does
   * not exist or can not be represented as a DATE according to the
   * DATE_FORMATTER
   *
   * @param key
   * @return
   */
  public Date getDate(String key) {
    try {
      String d = getString(key);
      if (d.matches("[0-9]{4}-[0-9]{1,2}-[0-9]{1,2}")) {
        return dateFormat2.parse(d);
      }
      return dateFormat.parse(getString(key));
    } catch (Exception ex) {
      System.err.println("Unable to parse date: " + getString(key));
      return null;
    }
  }

  @Override
  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, getRecordID());
      fHashCode = result;
    }
    return fHashCode;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof AbstractRecord && obj.getClass().equals(this.getClass())) {
      AbstractRecord g1 = this;
      AbstractRecord g2 = (AbstractRecord) obj;
      return (g1.getRecordID().equals(g2.getRecordID()));
    }
    return false;
  }

  public int compareTo(AbstractRecord r) {
    return getRecordID().compareTo(r.getRecordID());
  }

  /**
   * @return the recordID
   */
  public String getRecordID() {
    return recordID;
  }

  public Object get(String key) {
    try {
      return super.get(key);
    } catch (JSONException ex) {
      return null;
    }
  }

  public Element asXML() {
    String[] names = getClass().getName().split("\\.");
    String className = names[names.length - 1];
    className = className.replaceAll("Record$", "");
    Element rnaiEl = new Element(className);
    for (String fieldName : JSONObject.getNames(this)) {
      String[] fieldSubNames = fieldName.split("_");
      String elementName = "";
      for (String fieldSubName : fieldSubNames) {
        if (fieldSubName.length() > 1) {
          elementName = elementName + fieldSubName.substring(0, 1).toUpperCase() + fieldSubName.substring(1).toLowerCase();
        } else {
          elementName = elementName + fieldSubName.toUpperCase();
        }
      }
      Object value = get(fieldName);
      if (value == null) {
        ExtXMLElement.addElement(rnaiEl, elementName, "");
      } else if (value instanceof Number) {
        Number n = (Number) value;
        if (fieldName.toLowerCase().endsWith("id")) {
          ExtXMLElement.addElement(rnaiEl, elementName, n.intValue() + "");
        } else {
          ExtXMLElement.addElement(rnaiEl, elementName, value.toString());
        }
      } else {
        ExtXMLElement.addElement(rnaiEl, elementName, value.toString());
      }
    }
    return rnaiEl;
  }
}
