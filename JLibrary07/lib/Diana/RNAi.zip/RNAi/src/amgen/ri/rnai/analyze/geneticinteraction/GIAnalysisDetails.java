/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.rnai.analyze.AbstractAnalysisDetails;
import amgen.ri.rnai.analyze.AnalysisDetailsIF;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import java.io.File;
import java.io.Serializable;
import java.util.*;

/**
 *
 * @author jemcdowe
 */
public class GIAnalysisDetails extends AbstractAnalysisDetails implements AnalysisDetailsIF, Serializable {
  static final long serialVersionUID = -4799376995022091388L;
  protected String key;
  
  private List<Integer> giAnalysisIDs;
  
  private List<ExperimentRecord> experimentRecords;
  private List<GIExperiments> giResults;
  private String results;

  /**
   * Get the value of results
   *
   * @return the value of results
   */
  public String getResults() {
    return results;
  }

  /**
   * Set the value of results
   *
   * @param results new value of results
   */
  public void setResults(String results) {
    this.results = results;
  }

  private Date startTime;
  private Date endTime;
  
  public GIAnalysisDetails() {    
  }

  public GIAnalysisDetails(Collection<ExperimentRecord> experimentRecords) {
    super();
    this.key = UUID.randomUUID().toString();
    this.experimentRecords = new ArrayList<ExperimentRecord>(experimentRecords);
    this.giResults = new ArrayList<GIExperiments>();
  }
  

  public GIAnalysisDetails(GIAnalysis giAnalysis, AbstractResponder responder) {
    this(responder.getExperiments(Arrays.asList(giAnalysis.getExperiment_a_id(), giAnalysis.getExperiment_b_id())));
    this.key = "gi"+ giAnalysis.getRecordID();
    this.startTime= giAnalysis.getCreated();
    Calendar c = Calendar.getInstance();
    c.setTime(startTime);
    c.add(Calendar.MILLISECOND, (int)giAnalysis.getElapsed_millis());
    this.endTime= c.getTime();
    
  }  

  public String getKey() {
    return key;
  }

  public String getAnalysisName() {
    return "Genetic Interaction";
  }

  public Properties getAnalysisProperties() {
    throw new UnsupportedOperationException("Not supported yet.");
  }
  
  public List<GIExperiments> getGIExperimentResults() {
    return giResults;
  }

  public void addGIExperimentResults(GIExperiments gie) {
    giResults.add(gie);
  }

  public boolean hasFinished() {
    return (endTime != null);
  }

  public File getAnalysisLog() {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Date getEndTime() {
    return endTime;
  }

  public Date getStartTime() {
    return startTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = (endTime == null ? new Date() : endTime);
  }

  public void setStartTime(Date startTime) {
    this.startTime = (startTime == null ? new Date() : startTime);
  }

  public boolean isValid() {
    return true;
  }

  public List<ExperimentRecord> getExperimentRecords() {
    return experimentRecords;
  }

  /**
   * @return the giAnalysisIDs
   */
  public List<Integer> getGiAnalysisIDs() {
    return giAnalysisIDs;
  }

  /**
   * @param giAnalysisIDs the giAnalysisIDs to set
   */
  public void setGiAnalysisIDs(List<Integer> giAnalysisIDs) {
    this.giAnalysisIDs = giAnalysisIDs;
  }
}
