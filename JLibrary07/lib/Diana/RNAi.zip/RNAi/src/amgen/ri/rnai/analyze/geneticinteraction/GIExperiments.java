/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.csv.CSVReader;
import amgen.ri.json.JSONException;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.HashCodeGenerator;
import java.io.*;
import java.net.URL;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jayanthi
 */
public class GIExperiments implements Serializable {
  static final long serialVersionUID = 27463276600390598L;
  private ExperimentRecord experimentA;
  private ExperimentRecord experimentB;
  private GIAnalysis giAnalysis;
  private String giInputResults;
  private File resultFile;
  private URL webResultURL;
  private File dataFile;
  private File scriptFile;
  private byte[] rawResults;
  private List<String> columns;
  private boolean resultsSet;
  private int fHashCode;

  public GIExperiments(ExperimentRecord experimentA, ExperimentRecord experimentB, File workDir, GIAnalysis giAnalysis) {
    this.experimentA = experimentA;
    this.experimentB = experimentB;
    this.giAnalysis = giAnalysis;
    String experimentsKey = experimentA.getExperimentID() + "_" + experimentB.getExperimentID();
    this.dataFile = new File(workDir, experimentsKey + ".dat");
    this.scriptFile = new File(workDir, experimentsKey + ".sh");
    this.resultFile = new File(workDir, experimentsKey + ".out");
    this.columns = new ArrayList<String>();
  }

  public ExperimentRecord getExperimentA() {
    return experimentA;
  }

  public ExperimentRecord getExperimentB() {
    return experimentB;
  }

  public int getExperimentA_id() {
    return getExperimentA().getExperimentID();
  }

  public int getExperimentB_id() {
    return getExperimentB().getExperimentID();
  }

  /**
   * Get the value of giAnalysis
   *
   * @return the value of giAnalysis
   */
  public GIAnalysis getGIAnalysis() {
    return giAnalysis;
  }

  /**
   * Set the value of giAnalysis
   *
   */
  public void setGIAnalysis(GIAnalysis giAnalysis) {
    this.giAnalysis = giAnalysis;
  }

  /**
   * Get the value of giInputResults
   *
   * @return the value of giInputResults
   */
  public String getGiInputResults() {
    return giInputResults;
  }

  /**
   * Set the value of giInputResults
   *
   * @param giInputResults new value of giInputResults
   */
  public void setGiInputResults(String giInputResults) {
    this.giInputResults = giInputResults;
  }

  public File getDataFile() {
    return dataFile;
  }

  public File getScriptFile() {
    return scriptFile;
  }

  public File getResultFile() {
    return resultFile;
  }
  public URL getWebResultURL() {
    return webResultURL;
  }

  public void setWebResultURL(URL webResultURL) {
    this.webResultURL = webResultURL;
  }

  public List<String> getColumns() {
    return columns;
  }

  public byte[] getRawResults() {
    return rawResults;
  }

  public boolean isResultsSet() {
    return resultsSet;
  }

  public void setResultsFromResultFile(ResourceFactory resourceFactory, PersonRecordIF requestedBy) throws IOException, JSONException {
    setResultsFromReader(resourceFactory, requestedBy, new FileReader(getResultFile()));
  }

  public void setResultsFromReader(ResourceFactory resourceFactory, PersonRecordIF requestedBy, Reader reader) throws IOException, JSONException {
    getGIAnalysis().readResults(resourceFactory, requestedBy, reader);
    
  }

  @Override
  public int hashCode() {
    if (fHashCode == 0) {
      int result = HashCodeGenerator.SEED;
      result = HashCodeGenerator.hash(result, getExperimentA().getExperimentDate() + "." + getExperimentB().getExperimentID());
      fHashCode = result;
    }
    return fHashCode;
  }

  @Override
  public boolean equals(Object obj) {
    if (obj instanceof GIExperiments && obj.getClass().equals(this.getClass())) {
      GIExperiments g1 = this;
      GIExperiments g2 = (GIExperiments) obj;
      return (g1.getExperimentA().getExperimentID() == g2.getExperimentA().getExperimentID()
              && g1.getExperimentB().getExperimentID() == g2.getExperimentB().getExperimentID());
    }
    return false;
  }
}
