/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.search.ResourceFactory;
import java.util.Collection;
import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jemcdowe
 */
public class GIOracleInsertListener implements GeneticInteractionListenerIF {
  private ResourceFactory resourceFactory;

  public GIOracleInsertListener(ResourceFactory resourceFactory) {
    this.resourceFactory = resourceFactory;
  }

  public void processBegan(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments) {
  }

  public void analysisStarted(GeneticInteractionAnalysis geneticInteractionAnalysis, GIExperiments gie) {
    SqlSession sqlSession = null;
    try {
      sqlSession = resourceFactory.getRNAiSqlSession(ExecutorType.BATCH);
      sqlSession.getMapper(Mapper.class).deleteGIResults(gie.getGIAnalysis());
      sqlSession.getMapper(Mapper.class).deleteGIAnalysis(gie.getGIAnalysis());
      sqlSession.getMapper(Mapper.class).insertGIAnalysis(gie.getGIAnalysis());
      sqlSession.commit();
    } finally {
      resourceFactory.close(sqlSession);
    }
  }

  public void analysisComplete(GeneticInteractionAnalysis geneticInteractionAnalysis, GIExperiments gie) {
    SqlSession sqlSession = null;
    try {
      GIAnalysis giAnalysis = gie.getGIAnalysis();
      giAnalysis.setElapsed_millis(System.currentTimeMillis() - giAnalysis.getCreated().getTime());
      sqlSession = resourceFactory.getRNAiSqlSession(ExecutorType.BATCH);
      sqlSession.getMapper(Mapper.class).updateGIAnalysisElapsedMillis(giAnalysis);

      sqlSession.getMapper(Mapper.class).deleteGIResults(giAnalysis);
      for (GIResult giResult : gie.getGIAnalysis().getResultList()) {
        sqlSession.getMapper(Mapper.class).insertGIResults(giResult);
      }
      sqlSession.commit();
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      resourceFactory.close(sqlSession);
    }
  }

  public void processEnded(GeneticInteractionAnalysis giAnalysis, Collection<ExperimentRecord> experiments) {
  }
}
