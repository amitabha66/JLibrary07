/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.dao;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.graphs.SurvivalPlotData;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.util.ExtObject;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import org.apache.commons.lang.ArrayUtils;

/**
 *
 * @author jemcdowe
 */
public class SurvivalPlotInput {
  private ExperimentRecord experimentRecord;
  private List<GeneRecord> targetGeneRecords;
  private List<GeneRecord> controlGeneRecords;
  private JSONObject jResults;
  private List<SurvivalPlotData> survivalPlotData;

  public SurvivalPlotInput(ExperimentRecord experimentRecord, List<GeneRecord> targetGeneRecords, List<GeneRecord> controlGeneRecords) {
    this.experimentRecord = experimentRecord;
    this.targetGeneRecords = targetGeneRecords;
    this.controlGeneRecords = controlGeneRecords;
    this.survivalPlotData = new ArrayList<SurvivalPlotData>();
  }

  /**
   * Get the value of experimentID
   *
   * @return the value of experimentID
   */
  public int getExperimentID() {
    return experimentRecord.getExperimentID();
  }

  public List<Integer> getTargetGeneIDs() {
    List<Integer> targetGeneIDs = new ArrayList<Integer>();
    for (GeneRecord targetGeneRecord : targetGeneRecords) {
      targetGeneIDs.add(targetGeneRecord.getGeneID());
    }
    return targetGeneIDs;
  }

  public List<Integer> getControlGeneIDs() {
    List<Integer> controlGeneIDs = new ArrayList<Integer>();
    for (GeneRecord controlGeneRecord : controlGeneRecords) {
      controlGeneIDs.add(controlGeneRecord.getGeneID());
    }
    return controlGeneIDs;
  }

  public List<Integer> getTargetAndControlGeneIDs() {
    List<Integer> targetAndControlGeneIDs = new ArrayList<Integer>(getTargetGeneIDs());
    targetAndControlGeneIDs.addAll(getControlGeneIDs());
    return targetAndControlGeneIDs;
  }

  public List<Integer> getTargetGeneMixtureIDs() {
    return getTargetGeneIDs();
  }

  public List<Integer> getControlGeneMixtureIDs() {
    return getControlGeneIDs();
  }

  public List<Integer> getTargetAndControlGeneMixtureIDs() {
    return getTargetAndControlGeneIDs();
  }
  // (Integer rnaiID, Integer geneID, String isMixture, String primaryGeneSymbol, String barcode, Integer wellID, Integer experimentID, Double poc) {

  public void setResults(Byte[] b) throws IOException, ClassNotFoundException {
    this.survivalPlotData.clear();
    ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(ArrayUtils.toPrimitive(b))));
    jResults = (JSONObject) objIN.readObject();
    try {
      if (jResults.has("results")) {
        List<JSONObject> results = jResults.getJSONArray("results").asList();
        for (JSONObject jResult : results) {
          int rnaiID = jResult.getInt("rnai_id");
          int geneID = jResult.getInt("gene_id");
          String isMixture = jResult.getString("is_mixture");
          String primaryGeneSymbol = jResult.getString("primary_gene_symbol");
          String barcode = jResult.getString("barcode");
          int wellID = jResult.getInt("well_id");
          int experimentID = jResult.getInt("experiment_id");
          double poc = jResult.getDouble("poc");
          this.survivalPlotData.add(
              new SurvivalPlotData(rnaiID, geneID, isMixture, primaryGeneSymbol, barcode, wellID, experimentID, poc));
        }
      }
    } catch (JSONException ex) {
      Logger.getLogger(SurvivalPlotInput.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  public String getSql() {
    return "SELECT GMP.RNAI_ID \"rnai_id\", "
            + "    GMP.GENE_MIXTURE_ID \"gene_id\", "
            + "    GMP.IS_MIXTURE \"is_mixture\", "
            + "    GMP.PRIMARY_GENE_SYMBOL \"primary_gene_symbol\", "
            + "    GMP.BARCODE \"barcode\", "
            + "    GMP.WELL_ID \"well_id\", "
            + "    GMP.EXPERIMENT_ID \"experiment_id\", "
            + "    GMP.POC \"poc\" "
            + "    FROM RNAI_GENE_MIXTURES_POCS_VW GMP "
            + "    WHERE EXPERIMENT_ID = :experiment_id "
            + "    UNION "
            + "   SELECT GM.RNAI_ID \"rnai_id\", "
            + "    GM.GENE_ID \"gene_id\", "
            + "    GM.IS_MIXTURE \"is_mixture\", "
            + "    GM.PRIMARY_GENE_SYMBOL \"primary_gene_symbol\", "
            + "    GM.BARCODE \"barcode\", "
            + "    GM.WELL_ID \"well_id\", "
            + "    GM.EXPERIMENT_ID \"experiment_id\", "
            + "    GM.POC \"poc\" "
            + "    FROM RNAI_GENE_POCS_VW GM "
            + "    WHERE EXPERIMENT_ID = :experiment_id";
  }

  public byte[] getQuery() throws IOException {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value = new HashMap<String, String>();
    query.add(value);
    value.put("experiment_id", experimentRecord.getExperimentID() + "");
    byte[] b = ExtObject.serializeObject(query);

    return b;
  }
  
  public List<SurvivalPlotData> getSurvivalPlotData() {
    return survivalPlotData;
  }

}
