/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

/**
 *
 * @author jemcdowe
 */
class MissingParameterException extends Exception {

  public MissingParameterException(String msg) {
    super(msg);
  }
  
}
