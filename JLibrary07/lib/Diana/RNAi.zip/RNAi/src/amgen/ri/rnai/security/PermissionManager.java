package amgen.ri.rnai.security;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * A simple security manager for verifying RNAi permissions. Permissions are
 * defined in the PermissionType enum and are by global Outlook distribution
 * list groups.
 *
 * @author jemcdowe
 */
public class PermissionManager extends ResourceFactory {
  private PersonRecordIF requestedBy;
  private Map<PermissionType, Class> permissionTypeMap;

  public PermissionManager(MainUI servletBase) {
    this(servletBase.getPersonRecord());
  }

  public PermissionManager(PersonRecordIF requestedBy) {
    super(null);
    this.requestedBy = requestedBy;
    permissionTypeMap = new HashMap<PermissionType, Class>();
    permissionTypeMap.put(PermissionType.PUBLISH, PublishPermissionRule.class);
    permissionTypeMap.put(PermissionType.DELETE, DeletePermissionRule.class);
    permissionTypeMap.put(PermissionType.EDIT, EditPermissionRule.class);
    permissionTypeMap.put(PermissionType.ANALYZE, AnalyzePermissionRule.class);
    permissionTypeMap.put(PermissionType.VIEW, ViewPermissionRule.class);
    permissionTypeMap.put(PermissionType.IMPORT, ImportPermissionRule.class);
  }

  /**
   * Check whether the requestedBy user as the given privilege for the record
   * and throws a SecurityException if not true/false
   *
   * @param permission
   * @return
   * @throws SecurityException
   */
  public void checkPermission(PermissionType permission, AbstractRecord record) throws SecurityException {
    if (permission == null) {
      return;
    }
    PermissionRuleIF permissionRule = null;
    try {
      Class permissionRuleClass = permissionTypeMap.get(permission);
      if (permissionRuleClass == null) {
        throw new IllegalArgumentException("Unknown permission type");
      }
      permissionRule =
              (PermissionRuleIF) permissionRuleClass.getConstructor(new Class[]{PersonRecordIF.class}).newInstance(new Object[]{requestedBy});
    } catch (Exception e) {
      e.printStackTrace();
      throw new IllegalArgumentException("Unable to run permission rule: " + e);
    }
    permissionRule.checkPermission(record);
  }

  /**
   * Sets all permissions for the record into an array with key 'permissions'
   * Each permission has the kaye/value of
   * 'can_<permission in lower case>' : [true | false]
   *
   * @param record
   */
  public void setRecordPermissions(AbstractRecord record) {
    try {
      record.put("permissions", new JSONObject());
      for (PermissionType permission : PermissionType.values()) {
        if (!permission.equals(PermissionType.UNKNOWN)) {
          record.getJSONObject("permissions").put("can_" + permission.toString().toLowerCase(), hasPermission(permission, record));
        }
      }
    } catch (JSONException ex) {
    }
  }

  /**
   * Check whether the requestedBy user as the given privilege for the records
   * and returns true/false
   *
   * @param permission
   * @param records
   * @return
   * @throws SecurityException
   */  
  public boolean hasPermission(PermissionType permission, AbstractRecord... records) {
    return hasPermission(permission, (records== null ? new ArrayList<AbstractRecord>() : Arrays.asList(records)));   
  }

  /**
   * Check whether the requestedBy user as the given privilege for the records
   * and returns true/false
   *
   * @param permission
   * @return
   * @throws SecurityException
   */
  public boolean hasPermission(PermissionType permission, List<? extends AbstractRecord> records) {
    try {      
      for (AbstractRecord record : records) {
        try {
          checkPermission(permission, record);
        } catch (IllegalArgumentException e) {}
      }
      return true;
    } catch (SecurityException e) {
      return false;
    } catch (Exception e) {
      e.printStackTrace();
      return false;
    }
  }
}
