/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jemcdowe
 */
public class OperationLogRecord extends AbstractRecord {
  public OperationLogRecord(JSONObject source) throws JSONException {
    super(source, "log_id");
  }

  public OperationLogRecord(Integer logID) {
    super(logID + "");
    add("log_id", logID);
  }

  /**
   * Get the value of log_id
   *
   * @return the value of log_id
   */
  public int getLog_id() {
    return getNumber("log_id").intValue();
  }

  /**
   * Set the value of log_id
   *
   * @param log_id new value of log_id
   */
  public void setLog_id(int log_id) {
    add("log_id", log_id);
  }

  /**
   * Get the value of reference_id
   *
   * @return the value of reference_id
   */
  public int getReference_id() {
    return getNumber("reference_id").intValue();
  }

  /**
   * Set the value of reference_id
   *
   * @param reference_id new value of reference_id
   */
  public void setReference_id(int reference_id) {
    add("reference_id", reference_id);
  }

  /**
   * Get the value of log_type
   *
   * @return the value of log_type
   */
  public String getLog_type() {
    return getString("log_type");
  }

  /**
   * Set the value of log_type
   *
   * @param log_type new value of log_type
   */
  public void setLog_type(String log_type) {
    add("log_type", log_type);
  }

  /**
   * Get the value of entry_date
   *
   * @return the value of entry_date
   */
  public Date getEntry_date() {
    return getDate("entry_date");
  }

  /**
   * Set the value of entry_date
   *
   * @param entry_date new value of entry_date
   */
  public void setEntry_date(Date entry_date) {
    add("entry_date", entry_date);
  }

  /**
   * Get the value of entered_by
   *
   * @return the value of entered_by
   */
  public String getEntered_by() {
    return getString("entered_by");
  }

  /**
   * Set the value of entered_by
   *
   * @param entered_by new value of entered_by
   */
  public void setEntered_by(String entered_by) {
    add("entered_by", entered_by);
  }

  /**
   * Get the value of log_data
   *
   * @return the value of log_data
   */
  public String getLog_data() {
    return getString("log_data");
  }

  /**
   * Set the value of log_data
   *
   * @param log_data new value of log_data
   */
  public void setLog_data(String log_data) {
    add("log_data", log_data);
  }

  public JSONObject asNode() {
    JSONObject jNode = new JSONObject();
    try {
      jNode.put("id", getLog_id());
      jNode.put("leaf", true);
      String title= getLog_type().replaceAll("_", " ");
      title= ExtString.toTitleCase(title);
      title= title.replaceAll("Oga", "OGA");
      
      jNode.put("text", title + " [" + dateFormat.format(getEntry_date()) + "]");
    } catch (JSONException ex) {
      Logger.getLogger(OperationLogRecord.class.getName()).log(Level.SEVERE, null, ex);
    }
    return jNode;
  }
}
