package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.util.List;

/**
 * A record used to define Plate metadata
 * @author jemcdowe
 */
public final class PlateInfo extends AbstractRecord {  

  public PlateInfo(JSONObject obj) throws JSONException {
    super(obj, "barcode");
    switch(getDensity()) {
      case 1536:
        put("rows", 32);
        put("cols", 48);
        break;
      case 384:
        put("rows", 16);
        put("cols", 24);
        break;
      case 96:
        put("rows", 8);
        put("cols", 12);
        break;        
    }
  }
  
  public String getBarcode() {
    return getString("barcode");
  }

  public final void setBarcode(String barcode) {
    add("barcode", barcode);
  }

  public int getDensity() {
    return getNumber("density").intValue();
  }

  public int getRows() {
    return getNumber("rows").intValue();
  }

  public int getCols() {
    return getNumber("cols").intValue();
  }

  public final void setDensity(int density) {
    add("density", density);
  }

  public String getLayout() {
    return getString("layout");
  }

  public final void setLayout(String layout) {
    add("layout", layout);
  }

  public String getSite() {
    return getString("site");
  }

  public final void setSite(String site) {
    add("site", site);
  }

  public String getType() {
    return getString("type");
  }

  public final void setType(String type) {
    add("type", type);
  }

  public List<JSONObject> getWells() {
    return getList("wells");
  }
}
