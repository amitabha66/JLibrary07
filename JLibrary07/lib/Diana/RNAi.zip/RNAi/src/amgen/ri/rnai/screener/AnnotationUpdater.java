/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener;

import amgen.ri.crypt.StringEncrypter;
import amgen.ri.crypt.StringEncrypter.EncryptionException;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import java.io.*;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

public class AnnotationUpdater extends ResourceFactory {

    public AnnotationUpdater(SessionCache sessionCache) {
      super(sessionCache);
    }

    private AppServerReturnObject getId(Connection conn, String seqName) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        try {
            String queryString = "";
            queryString = "select " + seqName + ".nextval from dual";
            String seqId = "";
            Statement stmtSeqId = conn.createStatement();
            ResultSet rsSeqId = stmtSeqId.executeQuery(queryString);
            if (rsSeqId.next()) {
                seqId = Integer.toString(rsSeqId.getInt(1));
                rsSeqId.close();
                stmtSeqId.close();
                asro.setReturnObject(seqId);
                asro.setCallSucceed(true);
                return asro;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject getAnnotationGroup() {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        try {
            conn = getRNAiConnection();
            String queryString = "select * from annotation_group order by annotation_group_name";
            PreparedStatement ps = conn.prepareStatement(queryString);
            ResultSet rs = ps.executeQuery();
            JSONObject jResponse = new JSONObject();
            while (rs.next()) {
                String annotation_group_id = rs.getString("annotation_group_id");
                String annotation_group_name = rs.getString("annotation_group_name");
                JSONObject jCollection = new JSONObject();
                jCollection.put("annotation_group_id", annotation_group_id);
                jCollection.put("annotation_group_name", annotation_group_name);
                jResponse.append("annotation_group", jCollection);
            }
            asro.setReturnObject(jResponse);
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    public JSONObject processGetAnnotationGroup(Logger logger) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = getAnnotationGroup();
        if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    public AppServerReturnObject getAnnotation() {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        try {
            conn = getRNAiConnection();
            String queryString =
                    "select a.annotation_id, a.annotation_name, a.annotation_default_value, a.rnai_type_id, RT.RNAI_TYPE, " + "\n"
                    + "A.ANNOTATION_TYPE, A.DISPLAY_ORDER, A.annotation_group_id, AG.annotation_group_name" + "\n"
                    + "from annotation a, annotation_group ag, annotation_type at, rnai_type rt where" + "\n"
                    + "A.RNAI_TYPE_ID = RT.RNAI_TYPE_ID" + "\n"
                    + "and A.ANNOTATION_GROUP_ID = AG.ANNOTATION_GROUP_ID" + "\n"
                    + "and A.ANNOTATION_TYPE = AT.ANNOTATION_TYPE order by annotation_name";

            //System.out.println(queryString);
            PreparedStatement ps = conn.prepareStatement(queryString);
            ResultSet rs = ps.executeQuery();
            JSONObject jResponse = new JSONObject();
            while (rs.next()) {
                String annotation_id = rs.getString("annotation_id");
                String annotation_name = rs.getString("annotation_name");
                String annotation_default_value = rs.getString("annotation_default_value");
                String rnai_type_id = rs.getString("rnai_type_id");
                String rnai_type = rs.getString("rnai_type");
                String annotation_type = rs.getString("annotation_type");
                String display_order = rs.getString("display_order");
                String annotation_group_id = rs.getString("annotation_group_id");
                String annotation_group_name = rs.getString("annotation_group_name");

                JSONObject jCollection = new JSONObject();
                jCollection.put("annotation_id", annotation_id);
                jCollection.put("annotation_name", annotation_name);
                jCollection.put("annotation_default_value", annotation_default_value);
                jCollection.put("rnai_type_id", rnai_type_id);
                jCollection.put("rnai_type", rnai_type);
                jCollection.put("annotation_type", annotation_type);
                jCollection.put("display_order", display_order);
                jCollection.put("annotation_group_id", annotation_group_id);
                jCollection.put("annotation_group_name", annotation_group_name);

                jResponse.append("annotation", jCollection);
            }
            asro.setReturnObject(jResponse);
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    public JSONObject processGetAnnotation(Logger logger) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = getAnnotation();
        if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    public AppServerReturnObject getAnnotationOption(String annotation_ids) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        try {

            conn = getRNAiConnection();

            String queryString =
                    "select * from annotation_option where annotation_id in ( " + annotation_ids + ") order by annotation_id, display_order";
            //System.out.println(queryString);
            PreparedStatement ps = conn.prepareStatement(queryString);
            ResultSet rs = ps.executeQuery();
            JSONObject jResponse = new JSONObject();
            while (rs.next()) {
                String annotation_option_id = rs.getString("annotation_option_id");
                String annotation_id = rs.getString("annotation_id");
                String annotation_option_name = rs.getString("annotation_option_name");
                String annotation_option_description = rs.getString("annotation_option_description");
                String display_order = rs.getString("display_order");

                JSONObject jCollection = new JSONObject();
                jCollection.put("annotation_option_id", annotation_option_id);
                jCollection.put("annotation_id", annotation_id);
                jCollection.put("annotation_option_name", annotation_option_name);
                jCollection.put("annotation_option_description", annotation_option_description);
                jCollection.put("display_order", display_order);

                jResponse.append("annotationoptions", jCollection);
            }
            asro.setReturnObject(jResponse);
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    public JSONObject processGetAnnotationOption(Logger logger, String annotation_id) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = getAnnotationOption(annotation_id);
        if (asro.isCallSucceed()) {
            jResponse = (JSONObject) asro.getReturnObject();
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    private AppServerReturnObject deleteAnnotation(String tableName, String deleteIds) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        try {
//System.out.println(tableName);
//System.out.println(deleteIds);
            conn = getRNAiConnection();
            Statement stmt_gruop_annotation = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String updateQ = "";
            if (tableName.equalsIgnoreCase("annotation_option")) {
                updateQ = "delete from annotation_option where annotation_option_id in(" + deleteIds + ")";
            } else if (tableName.equalsIgnoreCase("annotation_group")) {
                updateQ = "delete from annotation_group where annotation_group_id in(" + deleteIds + ")";
            } else if (tableName.equalsIgnoreCase("annotation")) {
                updateQ = "delete from annotation_option where annotation_id in(" + deleteIds + ")";
                stmt_gruop_annotation.addBatch(updateQ);
                updateQ = "delete from annotation where annotation_id in(" + deleteIds + ")";

            }
            //System.out.println(updateQ);
            stmt_gruop_annotation.addBatch(updateQ);

            int[] updateCountsAnnotation = stmt_gruop_annotation.executeBatch();
            stmt_gruop_annotation.close();
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception e1) {
            }
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    private AppServerReturnObject updateAnnotation(String tableName, String updateJSONString) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        try {
            if (!ExtJSON.isJSON(updateJSONString)) {
                asro.setCallSucceed(false);
                asro.setComment("Invalid JSON string: " + updateJSONString);
            }
            conn = getRNAiConnection();
            Statement stmt_gruop_annotation = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            JSONArray ja = (JSONArray) ExtJSON.toJSON(updateJSONString);
            for (int i = 0; i < ja.length(); i++) {
                JSONObject jo = (JSONObject) ja.get(i);
                String updateQ = "";
                if (tableName.equalsIgnoreCase("annotation_option")) {
                    updateQ = "update annotation_option set ";
                    updateQ = updateQ + " annotation_option_name =RECTIFY_NON_ASCII(" + "'" + jo.getString("annotation_option_name") + "')";
                    updateQ = updateQ + ", annotation_option_description =" + "'" + (jo.getString("annotation_option_description") == null ? "" : jo.getString("annotation_option_description")) + "'";
                    updateQ = updateQ + ", display_order =" + jo.getString("display_order");
                    updateQ = updateQ + " where annotation_option_id = " + jo.getString("annotation_option_id");
                } else if (tableName.equalsIgnoreCase("annotation_group")) {
                    updateQ = "update annotation_group set ";
                    updateQ = updateQ + " annotation_group_name =" + "'" + jo.getString("annotation_group_name") + "'";
                    updateQ = updateQ + " where annotation_group_id = " + jo.getString("annotation_group_id");
                } else if (tableName.equalsIgnoreCase("annotation")) {
                    updateQ = "update annotation set ";
                    updateQ = updateQ + " annotation_name =" + "'" + jo.getString("annotation_name") + "'";
                    updateQ = updateQ + ", annotation_default_value =" + "'" + jo.getString("annotation_default_value") + "'";
                    updateQ = updateQ + ", rnai_type_id =" + jo.getString("rnai_type_id");
                    updateQ = updateQ + ", annotation_type =" + "'" + jo.getString("annotation_type") + "'";
                    updateQ = updateQ + ", display_order =" + jo.getString("display_order");
                    updateQ = updateQ + ", annotation_group_id =" + jo.getString("annotation_group_id");
                    updateQ = updateQ + " where annotation_id = " + jo.getString("annotation_id");

                }
                //System.out.println(updateQ);
                stmt_gruop_annotation.addBatch(updateQ);
            }
            int[] updateCountsAnnotation = stmt_gruop_annotation.executeBatch();
            stmt_gruop_annotation.close();
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception e1) {
            }
        } finally {
            closeResources(conn);
        }
        return asro;
    }

    public JSONObject processUpdateAnnotation(Logger logger, String tableName, String updateJSONString) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = updateAnnotation(tableName, updateJSONString);
        if (asro.isCallSucceed()) {
            jResponse.put("message", "Passed");
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    public JSONObject processDeleteAnnotation(Logger logger, String tableName, String deleteIds) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = deleteAnnotation(tableName, deleteIds);
        if (asro.isCallSucceed()) {
            jResponse.put("message", "Passed");
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    public JSONObject processAddAnnotation(Logger logger, String tableName, String addJSONString) throws Exception {
        JSONObject jResponse = new JSONObject();
        AppServerReturnObject asro = addAnnotation(tableName, addJSONString);
        if (asro.isCallSucceed()) {
            jResponse.put("message", "Passed");
        } else {
            jResponse.put("message", asro.getReturnObject());
        }
        //System.out.println(jResponse);
        logger.debug(jResponse);
        return jResponse;
    }

    private AppServerReturnObject addAnnotation(String tableName, String addJSONString) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        Connection conn = null;
        //System.out.println(addJSONString);
        try {
            if (!ExtJSON.isJSON(addJSONString)) {
                asro.setCallSucceed(false);
                asro.setComment("Invalid JSON string: " + addJSONString);
            }
            conn = getRNAiConnection();
            Statement stmt_gruop_annotation = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            JSONObject jo = (JSONObject) ExtJSON.toJSON(addJSONString);
            String insertQ = "";

            if (tableName.equalsIgnoreCase("annotation_group")) {
                insertQ = "insert into annotation_group (annotation_group_id, annotation_group_name)";
                insertQ = insertQ + " values (";
                insertQ = insertQ + "RNAI_annotation.nextval";
                insertQ = insertQ + ",'" + jo.getString("annotation_group_name") + "'";
                insertQ = insertQ + " )";
                stmt_gruop_annotation.addBatch(insertQ);
                //System.out.println(insertQ);
            } else if (tableName.equalsIgnoreCase("annotation")) {
                asro = getId(conn, "RNAI_annotation");
                if (!asro.isCallSucceed()) {
                    return asro;
                }
                String annotation_id = (String) asro.getReturnObject();
                String annotation_option_name = jo.getString("annotation_option_name");
                String annotation_option_desc = jo.getString("annotation_option_desc");
                
                insertQ = "insert into annotation (annotation_id, annotation_name, rnai_type_id, annotation_type, display_order,annotation_group_id, annotation_default_value, source)";
                insertQ = insertQ + " values (";
                insertQ = insertQ + annotation_id;
                insertQ = insertQ + ",'" + jo.getString("annotation_name") + "'";
                insertQ = insertQ + ", " + jo.getString("rnai_type_id");
                insertQ = insertQ + ", " + "'" + "TEXT" + "'";
                insertQ = insertQ + ", " + jo.getString("display_order");
                insertQ = insertQ + ", " + jo.getString("annotation_group_id");
                insertQ = insertQ + ", " + "'" + jo.getString("annotation_default_value") + "'";
                insertQ = insertQ + ", " + "'" + jo.getString("annotation_type") + "'";
                insertQ = insertQ + " )";
                System.out.println(insertQ);
                stmt_gruop_annotation.addBatch(insertQ);
                
                
                String[] allOptionNames = annotation_option_name.split("\n");
                String[] allOptionDescs = annotation_option_desc.split("\n");
                
                for (int j = 0; j < allOptionNames.length; j++) {
                    String cur_option = allOptionNames[j];
                    if(cur_option == null || cur_option.length()==0){
                        continue;
                    }
                    String cur_desc = "";
                    if (allOptionDescs != null && allOptionDescs.length > j && allOptionDescs[j] != null) {
                        cur_desc = allOptionDescs[j];
                    }
                    insertQ = "insert into annotation_option (annotation_option_id, annotation_id, annotation_option_name, annotation_option_description, display_order)";
                    insertQ = insertQ + " values (";
                    insertQ = insertQ + "RNAI_annotation.nextval";
                    insertQ = insertQ + ", " + annotation_id;
                    insertQ = insertQ + ", RECTIFY_NON_ASCII('" + cur_option + "')";
                    insertQ = insertQ + ", '" + cur_desc + "'";
                    insertQ = insertQ + ", " + j;
                    insertQ = insertQ + " )";
                    System.out.println(insertQ);
                    stmt_gruop_annotation.addBatch(insertQ);
                    
                }
                
                
                
            } else if (tableName.equalsIgnoreCase("annotation_option")) {
                String annotation_id = jo.getString("annotation_id");
                int display_order = 0;
                String queryString = "select max(display_order) as md from annotation_option where annotation_id = " + annotation_id;
                PreparedStatement ps = conn.prepareStatement(queryString);
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    display_order = rs.getInt("md");
                }

                String annotation_option_name = jo.getString("annotation_option_name");
                String annotation_option_desc = jo.getString("annotation_option_desc");
                String[] allOptionNames = annotation_option_name.split("\n");
                String[] allOptionDescs = annotation_option_desc.split("\n");
                for (int j = 0; j < allOptionNames.length; j++) {
                    String cur_option = allOptionNames[j];
                    String cur_desc = "";
                    if (allOptionDescs != null && allOptionDescs.length > j && allOptionDescs[j] != null) {
                        cur_desc = allOptionDescs[j];
                    }
                    display_order = display_order + 1;
                    insertQ = "insert into annotation_option (annotation_option_id, annotation_id, annotation_option_name, annotation_option_description, display_order)";
                    insertQ = insertQ + " values (";
                    insertQ = insertQ + "RNAI_annotation.nextval";
                    insertQ = insertQ + ", " + annotation_id;
                    insertQ = insertQ + ", RECTIFY_NON_ASCII('" + cur_option + "')";
                    insertQ = insertQ + ", '" + cur_desc + "'";
                    insertQ = insertQ + ", " + display_order;
                    insertQ = insertQ + " )";
                    //System.out.println(insertQ);
                    stmt_gruop_annotation.addBatch(insertQ);
                }


            }
            int[] updateCountsAnnotation = stmt_gruop_annotation.executeBatch();
            stmt_gruop_annotation.close();
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception e1) {
            }
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    public static void testEncrypt() throws EncryptionException {
        String passwd = "Ra1n1ng#";
        StringEncrypter st = new StringEncrypter();
        String encrypted = st.encrypt(passwd);
        encrypted = "!b1F7d0/eb9LTGvH4AH2Hyw==";
        String decrypted = st.decrypt(encrypted);
        //System.out.println(encrypted + ":" + decrypted);

    }

    public static void main(String[] args) throws Exception {
        //testEncrypt();
        //testAddAnnotationGroup();
        //testgetAnnotationGroup();
        //testAddAnnotation();
        //testCurrentCellLinesAgainstRTF();
        //testGetCellLinesFromRTF();
        testCurrentCellLinesAgainstRTFDirectRead();
        //testUpdateAnnotationGroup();
        //testUpdateAnnotationOption();
    }

    public static void testGetCellLinesFromRTF() throws Exception {
        File outFile = new File("H:\\projects\\RNAi\\annotations\\rtf_all_celllines.xml");
        OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8");
        String line = null;
        String url = "http://rtf/rtf/REST/xml/term/5806296?detail=128";
        URL link = new URL(url);
        URLConnection yc = link.openConnection();
        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        String inputLine;
        while ((inputLine = in.readLine()) != null) {
            out.write(inputLine + "\n");
        }
        out.write("\n\n");
        out.flush();
        out.close();
    }

    public static void testCurrentCellLinesAgainstRTF() throws Exception {
        //File outFile = new File("H:\\projects\\RNAi\\annotations\\rtf_current_celllines.txt");
        File outFile = new File("H:\\projects\\RNAi\\experiments_set2_cell_lines.txt");
        OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8");
        BufferedReader br = new BufferedReader(new FileReader("H:\\projects\\RNAi\\annotations\\annotation.txt"));
        String line = null;
        int count = 0;
        while ((line = br.readLine()) != null) {
            count++;
            out.write("CellLine(" + count + "): " + line.trim() + "\n");
            //String url = "http://rtf/rtf/Handlers/Query.ashx?scope_term_id=5806296&terms_by_text=" + line.trim() + "&detail=0&output=xml";
            String url = "http://rtf/rtf/REST/xml/term/5806296/terms;text=" + line.trim() + "?detail=4208";
            URL link = new URL(url);
            URLConnection yc = link.openConnection();
            BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                out.write(inputLine + "\n");
            }
            out.write("\n\n");

        }
        out.flush();
        out.close();
    }

    public static void testCurrentCellLinesAgainstRTFDirectRead() throws Exception {
        ArrayList allCellLines = new ArrayList();

        //File outFile = new File("H:\\projects\\RNAi\\annotations\\sharepoint_rtf_celllines.txt");
        //File outFile = new File("H:\\projects\\RNAi\\experiments_set2_cell_lines_match.txt");
        File outFile = new File("H:\\projects\\RNAi\\AllExperimentCellLinesResult.txt");
        OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8");


        //BufferedReader br = new BufferedReader(new FileReader("H:\\projects\\RNAi\\annotations\\annotation.txt"));
        //BufferedReader br = new BufferedReader(new FileReader("H:\\projects\\RNAi\\experiments_set2_cell_lines.txt"));
        BufferedReader br = new BufferedReader(new FileReader("H:\\projects\\RNAi\\AllExperimentCellLines.txt"));
        String line = null;
        int count = 0;
        Namespace rtf_ns = Namespace.getNamespace("r", "http://rtf.research.amgen.com/rtf/schema/v1");

        out.write("CellLine(Current)" + "\t" + "Name" + "\t" + "Anatomy" + "\t" + "ATCC ID" + "\t" + "Aliases" + "\n");
        while ((line = br.readLine()) != null) {
            if (allCellLines.contains(line.trim())) {
                continue;
            } else {
                allCellLines.add(line.trim());
            }
            count++;
            String name = "";
            String anatomy = "";
            String aliases = "";
            String atcc = "";
            SAXBuilder builder = new SAXBuilder();
            String url = "http://rtf/rtf/REST/xml/term/5806296/term;text=" + line.trim() + "?detail=4208";
            Document doc = null;
            try {
                doc = builder.build(new URL(url));
            } catch (Exception e) {
                //System.out.println(line.trim());
                out.write("CellLine(" + count + "): " + line.trim() + "\n");
                continue;
            }
            //Document doc = builder.build(new File("H:\\projects\\RNAi\\annotations\\result_293T.xml"));
            Namespace RTF = Namespace.getNamespace("r", "http://rtf.research.amgen.com/rtf/schema/v1");
            XPath xPathName = XPath.newInstance("/r:term/r:name");
            xPathName.addNamespace(RTF);
            Element nameE = (Element) xPathName.selectSingleNode(doc);
            name = nameE.getText();

            XPath xPathAnatomy = XPath.newInstance("/r:term/r:attributes/r:attribute[@shortName='Anatomy']/r:value/r:term/r:name");
            xPathAnatomy.addNamespace(RTF);
            Element anatomyE = (Element) xPathAnatomy.selectSingleNode(doc);
            if (anatomyE != null) {
                anatomy = anatomyE.getText();
            }

            XPath xPathAtcc = XPath.newInstance("/r:term/r:attributes/r:attribute[@shortName='ATCC#']/r:value/r:text");
            xPathAtcc.addNamespace(RTF);
            Element atccE = (Element) xPathAtcc.selectSingleNode(doc);
            if (atccE != null) {
                atcc = atccE.getText();
            }

            XPath xPathAliases = XPath.newInstance("/r:term/r:aliases/r:alias");
            xPathAliases.addNamespace(RTF);
            List aliasesList = (List) xPathAliases.selectNodes(doc);
            ArrayList aliasList = new ArrayList();
            for (int i = 0; i < aliasesList.size(); i++) {
                Element aliasE = (Element) aliasesList.get(i);
                if (!aliasList.contains(aliasE.getChildText("name", RTF))) {
                    aliases = aliases + aliasE.getChildText("name", RTF) + ",";
                    aliasList.add(aliasE.getChildText("name", RTF));
                }
            }

            if (aliases.length() > 0) {
                aliases = aliases.substring(0, aliases.lastIndexOf(","));
            }
            String result = "CellLine(" + count + "): " + line.trim() + "\t" + name + "\t" + anatomy + "\t" + atcc + "\t" + aliases;
            System.out.println(result);
            out.write(result + "\n");



        }
        out.flush();
        out.close();

    }

    public static void testAddAnnotation() throws Exception {
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@ussf-tdbx-ora03:1771:sf0010d.amgen.com");

        AppServerReturnObject asro = new AppServerReturnObject("", false, null);
        AnnotationUpdater ap = new AnnotationUpdater(null);
        String annotation_name = null;
        String annotation_default_value = null;
        int rnai_type_id = 0;
        String annotation_type = null;
        int display_order = 0;
        int annotation_group_id = 0;
        String options = "";

        annotation_name = "EXPERIMENT_TYPE";
        annotation_default_value = "Viability";
        rnai_type_id = 1;
        annotation_type = "TEXT";
        display_order = 3;
        annotation_group_id = 32;

        BufferedReader br = new BufferedReader(new FileReader("H:\\projects\\RNAi\\annotations\\annotation.txt"));

        String line = null;
        while ((line = br.readLine()) != null) {
            options = options + line + ",";
        }

    }

    public static void testgetAnnotationGroup() throws Exception {
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@ussf-tdbx-ora03:1771:sf0010d.amgen.com");
        AppServerReturnObject asro = new AppServerReturnObject("", false, null);
        AnnotationUpdater ap = new AnnotationUpdater(null);
        asro = ap.getAnnotationGroup();
        if (asro.isCallSucceed()) {
            //System.out.println("Call OK");
            JSONObject res = (JSONObject) asro.getReturnObject();
            //System.out.println(res);
        } else {
            //System.out.println("Call failed");
        }
    }

    public static void testAddAnnotationGroup() throws Exception {
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@ussf-tdbx-ora03:1771:sf0010d.amgen.com");
        AppServerReturnObject asro = new AppServerReturnObject("", false, null);
        AnnotationUpdater ap = new AnnotationUpdater(null);
        String annotation_options = "[{\"annotation_option_id\":50,\"annotation_id\":\"47\",\"annotation_option_name\":\"Viabilitydfs\",\"annotation_option_description\":\"\",\"display_order\":\"2\"},{\"annotation_option_id\":49,\"annotation_id\":\"47\",\"annotation_option_name\":\"Reporter genegfg\",\"annotation_option_description\":\"\",\"display_order\":\"3\"}]";
        asro = ap.addAnnotation("annotation", annotation_options);
        if (asro.isCallSucceed()) {
            //System.out.println("Call OK");
        } else {
            //System.out.println("Call failed");
        }

    }

    public static void testUpdateAnnotationOption() throws Exception {
        OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@ussf-tdbx-ora03:1771:sf0010d.amgen.com");
        AppServerReturnObject asro = new AppServerReturnObject("", false, null);
        AnnotationUpdater ap = new AnnotationUpdater(null);
        String annotation_options = "[{\"annotation_option_id\":50,\"annotation_id\":\"47\",\"annotation_option_name\":\"Viabilitydfs\",\"annotation_option_description\":\"\",\"display_order\":\"2\"},{\"annotation_option_id\":49,\"annotation_id\":\"47\",\"annotation_option_name\":\"Reporter genegfg\",\"annotation_option_description\":\"\",\"display_order\":\"3\"}]";
        asro = ap.updateAnnotation("annotation_option", annotation_options);
        if (asro.isCallSucceed()) {
            //System.out.println("Call OK");
        } else {
            //System.out.println("Call failed");
        }

    }
}
