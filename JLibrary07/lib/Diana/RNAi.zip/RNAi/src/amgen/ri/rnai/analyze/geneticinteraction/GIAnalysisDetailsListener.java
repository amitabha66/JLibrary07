/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.rnai.records.ExperimentRecord;
import java.util.Collection;

/**
 *
 * @author jemcdowe
 */
public class GIAnalysisDetailsListener implements GeneticInteractionListenerIF {
  private GIAnalysisDetails giAnalysisDetails;

  public GIAnalysisDetailsListener() {
  }

  public GIAnalysisDetails getGiAnalysisDetails() {
    return giAnalysisDetails;
  }

  public void processBegan(GeneticInteractionAnalysis geneticInteractionAnalysis, Collection<ExperimentRecord> experiments) {
    giAnalysisDetails = new GIAnalysisDetails(experiments);
    giAnalysisDetails.setStartTime(null);
  }

  public void analysisStarted(GeneticInteractionAnalysis geneticInteractionAnalysis, GIExperiments gie) {
  }

  public void analysisComplete(GeneticInteractionAnalysis geneticInteractionAnalysis, GIExperiments gie) {
    giAnalysisDetails.addGIExperimentResults(gie);
  }

  public void processEnded(GeneticInteractionAnalysis geneticInteractionAnalysis, Collection<ExperimentRecord> experiments) {
    giAnalysisDetails.setEndTime(null);
  }
}
