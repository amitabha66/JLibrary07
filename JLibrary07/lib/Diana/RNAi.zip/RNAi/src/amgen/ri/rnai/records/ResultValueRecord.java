/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author jemcdowe
 */
public class ResultValueRecord extends AbstractRecord {
  
  public ResultValueRecord(String resultID, String resultType, double resultValue) {
    super(resultID);
    setResultType(resultType);
    setValue(resultValue);
  }

  public ResultValueRecord(ResultSet rset) throws SQLException {
    super(rset.getString("ANALYSIS_RESULTS_ID"));
    setResultType(rset.getString("RESULT_TYPE"));
    setValue(rset.getDouble("RESULT_VALUE"));
  }

  /**
   * @return the value
   */
  public double getValue() {
    return getNumber("value").doubleValue();
  }

  /**
   * @param pvalue the value to set
   */
  public final void setValue(double value) {
    add("value", value);
  }

  /**
   * @return the resultType
   */
  public String getResultType() {
    return getString("result_type");
  }

  /**
   * @param resultType the resultType to set
   */
  public final void setResultType(String resultType) {
    add("result_type", resultType);
  }

}
