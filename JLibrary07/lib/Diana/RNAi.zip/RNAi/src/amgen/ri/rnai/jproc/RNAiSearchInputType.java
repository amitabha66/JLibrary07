/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc;

/**
 *
 * @author jemcdowe
 */
public enum RNAiSearchInputType {
    //for certain types which allow ALL to be returned
    ALL,
    //for certain types which allow ALL to be returned, but limited to those that have data
    ALL_WITHDATA,
      //Genes
    GENE_IDS,
    GENE_MIXTURE_IDS,
    GENE_SYMBOLS,
    GENE_KEYWORDS,
    ENTREZGENE_IDS,
    //Plates
    BARCODES,
    //RNAi
    COMPOUND_IDS,
    RNAI_IDS,
    //Experiments
    EXPERIMENT_IDS,
    EXPERIMENT_GENE_IDS,
    EXPERIMENT_GENE_MIXTURE_IDS,
    COLLECTION_IDS,
    CELLLINE_RTF_TERMID,
    TISSUE_RTF_TERMID,
    //Sequences
    SEQUENCES,
    AMGEN_LOGIN,
    UNKNOWN;

    public static RNAiSearchInputType fromString(String s) {
      try {
        return RNAiSearchInputType.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return UNKNOWN;
    }
}
