/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.dao.PersonRecord;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.*;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtArray;
import amgen.ri.util.ExtString;
import java.util.*;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class RNAiSearch extends AbstractSearch implements JSONResponderIF, Iterable<AbstractRecord> {
  private String rawQuery;
  private List<Integer> rnaiIDs;
  private List<Integer> geneIDs;
  private List<Integer> geneMixtureIDs;
  private List<Integer> expIDs;
  private List<String> compoundIDs;
  private RNAiSearchInputType searchType;
  private RNAiSearchOutputType searchResponse;
  private JSONObject jRNAiResults;

  public RNAiSearch(SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
  }

  public RNAiSearch(String query, String searchType, String searchResponse, SessionCache sessionCache, PersonRecordIF sessionUser) {
    this(query, RNAiSearchInputType.fromString(searchType), RNAiSearchOutputType.fromString(searchResponse),  sessionCache, sessionUser);
  }

  public RNAiSearch(String query, RNAiSearchInputType searchType, RNAiSearchOutputType searchResponse, SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
    this.rawQuery = query;
    this.searchType = searchType;
    this.searchResponse = searchResponse;
  }

  public RNAiSearch(List<Integer> rnaiIDs, List<String> compoundIDs, List<Integer> geneIDs, List<Integer> geneMixtureIDs, List<Integer> expIDs, RNAiSearchOutputType searchResponse, SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
    this.searchResponse = searchResponse;
    this.rnaiIDs = rnaiIDs;
    this.compoundIDs = compoundIDs;
    this.geneIDs = geneIDs;
    this.geneMixtureIDs = geneMixtureIDs;
    this.expIDs = expIDs;

    if (rnaiIDs != null) {
      searchType = RNAiSearchInputType.RNAI_IDS;
    } else if (compoundIDs != null) {
      searchType = RNAiSearchInputType.COMPOUND_IDS;
    } else if (geneIDs != null && expIDs != null) {
      searchType = RNAiSearchInputType.EXPERIMENT_GENE_IDS;
    } else if (geneMixtureIDs != null && expIDs != null) {
      searchType = RNAiSearchInputType.EXPERIMENT_GENE_MIXTURE_IDS;
    } else if (geneMixtureIDs != null) {
      searchType = RNAiSearchInputType.GENE_MIXTURE_IDS;
    } else if (geneIDs != null) {
      searchType = RNAiSearchInputType.GENE_IDS;
    } else if (expIDs != null) {
      searchType = RNAiSearchInputType.EXPERIMENT_IDS;
    }
  }

  @Override
  public JSONObject getResponse() throws Exception {
    if (jRNAiResults == null) {

      if (searchType.equals(RNAiSearchInputType.GENE_KEYWORDS)) {
        geneIDs = getGeneIDsByKeyword(rawQuery);
        searchType = RNAiSearchInputType.GENE_IDS;
      }

      JSONObject jResults = executeQuery(searchType, searchResponse);
      List<JSONObject> results = new ArrayList<JSONObject>();
      if (jResults.has("results")) {
        results = jResults.getJSONArray("results").asList();
      }
      switch (searchResponse) {
        case GENES:
        case GENEHITS:
        case COLLECTION_REFERENCE_GENES:
          Set<GeneRecord> geneRecords = new LinkedHashSet<GeneRecord>();
          for (JSONObject result : results) {
            try {
              geneRecords.add(new GeneRecord(result));
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("genes", geneRecords);
          break;
        case GENE_MIXTURES:
          Set<GeneMixtureRecord> geneMixtureRecords = new LinkedHashSet<GeneMixtureRecord>();
          for (JSONObject result : results) {
            try {
              geneMixtureRecords.add(new GeneMixtureRecord(result));
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("genes", geneMixtureRecords);
          break;
        case RNAI:
        case RNAI_DETAILS:
          Set<RNAiRecord> rnaiRecords = new LinkedHashSet<RNAiRecord>();
          for (JSONObject result : results) {
            try {
              rnaiRecords.add(new RNAiRecord(result));
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("rnai", rnaiRecords);
          break;
        case RAWRESULTS:
          Set<POCRecord> rnaiRawResultRecords = new LinkedHashSet<POCRecord>();
          int count= 0;
          for (JSONObject result : results) {
            count++;
            try {
              rnaiRawResultRecords.add(new POCRecord(result));
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("poc", rnaiRawResultRecords);
          break;
        case PLATES:
          Set<PlateInfo> plateRecords = new LinkedHashSet<PlateInfo>();
          for (JSONObject result : results) {
            try {
              plateRecords.add(new PlateInfo(result));
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("plates", plateRecords);
          break;
        case EXPERIMENTS:
          PermissionManager permissionManager = new PermissionManager(getSessionUser());
          Set<ExperimentRecord> expRecords = new LinkedHashSet<ExperimentRecord>();
          for (JSONObject result : results) {
            try {
              ExperimentRecord expRecord = new ExperimentRecord(result);
              if (permissionManager.hasPermission(PermissionType.VIEW, expRecord)) {
                permissionManager.setRecordPermissions(expRecord);
                expRecords.add(expRecord);
              }
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("experiments", expRecords);
          break;
        case ANNOTATIONS:
          Set<AnnotationRecord> annotationRecords = new LinkedHashSet<AnnotationRecord>();
          for (JSONObject result : results) {
            try {
              AnnotationRecord annotationRecord = new AnnotationRecord(result);
              annotationRecords.add(annotationRecord);
            } catch (JSONException e) {
              e.printStackTrace();
            }
          }
          jRNAiResults = createResponseJSON("annotations", annotationRecords);
          break;
        default:
          jRNAiResults = new JSONObject();
          break;
      }
      if (jResults.has("analysis") && jResults.has("result_types")) {
        jRNAiResults.put("analysis", jResults.get("analysis"));
        jRNAiResults.put("result_types", jResults.get("result_types"));
      }
    }
    return jRNAiResults;
  }

  protected List<Map<String, String>> getQuery() {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value;

    if (searchType.equals(RNAiSearchInputType.RNAI_IDS) && ExtArray.hasLength(getRnaiIDs())) {
      for (Integer rnaiID : getRnaiIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("rnai_id", rnaiID + "");
      }
      return query;
    }
    if (searchType.equals(RNAiSearchInputType.GENE_IDS) && ExtArray.hasLength(getGeneIDs())) {
      for (Integer geneID : getGeneIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("gene_id", geneID + "");
      }
      return query;
    }
    if (searchType.equals(RNAiSearchInputType.GENE_MIXTURE_IDS) && ExtArray.hasLength(getGeneMixtureIDs())) {
      for (Integer geneID : getGeneMixtureIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("gene_mixture_id", geneID + "");
      }
      return query;
    }

    if (searchType.equals(RNAiSearchInputType.EXPERIMENT_GENE_IDS) && ExtArray.hasLength(getGeneIDs()) && ExtArray.hasLength(getExperimentIDs())) {
      for (Integer expID : getExperimentIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("experiment_id", expID + "");
        value.put("gene_ids", ExtString.join(getGeneIDs(), ','));
      }
      return query;
    }

    if (searchType.equals(RNAiSearchInputType.EXPERIMENT_GENE_MIXTURE_IDS) && ExtArray.hasLength(getGeneMixtureIDs()) && ExtArray.hasLength(getExperimentIDs())) {
      for (Integer expID : getExperimentIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("experiment_id", expID + "");
        value.put("gene_mixture_ids", ExtString.join(getGeneMixtureIDs(), ','));
      }
      return query;
    }
    if (searchType.equals(RNAiSearchInputType.EXPERIMENT_IDS) && ExtArray.hasLength(getExperimentIDs())) {
      for (Integer expID : getExperimentIDs()) {
        value = new HashMap<String, String>();
        query.add(value);
        value.put("experiment_id", expID + "");
      }
      return query;
    }

    if (searchType.equals(RNAiSearchInputType.COMPOUND_IDS) && ExtArray.hasLength(getCompoundIDs())) {
      for (String compoundID : getCompoundIDs()) {
        String[] split = compoundID.split("#");
        if (split.length == 2 && ExtString.isAInteger(split[0]) && ExtString.isAInteger(split[1])) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("root_number", split[0]);
          value.put("lot_number", split[1]);
        }
      }
      return query;
    }

    List<String> inQueries = getParsedQuery(rawQuery);

    switch (searchType) {
      case RNAI_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("rnai_id", inQuery);
        }
        break;
      case GENE_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("gene_id", inQuery);
        }
        break;
      case GENE_MIXTURE_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("gene_mixture_id", inQuery);
        }
        break;        
      case GENE_SYMBOLS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("gene_symbol", inQuery);
        }
        break;
      case ENTREZGENE_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("eg_id", inQuery);
        }
        break;
      case BARCODES:
        inQueries = getParsedQuery(rawQuery, true);
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("barcode", inQuery);
        }
        break;
      case COMPOUND_IDS:
        for (String inQuery : inQueries) {
          String[] split = inQuery.split("#");
          if (split.length == 2 && ExtString.isAInteger(split[0]) && ExtString.isAInteger(split[1])) {
            value = new HashMap<String, String>();
            query.add(value);
            value.put("root_number", split[0]);
            value.put("lot_number", split[1]);
          }
        }
        break;
      case EXPERIMENT_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("experiment_id", inQuery);
        }
        break;
      case SEQUENCES:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("seq", inQuery);
        }
        break;
      case COLLECTION_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("collection_id", inQuery);
        }
        break;
      case CELLLINE_RTF_TERMID:
      case TISSUE_RTF_TERMID:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("term_id", inQuery);
        }
        break;
      case AMGEN_LOGIN:
        value = new HashMap<String, String>();
        query.add(value);
        PersonRecord personRecord= getPersonRecord(this.rawQuery);
        value.put("amgen_login", (personRecord== null ? getSessionUser().getUsername() : personRecord.getAmgen_login()));
        break;
      case ALL:
        return query;
      default:
        throw new IllegalArgumentException("Input type not supported- " + searchType);
    }
    return query;
  }

  @Override
  public List<AbstractRecord> asList() {
    JSONObject jResponse = null;
    try {
      jResponse = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jResponse != null) {
      try {
        if (jResponse.has("genes")) {
          return jResponse.getJSONArray("genes").asList();
        } else if (jResponse.has("rnai")) {
          return jResponse.getJSONArray("rnai").asList();
        } else if (jResponse.has("plates")) {
          return jResponse.getJSONArray("plates").asList();
        } else if (jResponse.has("experiments")) {
          return jResponse.getJSONArray("experiments").asList();
        } else if (jResponse.has("poc")) {
          return jResponse.getJSONArray("poc").asList();
        }
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return new ArrayList<AbstractRecord>();
  }

  @Override
  public int getCount() {
    JSONObject jResponse = null;
    try {
      jResponse = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jResponse != null) {
      try {
        if (jResponse.has("genes")) {
          return jResponse.getJSONArray("genes").length();
        } else if (jResponse.has("rnai")) {
          return jResponse.getJSONArray("rnai").length();
        } else if (jResponse.has("plates")) {
          return jResponse.getJSONArray("plates").length();
        } else if (jResponse.has("experiments")) {
          return jResponse.getJSONArray("experiments").length();
        }
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return 0;
  }

  @Override
  public Iterator<AbstractRecord> iterator() {
    return asList().iterator();
  }

  /**
   * @return the rnaiIDs
   */
  public List<Integer> getRnaiIDs() {
    return rnaiIDs;
  }

  /**
   * @return the geneIDs
   */
  public List<Integer> getGeneIDs() {
    return geneIDs;
  }

  /**
   * @return the gene mixture IDs
   */
  public List<Integer> getGeneMixtureIDs() {
    return geneMixtureIDs;
  }

  /**
   * @return the expIDs
   */
  public List<Integer> getExperimentIDs() {
    return expIDs;
  }

  /**
   * @return the compoundIDs
   */
  private List<String> getCompoundIDs() {
    return compoundIDs;
  }
}
