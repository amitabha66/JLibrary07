/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.oracle.ExtOracle;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.BioSequenceRecord;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.util.ExtArray;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import oracle.jdbc.OraclePreparedStatement;
import oracle.sql.CLOB;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class SquidSearch extends AbstractSearch implements JSONResponderIF, Iterable<BioSequenceRecord> {
  private JSONObject jBioSeqResults;
  private List<String> sequenceIDs;

  public SquidSearch(SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
  }

  public SquidSearch(List<String> sequenceIDs, SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
    this.sequenceIDs = sequenceIDs;
  }

  public SquidSearch(String sequenceID, SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache, sessionUser);
    this.sequenceIDs = new ArrayList<String>();
    this.sequenceIDs.add(sequenceID);
  }

  @Override
  public JSONObject getResponse() throws Exception {
    if (jBioSeqResults == null) {
      jBioSeqResults = new JSONObject();
      Connection conn = null;
      try {
        if (ExtArray.hasLength(sequenceIDs)) {
          conn = getSQUIDConnection();
          OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement(getSqlProvider().getSQLQuery("biosequence_by_accession").getSql());
          for (String sequenceID : sequenceIDs) {
            stmt.setStringAtName("accession", sequenceID);

            ResultSet rset = stmt.executeQuery();
            while (rset.next()) {
              String accession = rset.getString("ACCESSION");
              String description = rset.getString("DESCRIPTION");
              String type = rset.getString("TYPE");
              int length = rset.getInt("LENGTH");
              String dataSet = rset.getString("DATASET");
              int geneID = rset.getInt("GENE_ID");
              int entrezGeneID = rset.getInt("ENTREZ_GENE_ID");
              String organism = rset.getString("ORGANISM");
              int organismID = rset.getInt("TAXON_ID");
              int organismTermID = rset.getInt("TERM_ID");
              String sequence = ExtOracle.readCLOBToString((CLOB) rset.getClob("SEQUENCE"));

              BioSequenceRecord bioSequenceRecord = new BioSequenceRecord(accession, description, sequence,
                      type, length, dataSet, entrezGeneID, geneID, organism, organismID, organismTermID);
              jBioSeqResults.append("seqs", bioSequenceRecord);
            }
            rset.close();
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        closeResources(conn);
      }
    }
    return jBioSeqResults;
  }

  @Override
  public List<BioSequenceRecord> asList() {
    JSONObject jBioSequences = null;
    try {
      jBioSequences = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jBioSequences != null) {
      try {
        return jBioSequences.getJSONArray("seqs").asList();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return new ArrayList<BioSequenceRecord>();
  }

  @Override
  public int getCount() {
    JSONObject jBioSequences = null;
    try {
      jBioSequences = getResponse();
    } catch (Exception ex) {
      Logger.getLogger("rnai").error(ex);
    }
    if (jBioSequences != null) {
      try {
        return jBioSequences.getJSONArray("seqs").length();
      } catch (JSONException ex) {
        Logger.getLogger("rnai").error(ex);
      }
    }
    return 0;
  }

  @Override
  public Iterator<BioSequenceRecord> iterator() {
    return asList().iterator();
  }

  @Override
  protected List<Map<String, String>> getQuery() {
    throw new UnsupportedOperationException("Not supported yet.");
  }
}
