/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

/**
 *
 * @author jemcdowe
 */
public class OGAAnalysisException extends Exception {

  public OGAAnalysisException(String message) {
    super(message);
  }
  
  
}
