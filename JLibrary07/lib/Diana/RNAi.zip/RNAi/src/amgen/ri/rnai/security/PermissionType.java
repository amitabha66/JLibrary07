package amgen.ri.rnai.security;

/**
 * Defines known permissions for the RNAi- used by the SecurityManager
 * @author jemcdowe
 */
public enum PermissionType {
  PUBLISH, DELETE, EDIT, ANALYZE, VIEW, IMPORT, UNKNOWN;  
  
  public static PermissionType fromString(String s) {
    try {
      return PermissionType.valueOf(s.replaceAll("\\s+", "_").toUpperCase());
    } catch(Exception e) {
      return UNKNOWN;
    }
  }
  
}
