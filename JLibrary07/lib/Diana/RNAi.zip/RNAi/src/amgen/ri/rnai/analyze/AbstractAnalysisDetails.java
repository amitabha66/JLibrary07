/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.rnai.analyze.geneticinteraction.GIAnalysisDetails;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtObject;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.UUID;
import org.apache.commons.lang.time.DurationFormatUtils;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractAnalysisDetails implements AnalysisDetailsIF, Serializable {
  static final long serialVersionUID = 5164942537192573443L;

  public AbstractAnalysisDetails() {
  }

  public String getAnalysisType() {
    return (this instanceof GIAnalysisDetails ? "Genetic Interaction" : "OGA Analysis");
  }

  public static AbstractAnalysisDetails loadObject(File file) throws IOException, ClassNotFoundException {
    if (file.isDirectory()) {
      file = new File(file, "details.bin");
    }
    return (AbstractAnalysisDetails) ExtObject.deserializeObject(ExtFile.readFile(file));
  }

  public String getElapsedTime() {
    return DurationFormatUtils.formatDurationWords(getEndTime().getTime() - getStartTime().getTime(), true, true);
  }
}
