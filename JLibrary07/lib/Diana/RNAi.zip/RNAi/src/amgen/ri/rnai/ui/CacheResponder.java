package amgen.ri.rnai.ui;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.analyze.AnalysisDetailsIF;
import amgen.ri.rnai.analyze.AnalysisImageIF;
import amgen.ri.rnai.cache.CacheFilterSet;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.graphs.GraphsResponder;
import amgen.ri.rnai.search.AnalysisResultsSearch;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import java.util.List;
import javax.imageio.ImageIO;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Handles requests to the cache
 *
 * @author jemcdowe
 */
@WebServlet(name = "CacheResponder", urlPatterns = {"/rnaicache.go", "/rnaicache"})
public class CacheResponder extends MainUI {
  /**
   *
   */
  public CacheResponder() {
    super();
  }

  /**
   * @param req
   * @param resp
   */
  public CacheResponder(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);

  }

  /*
   * (non-Javadoc)
   *
   * @see
   * amgen.ri.servlet.ServletBase#getServlet(javax.servlet.http.HttpServletRequest,
   * javax.servlet.http.HttpServletResponse)
   */
  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new CacheResponder(req, resp);
  }

  /*
   * (non-Javadoc)
   *
   * @see amgen.ri.servlet.ServletBase#getServletMimeType()
   */
  @Override
  protected String getServletMimeType() {
    return "text/plain";
  }

  /*
   * (non-Javadoc)
   *
   * @see amgen.ri.servlet.ServletBase#performRequest()
   */
  @Override
  protected void performRequest() throws Exception {
    if (doesParameterExist("pngURL", true)) {
      createPNGResponse();
      return;
    }
    if (doesParameterExist("imgKey", true)) {
      getImageFromCache();
      return;
    }

    if (doesParameterEqual("action", "survival")) {
      createGraphResponse();
      return;
    }
    try {
      SessionCache sessionCache = getSessionCache();
      JSONObject jPageResults = new JSONObject();

      String dataID = getParameter("dataID");
      if (!ExtString.hasLength(dataID)) {
        throw new IllegalStateException("Cache request without a data ID provided");
      }
      int start = getParameterNumber("start", 0).intValue();
      int page = getParameterNumber("limit", 25).intValue();
      final String sort = getParameter("sort");
      final String dir = getParameter("dir", "ASC");
      CacheFilterSet filterSet = new CacheFilterSet(this);

      JSONObjectCacheItem jCachedResults = (JSONObjectCacheItem) sessionCache.get(SessionCache.CacheType.RESULTS, dataID);
      JSONObject jResults = jCachedResults.getSortedFilteredData(sort, dir, filterSet);
      List results = jResults.getJSONArray(jCachedResults.getResultName()).asList();
      int end = Math.min(start + page, results.size());
      List subResults = results.subList(start, end);
      jPageResults.put("total", results.size());
      jPageResults.put(jCachedResults.getResultName(), new JSONArray(subResults));
      response.getWriter().println(jPageResults);
    } catch (Exception e) {
      e.printStackTrace();
      if (e.getMessage() != null) {
        response.addHeader("error_mesg", e.getMessage());
        response.sendError(510, e.getMessage());
      }
    }
  }

  protected void createGraphResponse() throws Exception {
    GraphsResponder jsonResponse = new GraphsResponder(this);
    response.getWriter().println(jsonResponse.getResponse());
  }

  public SessionCache getSessionCache() {
    return new SessionCache(this);
  }

  private void getImageFromCache() {
    try {
      SessionCache sessionCache = getSessionCache();

      response.setContentType("image/png");
      response.addHeader("Content-disposition", "attachment; filename=" + getParameter("name") + ".png");
      String imgKey = getParameter("imgKey");
      AnalysisImageIF cachedImage = (AnalysisImageIF) sessionCache.get(SessionCache.CacheType.ANALYSIS, imgKey);

      ImageIO.write(cachedImage.getImage(), "png", response.getOutputStream());
      response.getOutputStream().flush();
    } catch (Exception e) {
      e.printStackTrace();
    }

  }

  private void createPNGResponse() {
    try {
      response.setContentType("image/png");
      response.addHeader("Content-disposition", "attachment; filename=" + getParameter("name") + ".png");
      String pngURL = getParameter("pngURL");
      File pngFile = new File(getCrossSessionDir(), pngURL);

      BufferedImage img;
      if (pngFile.exists()) {
        img = ImageIO.read(pngFile);
      } else {
        img = ImageIO.read(new URL(pngURL));
      }
      ImageIO.write(img, "png", response.getOutputStream());
      response.getOutputStream().flush();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}