/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.listener;

import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.ExtFile;
import java.io.File;
import java.sql.Connection;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

/**
 *
 * @author jemcdowe
 */
@WebListener
public class ContextListener implements ServletContextListener {
  public ContextListener() {
  }

  @Override
  public void contextInitialized(ServletContextEvent sce) {
    class LocalResourseFactory extends ResourceFactory {
      public LocalResourseFactory() {
        super(null);
      }
    }
    new LocalResourseFactory().testAllConnectionPools();
  }

  @Override
  public void contextDestroyed(ServletContextEvent sce) {
    try {
      File tempBaseDir =
              new File(sce.getServletContext().getInitParameter("WORK_DIR")
              + "/RNAi"
              + "/" + sce.getServletContext().getInitParameter("RNAI_VERSION").toLowerCase());

      ExtFile.deepdelete(tempBaseDir);
    } catch (Exception e) {
    }
  }
}
