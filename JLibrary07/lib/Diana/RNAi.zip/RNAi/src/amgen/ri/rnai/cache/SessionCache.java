package amgen.ri.rnai.cache;

import amgen.ri.servlet.ServletBase;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import javax.servlet.http.HttpSession;
import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;

/**
 * Manages interactions with the JCS cache
 *
 * @version $id$
 */
public class SessionCache {
  private String cacheID;
  private JCS jcsCache;

  public enum CacheType {
    PLATE, RESULTS, ANALYSIS;
  };

  public SessionCache() {
    try {
      jcsCache = JCS.getInstance("rnaiSessionCache");
      cacheID = UUID.randomUUID().toString();
    } catch (CacheException ex1) {
      ex1.printStackTrace();
      throw new IllegalArgumentException(ex1);
    }
  }

  /**
   * Creates a new, singleton CacheManager
   *
   * @throws AIGException
   */
  public SessionCache(HttpSession session) {
    this();
    if (session == null) {
      cacheID = UUID.randomUUID().toString();
    } else {
      cacheID = session.getId();
    }
  }

  public SessionCache(ServletBase servletBase) {
    this(servletBase.getHttpServletRequest().getSession());
    if (servletBase.doesParameterExist("cacheID", true)) {
      cacheID = servletBase.getParameter("cacheID");
    }
  }

  /**
   * Returns the Cache object. Interaction with the cache directly is not
   * recommended and is only here for development purposes. Use the wrapper
   * methods defined in this class- get, put, remove, contains, ...
   *
   * @return JCS
   */
  public JCS getCache() {
    return jcsCache;
  }

  /**
   * Returns the current cache ID
   *
   * @return
   */
  public String getCacheID() {
    return cacheID;
  }

  /**
   * Puts an object into the Cache in the proper group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @param obj Object
   * @return Object
   * @throws AIGException
   */
  public Object put(CacheType cacheType, String key, Object obj) throws CacheException {
    jcsCache.putInGroup(cacheType + ":" + key, cacheID, obj);
    return obj;
  }

  /**
   * Gets a cached object from the Cache or null if the key does not exist in
   * the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return Object
   */
  public Object get(CacheType cacheType, String key) {
    return jcsCache.getFromGroup(cacheType + ":" + key, cacheID);
  }

  /**
   * Returns all items in the given cache
   *
   * @param cacheType CacheType
   * @return Object
   */
  public Set getAll(CacheType cacheType) {
    Set<String> keys = new HashSet<String>();
    Set groupKeys = jcsCache.getGroupKeys(cacheID);
    for (Object groupKey : groupKeys) {
      String key = groupKey.toString();
      if (key.startsWith(cacheType + ":")) {
        keys.add(key.replaceFirst(cacheType + ":", ""));
      }
    }
    Set items = new HashSet();
    for(String key : keys) {
      Object obj= get(cacheType, key);
      if (obj!= null) {
        items.add(obj);
      }
    }    
    return items;
  }

  /**
   * Returns whether the Cache contains the given key in the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   * @return boolean
   */
  public boolean contains(CacheType cacheType, String key) {
    return (get(cacheType, key) != null);
  }

  /**
   * Removes an object from the Cache. Does nothing if the object does not exist
   * in the group and hierarchy
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param key String
   */
  public void remove(CacheType cacheType, String key) {
    jcsCache.remove(cacheType + ":" + key, cacheID);
  }

  /**
   * Removes the session cache from the Cache removing all cached objects
   *
   * @param session HttpSession
   */
  public void removeSessionCache() {
    jcsCache.invalidateGroup(cacheID);
  }

  /**
   * Removes a set of keys from the cache
   *
   * @param session HttpSession
   * @param cacheType CacheType
   * @param strings String[]
   * @return int
   */
  public void remove(CacheType cacheType, Collection<String> keys) {
    for (String key : keys) {
      remove(cacheType, key);
    }
  }
}
