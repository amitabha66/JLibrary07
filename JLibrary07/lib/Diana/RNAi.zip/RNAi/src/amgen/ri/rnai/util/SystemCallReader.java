package amgen.ri.rnai.util;

import java.io.*;

public class SystemCallReader
    extends Thread {
  BufferedReader reader = null;
  StringBuffer buff = new StringBuffer();

  public SystemCallReader(InputStream ins) {
    reader = new BufferedReader(new InputStreamReader(ins));
  }

  public void run() {
    String str = null;

    try {
      while ( (str = reader.readLine()) != null) {
        buff.append(str);
        buff.append('\n');
      }
    }
    catch (IOException x) {
      x.printStackTrace();
      // blah....
    }
    finally {
      try {
        reader.close();
      }
      catch (IOException x) {
      }
    }
  }

  public StringBuffer getBuff() {
    return buff;
  }
}
