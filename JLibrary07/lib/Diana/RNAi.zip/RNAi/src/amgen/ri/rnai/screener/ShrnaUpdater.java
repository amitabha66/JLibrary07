/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener;

import amgen.ri.crypt.StringEncrypter;
import amgen.ri.crypt.StringEncrypter.EncryptionException;
import amgen.ri.json.ExtJSON;
import amgen.ri.json.JSONObject;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.Authenticator;
import java.net.PasswordAuthentication;
import java.net.URL;
import java.net.URLConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class ShrnaUpdater extends ResourceFactory {
  public String userName = "";
  private static final DateFormat DATE_FORMAT = new SimpleDateFormat("MM/dd/yyyy");
  private ArrayList tempTables = new ArrayList();
  private ArrayList problemPlates = new ArrayList();

  public ShrnaUpdater() {
  }

  private static Date parseDateSafe(String dateString) {
    try {
      if (dateString != null) {
        return DATE_FORMAT.parse(dateString);
      } else {
        return null;
      }
    } catch (ParseException e) {
      throw new RuntimeException(e);
    }
  }

  private static String convertDateToString(Date _inDate, String _format) {
    Date inDate = null;
    String outString = null;
    SimpleDateFormat inDateFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss z yyyy");
    SimpleDateFormat outStringFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
    String inString = null;
    Date outDate = null;
    try {
      outStringFormat = new SimpleDateFormat(_format);
      inDate = inDateFormat.parse(_inDate.toString());
      outString = outStringFormat.format(inDate);
    } catch (Exception e) {
      outString = null;
    }

    return outString;
  }

  private HashMap buildWellMap() {
    HashMap wellrowMap = new HashMap();
    wellrowMap.put("1", "A");
    wellrowMap.put("2", "B");
    wellrowMap.put("3", "C");
    wellrowMap.put("4", "D");
    wellrowMap.put("5", "E");
    wellrowMap.put("6", "F");
    wellrowMap.put("7", "G");
    wellrowMap.put("8", "H");
    wellrowMap.put("9", "I");
    wellrowMap.put("10", "J");
    wellrowMap.put("11", "K");
    wellrowMap.put("12", "L");
    wellrowMap.put("13", "M");
    wellrowMap.put("14", "N");
    wellrowMap.put("15", "O");
    wellrowMap.put("16", "P");
    return wellrowMap;
  }

  private AppServerReturnObject getId(Connection conn, String seqName) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
    try {
      String queryString = "";
      queryString = "select " + seqName + ".nextval from dual";
      String seqId = "";
      Statement stmtSeqId = conn.createStatement();
      ResultSet rsSeqId = stmtSeqId.executeQuery(queryString);
      if (rsSeqId.next()) {
        seqId = Integer.toString(rsSeqId.getInt(1));
        rsSeqId.close();
        stmtSeqId.close();
        asro.setReturnObject(seqId);
        asro.setCallSucceed(true);
        return asro;
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getFieldDate(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "datefield");
      jCollection.put("fieldLabel", "From Date");
      jCollection.put("name", "fromDate");
      jCollection.put("format", "m/d/Y");

      SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");

      Date now = new Date(System.currentTimeMillis());
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(now);
      calendar.add(Calendar.DAY_OF_YEAR, -7);
      Date newDate = calendar.getTime();
      String ndate = dateFormat.format(newDate);

      //jCollection.put("value", "01/06/2011");
      jCollection.put("value", ndate);
      jResponse.append("items", jCollection);

      jCollection = new JSONObject();
      jCollection.put("xtype", "datefield");
      jCollection.put("fieldLabel", "To Date");
      jCollection.put("name", "toDate");
      jCollection.put("format", "m/d/Y");
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldAssay(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * Assays
       */
      JSONObject assayStoreParams = new JSONObject();
      assayStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      assayStoreParams.put("action_id", "get-assay");
      assayStoreParams.put("fromDate", "01/06/2011");
      assayStoreParams.put("toDate", "");
      assayStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("assay");

      JSONObject assayStore = new JSONObject();
      assayStore.put("xtype", "jsonstore");
      assayStore.put("id", "assay");
      assayStore.put("root", "assays");
      assayStore.put("url", "/RNAi/rnai.go");
      assayStore.put("autoLoad", false);
      assayStore.put("baseParams", assayStoreParams);
      assayStore.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", "Assay");
      jCollection.put("hiddenName", "assay");
      jCollection.put("valueField", "assay");
      jCollection.put("displayField", "assay");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select Assay");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      //jCollection.put("lazyInit", false);
      //jCollection.put("lazyRender", true);            
      jCollection.put("mode", "remote");
      jCollection.put("store", assayStore);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldQC(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * QCs
       */
      JSONObject qcStoreParams = new JSONObject();
      qcStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      qcStoreParams.put("action_id", "get-qc");
      qcStoreParams.put("assay", "AA1");
      qcStoreParams.put("fromDate", "01/06/2011");
      qcStoreParams.put("toDate", "");
      qcStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("experiment_name");
      fields.add("qc_name");
      fields.add("insert_date");
      fields.add("folder");
      fields.add("keystr");
      fields.add("valstr");

      JSONObject qcStore = new JSONObject();
      qcStore.put("xtype", "jsonstore");
      qcStore.put("id", "keystr");
      qcStore.put("root", "qc");
      qcStore.put("url", "/RNAi/rnai.go");
      qcStore.put("autoLoad", false);
      qcStore.put("baseParams", qcStoreParams);
      qcStore.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("listWidth", "450");
      jCollection.put("fieldLabel", "QCName");
      jCollection.put("hiddenName", "qcName");
      jCollection.put("valueField", "keystr");
      jCollection.put("displayField", "valstr");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select QC");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("mode", "remote");
      jCollection.put("store", qcStore);


      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldLayer(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      /*
       * Assays
       */
      JSONObject layerStoreParams = new JSONObject();
      layerStoreParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      layerStoreParams.put("action_id", "get-layer");
      layerStoreParams.put("qc_name", "");
      layerStoreParams.put("site", "");

      ArrayList fields = new ArrayList();
      fields.add("layerName");

      JSONObject layerStore = new JSONObject();
      layerStore.put("xtype", "jsonstore");
      layerStore.put("id", "layerName");
      layerStore.put("root", "layers");
      layerStore.put("url", "/RNAi/rnai.go");
      layerStore.put("autoLoad", false);
      layerStore.put("baseParams", layerStoreParams);
      layerStore.put("fields", fields);

      jCollection = new JSONObject();
      //jCollection.put("xtype", "combo");
      jCollection.put("xtype", "lovcombo");
      jCollection.put("fieldLabel", "Layer");
      jCollection.put("hiddenName", "layerName");
      jCollection.put("valueField", "layerName");
      jCollection.put("displayField", "layerName");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select Layer");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("mode", "remote");
      jCollection.put("store", layerStore);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;



    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldFileUpload(JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();
      jCollection = new JSONObject();
      jCollection.put("xtype", "fileuploadfield");
      jCollection.put("fieldLabel", "Experiment File");
      jCollection.put("hiddenName", "import_data_file");
      jCollection.put("name", "import_data_file");
      jCollection.put("emptyText", "Select a file");
      jCollection.put("width", 300);
      jCollection.put("buttonText", "Browse");
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getFieldList(String fieldName) throws Exception {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jResponse = new JSONObject();

      ArrayList<String> values = new ArrayList();
      if (fieldName.equalsIgnoreCase("visibility")) {
        values.add("Public");
        values.add("Private");
      } else if (fieldName.equalsIgnoreCase("status")) {
        values.add("Valid");
        values.add("Invalid");
      } else if (fieldName.equalsIgnoreCase("site")) {
        values.add("ARG");
        values.add("ASF");
      }
      for (String key : values) {
        JSONObject jCollection = new JSONObject();
        jCollection.put(fieldName, key.toString());
        jResponse.append("results", jCollection);
      }
      System.out.println(jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }

    return asro;
  }

  public AppServerReturnObject getField(JSONObject jResponse, String fieldName) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      JSONObject jCollection = new JSONObject();

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-fieldlist");
      storeParams.put("dtype", fieldName);

      ArrayList fields = new ArrayList();
      fields.add(fieldName);

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", fieldName);
      store.put("root", "results");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", fieldName);
      jCollection.put("hiddenName", fieldName);
      jCollection.put("valueField", fieldName);
      jCollection.put("displayField", fieldName);
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select " + fieldName);
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getAnnotationCollectionSource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.CollectionResponder");
      storeParams.put("action_id", "get-collection");

      ArrayList fields = new ArrayList();
      fields.add("collection_id");
      fields.add("collection_name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "collection_id");
      store.put("root", "collection");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "collection_id");
      jCollection.put("displayField", "collection_name");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRDHTASource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-rdhta");

      ArrayList fields = new ArrayList();
      fields.add("value");
      fields.add("label");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "value");
      store.put("root", "options");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "value");
      jCollection.put("displayField", "label");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationOptionSource(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {

      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.AnnotationResponder");
      storeParams.put("action_id", "get-annotation-option");
      storeParams.put("annotation_id", annotation_id);

      ArrayList fields = new ArrayList();
      fields.add("annotation_option_id");
      fields.add("annotation_option_name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "annotation_option_id");
      store.put("root", "annotationoptions");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "annotation_option_id");
      jCollection.put("displayField", "annotation_option_name");
      jCollection.put("triggerAction", "all");
      jCollection.put("emptyText", "Select ");
      jCollection.put("selectOnFocus", true);
      jCollection.put("editable", false);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRDHTA(String sessionToken) {
    //System.out.println("Coming here");
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      /*
       * InetAddress addr = InetAddress.getLocalHost();
       * System.out.println("Coming11 here");
       * String hostName = addr.getHostName();
       * ServiceDetails serviceDetail = null;
       * if (System.getProperty("os.name").indexOf("Windows") >= 0) {
       * System.out.println("Coming12 here");
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * System.out.println("Coming12end here" + serviceDetail);
       * } else {
       * if (hostName.indexOf("papp") > 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * } else if (hostName.indexOf("tapp") > 0 || hostName.indexOf("stampy")
       * >= 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.TEST_UDDIDETAILS,
       * "6045c732-0bb9-4ff4-9331-bb2ddfc2d241");
       * } else if (hostName.indexOf("dapp") > 0) {
       * serviceDetail = new ServiceDetails(UDDIDetails.DEV_UDDIDETAILS,
       * "19812123-2ad1-48c9-afcc-410a08029f4c");
       * } else {
       * serviceDetail = new ServiceDetails(UDDIDetails.PROD_UDDIDETAILS,
       * "f38161ff-0375-4fa5-a118-4aea265bc440");
       * }
       *
       * }
       * System.out.println("Coming1 here");
       *
       * serviceDetail.addSecurityToken(new
       * SiteMinderSessionSecurityToken(sessionToken));
       *
       * serviceDetail.setServiceCallTimeout(960000);
       * serviceDetail.setParameterValue("lookUpTableName", "TherapeuticArea");
       * serviceDetail.setParameterValue("lookUpValue", "%");
       * serviceDetail.setParameterValue("obsolete", "false");
       * Document doc = serviceDetail.executeService2JDocument("List XSD");
       * System.out.println("Coming2 here");
       * Element root = doc.getRootElement();
       * Element selection = root.getChild("Selection");
       * List options = selection.getChildren("Option");
       *
       * JSONObject jResponse = new JSONObject();
       * System.out.println("Options size: " + options.size());
       * for (int i = 0; i < options.size(); i++) {
       * Element curoption = (Element) options.get(i);
       * String label = curoption.getChild("Label").getText();
       * String value = curoption.getChild("Value").getText();
       * JSONObject jCollection = new JSONObject();
       * jCollection.put("value", value);
       * jCollection.put("label", label);
       * jResponse.append("options", jCollection);
       * }
       */
      ArrayList values = new ArrayList();
      values.add("Bone");
      values.add("General Medicine");
      values.add("Hematology");
      values.add("Hematology/Oncology");
      values.add("Inflammation");
      values.add("Metabolic Disorders");
      values.add("Nephrology");
      values.add("Oncology");
      values.add("Oncology Therapeutics");
      values.add("Oncology-Supportive");
      values.add("Unknown");
      values.add("Not Applicable");

      JSONObject jResponse = new JSONObject();
      for (int i = 0; i < values.size(); i++) {
        String label = (String) values.get(i);
        String value = (String) values.get(i);
        JSONObject jCollection = new JSONObject();
        jCollection.put("value", value);
        jCollection.put("label", label);
        jResponse.append("options", jCollection);
      }

      //System.out.println("jResponse: " + jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      System.out.println("Coming to exception");
      e.printStackTrace();

    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRTFCellLine(String inputtype, String input) {
    //System.out.println("Coming here");
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String result = "";
      if (inputtype.equalsIgnoreCase("cellline")) {
        Authenticator.setDefault(new Authenticator() {
          @Override
          public PasswordAuthentication getPasswordAuthentication() {
            try {
              Properties rgAccountProperties = getRGServiceAccountProperties();
              String username = rgAccountProperties.getProperty("http.serviceaccount.domain") + "\\" + rgAccountProperties.getProperty("http.serviceaccount.username");
              return new PasswordAuthentication(username, new StringEncrypter().decrypt(rgAccountProperties.getProperty("http.serviceaccount.domain")).toCharArray());
            } catch (EncryptionException ex) {
              java.util.logging.Logger.getLogger(ScreenerUpdater.class.getName()).log(Level.SEVERE, null, ex);
            }
            return null;
          }
        });
        String url = "http://rtf.amgen.com/rtf/REST/json/term/5806296/terms;suggest=" + input + "?max_results=500";
        URL link = new URL(url);
        URLConnection yc = link.openConnection();
        //System.out.println("Authentication: " + authinstance.getPasswordAuthentication().getUserName());

        //System.out.println("URL:" + url + "\nLink: " + link + "\nUConnection: " + yc.getInputStream());

        BufferedReader in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
        //System.out.println("in:" + in);
        String inputLine;

        while ((inputLine = in.readLine()) != null) {
          result = result + inputLine;
        }

      }
      JSONObject jResponse = new JSONObject();
      if (ExtJSON.isJSON(result)) {
        jResponse = (JSONObject) ExtJSON.toJSON(result);
      } else {
        asro.setCallSucceed(false);
        return asro;
      }
      //System.out.println("jResponse: " + jResponse);
      asro.setReturnObject(jResponse);
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      System.out.println("Coming to exception");
      e.printStackTrace();

    }
    return asro;
  }

  public AppServerReturnObject getAnnotationRTFCellLine(String annotation_name, String annotation_id, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {
      JSONObject storeParams = new JSONObject();
      storeParams.put("req", "amgen.ri.rnai.screener.ScreenerResponder");
      storeParams.put("action_id", "get-rtf");
      storeParams.put("inputtype", "cellline");
      storeParams.put("input", "");

      ArrayList fields = new ArrayList();
      fields.add("id");
      fields.add("name");

      JSONObject store = new JSONObject();
      store.put("xtype", "jsonstore");
      store.put("id", "id");
      store.put("root", "term");
      store.put("url", "/RNAi/rnai.go");
      store.put("autoLoad", true);
      store.put("baseParams", storeParams);
      store.put("fields", fields);

      JSONObject jCollection = new JSONObject();
      jCollection.put("xtype", "combo");
      jCollection.put("hiddenName", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
      jCollection.put("valueField", "id");
      jCollection.put("displayField", "name");
      jCollection.put("autoLoad", true);
      jCollection.put("triggerAction", "all");
      jCollection.put("minChars", "2");
      jCollection.put("forceSelection", true);
      jCollection.put("allowBlank", false);
      jCollection.put("emptyText", "Select ");
      jCollection.put("fieldLabel", annotation_name);
      jCollection.put("editable", true);
      jCollection.put("mode", "remote");
      jCollection.put("typeAhead", true);
      jCollection.put("selectOnFocus", true);
      jCollection.put("store", store);
      jResponse.append("items", jCollection);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public AppServerReturnObject getAnnotationGroupFields(Connection conn, String annotation_group_name, JSONObject jResponse) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {
      String queryString = "select * from annotation a, annotation_group ag " + "\n"
              + "where a.rnai_type_id = 2 and a.annotation_group_id = ag.annotation_group_id " + "\n"
              + "and annotation_group_name = '" + annotation_group_name + "' " + "\n"
              + "order by display_order asc";

      //System.out.println(queryString);
      PreparedStatement ps = conn.prepareStatement(queryString);
      ResultSet rs = ps.executeQuery();
      while (rs.next()) {
        String annotation_name = rs.getString("annotation_name");
        String annotation_id = rs.getString("annotation_id");
        String source = rs.getString("source");
        String action = "";
        if (source == null || source.length() == 0 || source.equalsIgnoreCase("annotation_options")) {
          asro = this.getAnnotationOptionSource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("FREE_TEXT")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "textfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_DATE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "datefield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jCollection.put("format", "m/d/Y");
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_DOUBLE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "numberfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("allowDecimals", true);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("FREE_INTEGER")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "numberfield");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("allowDecimals", false);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("RTF_CELLLINE")) {
          asro = this.getAnnotationRTFCellLine(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("RTF_TISSUE")) {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "field");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("disabled", true);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        } else if (source.equalsIgnoreCase("COLLECTIONS")) {
          asro = this.getAnnotationCollectionSource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else if (source.equalsIgnoreCase("RDH_TA")) {
          asro = this.getAnnotationRDHTASource(annotation_name, annotation_id, jResponse);
          if (!asro.isCallSucceed()) {
            return asro;
          }
        } else {
          JSONObject jCollection = new JSONObject();
          jCollection.put("xtype", "field");
          jCollection.put("fieldLabel", annotation_name);
          jCollection.put("name", "AN__" + annotation_name.replaceAll(" ", "_SPACE_"));
          jResponse.append("items", jCollection);
        }
      }
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;

  }

  public AppServerReturnObject getExpLoadFormItems() {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;
    try {
      conn = new OraSQLManager().getConnection("RNAI_INDEX");

      JSONObject jResponse = new JSONObject();

      JSONObject annotategroupAQC0 = new JSONObject();
      annotategroupAQC0.put("xtype", "fieldset");
      annotategroupAQC0.put("layout", "column");
      jResponse.append("items", annotategroupAQC0);

      JSONObject expname = new JSONObject();
      expname.put("xtype", "textfield");
      expname.put("fieldLabel", "Experiment Name");
      expname.put("name", "experiment_name");
      annotategroupAQC0.append("items", expname);

      JSONObject AQC = new JSONObject();
      AQC.put("xtype", "fieldset");
      AQC.put("title", "Experiment Information");
      AQC.put("columnWidth", .5);
      AQC.put("border", false);
      annotategroupAQC0.append("items", AQC);

      asro = this.getFieldFileUpload(AQC);
      if (!asro.isCallSucceed()) {
        return asro;
      }


      JSONObject annotategroup0 = new JSONObject();
      annotategroup0.put("xtype", "fieldset");
      annotategroup0.put("title", "Experiment Information");
      annotategroup0.put("columnWidth", .5);
      annotategroup0.put("border", false);
      annotategroupAQC0.append("items", annotategroup0);

      asro = getAnnotationGroupFields(conn, "Experiment Information", annotategroup0);
      if (!asro.isCallSucceed()) {
        return asro;
      }



      System.out.println(jResponse);
      asro.setCallSucceed(true);
      asro.setReturnObject(jResponse);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      OraSQLManager.closeResources(conn);

    }
    return asro;
  }

  public JSONObject processAddExperiment(Logger logger, String tableName, String addJSONString, Workbook wb) throws Exception {

    JSONObject jResponse = new JSONObject();
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    if (tableName.equalsIgnoreCase("shrna")) {
      asro = addExperiment(wb, addJSONString);

    }
    if (asro.isCallSucceed()) {
      jResponse.put("message", "Passed");
    } else {

      jResponse.put("message", asro.getComment());
    }
    //System.out.println(jResponse);
    logger.debug(jResponse);
    return jResponse;
  }

  private AppServerReturnObject addExperiment(Workbook wb, String addJSONString) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    Connection conn = null;

    System.out.println("Loading data:\n" + addJSONString);
    try {
      if (!ExtJSON.isJSON(addJSONString)) {
        asro.setCallSucceed(false);
        asro.setComment("Invalid JSON string: " + addJSONString);
      }
      conn = new OraSQLManager().getConnection("RNAI_INDEX");


      JSONObject jo = (JSONObject) ExtJSON.toJSON(addJSONString);
      HashMap annotations = new HashMap();
      Map form_elements = jo.asMap();

      String visibility = "Private";
      String status = "Valid";
      String experiment_name = (String) form_elements.get("experiment_name");



      Iterator it = form_elements.keySet().iterator();
      while (it.hasNext()) {
        String key = (String) it.next();
        String value = (String) form_elements.get(key);
        if (key.startsWith("AN__")) {
          annotations.put(key.substring(4), value);
        }
      }

      asro = Load(conn, wb, experiment_name, visibility, status, annotations);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      System.out.println("Loading completed");
      asro.setCallSucceed(true);
      return asro;

    } catch (Exception e) {
      e.printStackTrace();
      try {
        conn.rollback();
      } catch (Exception e1) {
      }
    } finally {
      OraSQLManager.closeResources(conn);


    }
    return asro;
  }

  public String getUserName() {
    return userName;
  }

  public void setUserName(String userName) {
    this.userName = userName;
  }

  private AppServerReturnObject Load(Connection conn, Workbook wb, String experiment_name, String visibility, String status, HashMap annotations) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {
      conn.setAutoCommit(false);
      String psql_exp = "insert into experiment(experiment_id, EXPERIMENT_NAME, upload_person, upload_date, visibility, status) values (?,?,?,sysdate,?,?)";
      PreparedStatement pstmt_exp = conn.prepareStatement(psql_exp);

      Statement stmt_well = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
      Statement stmt_annotations = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);


      asro = LoadExpPlateWell(conn, wb, experiment_name, visibility, status, pstmt_exp, stmt_well, stmt_annotations, annotations);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      int[] updateCountsExp = pstmt_exp.executeBatch();
      System.out.println("Experiment query executed: " + updateCountsExp.length);
      int[] updateCountsAnnotations = stmt_annotations.executeBatch();
      System.out.println("Experiment Annotation query executed: " + updateCountsAnnotations.length);
      int[] updateCountsWell = stmt_well.executeBatch();
      System.out.println("Experiment well query executed: " + updateCountsWell.length);
      conn.commit();
      pstmt_exp.close();
      stmt_annotations.close();
      stmt_well.close();
      asro.setCallSucceed(true);

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
    }
    return asro;
  }

  private AppServerReturnObject LoadExp(Connection conn, PreparedStatement pstmt_exp, String experiment_id, String experiment_name, String visibility, String status) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);;

    try {

      pstmt_exp.setString(1, experiment_id);
      pstmt_exp.setString(2, experiment_name);
      pstmt_exp.setString(3, this.userName);
      pstmt_exp.setString(4, "Private");
      pstmt_exp.setString(5, "Valid");

      asro.setCallSucceed(true);

      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject LoadExpAnnotations(Connection conn, Statement stmt_annotations, String experiment_id, HashMap annotations) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

    try {
      Iterator it = annotations.keySet().iterator();
      while (it.hasNext()) {
        asro = getId(conn, "RNAI_result");
        if (!asro.isCallSucceed()) {
          return asro;
        }
        String result_id = (String) asro.getReturnObject();
        String annotation_name = (String) it.next();
        String actual_annotation_name = annotation_name.replaceAll("_SPACE_", " ");
        String value = (String) annotations.get(annotation_name);
        String insert = "insert into EXPERIMENT_ANNOTATION_VALUE(EXPERIMENT_ANNOTATION_VALUE_id, experiment_id, annotation_id, value) "
                + "values(" + result_id + "," + experiment_id + ","
                + "(select annotation_id from annotation where rnai_type_id = 1  and annotation_name = '" + actual_annotation_name + "')" + ","
                + "'" + value + "')";
        System.out.println(insert);
        stmt_annotations.addBatch(insert);
      }
      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  private AppServerReturnObject LoadExpPlateWell(Connection conn, Workbook wb, String experiment_name, String visibility, String status, PreparedStatement pstmt_exp, Statement stmt_well, Statement stmt_annotations, HashMap annotations) {
    AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
    try {

      HashMap wellrowMap = buildWellMap();
      DecimalFormat df = new DecimalFormat("###E0");
      DecimalFormat df1 = new DecimalFormat("##");

      asro = getId(conn, "rnai_experiment");
      if (!asro.isCallSucceed()) {
        return asro;
      }

      String experiment_id = (String) asro.getReturnObject();
      System.out.println("experiment_id: " + experiment_id);

      asro = this.LoadExp(conn, pstmt_exp, experiment_id, experiment_name, visibility, status);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      asro = LoadExpAnnotations(conn, stmt_annotations, experiment_id, annotations);
      if (!asro.isCallSucceed()) {
        return asro;
      }

      Sheet sheet = null;
      sheet = wb.getSheetAt(0);
      int rowCount = sheet.getPhysicalNumberOfRows();
      for (int i = 1; i < rowCount; i++) {
        Row row = (Row) sheet.getRow(i);
        if (row == null) {
          continue;
        }
        String cell_exp = row.getCell(9).getStringCellValue();
        String cell_rnai_id = Double.toString(row.getCell(12).getNumericCellValue());
        String cell_poc = Double.toString(row.getCell(13).getNumericCellValue());
        String well_insert = "insert into experiment_well_results(experiment_well_result_id, experiment_id, result_type_id, value, text_value, rnai_id)"
                + "(select plate_well_seq.nextval, " + experiment_id + " as experiment_id,  11, " + cell_poc + "," + cell_poc + "," + cell_rnai_id
                + " from dual)";
        if (i < 5) {
          System.out.println(cell_exp + "\t" + cell_rnai_id + "\t" + cell_poc);
        }
        stmt_well.addBatch(well_insert);
      }

      if (rowCount > 0) {
        pstmt_exp.addBatch();
      }

      asro.setCallSucceed(true);
      return asro;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return asro;
  }

  public static void main(String[] args) throws Exception {
    //testListReturn();
    //testEncrypt();
    //testLoading();
    testScreenerLoading();
    //testJsonObject();
    System.out.println("Completed");
  }

  public static void testJsonObject() throws EncryptionException {
    ShrnaUpdater qcp = new ShrnaUpdater();
    JSONObject result = new JSONObject();
    AppServerReturnObject asro = qcp.getField(result, "Status");
    System.out.println(result);
  }

  public static void testEncrypt() throws EncryptionException {
    String passwd = "Ra1n1ng#";
    StringEncrypter st = new StringEncrypter();
    String encrypted = st.encrypt(passwd);
    String decrypted = st.decrypt(encrypted);
    System.out.println(encrypted + ":" + decrypted);
  }

  public static void testScreenerLoading() throws Exception {
    //OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");
    OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-pdbx-ora09.amgen.com:1521:Wa0630p.amgen.com");
    //String rest = "{\"visibility\":\"Private\",\"status\":\"0\",\"fromDate\":\"01/06/2011\",\"toDate\":\"\",\"assay\":\"AA16943\",\"qcName\":\"AA16943_2:SF295_R025_10_MSD_Confirmations:1302035595765:/ONC_OTHER_siRNA\",\"AN__CellLine\":\"5807097\",\"AN__ModifiedCellLine\":\"\",\"AN__OncogenicState\":\"Normal\",\"AN__Culture\":\"Fresh\",\"AN__CellLineSource\":\"AMA-Cindy Wilson, constructed by Craig Strathdee\",\"AN__CellLineCatalog\":\"C-2501A\",\"AN__CellMorphology\":\"Adherent\",\"AN__CellsPerWell\":\"500\",\"AN__ScreenedBy\":\"mikhalr\",\"AN__ExperimentType\":\"Imaging\",\"AN__EndpointAssay\":\"CTG\",\"AN__Collection\":\"150\",\"AN__TherapeuticArea\":\"Bone\",\"AN__Algorithm\":\"OGA Method v2\",\"AN__AssayDevelopmentBy\":\"mikhalr\",\"AN__AssayDevelopmentDate\":\"01/03/2012\",\"AN__FreezeMedia\":\"70% RPMI (1%P/S/G), 10% DMSO, 20%FBS\",\"AN__PassageNumber\":\"4\",\"AN__StorageLocation\":\"siRNA Tank1 Tower2 Boxes 8/9\",\"AN__DateFrozen\":\"01/04/2012\",\"AN__FrozenBy\":\"liwong\",\"AN__Modifier\":\"\",\"AN__ModifierConcentration\":\"1000x\",\"AN__GrowthMedia\":\"DMEM\",\"AN__GrowthSerum\":\"10% FBS  2 mM L-glutamine  10 mM HEPES  1.0 mM sodium pyruvate  2 g/L glucose\",\"AN__ScreenMedia\":\"DMEM % FBS\",\"AN__ScreenSerum\":\"10% FBS\"}";
    //String rest = "{\"fromDate\":\"08/21/2012\",\"toDate\":\"\",\"Site\":\"ASF\",\"assay\":\"AA24945\",\"qcName\":\"GFP-p62_U2OS_Lamp2:20120823 GFP-p62_U2OS_Lamp2:1346026060547:/NEURO/OTHER/siRNA\",\"layerName\":\"Cells Analyzed\",\"Visibility\":\"Private\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/22/2012\",\"toDate\":\"\",\"Site\":\"ASF\",\"assay\":\"AA24945\",\"qcName\":\"GFP-p62_U2OS_Lamp2:20120823 GFP-p62_U2OS_Lamp2:1346026060547:/NEURO/OTHER/siRNA\",\"layerName\":\"Mean GFP-p62 Ring Inty\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/23/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA16852\",\"qcName\":\"AA16852:109169-68-1_V226:1346069309670:/ONC/PHOSPH/SMG1\",\"layerName\":\"Ratio,WL1,WL2\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    //String rest = "{\"fromDate\":\"08/29/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA25043\",\"qcName\":\"AA25043_USP8_2:109166-87-1_P001:1346768377163:/ONC/siRNA/CIT_USP8\",\"layerName\":\"LUM\",\"Status\":\"Valid\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    String rest = "{\"fromDate\":\"09/03/2012\",\"toDate\":\"\",\"Site\":\"ARG\",\"assay\":\"AA25043\",\"qcName\":\"AA25043_RANDOM2_4:109166-83-2_P002:1346846027663:/ONC/siRNA/CIT_USP8\",\"layerName\":\"LUM\",\"Status\":\"\",\"AN__Transfection_SPACE_Reagent\":\"\",\"AN__SiRNA_SPACE_Concentration\":\"\",\"AN__Incubation_SPACE_Length\":\"\",\"AN__Transfection_SPACE_Reagent_SPACE_Volume_SPACE_(uL)\":\"\",\"AN__Plate_SPACE_Type\":\"\",\"AN__Plate_SPACE_Format\":\"\",\"AN__Cell_SPACE_Line\":\"\",\"AN__Oncogenic_SPACE_State\":\"\",\"AN__Culture\":\"\",\"AN__Cell_SPACE_Line_SPACE_Source\":\"\",\"AN__Cell_SPACE_Line_SPACE_Catalog\":\"\",\"AN__Cell_SPACE_Morphology\":\"\",\"AN__Cells_SPACE_Per_SPACE_Well\":\"\",\"AN__Screened_SPACE_By\":\"\",\"AN__Experiment_SPACE_Type\":\"\",\"AN__Endpoint_SPACE_Assay\":\"\",\"AN__Collection\":\"\",\"AN__Therapeutic_SPACE_Area\":\"\",\"AN__Algorithm\":\"\",\"AN__Assay_SPACE_Development_SPACE_By\":\"\",\"AN__Assay_SPACE_Development_SPACE_Data\":\"\",\"AN__Comments\":\"\",\"AN__Freeze_SPACE_Media\":\"\",\"AN__Passage_SPACE_Number\":\"\",\"AN__Storage_SPACE_Location\":\"\",\"AN__Date_SPACE_Frozen\":\"\",\"AN__Frozen_SPACE_By\":\"\",\"AN__Reagent_SPACE_Lot\":\"\",\"AN__Modifier\":\"\",\"AN__Modifier_SPACE_Concentration\":\"\",\"AN__Growth_SPACE_Media\":\"\",\"AN__Growth_SPACE_Serum\":\"\",\"AN__Screen_SPACE_Media\":\"\",\"AN__Screen_SPACE_Serum\":\"\"}";
    ShrnaUpdater qcp = new ShrnaUpdater();
    qcp.setUserName("jayanthi");
    //AppServerReturnObject asro = qcp.addExperiment(rest);
    ///For MPlate: ONC_OTHER_siRNA/AA18143/108143-43-1_P001_SJSA1_0.06ul/well_30nM_DMSO_for0.8uM_YeastEssential_PDK/Wed Jan 11 14:58:28 PST 2012
  }

  public static void testListReturn() throws Exception {
    ShrnaUpdater qcp = new ShrnaUpdater();
    String site = "ASF";
    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
    String fromDateStr = "12/01/2011";
    Date fromDate = null;
    fromDate = (fromDateStr == null || fromDateStr.trim().length() == 0) ? null : sdf.parse(fromDateStr);
    OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");
    //AppServerReturnObject asro = qcp.getQCJson(null, null, null, null, null, null, null, null, "AA18071", "USSF");
    //AppServerReturnObject asro = qcp.getQCJson(null, null, null, null, null, null, null, null, "AA17108", "USSF");
    //AppServerReturnObject asro = qcp.getQC("/ONC_OTHER_siRNA", null, null, null, null, "AA11045", "USSF");
    //AppServerReturnObject asro = qcp.getAssay(null, null, null, fromDate, null, site);
    //AppServerReturnObject asro = qcp.getExpLoadFormItems();
    AppServerReturnObject asro = qcp.getAnnotationRTFCellLine("cellline", "SCH");
    //AppServerReturnObject asro = null;
    if (!asro.isCallSucceed()) {
      System.out.println("Failed");
    }

    JSONObject res = (JSONObject) asro.getReturnObject();
    //System.out.println(res.getJSONArray("assays").length());
    //System.out.println(res.getJSONArray("items"));
    System.out.println(res);

    /*
     * HashMap results = (HashMap) asro.getReturnObject();
     * ArrayList<String> keys = new ArrayList();
     * HashMap values = new HashMap();
     * keys = (ArrayList) results.get("1");
     * values = (HashMap) results.get("2");
     * for (String key : keys) {
     * System.out.println(key);
     * String[] pkeys = key.split(":");
     * if (pkeys.length == 4) {
     * String experimentName = pkeys[0];
     * String sessionName = pkeys[1];
     * String dateLong = pkeys[2];
     * String folderName = pkeys[3];
     * System.out.println("InputKey: " + folderName + "/" + experimentName + "/"
     * + sessionName + "/" + dateLong);
     * QCSessionReportKey qckey = new QCSessionReportKey(experimentName,
     * sessionName, new Date(Long.parseLong(dateLong)), folderName);
     * QCSessionReport qcReport =
     * qcp.getQueryService().getQCSessionReport(qckey);
     * System.out.println("ActualKey: " + qckey.getFolderName() + "/" +
     * qckey.getExperimentName() + "/" + qckey.getQCSessionName() + "/" +
     * qckey.getInsertDate());
     * System.out.println(qcReport.getQCSessionInformation().getExperimentName());
     *
     *
     * }
     *
     * }
     */


  }
}
