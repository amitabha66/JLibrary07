/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.util.List;

/**
 *
 * @author jemcdowe
 */
public class PlateParentage extends AbstractRecord {
  public PlateParentage(JSONObject source) throws JSONException {
    super(source, "barcode");
  }

  public PlateParentage(AbstractRecord record) throws JSONException {
    super(record);
  }

  public PlateParentage(String recordID) {
    super(recordID);
  }

  public String getBarcode() {
    return getString("barcode");
  }

  public List<String> getDescendants() {
    return getList("descendants");
  }

  public List<String> getParents() {
    return getList("parents");
  }

  public boolean getFlag() {
    return optBoolean("flag", false);
  }
}
