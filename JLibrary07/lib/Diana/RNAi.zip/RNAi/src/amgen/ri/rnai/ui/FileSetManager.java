package amgen.ri.rnai.ui;

import java.io.FileNotFoundException;
import java.io.Writer;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jdom.Document;
import org.jdom.Element;
import amgen.ri.jawr.JAWRLinkRenderer;

import amgen.ri.html.GenericHTMLElement;
import amgen.ri.html.HTMLElement;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import amgen.ri.xml.XMLElement;
import java.util.ArrayList;

/**
 * <p>@version $Id: FileSetManager.java,v 1.2 2012/12/21 00:14:20 cvs Exp $</p>
 *
 * <p> </p>
 *
 * <p> </p>
 *
 * <p> </p> not attributable
 */
public class FileSetManager {
  public static String CONFIG_FILENAME = "/jawr_filesets.xml";
  private HttpServletRequest request;
  private Document fileSetDoc;


  public FileSetManager(HttpServletRequest request) throws FileNotFoundException {
    this.request = request;
    fileSetDoc = ExtXMLElement.toDocument(this.getClass(), CONFIG_FILENAME);
  }

  public void writeScripts(Writer writer, String fileSetName) {
    HTMLElement parentEl = new GenericHTMLElement("parent");
    appendScripts(parentEl, fileSetName);
    for (XMLElement scriptEl : parentEl.getMembers()) {
      scriptEl.write(writer);
    }
  }

  public void writeStyles(Writer writer, String fileSetName) {
    HTMLElement parentEl = new GenericHTMLElement("parent");
    appendStyles(parentEl, fileSetName);
    for (XMLElement cssLinkEl : parentEl.getMembers()) {
      cssLinkEl.write(writer);
    }
  }

  public void appendScripts(HTMLElement parentEl, String fileSetName) {
    JAWRLinkRenderer jawrLinkRenderer = new JAWRLinkRenderer(request, false);    
    Element fileSetEl= ExtXMLElement.getXPathElement(fileSetDoc, "//JSFileSets/FileSet[@name='" + fileSetName + "']");      
    if (fileSetEl != null) {
      String fileSetBaseDir = fileSetEl.getAttributeValue("baseDir");
      List<Element> fileListEls = fileSetEl.getChildren("filelist");
      for (Element fileListEl : fileListEls) {
        String dir = fileListEl.getAttributeValue("dir");
        List<Element> fileEls = fileListEl.getChildren("file");
        for (Element fileEl : fileEls) {
          String fileName = fileEl.getAttributeValue("name");
          boolean isBundle = ExtXMLElement.getAttributeBoolean(fileEl, "bundle");
          if (ExtString.hasLength(fileName)) {
            if (isBundle) {
              jawrLinkRenderer.appendScriptLinks(fileName, parentEl);
            } else {
              if (!fileName.startsWith("http://")) {
                StringBuffer filePath = new StringBuffer(request.getContextPath());
                if (ExtString.hasLength(fileSetBaseDir)) {
                  filePath.append(fileSetBaseDir + "/");
                }
                if (ExtString.hasLength(dir)) {
                  filePath.append(dir + "/");
                }
                filePath.append(fileName);
                fileName = filePath.toString();
              }
              HTMLElement script = new GenericHTMLElement("script");
              script.addAttribute("type", "text/javascript");
              script.addAttribute("src", fileName);
              parentEl.addMemberElement(script);
            }
          }
        }
      }
    } else {
      System.err.println("Unable to find JS FileSet " + fileSetName);
    }
  }

  public void appendStyles(HTMLElement parentEl, String fileSetName) {
    JAWRLinkRenderer jawrLinkRenderer = new JAWRLinkRenderer(request, false);    
    Element fileSetEl= ExtXMLElement.getXPathElement(fileSetDoc, "//CSSFileSets/FileSet[@name='" + fileSetName + "']");
    if (fileSetEl != null) {
      String fileSetBaseDir = fileSetEl.getAttributeValue("baseDir");
      List<Element> fileListEls = fileSetEl.getChildren("filelist");
      for (Element fileListEl : fileListEls) {
        String dir = fileListEl.getAttributeValue("dir");
        List<Element> fileEls = fileListEl.getChildren("file");
        for (Element fileEl : fileEls) {
          String fileName = fileEl.getAttributeValue("name");
          boolean isBundle = ExtXMLElement.getAttributeBoolean(fileEl, "bundle");
          if (ExtString.hasLength(fileName)) {
            if (isBundle) {
              jawrLinkRenderer.appendStyleLinks(fileName, parentEl);
            } else {
              if (!fileName.startsWith("http://")) {
                StringBuffer filePath = new StringBuffer(request.getContextPath());
                if (ExtString.hasLength(fileSetBaseDir)) {
                  filePath.append(fileSetBaseDir + "/");
                }
                if (ExtString.hasLength(dir)) {
                  filePath.append(dir + "/");
                }
                filePath.append(fileName);
                fileName = filePath.toString();
              }
              HTMLElement cssLink = new GenericHTMLElement("link");
              cssLink.addAttribute("rel", "stylesheet");
              cssLink.addAttribute("type", "text/css");
              cssLink.addAttribute("href", fileName);
              parentEl.addMemberElement(cssLink);
            }
          }
        }
      }
    } else {
      System.err.println("Unable to find CSS FileSet " + fileSetName);
    }

  }
}
