package amgen.ri.rnai.log;

import java.util.Date;
import org.apache.commons.lang.StringUtils;

public final class LogEntry {
  private String username;
  private String session_id;
  private String request;
  private String details;

  public LogEntry() {
  }

  public LogEntry(String username, String session_id, String request, String details) {
    this.username = username;
    this.session_id = session_id;
    setRequest(request);
    setDetails(details);
  }

  /**
   * Get value for username
   */
  public String getUsername() {
    return username;
  }

  /**
   * Get value for session_id
   */
  public String getSession_id() {
    return session_id;
  }

  /**
   * Get value for request
   */
  public String getRequest() {
    return request;
  }

  /**
   * Get value for details
   */
  public String getDetails() {
    return details;
  }

  /**
   * Set value for username
   * @param username
   */
  public void setUsername(String username) {
    this.username = username;
  }

  /**
   * Set value for session_id
   * @param session_id
   */
  public void setSession_id(String session_id) {
    this.session_id = session_id;
  }

  /**
   * Set value for request
   * @param request
   */
  public void setRequest(String request) {
    this.request = StringUtils.left(request, 500);
  }

  /**
   * Set value for details
   * @param details
   */
  public void setDetails(String details) {
    this.details = StringUtils.left(details, 4000);
  }
}
