/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.util;

import java.io.IOException;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 *
 * @author jayanthi
 */
public class ConfigUtil {

    private static final String configFile = "config.xml";

    public static Element readXmlFile(String path) throws Exception {
        Element root = null;
        SAXBuilder builder = new SAXBuilder();
        try {
            Document doc = builder.build(path);
            return doc.getRootElement();
        } catch (JDOMException e) {

            System.out.println(e.getMessage());
        } catch (IOException e) {
            System.out.println("Could not check " + path);
            System.out.println(" because " + e.getMessage());
        }
        return root;
    }
    
    

    public static void main(String[] args) {
        String confiFile = "C:\\work\\Netbeans\\Applications\\RNAi\\WebContent\\WEB-INF\\config.xml";


    }
}
