/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.dao.PersonRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneMixtureRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.ExtString;
import java.text.SimpleDateFormat;
import java.util.*;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractResponder extends ResourceFactory implements JSONResponderIF {
  private final MainUI servletBase;
  private Logger logger;
  public static final String JSON_DATE_PATTERN = "MM/dd/yyyy hh:mm:ss a";

  public AbstractResponder(MainUI servletBase) {
    super(new SessionCache(servletBase));
    this.servletBase = servletBase;
    logger = Logger.getLogger("rnai");
  }

  /**
   * @return the servletBase
   */
  public MainUI getServletBase() {
    return servletBase;
  }

  protected String getParameter(String parameterName) {
    return servletBase.getParameter(parameterName);
  }

  protected List<String> getParameters(String parameterName, String regex) {
    return servletBase.getParameters(parameterName, regex);
  }

  protected List<String> getParameters(String parameterName) {
    return servletBase.getParameters(parameterName, "[,;]+");
  }

  protected List<Number> getParameterNumbers(String parameterName) {
    List<String> params = servletBase.getParameters(parameterName, "\\D+");
    List<Number> paramNums = new ArrayList<Number>();
    for (String paramVal : params) {
      if (ExtString.isANumber(paramVal)) {
        paramNums.add(ExtString.toDouble(paramVal));
      }
    }
    return paramNums;
  }

  protected int getParameterInteger(String parameterName, int defaultValue) {
    List<Integer> paramNums = getParameterIntegers(parameterName);
    return (paramNums.isEmpty() ? defaultValue : paramNums.get(0));
  }

  protected String getParameter(String parameterName, String defaultValue) {
    return servletBase.getParameter(parameterName, defaultValue);
  }

  protected Number getParameterNumber(String parameterName) {
    return servletBase.getParameterNumber(parameterName);
  }

  protected Number getParameterNumber(String parameterName, double defaultValue) {
    return servletBase.getParameterNumber(parameterName, defaultValue);
  }

  /**
   * Returns a List of integers contained in a parameter. The integers are
   * delimited by any non-digit character
   *
   * @param parameterName
   * @return
   */
  protected List<Integer> getParameterIntegers(String parameterName) {
    List<Integer> numbers = new ArrayList<Integer>();
    String value = getParameter(parameterName);
    if (value != null) {
      String[] nums = value.split("\\D+");
      for (String num : nums) {
        if (ExtString.isAInteger(num)) {
          numbers.add(ExtString.toInteger(num));
        }
      }
    }
    return numbers;
  }

  /**
   * Returns a list of ExperimentRecords using the experiment IDs contained in
   * the
   * parameter experiment_ids (see getParameterIntegers())
   *
   * @return
   */
  protected List<ExperimentRecord> getExperimentRecordsFromParameter() {
    return getExperimentRecordsFromParameter("experiment_ids");
  }

  /**
   * Returns a list of ExperimentRecords using the experiment IDs contained in a
   * parameter (see getParameterIntegers())
   *
   * @param parameter
   * @return
   */
  protected List<ExperimentRecord> getExperimentRecordsFromParameter(String parameter) {
    return getExperiments(getParameterIntegers(parameter));
  }

  /**
   * Returns an ExperimentRecord using the experiment IDs contained in a
   * parameter (see getParameterIntegers()). If more that one experiment ID
   * present, the first is returned.
   * If none, null is returned
   *
   * @return
   */
  protected ExperimentRecord getExperimentRecordFromParameter(String parameter) {
    List<ExperimentRecord> expRecords = getExperimentRecordsFromParameter(parameter);
    return (expRecords.isEmpty() ? null : expRecords.get(0));
  }

  /**
   * Retrieves a list of ExperimentRecords using the ExpIDs provided in the
   * expRecords parameter
   *
   * @param expIDParameterName
   * @return
   */
  public List<ExperimentRecord> getExperimentRecords(List<ExperimentRecord> expRecords) {
    List<Integer> experimentIDs = new ArrayList<Integer>();
    for (ExperimentRecord expRecord : expRecords) {
      experimentIDs.add(expRecord.getExperimentID());
    }
    return getExperiments(experimentIDs);
  }

  /**
   * Retrieves a list of ExperimentRecords using the Experiment IDs
   */
  public List<ExperimentRecord> getExperiments(Collection<Integer> experimentIDs) {
    return getExperiments(experimentIDs, getServletBase().getPersonRecord());
  }

  /**
   * Returns a List of GeneRecords for a List of gene IDs
   *
   * @param geneIDs
   * @return
   */
  public List<GeneRecord> getGenes(Collection<Integer> geneIDs) {
    return getGenes(geneIDs, getServletBase().getPersonRecord());
  }

  /**
   * Returns a List of GeneRecords for a List of gene IDs that are embedded in a
   * parameter value.
   *
   * @see getParameterIntegers for a description of how the gene IDs are parsed
   * from the parameter
   *
   * @param parameter
   * @return
   */
  public List<GeneRecord> getGeneRecordsFromParameter(String parameter) {
    List<Integer> geneIDs = getParameterIntegers(parameter);
    return (geneIDs.isEmpty() ? new ArrayList<GeneRecord>() : getGenes(geneIDs, getServletBase().getPersonRecord()));
  }

  /**
   * Returns a List of GeneMixtureRecords for a List of gene mixture IDs that are embedded in a
   * parameter value.
   *
   * @see getParameterIntegers for a description of how the gene mixture IDs are parsed
   * from the parameter
   *
   * @param parameter
   * @return
   */
  public List<GeneMixtureRecord> getGeneMixtureRecordsFromParameter(String parameter) {
    List<Integer> geneIDs = getParameterIntegers(parameter);
    return (geneIDs.isEmpty() ? new ArrayList<GeneMixtureRecord>() : getGeneMixtures(geneIDs, getServletBase().getPersonRecord()));
  }

  /**
   * Returns a GeneRecord for gene IDs that are embedded in a parameter value.
   *
   * @see getParameterIntegers for a description of how the gene IDs are parsed
   * from the parameter
   *
   * If more than one gene ID is present, this returns the first. Null if none
   * are present.
   *
   * @param parameter
   * @return
   */
  public GeneRecord getGeneRecordFromParameter(String parameter) {
    List<GeneRecord> geneRecords = getGeneRecordsFromParameter(parameter);
    return (geneRecords.isEmpty() ? null : geneRecords.get(0));
  }

  /**
   * Returns a List of GeneRecords for a List of gene symbols that are embedded
   * in a parameter value.
   * The symbols are parsed from the parameter value using the regex-
   * [\n\f\r;,]+
   *
   * @param parameter
   * @return
   */
  public List<GeneRecord> getGeneRecordsFromGeneSymbolParameter(String parameter) {
    Set<String> geneSymbols = new HashSet<String>(Arrays.asList(getParameter(parameter).split("[\\n\\f\\r;,]+")));
    return (geneSymbols.isEmpty() ? new ArrayList<GeneRecord>() : getGenesBySymbol(geneSymbols, getServletBase().getPersonRecord()));
  }

  protected void verifyParameter(String[] requiredParameters) throws MissingParameterException {
    for (String requiredParameter : requiredParameters) {
      if (!ExtString.hasTrimmedLength(getParameter(requiredParameter))) {
        throw new MissingParameterException("Required parameter [" + requiredParameter + "] not present");
      }
    }
  }

  public SimpleDateFormat getJSONDateFormatter() {
    return new SimpleDateFormat(JSON_DATE_PATTERN);
  }

  /**
   * for an optional JSONArray member of the jObj JSONObject, returns the
   * JSONArray for the key or an empty JSONArray if the key does not exist
   *
   * @param jObj
   * @param key
   * @return
   */
  protected JSONArray optJSONArray(JSONObject jObj, String key) {
    JSONArray jArr = jObj.optJSONArray(key);
    return (jArr == null ? new JSONArray() : jArr);
  }

  /**
   * for an optional JSONArray member of the jObj JSONObject, returns the
   * JSONArray as a List for the key or an empty List if the key does not exist
   *
   * @param jObj
   * @param key
   * @return
   */
  protected List optList(JSONObject jObj, String key) {
    return optJSONArray(jObj, key).asList();
  }

  @Override
  public JSONObject getResponse() {
    System.out.println("Should not come here..");
    return null;
  }

  /**
   * @return the logger
   */
  public Logger getLogger() {
    return logger;
  }

  protected PersonRecord getPersonRecordfromParameter(String parameter) {
    String amgenLogin= getParameter(parameter);
    if (StringUtils.isEmpty(amgenLogin)) {
      return null;
    }
    Map<String, PersonRecord> map = getPersonRecords(Arrays.asList(amgenLogin));
    return map.get(amgenLogin);
  }

}
