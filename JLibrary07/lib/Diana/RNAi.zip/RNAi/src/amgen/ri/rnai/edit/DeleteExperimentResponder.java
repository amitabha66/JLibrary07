package amgen.ri.rnai.edit;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OracleCallableStatement;

/**
 *
 * @author jemcdowe
 */
public class DeleteExperimentResponder extends AbstractResponder implements JSONResponderIF {
  public DeleteExperimentResponder(MainUI servletBase) {
    super(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    String RUN_DELETE_EXPERIMENT = "BEGIN DELETE_EXPERIMENT(?,?); END;";

    JSONObject jResponse = new JSONObject();
    try {
      jResponse.put("deletes", new JSONArray());
      List<ExperimentRecord> experimentRecords = getExperimentRecordsFromParameter();
      List<ExperimentRecord> deletedExperimentRecords = new ArrayList<ExperimentRecord>();
      if (!experimentRecords.isEmpty()) {
        Connection conn = null;
        try {
          conn = getRNAiConnection();
          OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(RUN_DELETE_EXPERIMENT);

          PermissionManager permissionsMgr = new PermissionManager(getServletBase());
          String dataID = getParameter("dataID");


          for (ExperimentRecord experimentRecord : experimentRecords) {
            if (permissionsMgr.hasPermission(PermissionType.DELETE, experimentRecord)) {
              cs.setInt(1, experimentRecord.getExperimentID());
              cs.registerOutParameter(2, Types.INTEGER);
              cs.execute();
              int success = cs.getInt(2);
              if (success > 0) {
                deletedExperimentRecords.add(experimentRecord);
                jResponse.append("deletes", experimentRecord.getExperimentID());
              }
            }
          }
          if (dataID != null) {
            JSONObjectCacheItem jCachedResults = (JSONObjectCacheItem) getServletBase().getSessionCache().get(SessionCache.CacheType.RESULTS, dataID);
            if (jCachedResults != null) {
              jCachedResults.deleteRecords(getExperimentRecords(deletedExperimentRecords));
            }
          }
        } catch (Exception e) {
          e.printStackTrace();
        } finally {
          close(conn);
        }
      }
    } catch (JSONException ex) {
      Logger.getLogger(UpdateExperimentResponder.class.getName()).log(Level.SEVERE, null, ex);
    }
    return jResponse;
  }
}
