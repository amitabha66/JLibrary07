/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc;

/**
 *
 * @author jemcdowe
 */
public enum RNAiSearchOutputType {
  GENES,
  GENE_MIXTURES,
  GENEHITS,
  RNAI,
  RNAI_DETAILS,
  PLATES,
  PLATEMAP,
  PLATELINEAGE, 
  EXPERIMENTS,
  RESULTS,
  RAWRESULTS,
  POCGENE,
  RESULT_TYPES,
  ANALYSIS_TYPES,
  COLLECTIONS,
  COLLECTION_REFERENCE_GENES,
  ANNOTATIONS,
  CELLLINE_ANNOTATIONS,
  UNKNOWN;

  public static RNAiSearchOutputType fromString(String s) {
    try {
      return RNAiSearchOutputType.valueOf(s.toUpperCase());
    } catch (Exception e) {
    }
    return UNKNOWN;
  }
}
