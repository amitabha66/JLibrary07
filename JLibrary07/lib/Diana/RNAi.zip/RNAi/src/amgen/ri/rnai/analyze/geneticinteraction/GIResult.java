package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.json.JSONException;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.GeneRecord;
import java.util.logging.Level;
import java.util.logging.Logger;

public class GIResult extends AbstractRecord {
  static final long serialVersionUID = -3830389130433004173L;
//geneID [int] 
//gi_analysis_id [int]
//experimentA_ID [int] 
//analysisA_ID [int] 
//experimentB_ID [int] 
//analysisB_ID [int] 
//pvalue [double] 
//pvalueAdj [double] 
//pvalueSuppressor [double] 
//pvalueSuppressorAdj [double] 
//pvalueEnhancer [double] 
//pvalueEnhancerAdj [double] 

  public GIResult(GeneRecord geneRecord, Integer gi_analysis_id, Double pvalue, Double pvalueAdj, 
          Double pvalueSuppressor, Double pvalueSuppressorAdj, 
          Double pvalueEnhancer, Double pvalueEnhancerAdj) {
    super(geneRecord.getRecordID());
    add("gene", geneRecord);
    add("geneID", geneRecord.getGeneID());
    add("geneSymbol", geneRecord.getGeneSymbol());
    add("gi_analysis_id", gi_analysis_id);
    add("pvalue", pvalue);
    add("pvalueAdj", pvalueAdj);
    add("pvalueSuppressor", pvalueSuppressor);
    add("pvalueSuppressorAdj", pvalueSuppressorAdj);
    add("pvalueEnhancer", pvalueEnhancer);
    add("pvalueEnhancerAdj", pvalueEnhancerAdj);
  }

  public GeneRecord getGeneRecord() {
    try {
      return (GeneRecord)getJSONObject("gene");
    } catch (JSONException ex) {
      return null;
    }
  }
  /**
   * Get value for geneID
   */
  public int getGeneID() {
    return getNumber("geneID").intValue();
  }

  /**
   * Get value for pvalue
   */
  public double getPvalue() {
    return getNumber("pvalue").doubleValue();
  }

  /**
   * Get value for gi_analysis_id
   */
  public int getGi_analysis_id() {
    return getNumber("gi_analysis_id").intValue();
  }


  /**
   * Get value for pvalueAdj
   */
  public double getPvalueAdj() {
    return getNumber("pvalueAdj").doubleValue();
  }

  /**
   * Get value for pvalueSuppressor
   */
  public double getPvalueSuppressor() {
    return getNumber("pvalueSuppressor").doubleValue();
  }

  /**
   * Get value for pvalueSuppressorAdj
   */
  public double getPvalueSuppressorAdj() {
    return getNumber("pvalueSuppressorAdj").doubleValue();
  }

  /**
   * Get value for pvalueEnhancer
   */
  public double getPvalueEnhancer() {
    return getNumber("pvalueEnhancer").doubleValue();
  }

  /**
   * Get value for pvalueEnhancerAdj
   */
  public double getPvalueEnhancerAdj() {
    return getNumber("pvalueEnhancerAdj").doubleValue();
  }

  /**
   * Set value for geneID
   */
  public void setGeneID(int geneID) {
    add("geneID", geneID);
  }
  /**
   * Set value for gi_analysis_id
   */
  public void setGi_analysis_id(int gi_analysis_id) {
    add("gi_analysis_id", gi_analysis_id);
  }

  /**
   * Set value for pvalue
   */
  public void setPvalue(double pvalue) {
    add("pvalue", pvalue);
  }

  /**
   * Set value for pvalueAdj
   */
  public void setPvalueAdj(double pvalueAdj) {
    add("pvalueAdj", pvalueAdj);
  }

  /**
   * Set value for pvalueSuppressor
   */
  public void setPvalueSuppressor(double pvalueSuppressor) {
    add("pvalueSuppressor", pvalueSuppressor);
  }

  /**
   * Set value for pvalueSuppressorAdj
   */
  public void setPvalueSuppressorAdj(double pvalueSuppressorAdj) {
    add("pvalueSuppressorAdj", pvalueSuppressorAdj);
  }

  /**
   * Set value for pvalueEnhancer
   */
  public void setPvalueEnhancer(double pvalueEnhancer) {
    add("pvalueEnhancer", pvalueEnhancer);
  }

  /**
   * Set value for pvalueEnhancerAdj
   */
  public void setPvalueEnhancerAdj(double pvalueEnhancerAdj) {
    add("pvalueEnhancerAdj", pvalueEnhancerAdj);
  }
}