/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;

/**
 *
 * @author jemcdowe
 */
public class POCRecord extends RNAiRecord {

  public POCRecord(JSONObject obj) throws JSONException {
    super(obj, "well_id");
  }  

  public int getWellID() {
    return getNumber("well_id").intValue();
  }

  public double getPoc() {
    return getNumber("poc").doubleValue();
  }
  
  
}
