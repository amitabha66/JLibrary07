/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtString;

/**
 *
 * @author jemcdowe
 */
public class ImportPermissionRule extends AbstractPermissionRule implements PermissionRuleIF {

  public ImportPermissionRule(PersonRecordIF requestedBy) {
    super(PermissionType.IMPORT, requestedBy);
  } 

  /**
   * Check whether the requestedBy user can import records
   * and throws a SecurityException if not true/false
   *
   * @param record
   * @return
   * @throws SecurityException
   */
  public void checkPermission(AbstractRecord record) throws SecurityException {
    //Everyone can at the moment      
  }
  
}
