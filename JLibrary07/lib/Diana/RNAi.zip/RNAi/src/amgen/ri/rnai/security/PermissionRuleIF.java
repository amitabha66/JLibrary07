/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.rnai.records.AbstractRecord;

/**
 *
 * @author jemcdowe
 */
public interface PermissionRuleIF {
  /**
   * Check whether the requestedBy user as the given privilege for the record
   * and throws a SecurityException if not true/false
   *
   * @param record
   * @throws SecurityException
   */
  void checkPermission(AbstractRecord record) throws SecurityException;
}
