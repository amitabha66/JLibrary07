/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.asf.bio.FastaEntry;
import amgen.ri.json.JSONException;
import amgen.ri.xml.ExtXMLElement;
import org.jdom.Element;

/**
 *
 * RNAi.Record.BioSequence=
 *
 * @author jemcdowe
 */
public final class BioSequenceRecord extends AbstractRecord {
  public BioSequenceRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public BioSequenceRecord(String recordID) {
    super(recordID);
  }
  
  public BioSequenceRecord(String seqID, String description, String sequence,
          String type, int length, String dataset, int entrezGeneId,
          int geneId, String organism, int organismID, int termID) {
    super(seqID);
    setSeqID(seqID);
    setDescription(description);
    setType(type);
    setLength(length);
    setDataset(dataset);
    setGeneID(geneId);
    setEntrezgeneID(entrezGeneId);
    setOrganism(organism);
    setSequence(sequence);
    setOrganismID(organismID);
    setOrganismTermID(termID);
  }

  public BioSequenceRecord(Element seqEl) {
    super(seqEl.getChildText("Id"));
    Element propertiesEl = seqEl.getChild("Properties");

    String seqID = getRecordID();
    String description = seqEl.getChildText("Description");
    String sequence = seqEl.getChildText("Sequence");
    String type = propertiesEl.getChildText("SeqType");
    int length = new Integer(propertiesEl.getChildText("SeqLength"));
    String dataset = propertiesEl.getChildText("Dataset");
    int entrezGeneId = new Integer(propertiesEl.getChildText("EntrezGeneId"));
    int geneId = new Integer(propertiesEl.getChildText("AmgenGeneId"));
    String organism = propertiesEl.getChild("Organism").getAttributeValue("name");
    int organismID = new Integer(propertiesEl.getChild("Organism").getChildText("NCBITaxonId"));
    int termID = ExtXMLElement.getXPathNumberValue(propertiesEl, "./Organism/RTF/TermId").intValue();

    setSeqID(seqID);
    setDescription(description);
    setType(type);
    setLength(length);
    setDataset(dataset);
    setGeneID(geneId);
    setEntrezgeneID(entrezGeneId);
    setOrganism(organism);
    setSequence(sequence);
    setOrganismID(organismID);
    setOrganismTermID(termID);
  }

  /**
   * @return the seq_id
   */
  public String getSeqID() {
    return getString("seq_id");
  }

  /**
   * @param seq_id the seq_id to set
   */
  public void setSeqID(String seq_id) {
    add("seq_id", seq_id);
  }

  /**
   * @return the description
   */
  public String getDescription() {
    return getString("description");
  }

  /**
   * @param description the description to set
   */
  public void setDescription(String description) {
    add("description", description);
  }

  /**
   * @return the type
   */
  public String getType() {
    return getString("type");
  }

  /**
   * @param type the type to set
   */
  public void setType(String type) {
    add("type", type);
  }

  /**
   * @return the length
   */
  public int getLength() {
    return getNumber("length").intValue();
  }

  /**
   * @param length the length to set
   */
  public void setLength(int length) {
    add("length", length);
  }

  /**
   * @return the dataset
   */
  public String getDataset() {
    return getString("dataset");
  }

  /**
   * @param dataset the dataset to set
   */
  public void setDataset(String dataset) {
    add("dataset", dataset);
  }

  /**
   * @return the gene_id
   */
  public int getGeneID() {
    return getNumber("gene_id").intValue();
  }

  /**
   * @param gene_id the gene_id to set
   */
  public void setGeneID(int gene_id) {
    add("gene_id", gene_id);
  }

  /**
   * @return the entrezgene_id
   */
  public int getEntrezgeneID() {
    return getNumber("entrezgene_id").intValue();
  }

  /**
   * @param entrezgene_id the entrezgene_id to set
   */
  public void setEntrezgeneID(int entrezgene_id) {
    add("entrezgene_id", entrezgene_id);
  }

  /**
   * @return the sequence
   */
  public String getSequence() {
    return getString("sequence");
  }

  /**
   * @param sequence the sequence to set
   */
  public void setSequence(String sequence) {
    add("sequence", sequence);
  }

  /**
   * @return the organism
   */
  public String getOrganism() {
    return getString("organism");
  }

  /**
   * @param organism the organism to set
   */
  public void setOrganism(String organism) {
    add("organism", organism);
  }

  /**
   * @return the organism_id
   */
  public int getOrganismID() {
    return getNumber("organism_id").intValue();
  }

  /**
   * @param organism_id the organism_id to set
   */
  public void setOrganismID(int organism_id) {
    add("organism_id", organism_id);
  }

  /**
   * @return the organism_term_id
   */
  public int getOrganismTermID() {
    return getNumber("organism_term_id").intValue();
  }

  /**
   * @param organism_term_id the organism_term_id to set
   */
  public void setOrganismTermID(int organism_term_id) {
    add("organism_term_id", organism_term_id);
  }

  public FastaEntry asFastaEntry() {
    return new FastaEntry(getSeqID(), getDescription(), getSequence());
  }

}
