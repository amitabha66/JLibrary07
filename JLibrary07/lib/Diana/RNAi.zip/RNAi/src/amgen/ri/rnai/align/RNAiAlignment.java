/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.align;

import amgen.ri.asf.bio.FastaEntry;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.BioSequenceRecord;
import amgen.ri.rnai.records.RNAiRecord;
import amgen.ri.rnai.search.SquidSearch;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtArray;
import java.io.IOException;
import java.util.*;

/**
 *
 * @author jemcdowe
 */
public class RNAiAlignment implements Iterable<RNAiRecord> {
  private MainUI requestor;
  private BioSequenceRecord targetSequenceRecord;
  private List<RNAiRecord> rnaiRecords;
  private Map<RNAiRecord, List<AlignmentPair>> alignmentPairs;

  public RNAiAlignment(MainUI requestor, String targetSequenceAccession, List<RNAiRecord> rnaiRecords) throws IOException {
    this.requestor = requestor;
    this.rnaiRecords = rnaiRecords;

    SquidSearch squidSearch = new SquidSearch(targetSequenceAccession, new SessionCache(requestor), requestor.getPersonRecord());
    List<BioSequenceRecord> bioseqRecords = squidSearch.asList();
    if (!ExtArray.hasLength(bioseqRecords)) {
      throw new IOException("Unable to retrieve sequence " + targetSequenceAccession);
    }
    targetSequenceRecord = bioseqRecords.get(0);
  }
  public BioSequenceRecord getTargetSequenceRecord() {
    return targetSequenceRecord;
  }

  public void doAlignment() {
    FastaEntry targetEntry = targetSequenceRecord.asFastaEntry();

    alignmentPairs = new LinkedHashMap<RNAiRecord, List<AlignmentPair>>();

    for (RNAiRecord rnaiRecord : rnaiRecords) {
      Alignment alignment = new Alignment(requestor, targetEntry, rnaiRecord.asFastaEntry(), true);
      alignmentPairs.put(rnaiRecord, alignment.getAlignmentPairs());
    }
  }

  public List<AlignmentPair> getAlignmentPairs(RNAiRecord rnaiRecord) {
    if (alignmentPairs == null) {
      doAlignment();
    }
    return alignmentPairs.get(rnaiRecord);
  }

  @Override
  public Iterator<RNAiRecord> iterator() {
    if (alignmentPairs == null) {
      doAlignment();
    }
    return alignmentPairs.keySet().iterator();
  }
}
