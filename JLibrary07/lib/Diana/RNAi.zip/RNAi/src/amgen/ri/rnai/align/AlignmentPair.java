/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.align;

public class AlignmentPair {
  private String target;
  private String query;
  private double identity;
  private int alignment;
  private int mismatches;
  private int gaps;
  private int qStart;
  private int qEnd;
  private int sStart;
  private int sEnd;
  private double score;
  private double bitScore;

  public AlignmentPair(String target, String query, double identity, int alignment, int mismatches, int gaps, int qStart, int qEnd, int sStart, int sEnd, double score, double bitScore) {
    this.target = target;
    this.query = query;
    this.identity = identity;
    this.alignment = alignment;
    this.mismatches = mismatches;
    this.gaps = gaps;
    this.qStart = qStart;
    this.qEnd = qEnd;
    this.sStart = sStart;
    this.sEnd = sEnd;
    this.score = score;
    this.bitScore = bitScore;
  }

  /**
   * @return the target
   */
  public String getTarget() {
    return target;
  }

  /**
   * @return the query
   */
  public String getQuery() {
    return query;
  }

  /**
   * @return the identity
   */
  public double getIdentity() {
    return identity;
  }

  /**
   * @return the alignment
   */
  public int getAlignment() {
    return alignment;
  }

  /**
   * @return the mismatches
   */
  public int getMismatches() {
    return mismatches;
  }

  /**
   * @return the gaps
   */
  public int getGaps() {
    return gaps;
  }

  /**
   * @return the qStart
   */
  public int getQueryStart() {
    return qStart;
  }

  /**
   * @return the qEnd
   */
  public int getQueryEnd() {
    return qEnd;
  }

  /**
   * @return the sStart
   */
  public int getSubjectStart() {
    return sStart;
  }

  /**
   * @return the sEnd
   */
  public int getSubjectEnd() {
    return sEnd;
  }

  /**
   * @return the score
   */
  public double getScore() {
    return score;
  }

  /**
   * @return the bitScore
   */
  public double getBitScore() {
    return bitScore;
  }
};