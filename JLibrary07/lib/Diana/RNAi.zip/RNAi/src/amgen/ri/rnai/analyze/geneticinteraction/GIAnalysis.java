package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.csv.CSVReader;
import amgen.ri.json.record.AbstractRecord;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.ExtString;
import java.io.CharArrayReader;
import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.util.*;
import org.apache.commons.io.IOUtils;
import org.apache.ibatis.session.SqlSession;

public class GIAnalysis extends AbstractRecord {
//gi_analysis_id [int] 
//experiment_a_id [int] 
//analysis_a_id [int] 
//experiment_b_id [int] 
//analysis_b_id [int] 
//created_by [String] 
//created [Date] 
//elapsed_millis [int] 
  public GIAnalysis(Integer gi_analysis_id, Integer experiment_a_id, Integer analysis_a_id, Integer experiment_b_id, Integer analysis_b_id, String created_by, Date created, Integer elapsed_millis) {
    super(gi_analysis_id + "");
    add("gi_analysis_id", gi_analysis_id);
    add("experiment_a_id", experiment_a_id);
    add("analysis_a_id", analysis_a_id);
    add("experiment_b_id", experiment_b_id);
    add("analysis_b_id", analysis_b_id);
    add("created_by", created_by);
    add("created", created);
    add("elapsed_millis", elapsed_millis);
  }

  public GIAnalysis(Integer experiment_a_id, Integer analysis_a_id, Integer experiment_b_id, Integer analysis_b_id, String created_by, Date created) {
    this(-1, experiment_a_id, analysis_a_id, experiment_b_id, analysis_b_id, created_by, created, 0);
  }

  public GIAnalysis(Integer experiment_a_id, Integer analysis_a_id, Integer experiment_b_id, Integer analysis_b_id, String created_by) {
    this(-1, experiment_a_id, analysis_a_id, experiment_b_id, analysis_b_id, created_by, new Date(), 0);
  }

  public GIAnalysis(Integer experiment_a_id, Integer analysis_a_id, Integer experiment_b_id, Integer analysis_b_id) {
    this(-1, experiment_a_id, analysis_a_id, experiment_b_id, analysis_b_id, null, new Date(), 0);
  }

  /**
   * Get value for gi_analysis_id
   */
  public int getGi_analysis_id() {
    return getNumber("gi_analysis_id").intValue();
  }

  /**
   * Get value for experiment_a_id
   */
  public int getExperiment_a_id() {
    return getNumber("experiment_a_id").intValue();
  }

  /**
   * Get value for analysis_a_id
   */
  public int getAnalysis_a_id() {
    return getNumber("analysis_a_id").intValue();
  }

  /**
   * Get value for experiment_b_id
   */
  public int getExperiment_b_id() {
    return getNumber("experiment_b_id").intValue();
  }

  /**
   * Get value for analysis_b_id
   */
  public int getAnalysis_b_id() {
    return getNumber("analysis_b_id").intValue();
  }

  /**
   * Get value for created_by
   */
  public String getCreated_by() {
    return getString("created_by");
  }

  /**
   * Get value for created
   */
  public Date getCreated() {
    return getDate("created");
  }

  /**
   * Get value for elapsed_millis
   */
  public long getElapsed_millis() {
    return getNumber("elapsed_millis").longValue();
  }

  /**
   * Set value for gi_analysis_id
   */
  public void setGi_analysis_id(int gi_analysis_id) {
    add("gi_analysis_id", gi_analysis_id);
  }

  /**
   * Set value for experiment_a_id
   */
  public void setExperiment_a_id(int experiment_a_id) {
    add("experiment_a_id", experiment_a_id);
  }

  /**
   * Set value for analysis_a_id
   */
  public void setAnalysis_a_id(int analysis_a_id) {
    add("analysis_a_id", analysis_a_id);
  }

  /**
   * Set value for experiment_b_id
   */
  public void setExperiment_b_id(int experiment_b_id) {
    add("experiment_b_id", experiment_b_id);
  }

  /**
   * Set value for analysis_b_id
   */
  public void setAnalysis_b_id(int analysis_b_id) {
    add("analysis_b_id", analysis_b_id);
  }

  /**
   * Set value for created_by
   */
  public void setCreated_by(String created_by) {
    add("created_by", created_by);
  }

  /**
   * Set value for created
   */
  public void setCreated(Date created) {
    add("created", created);
  }

  /**
   * Set value for elapsed_millis
   */
  public void setElapsed_millis(long elapsed_millis) {
    add("elapsed_millis", elapsed_millis);
  }

  public void loadResults(ResourceFactory resourceFactory, PersonRecordIF requestedBy) throws IOException {
    SqlSession sqlSession = null;
    String previousResults = null;
    try {
      sqlSession = resourceFactory.getRNAiSqlSession();
      previousResults = sqlSession.getMapper(Mapper.class).getGeneticInteractionAnalysisResults(this);
    } finally {
      resourceFactory.close(sqlSession);
    }
    if (ExtString.hasLength(previousResults)) {
      readResults(resourceFactory, requestedBy, new StringReader(previousResults));
    }
  }

  public void readResults(ResourceFactory resourceFactory, PersonRecordIF requestedBy, Reader resultsReader) throws IOException {
    remove("results");
    
    char[] input = IOUtils.toCharArray(resultsReader);
    Set<Integer> geneIDs = new HashSet<Integer>();
    CSVReader resultsCSVReader = new CSVReader(new CharArrayReader(input), '\t');
    resultsCSVReader.readHeaders();
    while (resultsCSVReader.readRecord()) {
      int geneID = new Integer(resultsCSVReader.get("gene_id"));
      geneIDs.add(geneID);
    }
    resultsCSVReader.close();
    List<GeneRecord> geneRecords = resourceFactory.getGenes(geneIDs, requestedBy);

    //Setup a binary search on the GIResults keys (GeneRecords)
    Comparator geneComparator = new Comparator() {
      public int compare(Object o1, Object o2) {
        Integer geneID1 = ((GeneRecord) o1).getGeneID();
        Integer geneID2 = ((GeneRecord) o2).getGeneID();
        return geneID1.compareTo(geneID2);
      }
    };
    Collections.sort(geneRecords, geneComparator);

    resultsCSVReader = new CSVReader(new CharArrayReader(input), '\t');
    resultsCSVReader.readHeaders();

    while (resultsCSVReader.readRecord()) {
      int geneID = new Integer(resultsCSVReader.get("gene_id"));
      double pvalue = new Double(resultsCSVReader.get("pvalue"));
      double pvalueAdj = new Double(resultsCSVReader.get("pvals.adj"));
      double pvalueSuppressor = new Double(resultsCSVReader.get("pvals.suppressor"));
      double pvalueSuppressorAdj = new Double(resultsCSVReader.get("pvals.suppressor.adj"));
      double pvalueEnhancer = new Double(resultsCSVReader.get("pvals.enhancer"));
      double pvalueEnhancerAdj = new Double(resultsCSVReader.get("pvals.enhancer.adj"));

      int geneIndex = Collections.binarySearch(geneRecords, new GeneRecord(geneID), geneComparator);
      if (geneIndex >= 0) {
        GeneRecord geneRecord = geneRecords.get(geneIndex);
        GIResult giResult = new GIResult(geneRecord, getGi_analysis_id(),
                pvalue, pvalueAdj,
                pvalueSuppressor, pvalueSuppressorAdj,
                pvalueEnhancer, pvalueEnhancerAdj);
        addToArray("results", giResult);
      }
    }
    resultsCSVReader.close();
  }
  
  public List<GIResult> getResultList() {
    return getList("results");
  }

  public Iterator<GIResult> iterator() {
    return getResultList().iterator();
  }

  public int size() {
    return getResultList().size();
  }

  public boolean isEmpty() {
    return getResultList().isEmpty();
  }

  public boolean contains(Object o) {
    return getResultList().contains(o);
  }

  public Object[] toArray() {
    return getResultList().toArray();
  }

  public <GIResult> GIResult[] toArray(GIResult[] a) {
    return getResultList().toArray(a);
  }

  public boolean add(GIResult e) {
    return getResultList().add(e);
  }

  public boolean remove(Object o) {
    return getResultList().remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return getResultList().containsAll(c);
  }

  public boolean addAll(Collection<? extends GIResult> c) {
    return getResultList().addAll(c);
  }

  public boolean removeAll(Collection<?> c) {
    return getResultList().removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    return getResultList().retainAll(c);
  }

  public void clear() {
    remove("results");
  }
}