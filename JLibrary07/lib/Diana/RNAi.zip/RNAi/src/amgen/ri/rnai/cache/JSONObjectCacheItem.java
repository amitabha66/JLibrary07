package amgen.ri.rnai.cache;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.Debug;
import java.io.Serializable;
import java.util.*;

/**
 * Maintains a cached result object and any sorting to the object
 *
 * @author jemcdowe
 */
public class JSONObjectCacheItem implements Serializable {
  private String cacheID;
  private JSONObject jBaseObj;
  private String resultName = null;
  private int resultCount;
  private Map<String, JSONObject> sortJObjsMap;

  public JSONObjectCacheItem(String cacheID, JSONObject jBaseObj) throws JSONException {
    this.cacheID = cacheID;
    this.jBaseObj = jBaseObj;
    if (jBaseObj.has("genes")) {
      resultName = "genes";
    } else if (jBaseObj.has("rnai")) {
      resultName = "rnai";
    } else if (jBaseObj.has("plates")) {
      resultName = "plates";
    } else if (jBaseObj.has("experiments")) {
      resultName = "experiments";
    } else if (jBaseObj.has("poc")) {
      resultName = "poc";
    }
    if (resultName == null) {
      throw new IllegalArgumentException("No results returned.");
    }
    resultCount = this.jBaseObj.getJSONArray(resultName).asList().size();
    sortJObjsMap = new HashMap<String, JSONObject>();
  }

  public String getCacheID() {
    return cacheID;
  }

  public JSONObject getData() {
    return jBaseObj;
  }

  public String getResultName() {
    return resultName;
  }

  public int getResultCount() {
    return resultCount;
  }

  public JSONObject getSortedData(String sortField, String direction) {
    if (sortField == null || sortField.length() == 0) {
      return getData();
    }
    if (direction == null) {
      direction = "asc";
    }
    String sortKey = new String(sortField + "." + direction).toLowerCase();
    if (!sortJObjsMap.containsKey(sortKey)) {
      try {
        final String sort = sortField;
        final boolean asc = direction.equalsIgnoreCase("asc");
        List results = getData().getJSONArray(resultName).asList();

        if (!results.isEmpty()) {
          AbstractRecord ar = null;
          for (Object obj : results) {
            if (obj != null) {
              ar = (AbstractRecord) obj;
              break;
            }
          }
          if (ar != null) {
            final boolean isDate = ar.isDate(sort);

            JSONObject[] obj = (JSONObject[]) results.toArray(new JSONObject[0]);
            Arrays.sort(obj, new Comparator() {
              public int compare(Object o1, Object o2) {
                try {
                  JSONObject jObj1 = (JSONObject) o1;
                  JSONObject jObj2 = (JSONObject) o2;
                  Object v1 = jObj1.get(sort);
                  Object v2 = jObj2.get(sort);

                  if (v1 != null && v2 != null) {
                    if (v1 instanceof Number && v2 instanceof Number) {
                      double d1 = ((Number) v1).doubleValue();
                      double d2 = ((Number) v2).doubleValue();
                      return (asc ? 1 : -1) * Double.compare(d1, d2);
                    } else if (v1 instanceof Date && v2 instanceof Date) {
                      Date d1 = (Date) v1;
                      Date d2 = (Date) v2;
                      long t1 = d1.getTime();
                      long t2 = d2.getTime();
                      return (asc ? 1 : -1) * Long.compare(t1, t2);
                    } else if (isDate) {
                      AbstractRecord ar1 = (AbstractRecord) jObj1;
                      AbstractRecord ar2 = (AbstractRecord) jObj2;
                      Date d1 = ar1.getDate(sort);
                      Date d2 = ar2.getDate(sort);
                      long t1 = d1.getTime();
                      long t2 = d2.getTime();
                      return (asc ? 1 : -1) * Long.compare(t1, t2);
                    } else {
                      //Just sort by String
                      String s1 = v1.toString().toLowerCase();
                      String s2 = v2.toString().toLowerCase();
                      return (asc ? 1 : -1) * s1.compareTo(s2);
                    }
                  } else if (v1 == null && v2 != null) {
                    return (asc ? 1 : -1);
                  } else if (v2 == null && v1 != null) {
                    return (asc ? -1 : 1);
                  } else {
                    return 0;
                  }
                } catch (Exception e) {
                  e.printStackTrace();
                }
                return 0;
              }
            });
            List sortedList = Arrays.asList(obj);
            JSONObject sortedJObj = new JSONObject();
            sortedJObj.put(getResultName(), new JSONArray(sortedList));
            sortJObjsMap.put(sortKey, sortedJObj);
          }
        }
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
    return sortJObjsMap.get(sortKey);
  }

  public JSONObject getSortedFilteredData(String sortField, String direction, CacheFilterSet filterSet) {
    JSONObject jSortedObj = getSortedData(sortField, direction);
    if (filterSet == null || filterSet.isEmpty()) {
      return jSortedObj;
    }
    try {
      List<JSONObject> filteredJObjs = new ArrayList<JSONObject>();

      List<JSONObject> sortedJObjs = jSortedObj.getJSONArray(getResultName()).asList();
      for (JSONObject sortedJObj : sortedJObjs) {
        boolean match = true;
        for (CacheFilter filter : filterSet) {
          Object v1 = sortedJObj.get(filter.getField());
          if (!filter.match(v1)) {
            match = false;
            break;
          }
        }
        if (match) {
          filteredJObjs.add(sortedJObj);
        }
      }
      JSONObject filteredJObj = new JSONObject();
      filteredJObj.put(getResultName(), new JSONArray(filteredJObjs));
      return filteredJObj;
    } catch (Exception e) {
      e.printStackTrace();
    }
    return jSortedObj;
  }

  public void updateRecords(List<ExperimentRecord> expRecords) throws JSONException {
    updateRecords(expRecords, jBaseObj);
    for (JSONObject sortJObj : sortJObjsMap.values()) {
      updateRecords(expRecords, sortJObj);
    }
  }

  private void updateRecords(List<ExperimentRecord> expRecords, JSONObject jObj) throws JSONException {
    JSONArray jExpRecords = jObj.getJSONArray("experiments");
    for (ExperimentRecord expRecord : expRecords) {
      for (int i = 0; i < jExpRecords.length(); i++) {
        JSONObject currentRecord = jExpRecords.getJSONObject(i);
        if (expRecord.getExperimentID() == currentRecord.optInt("experiment_id", -1)) {
          jExpRecords.put(i, expRecord);
        }
      }
    }
  }

  public void deleteRecords(List<ExperimentRecord> expRecords) throws JSONException {
    deleteRecords(expRecords, jBaseObj);
    for (JSONObject sortJObj : sortJObjsMap.values()) {
      deleteRecords(expRecords, sortJObj);
    }
  }

  private void deleteRecords(List<ExperimentRecord> expRecords, JSONObject jObj) throws JSONException {
    List jExpRecords = jObj.getJSONArray("experiments").asList();
    for (ExperimentRecord expRecord : expRecords) {
      jExpRecords.remove(expRecord);
    }
  }
}
