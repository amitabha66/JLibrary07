package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;

/**
 *
 * @author jemcdowe
 */
public class ChartRecord extends AbstractRecord {
  public ChartRecord(JSONObject obj) throws JSONException {
    super(obj, "chart_id");
  }
}
