/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.cache;

import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author jemcdowe
 */
public class CacheFilterSet implements Collection<CacheFilter>, Iterable<CacheFilter> {
  private List<CacheFilter> filters;

  public CacheFilterSet(ServletBase servletBase) {
    this.filters= new ArrayList<CacheFilter>();
    int filterCount = 0;
    for (int i = 0; i < 50; i++) {
      if (servletBase.getParameter("filter[" + i + "][field]") == null) {
        break;
      } else {
        filterCount++;
      }
    }
    if (filterCount > 0) {
      for (int i = 0; i < filterCount; i++) {
        String fieldPName= "filter["+i+"][field]";
        String compPName= "filter["+i+"][data][comparison]";
        String typePName= "filter["+i+"][data][type]";
        String valuePName= "filter["+i+"][data][value]";
        try {
          CacheFilter filter= new CacheFilter(servletBase.getParameter(fieldPName), servletBase.getParameter(typePName), servletBase.getParameter(compPName), servletBase.getParameter(valuePName));
          filters.add(filter);
        } catch (Exception ex) {
          ex.printStackTrace();
        }        
      }
    }    
  }
  public Iterator<CacheFilter> iterator() {
    return filters.iterator();
  }

  public int size() {
    return filters.size();
  }

  public boolean isEmpty() {
    return filters.isEmpty();
  }

  public boolean contains(Object o) {
    return filters.contains(o);
  }

  public Object[] toArray() {
    return filters.toArray();
  }

  public <T> T[] toArray(T[] a) {
    return filters.toArray(a);
  }

  public boolean add(CacheFilter e) {
    return filters.add(e);
  }

  public boolean remove(Object o) {
    return filters.remove(o);
  }

  public boolean containsAll(Collection<?> c) {
    return filters.containsAll(c);
  }

  public boolean addAll(Collection<? extends CacheFilter> c) {
    return filters.addAll(c);
  }

  public boolean removeAll(Collection<?> c) {
    return filters.removeAll(c);
  }

  public boolean retainAll(Collection<?> c) {
    return filters.retainAll(c);
  }

  public void clear() {
    filters.clear();
  }
  
}
