/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.jproc;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import oracle.jdbc.OraclePreparedStatement;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import oracle.sql.BLOB;
import oracle.sql.CLOB;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractJProc {
  SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a");
  SimpleDateFormat dateFormat2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
  protected String lastSQL;

  public AbstractJProc() {
  }

  /**
   * This process the ResultSet appending the columns by column label to the
   * results JSONObject using the resultKey as an array key.
   *
   * @param rset
   * @param results
   * @param resultKey
   * @return
   * @throws SQLException
   * @throws JSONException
   */
  protected JSONObject processResults(ResultSet rset, JSONObject results, String resultKey) throws SQLException, JSONException {
    return processResults(rset, results, null, resultKey);
  }

  /**
   * This process the ResultSet appending the columns by column label to the
   * results JSONObject using the resultKey as an array key.
   *
   * The columnName2FieldNameMap provides a means to map a reported column name
   * to the field in the result JSONObject. If it is null or the column name not
   * in the Map, the column name is used as the field name
   *
   * @param rset
   * @param results
   * @param resultKey
   * @return
   * @throws SQLException
   * @throws JSONException
   */
  protected JSONObject processResults(ResultSet rset, JSONObject results, Map<String, String> columnName2FieldNameMap, String resultKey) throws SQLException, JSONException {

    ResultSetMetaData md = rset.getMetaData();
    while (rset.next()) {
      JSONObject record = new JSONObject();
      results.append(resultKey, record);
      for (int j = 1; j <= md.getColumnCount(); j++) {
        int columnType = md.getColumnType(j);
        String columnName = md.getColumnLabel(j);
        String fieldName = columnName;
        if (columnName2FieldNameMap != null && !columnName2FieldNameMap.isEmpty() && columnName2FieldNameMap.containsKey(columnName)) {
          fieldName = columnName2FieldNameMap.get(columnName);
        }
        String value = rset.getString(columnName);
        if (value != null) {
          switch (columnType) {
            //Integers
            case Types.BIGINT:
            case Types.INTEGER:
            case Types.SMALLINT:
            case Types.TINYINT:
              record.put(fieldName, rset.getInt(columnName));
              break;

            //Doubles
            case Types.DECIMAL:
            case Types.DOUBLE:
            case Types.FLOAT:
            case Types.REAL:
              //add Scale=0
              record.put(fieldName, rset.getDouble(columnName));
              break;
            case Types.NUMERIC:
              if (md.getScale(j) == 0) {
                record.put(fieldName, rset.getInt(columnName));
              } else {
                record.put(fieldName, rset.getDouble(columnName));
              }
              break;
              //Dates
            case Types.DATE:
            case Types.TIME:
            case Types.TIMESTAMP:
              //record.put(fieldName, dateFormat.format(rset.getDate(columnName)));
              record.put(fieldName, dateFormat.format(rset.getDate(columnName)));
              break;

            //Boolean
            case Types.BIT:
            case Types.BOOLEAN:
              record.put(fieldName, rset.getBoolean(columnName));
              break;

            //Everything else- String
            default:
              record.put(fieldName, value);
              break;
          }
        }
      }
    }
    return results;
  }

  /**
   * This process the ResultSet adding the columns by column label to the
   * results JSONObject using the first column as a key
   *
   * @param rset
   * @param results
   * @param resultKey
   * @return
   * @throws SQLException
   * @throws JSONException
   */
  protected JSONObject processResults(ResultSet rset, JSONObject results) throws SQLException, JSONException {
    ResultSetMetaData md = rset.getMetaData();
    while (rset.next()) {
      JSONObject record = null;
      for (int j = 1; j <= md.getColumnCount(); j++) {
        String columnName = md.getColumnLabel(j);
        String value = rset.getString(columnName);
        if (value != null) {
          if (j == 1) {
            record = new JSONObject();
            results.put(value, record);
          }
          if (record != null) {
            record.put(columnName, value);
          }
        }
      }
    }
    return results;
  }

  protected BLOB createBLOB(Connection conn, Object obj) throws SQLException {
    BLOB tempBlob = null;
    try {
      tempBlob = BLOB.createTemporary(conn, true, BLOB.DURATION_SESSION);
      OutputStream blobOutStream = tempBlob.setBinaryStream(0);
      ObjectOutputStream oop = new ObjectOutputStream(new GZIPOutputStream(blobOutStream));
      if (obj instanceof JSONObject || obj instanceof JSONArray) {
        oop.writeObject(obj);
      } else {
        oop.writeObject(obj.toString());
      }
      oop.flush();
      oop.close();
      blobOutStream.close();
    } catch (Exception exp) {
      tempBlob.freeTemporary();
      throw new SQLException(exp);
    }
    return tempBlob;
  }

  /**
   * for an optional JSONArray member of the jObj JSONObject, returns the
   * JSONArray for the key or an empty JSONArray if the key does not exist
   *
   * @param jObj
   * @param key
   * @return
   */
  protected JSONArray optJSONArray(JSONObject jObj, String key) {
    JSONArray jArr = jObj.optJSONArray(key);
    return (jArr == null ? new JSONArray() : jArr);
  }

  /**
   * for an optional JSONArray member of the jObj JSONObject, returns the
   * JSONArray as a List for the key or an empty List if the key does not exist
   *
   * @param jObj
   * @param key
   * @return
   */
  protected List optList(JSONObject jObj, String key) {
    return optJSONArray(jObj, key).asList();
  }

  public static String fromBlob2String(Blob b) throws SQLException {
    InputStream in = null;
    ByteArrayOutputStream bytesOut = null;
    try {
      in = b.getBinaryStream();
      bytesOut = new ByteArrayOutputStream();
      byte[] bytes = new byte[1025];
      int byteCount = -1;
      while ((byteCount = in.read(bytes)) > 0) {
        bytesOut.write(bytes);
      }
      in.close();
      bytesOut.close();
      ObjectInputStream objIN = new ObjectInputStream(new GZIPInputStream(new ByteArrayInputStream(bytesOut.toByteArray())));
      return (String) objIN.readObject();
    } catch (Exception e) {
    } finally {
      try {
        in.close();
      } catch (Exception e) {
      }
      try {
        bytesOut.close();
      } catch (Exception e) {
      }
    }
    return new String();
  }

  public static void close(Connection conn) {
    if (conn != null) {
      try {
        conn.commit();
        //conn.rollback();
        conn.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public static void close(ResultSet rset) {
    if (rset != null) {
      try {
        rset.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public static void close(Statement stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public static void close(CLOB stmt) {
    if (stmt != null) {
      try {
        stmt.close();
      } catch (SQLException e) {
        e.printStackTrace();
      }
    }
  }

  public static Connection getConnection() throws SQLException {
    if (System.getProperty("os.name").indexOf("Windows") >= 0) {
      OracleDataSource ods = new OracleDataSource();
      ods.setDriverType("thin");

      ods.setServerName("Uswa-ddbx-ora10.amgen.com");
      ods.setDatabaseName("Wa0630d");
      ods.setPortNumber(1521);
      ods.setUser("rnai_index");
      ods.setPassword("Ra1n1ng#");

//      ods.setServerName("uswa-pdbx-ora09.amgen.com");
//      ods.setDatabaseName("Wa0630p");
//      ods.setPortNumber(1521);
//      ods.setUser("rnai_index");
//      ods.setPassword("Ra1n1ng#");
      return ods.getConnection();
    } else {
      return DriverManager.getConnection("jdbc:default:connection:");
    }
  }

  protected OraclePreparedStatement getQueryAsStatement(Connection conn, String name) throws SQLException {
    String q = getQuery(conn, name);
    //System.out.print(q);
    return (OraclePreparedStatement) conn.prepareStatement(getQuery(conn, name));
  }

  protected String getQuery(Connection conn, String name) throws SQLException {
    Pattern p = Pattern.compile("\\{SELECT:([\\w ]+)\\}", Pattern.CASE_INSENSITIVE);
    OraclePreparedStatement stmt = (OraclePreparedStatement) conn.prepareStatement("SELECT QUERY from JPROC_QUERIES where QUERY_NAME= :name");
    stmt.setStringAtName("name", name);
    ResultSet rset = null;
    try {
      String query = null;
      rset = stmt.executeQuery();
      if (rset.next()) {
        query = rset.getString(1);
      }
      close(rset);
      close(stmt);
      if (query != null) {
        Matcher m = p.matcher(query);
        boolean result = m.find();
        if (result) {
          StringBuffer sb = new StringBuffer();
          do {
            m.appendReplacement(sb, getQuery(conn, m.group(1)));
            result = m.find();
          } while (result);
          m.appendTail(sb);
          return sb.toString();
        }
        setLastSQL(query);
        return query;
      }
    } finally {
      close(rset);
      close(stmt);
    }
    return null;
  }

  protected String join(Collection c, String delimiter) {
    StringBuffer joined = new StringBuffer();
    for (Object obj : c) {
      if (joined.length() > 0) {
        joined.append(delimiter);
      }
      joined.append(obj + "");
    }
    return joined.toString();
  }

  protected String encloseAndJoin(Collection c, String delimiter) {
    StringBuffer joined = new StringBuffer();
    for (Object obj : c) {
      if (joined.length() > 0) {
        joined.append(delimiter);
      }
      joined.append("'" + obj + "'");
    }
    return joined.toString();
  }

  public static void insertLog(Connection conn, String msg) {
    OraclePreparedStatement stmt = null;
    try {
      String query = new RNAiSearchJProc().getQuery(conn, "INSERT_FAVORITE_LOG");
      stmt = (OraclePreparedStatement) conn.prepareStatement(query);
      stmt.setStringAtName("msg", msg);
      stmt.executeUpdate();
    } catch (SQLException e) {
      e.printStackTrace();
    } finally {
      close(stmt);
    }
  }

  public static void insertLog(Connection conn, Throwable t) {
    StringWriter writer = new StringWriter();
    t.printStackTrace(new PrintWriter(writer));
    try {
      writer.close();
    } catch (IOException e1) {
    }
    insertLog(conn, writer.toString());
  }

  public String getLastSQL() {
    return lastSQL;
  }

  public void setLastSQL(String lastSQL) {
    this.lastSQL = lastSQL;
  }
}
