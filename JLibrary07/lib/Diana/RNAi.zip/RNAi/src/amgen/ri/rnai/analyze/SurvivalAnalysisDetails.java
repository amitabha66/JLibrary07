/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneRecord;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.Serializable;
import java.util.*;

/**
 *
 * @author jemcdowe
 */
public class SurvivalAnalysisDetails extends AbstractAnalysisDetails implements AnalysisDetailsIF, AnalysisImageIF, Serializable {
  //static final long serialVersionUID = -4799376995022091388L;
  protected String key;
  private ExperimentRecord experimentRecord;
  private List<GeneRecord> targetGeneRecords;
  private List<GeneRecord> controlGeneRecords;
  private BufferedImage survivalImage;
  private Date startTime;
  private Date endTime;

  public SurvivalAnalysisDetails(ExperimentRecord experimentRecord, List<GeneRecord> targetGeneRecords, List<GeneRecord> controlGeneRecords) {
    super();
    this.key = UUID.randomUUID().toString();
    this.experimentRecord = experimentRecord;
    this.targetGeneRecords = targetGeneRecords;
    this.controlGeneRecords = controlGeneRecords;
  }

  public String getKey() {
    return key;
  }

  public String getAnalysisName() {
    return "Survival Plot";
  }

  public Properties getAnalysisProperties() {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public List<GeneRecord> getControlGeneRecords() {
    return controlGeneRecords;
  }

  public ExperimentRecord getExperimentRecord() {
    return experimentRecord;
  }

  public BufferedImage getSurvivalImage() {
    return survivalImage;
  }

  public void setSurvivalImage(BufferedImage survivalImage) {
    this.survivalImage = survivalImage;
  }

  public List<GeneRecord> getTargetGeneRecords() {
    return targetGeneRecords;
  }

  public void setTargetGeneRecords(List<GeneRecord> targetGeneRecords) {
    this.targetGeneRecords = targetGeneRecords;
  }

  public boolean hasFinished() {
    return (endTime != null);
  }

  public File getAnalysisLog() {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Date getEndTime() {
    return endTime;
  }

  public Date getStartTime() {
    return startTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = (endTime == null ? new Date() : endTime);
  }

  public void setStartTime(Date startTime) {
    this.startTime = (startTime == null ? new Date() : startTime);
  }

  public boolean isValid() {
    return true;
  }

  public List<ExperimentRecord> getExperimentRecords() {
    return Arrays.asList(experimentRecord);
  }

  public BufferedImage getImage() {
    return getSurvivalImage();
  }
}
