/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.time.ElapsedTime;
import amgen.ri.util.ExtString;
import java.sql.*;
import java.util.*;
import java.util.regex.Pattern;
import oracle.jdbc.OracleCallableStatement;

/**
 *
 * @author jemcdowe
 */
public abstract class AbstractSearch extends ResourceFactory {
  final Pattern compoundIDPattern = Pattern.compile("([0-9]+)#([0-9]+).*");
  private PersonRecordIF sessionUser;
  private PermissionManager permissionManager;

  public AbstractSearch(AbstractResponder responder) {
    this(responder.getSessionCache(), responder.getServletBase().getPersonRecord());
  }

  public AbstractSearch(SessionCache sessionCache, PersonRecordIF sessionUser) {
    super(sessionCache);
    this.sessionUser = sessionUser;
    this.permissionManager = new PermissionManager(sessionUser);
  }

  public PersonRecordIF getSessionUser() {
    return sessionUser;
  }

  /**
   * Splits the query String by line breaks: [\n\f\r]+
   *
   * @param query
   * @return
   */
  protected List<String> getParsedQuery(String query) {
    return getParsedQuery(query, false);
  }

  /**
   * Splits the query String by line breaks: [\n\f\r]+ and optionally
   * punctuation characters (,;)
   *
   * @param query
   * @return
   */
  protected List<String> getParsedQuery(String query, boolean includePunctuation) {
    if (!includePunctuation) {
      return getParsedQuery(query, "[\\n\\f\\r]+");
    } else {
      return getParsedQuery(query, "[\\n\\f\\r;,]+");
    }
  }

  /**
   * Splits the query String by line breaks: [\n\f\r]+ and optionally
   * punctuation characters (,;)
   *
   * @param query
   * @return
   */
  protected List<String> getParsedQuery(String query, String splitRegEx) {
    if (ExtString.hasLength(query)) {
      return Arrays.asList(query.split(splitRegEx));
    }
    return new ArrayList<String>();
  }
  /*
   * Converts the Result Type names to something more readable- replaces
   * underscores with spaces and makes it title case
   */

  public static String getExperimentResultTypeLabel(String resultType) {
    if (resultType.equalsIgnoreCase("poc")) {
      return resultType.toUpperCase();
    }
    String label = ExtString.toTitleCase(resultType.replaceAll("_", " "));
    Pattern p = Pattern.compile("rna", Pattern.CASE_INSENSITIVE);
    return p.matcher(label).replaceAll("RNA");
  }

  /**
   * Reverts a Result Type label back to a Result Type name- replaces spaces
   * with underscores and makes it upper case
   *
   * @param resultTypeLabel
   * @return
   */
  public static String getExperimentResultTypeFromLabel(String resultTypeLabel) {
    return resultTypeLabel.trim().replaceAll("\\s+", "_").toUpperCase();
  }

  protected abstract List<Map<String, String>> getQuery();

  protected List<Map<String, String>> getQuery(RNAiSearchInputType searchType, String rawQuery) {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value;

    List<String> inQueries = getParsedQuery(rawQuery);

    switch (searchType) {
      case RNAI_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("rnai_id", inQuery);
        }
        break;
      case GENE_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("gene_id", inQuery);
        }
        break;
      case GENE_SYMBOLS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("gene_symbol", inQuery);
        }
        break;
      case ENTREZGENE_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("eg_id", inQuery);
        }
        break;
      case BARCODES:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("barcode", inQuery);
        }
        break;
      case COMPOUND_IDS:
        for (String inQuery : inQueries) {
          String[] split = inQuery.split("#");
          if (split.length == 2 && ExtString.isAInteger(split[0]) && ExtString.isAInteger(split[1])) {
            value = new HashMap<String, String>();
            query.add(value);
            value.put("root_number", split[0]);
            value.put("lot_number", split[1]);
          }
        }
        break;
      case EXPERIMENT_IDS:
        for (String inQuery : inQueries) {
          value = new HashMap<String, String>();
          query.add(value);
          value.put("experiment_id", inQuery);
        }
        break;
    }
    return query;
  }

  protected JSONObject executeQuery(RNAiSearchInputType inputType, RNAiSearchOutputType outputType) throws SQLException {
    return executeQuery(inputType, outputType, getQuery());
  }

  protected JSONObject executeQuery(RNAiSearchInputType inputType, RNAiSearchOutputType outputType, List<Map<String, String>> query) throws SQLException {
    //ElapsedTime time = new ElapsedTime(true);
    //time.writeSplit("In: " + inputType + " Out: " + outputType, true);
    String runQuerySQL = "begin ? := RNAIQUERY.runQuery(?, ?, ?); end;";
    Connection conn = null;
    //JSONObject response= null;    
    try {
      conn = getRNAiConnection();
      //time.writeSplit(true);
      OracleCallableStatement cs = (OracleCallableStatement) conn.prepareCall(runQuerySQL);
      cs.registerOutParameter(1, Types.BLOB);
      cs.setString(2, inputType.toString());
      cs.setString(3, outputType.toString());
      cs.setBLOB(4, createBLOB(conn, query));
      //time.writeSplit(true);
      cs.execute();
      //time.writeSplit(true);
      Blob resultBlob = cs.getBlob(1);
      //time.writeSplit(true);
      JSONObject jResults = fromBlob(resultBlob);
      //time.writeSplit(true);

      //response= jResults;
      return jResults;
    } finally {
      //writeQuery(inputType, outputType, query, response);
      OraSQLManager.closeResources(conn);
    }
  }

  public abstract List<? extends AbstractRecord> asList();

  public abstract int getCount();

  protected boolean checkUserHasAccess(ExperimentRecord expRecord) {
    return permissionManager.hasPermission(PermissionType.VIEW, expRecord);
  }

  protected boolean checkUserCanPublish(ExperimentRecord expRecord) {
    return permissionManager.hasPermission(PermissionType.EDIT, expRecord);
  }

  protected boolean checkUserCanDelete(ExperimentRecord expRecord) {
    return permissionManager.hasPermission(PermissionType.DELETE, expRecord);
  }
}
