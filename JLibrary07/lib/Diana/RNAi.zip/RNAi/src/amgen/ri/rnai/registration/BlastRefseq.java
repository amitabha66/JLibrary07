/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.registration;

import amgen.ri.asf.bio.FastaEntry;
import amgen.ri.asf.bio.FastaReader;
import amgen.ri.servlet.ServletBase;
import amgen.ri.sys.SystemCommand;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Pattern;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author jemcdowe
 */
@WebServlet(name = "BlastRefseq", urlPatterns = {"/blastrefseq.go"})
public class BlastRefseq extends ServletBase {
  private Pattern overhangPattern = Pattern.compile("([agctu]){19}(tt|uu)", Pattern.CASE_INSENSITIVE);
  private Properties blastProperties;
  private String propertiesPrefix = "blast";
  private Map<String, FastaEntry> queryFastaMap;
  private File blastHome;
  private File workDir;

  public BlastRefseq() {
  }

  public BlastRefseq(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
    try {
      if (System.getProperty("os.name").toLowerCase().indexOf("windows") > -1) {
        propertiesPrefix = "blast.windows";
      } else if (System.getProperty("os.name").toLowerCase().indexOf("linux") > -1) {
        propertiesPrefix = "blast.linux";
      }

      queryFastaMap = new HashMap<String, FastaEntry>();
      blastProperties = new Properties();
      blastProperties.load(getClass().getResourceAsStream("/blast.properties"));
      blastHome = new File(blastProperties.getProperty(propertiesPrefix + ".home"));
      workDir = new File(blastProperties.getProperty(propertiesPrefix + ".work") + "/" + UUID.randomUUID().toString());
      if (!workDir.isDirectory()) {
        if (!workDir.mkdirs()) {
          throw new IOException("Unable to create temporary directory " + workDir);
        }
      }
    } catch (IOException ex) {
      Logger.getLogger(BlastRefseq.class.getName()).log(Level.SEVERE, null, ex);
    }
  }

  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new BlastRefseq(req, resp);
  }

  @Override
  protected void performRequest() throws Exception {
    try {
      File queryFile = createQueryFile();
      FastaReader reader = new FastaReader(new FileReader(queryFile));
      for (FastaEntry fasta : reader) {
        queryFastaMap.put(fasta.getID(), fasta);
      }
      String species = getParameter("species", "human");
      File outFile = runBlast(queryFile, species);
      BufferedReader outReader = new BufferedReader(new FileReader(outFile));
      String line;
      while ((line = outReader.readLine()) != null) {
        String[] fields = line.split("\\s+");
        if (fields.length == 12) {
          String queryID = fields[0];
          FastaEntry queryEntry = queryFastaMap.get(queryID);
          String querySeq = queryEntry.getBioSequence().getSequence();
          int queryLen = queryEntry.getBioSequence().length();
          String targetID = fields[1];
          String[] targetIDFields = targetID.split("\\|");
          if (targetIDFields.length > 1) {
            targetID = targetIDFields[targetIDFields.length - 1];
          }

          double identity = new Double(fields[2]);
          int alignmentLength = new Integer(fields[3]);
          int mismatches = new Integer(fields[4]);
          int gaps = new Integer(fields[5]);
          int qStart = new Integer(fields[6]);
          int qEnd = new Integer(fields[7]);
          int sStart = new Integer(fields[8]);
          int sEnd = new Integer(fields[9]);
          double eValue = new Double(fields[10]);
          double bitScore = new Double(fields[11]);
          response.getWriter().printf("%s\t%s\t%d\t%s\t%f\t%d\t%d\t%d\t%d\t%d\t%d\t%d\t%f\t%f\t%s\n", new Object[]{
                    queryID,
                    querySeq,
                    queryLen,
                    targetID,
                    identity,
                    alignmentLength,
                    mismatches,
                    gaps,
                    qStart,
                    qEnd,
                    sStart,
                    sEnd,
                    eValue,
                    bitScore,
                    (isMatch(queryEntry, alignmentLength, identity, qStart, qEnd) ? "YES" : "NO")
                  });

        }
      }
      outReader.close();
    } catch (Exception e) {
      response.addHeader("ERROR_MSG", e.getMessage());
      response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
    } finally {
      ExtFile.deepdelete(workDir);
    }
  }

  @Override
  protected String getServletMimeType() {
    return "text/plain";
  }

  /**
   * Run the blast process
   *
   * @param queryFile File
   * @param dbFile File
   * @param options Map
   * @throws IOException
   */
  private File runBlast(File queryFile, String species) throws IOException, InterruptedException {
    species = species.toLowerCase();
    if (species.startsWith("mus") || species.startsWith("mouse")) {
      species = "mouse";
    } else if (species.startsWith("rat")) {
      species = "rat";
    } else {
      species = "human";
    }
    final String matchSpecies = species;

    File blastallExe = new File(new File(blastHome, "bin"), "blastall");
    File blastOutputFile = new File(workDir, "fasta" + ".blast");
    File dbHomeFile = new File(blastHome, "db");

    File[] dbFiles = dbHomeFile.listFiles(new FilenameFilter() {
      public boolean accept(File dir, String name) {
        return name.matches(matchSpecies + ".*" + "\\.fna");
      }
    });
    Arrays.sort(dbFiles, new Comparator() {
      public int compare(Object o1, Object o2) {
        File f1 = (File) o1;
        File f2 = (File) o2;
        return -Double.compare(f1.lastModified(), f2.lastModified());
      }
    });   

    File dbFile = dbFiles[0];
    File dbNSQFile = new File(dbFile + ".nsq");
    
    if (!dbFile.exists()) {
      throw new IOException("Database " + dbFile.getName() + " does not exist." + dbFile);
    }
    if (!dbNSQFile.exists() || dbFile.lastModified() > dbNSQFile.lastModified()) {
      SystemCommand sysCommand = new SystemCommand(
              ExtString.concat(new Object[]{
                new File(new File(blastHome, "bin"), "formatdb"),
                blastProperties.getProperty(propertiesPrefix + ".formatdb.options"),
                createOption("i", dbFile.getName())
              }, ' '), null, dbFile.getParentFile());
      int ret = sysCommand.execute();
      if (ret != 0) {
        throw new IOException("Unable to format database " + dbFile.getName() + " [" + sysCommand.getStderr() + "]");
      }
    }


    SystemCommand sysCommand = new SystemCommand(
            ExtString.concat(new Object[]{
              blastallExe,
              blastProperties.getProperty(propertiesPrefix + ".options"),
              createOption("i", queryFile),
              createOption("d", dbFile.getName()),
              createOption("o", blastOutputFile)
            }, ' '), null, dbFile.getParentFile());
    int ret = sysCommand.execute();
    if (ret != 0) {
      throw new IOException("BLAST failed. [" + sysCommand.getStderr() + "]");
    }
    return blastOutputFile;
  }

  private boolean isMatch(FastaEntry query, int alignment, double identity, int qStart, int qEnd) {
    if (alignment == query.getSequenceLength() && identity > 99) {
      return true;
    }
    if (qStart == 1 && qEnd >= 19 && query.getSequenceLength() == 21 && identity > 99 && overhangPattern.matcher(query.getBioSequence().getSequence()).matches()) {
      return true;
    }
    return false;
  }

  private File createQueryFile() throws IOException {
    File queryFile = new File(workDir, "query.fa");
    String queryFasta = getParameter("in");
    if (queryFasta.startsWith(">")) {
      ExtFile.writeTextFile(queryFile, queryFasta);
    } else {
      PrintWriter queryWriter = new PrintWriter(queryFile);
      String[] sequences = getParameter("in").split("[\\n;]+");
      for (String entry : sequences) {
        String[] entryFields = entry.split(":");
        if (entryFields.length == 2) {
          FastaEntry fasta = new FastaEntry(entryFields[0], null, entryFields[1]);
          queryWriter.println(fasta);
        }
      }
      queryWriter.close();
    }
    return queryFile;
  }

  /**
   * Formats a command line option for BLAST calls
   *
   * @param key String
   * @param val String
   * @return String
   */
  private String createOption(String key, Object val) {
    String opt = key.trim();
    opt = (opt.startsWith("-") ? opt : "-" + opt);

    String commLineOptions = opt;
    if (val != null && ExtString.hasLength(val.toString())) {
      commLineOptions = commLineOptions + " " + val;
    }
    return commLineOptions;
  }
}
