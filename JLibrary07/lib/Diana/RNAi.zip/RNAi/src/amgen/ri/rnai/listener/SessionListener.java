/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.listener;

import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.util.ExtFile;
import java.io.File;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

/**
 *
 * @author jemcdowe
 */
@WebListener
public class SessionListener implements HttpSessionListener {
  public SessionListener() {
  }

  @Override
  public void sessionCreated(HttpSessionEvent se) {
   
  }

  @Override
  public void sessionDestroyed(HttpSessionEvent se) {
    try {
      new SessionCache(se.getSession()).removeSessionCache();
      File tempDir = (File) se.getSession().getAttribute("WORK_DIR");
      if (tempDir != null) {
        ExtFile.deepdelete(tempDir);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
