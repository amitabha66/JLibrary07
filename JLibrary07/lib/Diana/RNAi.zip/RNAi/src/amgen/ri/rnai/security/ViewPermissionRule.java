/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.security;

import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtString;

/**
 *
 * @author jemcdowe
 */
public class ViewPermissionRule extends AbstractPermissionRule implements PermissionRuleIF {
  public ViewPermissionRule(PersonRecordIF requestedBy) {
    super(PermissionType.VIEW, requestedBy);
  }

  /**
   * Check whether the requestedBy user can view the record
   * and throws a SecurityException if not true/false
   *
   * @param record
   * @return
   * @throws SecurityException
   */
  public void checkPermission(AbstractRecord record) throws SecurityException {
    if (!(record instanceof ExperimentRecord)) {
      throw new IllegalArgumentException("Permission requires experiment record");
    }
    ExperimentRecord expRecord = (ExperimentRecord) record;
    if (isAdministrator() || 
        expRecord.getUploadedByUsername().equals(getRequestedBy().getUsername()) ||
        ExtString.equalsIgnoreCase(expRecord.getVisibility(), "public")) {
      return;
    }
    throw new SecurityException("User does not have sufficient privilege to view experiment");
  }
}
