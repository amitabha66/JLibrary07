/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public final class AlignmentPairRecord extends AbstractRecord {  

  public AlignmentPairRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public AlignmentPairRecord(String recordID) {
    super(recordID);
  }
  
  public AlignmentPairRecord(String id, int subjectStart, int subjectEnd, int queryStart, int queryEnd) {
    super(id);
    setSubjectStart(subjectStart);
    setSubjectEnd(subjectEnd);
    setQueryStart(queryStart);
    setQueryEnd(queryEnd);
  }

  /**
   * @return the subjectStart
   */
  public int getSubjectStart() {
    return getNumber("sStart").intValue();
  }

  /**
   * @param subjectStart the subjectStart to set
   */
  public void setSubjectStart(int subjectStart) {
    add("sStart", subjectStart);
  }

  /**
   * @return the subjectEnd
   */
  public int getSubjectEnd() {
    return getNumber("sEnd").intValue();
  }

  /**
   * @param subjectEnd the subjectEnd to set
   */
  public void setSubjectEnd(int subjectEnd) {
    add("sEnd", subjectEnd);
  }

  /**
   * @return the queryStart
   */
  public int getQueryStart() {
    return getNumber("qStart").intValue();
  }

  /**
   * @param queryStart the queryStart to set
   */
  public void setQueryStart(int queryStart) {
    add("qStart", queryStart);
  }

  /**
   * @return the queryEnd
   */
  public int getQueryEnd() {
    return getNumber("qEnd").intValue();
  }

  /**
   * @param queryEnd the queryEnd to set
   */
  public void setQueryEnd(int queryEnd) {
    add("qEnd", queryEnd);
  }
  
}
