/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.log;

import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.util.Debug;
import com.google.common.collect.Iterators;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jemcdowe
 */
 @WebFilter(filterName = "LogFilter", urlPatterns={"/*"})
public class LogFilter extends ResourceFactory implements Filter {

  public LogFilter() {
  }

  @Override
  public void init(FilterConfig filterConfig) throws ServletException {
  }

  @Override
  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
    HttpServletRequest req = (HttpServletRequest) request;
    if (StringUtils.isNotEmpty(req.getRequestURI()) && StringUtils.contains(req.getRequestURI(), "/RNAi/rnai.go") && !ServletFileUpload.isMultipartContent(req)) {
      SqlSession sqlSession = null;
      try {
        sqlSession = getRNAiSqlSession();
        String requestClassName = req.getParameter("req");
        if (StringUtils.isEmpty(requestClassName)) {
          requestClassName = "Main UI";
        }
        List<String> requestParams = new ArrayList<String>();
        for (String paramName : req.getParameterMap().keySet()) {
          requestParams.add(paramName + "=" + StringUtils.join(req.getParameterValues(paramName), ','));
        }
        LogEntry logEntry = new LogEntry(req.getRemoteUser(), req.getSession().getId(), requestClassName, StringUtils.join(requestParams, ';'));
        sqlSession.getMapper(Mapper.class).insertLogEntry(logEntry);
        sqlSession.commit();
      } catch (Exception e) {
        e.printStackTrace();
      } finally {
        close(sqlSession);
      }
    }
    chain.doFilter(request, response);
  }

  @Override
  public void destroy() {
  }

}
