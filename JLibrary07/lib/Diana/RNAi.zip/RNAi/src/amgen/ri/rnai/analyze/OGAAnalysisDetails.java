/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author jemcdowe
 */
public class OGAAnalysisDetails extends AbstractAnalysisDetails implements AnalysisDetailsIF, Serializable {
  static final long serialVersionUID = -7655021389588385332L;
  private String key;
  private String name;
  private File workingDir;
  private List<ExperimentRecord> expRecords;
  private Date startTime;
  private Date endTime;
  private SimpleDateFormat logDateParser;
  private Properties ogaAnalysisProperties;

  public OGAAnalysisDetails(File workingDir) {
    super();
    this.key = UUID.randomUUID().toString();    
    this.name = "OGA Analysis";
    this.workingDir = workingDir;
    this.expRecords = new ArrayList<ExperimentRecord>();
    logDateParser = new SimpleDateFormat("dd MMM yyyy HH:mm:ss");
    ogaAnalysisProperties = new Properties();
  }

  public String getKey() {
    return key;
  }

  public String getAnalysisName() {
    if (getExperimentRecords().isEmpty()) {
      return "OGA Analysis";
    }
    if (getExperimentRecords().size() == 1) {
      return "OGA Analysis: " + getExperimentRecords().get(0).getExperimentName();
    }
    return "OGA Analysis: " + getExperimentRecords().size() + " exps";
  }

  public boolean isValid() {
    return (getAnalysisStartDate() != null);
  }

  public File getWorkingDir() {
    return workingDir;
  }

  public void setWorkingDir(File workingDir) {
    this.workingDir = workingDir;
  }

  public List<ExperimentRecord> getExperimentRecords() {
    return expRecords;
  }

  public void addExperimentRecord(ExperimentRecord expRecord) {
    expRecords.add(expRecord);
  }

  public void addOGAProperty(String key, String value) {
    ogaAnalysisProperties.put(key, value);
  }

  public File getLog() {
    return new File(workingDir, "log");
  }


  public File getAnalysisLog() {
    return new File(getLog().getAbsoluteFile() + ".analysis.log");
  }

  public Date getAnalysisStartDate() {
    return findDateProperty("STARTED");
  }

  public Date getAnalysisEndDate() {
    return findDateProperty("ENDED");
  }

  public boolean hasFinished() {
    if (endTime != null) {
      return true;
    }
    Date endTime = findDateProperty("ENDED");
    if (endTime != null) {
      this.endTime = endTime;
      return true;
    }
    return false;
  }

  private Date findDateProperty(String key) {
    try {
      List<String> values = findPropertyValues(key);
      if (!values.isEmpty()) {
        return logDateParser.parse(values.get(0));
      }
    } catch (Exception ex) {
    }
    return null;
  }

  private List<String> findPropertyValues(String key) {
    List<String> propertyValues = new ArrayList<String>();
    BufferedReader reader = null;
    try {
      reader = new BufferedReader(new FileReader(getAnalysisLog()));
      String line;
      while ((line = reader.readLine()) != null) {
        if (line.startsWith(key)) {
          propertyValues.add(line.replaceFirst(key, "").trim());
        }
      }
    } catch (Exception ex) {
      //ex.printStackTrace();
    } finally {
      if (reader != null) {
        try {
          reader.close();
        } catch (Exception ex) {
        }
      }
    }
    return propertyValues;
  }

  public Properties getAnalysisProperties() {
    return ogaAnalysisProperties;
  }

  public Date getStartTime() {
    return startTime;
  }

  public void setStartTime(Date startTime) {
    this.startTime = startTime;
  }

  public Date getEndTime() {
    return endTime;
  }

  public void setEndTime(Date endTime) {
    this.endTime = endTime;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public void saveObject() throws IOException {
    ExtFile.writeFile(new File(workingDir, "detail.bin"), ExtObject.serializeObject(this));
  }

}
