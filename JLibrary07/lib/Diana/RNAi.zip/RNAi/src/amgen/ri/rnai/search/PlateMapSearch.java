/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONObject;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.PlateInfo;
import amgen.ri.rnai.ui.AbstractResponder;
import java.util.*;

/**
 * * A simple version of the AbstractSearch class specific for searching for
 * Collections and Members
 *
 * @author jemcdowe
 */
public class PlateMapSearch extends AbstractSearch {
  List<PlateInfo> plateInfoRecords;
  private Collection<String> barcodes;

  public PlateMapSearch(AbstractResponder responder, Collection<String> barcodes) {
    super(responder);
    this.barcodes = barcodes;
  }

  @Override
  protected List<Map<String, String>> getQuery() {
    List<Map<String, String>> query = new ArrayList<Map<String, String>>();
    Map<String, String> value;
    for (String barcode : barcodes) {
      value = new HashMap<String, String>();
      query.add(value);
      value.put("barcode", barcode);
    }
    return query;
  }

  @Override
  public List<? extends AbstractRecord> asList() {
    if (plateInfoRecords == null) {
      try {
        plateInfoRecords = new ArrayList<PlateInfo>();
        JSONObject jResults = executeQuery(RNAiSearchInputType.BARCODES, RNAiSearchOutputType.PLATEMAP, getQuery());
        List<JSONObject> results = new ArrayList<JSONObject>();
        if (jResults.has("results")) {
          results = jResults.getJSONArray("results").asList();
        }
        for (JSONObject result : results) {
          plateInfoRecords.add(new PlateInfo(result));
        }
      } catch (Exception ex) {
      }
    }
    return plateInfoRecords;
  }

  @Override
  public int getCount() {
    return asList().size();
  }
}