/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.edit;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.cache.JSONObjectCacheItem;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.security.PermissionManager;
import amgen.ri.rnai.security.PermissionType;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtString;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import oracle.jdbc.OraclePreparedStatement;

/**
 *
 * @author jemcdowe
 */
public class UpdateExperimentResponder extends AbstractResponder implements JSONResponderIF {
  public UpdateExperimentResponder(MainUI servletBase) {
    super(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    try {
      jResponse.put("updates", 0);
      List<ExperimentRecord> experimentRecords = getExperimentRecordsFromParameter();
      List<ExperimentRecord> updatedExperimentRecords = new ArrayList<ExperimentRecord>();
      if (!experimentRecords.isEmpty()) {
        Connection conn = null;
        try {
          conn = getRNAiConnection();
          OraclePreparedStatement stmt = getJProcQueryAsStatement(conn, "UPDATEEXPERIMENT");
          PermissionManager permissionsMgr = new PermissionManager(getServletBase());
          String visibility = getParameter("visibility");
          String status = getParameter("status");
          String dataID = getParameter("dataID");


          for (ExperimentRecord experimentRecord : experimentRecords) {
            if (permissionsMgr.hasPermission(PermissionType.PUBLISH, experimentRecord)) {
              String updateVisibility = (ExtString.hasLength(visibility) ? visibility : experimentRecord.getVisibility());
              String updateStatus = (ExtString.hasLength(status) ? status : experimentRecord.getStatus());
              stmt.setStringAtName("visibility", updateVisibility);
              stmt.setStringAtName("status", updateStatus);
              stmt.setIntAtName("experiment_id", experimentRecord.getExperimentID());
              int updated = stmt.executeUpdate();
              if (updated > 0) {
                updatedExperimentRecords.add(experimentRecord);
              }
              jResponse.put("updates", jResponse.getInt("updates") + updated);
            }
          }
          if (dataID != null) {
            JSONObjectCacheItem jCachedResults = (JSONObjectCacheItem) getServletBase().getSessionCache().get(SessionCache.CacheType.RESULTS, dataID);
            if (jCachedResults != null) {
              jCachedResults.updateRecords(getExperimentRecords(updatedExperimentRecords));
            }
          }
        } catch (Exception e) {
          e.printStackTrace();
        } finally {
          close(conn);
        }
      }
    } catch (JSONException ex) {
      Logger.getLogger(UpdateExperimentResponder.class.getName()).log(Level.SEVERE, null, ex);
    }
    return jResponse;
  }
}
