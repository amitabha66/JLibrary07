/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.util;

import amgen.ri.asf.bio.NASequence;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.records.RNAiRecord;
import amgen.ri.sql.GenericSQLProvider;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.*;
import oracle.jdbc.OraclePreparedStatement;

/**
 *
 * @author jemcdowe
 */
public class Tester {
  public Tester() {
  }

  public static void main(String[] args) throws Exception {
    
    String[] t= {"a", "b", "c", "d"};
    
    TreeSet<String> tree= new TreeSet<String>(Arrays.asList(t));
    
    for(String s : tree) {
      for(String s1 : tree.tailSet(s, false)) {
        System.out.println(s+"\t"+s1);
      }
    }


  }
}
