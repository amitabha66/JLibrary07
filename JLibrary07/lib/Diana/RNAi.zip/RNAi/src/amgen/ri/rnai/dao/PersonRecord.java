package amgen.ri.rnai.dao;

import amgen.ri.rnai.records.AbstractRecord;

public class PersonRecord extends AbstractRecord {
//person_id [int] 
//amgen_login [String] 
//first_name [String] 
//last_name [String] 
//ledger_name [String] 
//email [String] 
//location_code [String] 
  public PersonRecord(Integer person_id) {
    super(person_id + "");
    add("person_id", person_id);
  }

  /**
   * Get value for person_id
   */
  public int getPerson_id() {
    return getNumber("person_id").intValue();
  }

  /**
   * Get value for amgen_login
   */
  public String getAmgen_login() {
    return getString("amgen_login");
  }

  /**
   * Get value for first_name
   */
  public String getFirst_name() {
    return getString("first_name");
  }

  /**
   * Get value for last_name
   */
  public String getLast_name() {
    return getString("last_name");
  }

  /**
   * Get value for ledger_name
   */
  public String getLedger_name() {
    return getString("ledger_name");
  }

  /**
   * Get value for email
   */
  public String getEmail() {
    return getString("email");
  }

  /**
   * Get value for location_code
   */
  public String getLocation_code() {
    return getString("location_code");
  }

  /**
   * Set value for person_id
   */
  public void setPerson_id(int person_id) {
    add("person_id", person_id);
  }

  /**
   * Set value for amgen_login
   */
  public void setAmgen_login(String amgen_login) {
    add("amgen_login", amgen_login);
  }

  /**
   * Set value for first_name
   */
  public void setFirst_name(String first_name) {
    add("first_name", first_name);
  }

  /**
   * Set value for last_name
   */
  public void setLast_name(String last_name) {
    add("last_name", last_name);
  }

  /**
   * Set value for ledger_name
   */
  public void setLedger_name(String ledger_name) {
    add("ledger_name", ledger_name);
  }

  /**
   * Set value for email
   */
  public void setEmail(String email) {
    add("email", email);
  }

  /**
   * Set value for location_code
   */
  public void setLocation_code(String location_code) {
    add("location_code", location_code);
  }

  public void setIsAdministrator(boolean isAdministrator) {
    add("isAdministrator", isAdministrator);
  }

  public boolean isAdministrator() {
    return getBoolean("isAdministrator");
  }  
}