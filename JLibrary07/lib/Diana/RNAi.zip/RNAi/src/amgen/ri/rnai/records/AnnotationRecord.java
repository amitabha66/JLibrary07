/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;

/**
 * Encapsulates a Collection Record
 *
 * @author jemcdowe
 */
public class AnnotationRecord extends AbstractRecord {
  public AnnotationRecord(JSONObject source) throws JSONException {
    super(source, "annotation_id");
  }

  public AnnotationRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public AnnotationRecord(String recordID) {
    super(recordID);
  }

  public int getAnnotationID() {
    return getNumber("annotation_id").intValue();
  }

  public String getAnnotationGroupName() {
    return getString("annotation_group_name");
  }

  public String getAnnotationName() {
    return getString("annotation_name");
  }

  public int getDisplayOrder() {
    return getNumber("display_order").intValue();
  }

  public String getValue() {
    return getString("value");
  }
}
