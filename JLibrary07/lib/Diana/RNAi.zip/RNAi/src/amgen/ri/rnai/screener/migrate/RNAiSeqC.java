/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener.migrate;

import java.util.ArrayList;

/**
 *
 * @author jayanthi
 */
public class RNAiSeqC {
    
    private String seq = "";
    private ArrayList<Integer> rnai_seq_ids = new ArrayList();
    private String all_rnai_seq_ids_clause = "";
    private ArrayList<Integer> rnai_ids = new ArrayList() ;
    private String all_rnai_ids_clause = "";
    private int lowest_rnai_seq_id;

    public String getAll_rnai_ids_clause() {
        return all_rnai_ids_clause;
    }

    public void setAll_rnai_ids_clause(String all_rnai_ids_clause) {
        this.all_rnai_ids_clause = all_rnai_ids_clause;
    }

    public String getAll_rnai_seq_ids_clause() {
        return all_rnai_seq_ids_clause;
    }

    public void setAll_rnai_seq_ids_clause(String all_rnai_seq_ids_clause) {
        this.all_rnai_seq_ids_clause = all_rnai_seq_ids_clause;
    }

    public int getLowest_rnai_seq_id() {
        return lowest_rnai_seq_id;
    }

    public void setLowest_rnai_seq_id(int lowest_rnai_seq_id) {
        this.lowest_rnai_seq_id = lowest_rnai_seq_id;
    }

    public ArrayList<Integer> getRnai_ids() {
        return rnai_ids;
    }

    public void setRnai_ids(ArrayList<Integer> rnai_ids) {
        this.rnai_ids = rnai_ids;
    }

    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public ArrayList<Integer> getRnai_seq_ids() {
        return rnai_seq_ids;
    }

    public void setRnai_seq_ids(ArrayList<Integer> rnai_seq_ids) {
        this.rnai_seq_ids = rnai_seq_ids;
    }

    
    
    
    
}
