/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.cache;

import amgen.ri.util.Debug;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author jemcdowe
 */
public class CacheFilter {
  private static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

  enum ComparisonType {
    EQ, LT, GT;

    public static ComparisonType fromString(String s) {
      try {
        return ComparisonType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return ComparisonType.EQ;
      }
    }
  };

  enum DataType {
    STRING, DATE, NUMERIC, LIST;

    public static DataType fromString(String s) {
      try {
        return DataType.valueOf(s.toUpperCase());
      } catch (Exception e) {
        return DataType.STRING;
      }
    }
  };
  private String field;
  private DataType dataType;
  private ComparisonType comparisonType;
  private List<Object> values;

  public CacheFilter(String field, String dataType, String comparisonType, Object value) throws ParseException {
    this(field, dataType, comparisonType, Arrays.asList(new Object[]{value}));
  }

  public CacheFilter(String field, String dataType, String comparisonType, List<Object> values) throws ParseException {
    this.field = field;
    this.dataType = DataType.fromString(dataType);
    this.comparisonType = ComparisonType.fromString(comparisonType);
    this.values = new ArrayList<Object>();

    switch (this.dataType) {
      case LIST:
        for (Object value : values) {
          this.values.add(value.toString().toUpperCase());
        }
        break;
      case DATE:
        for (Object value : values) {
          if (value instanceof Date) {
            this.values.add((Date) value);
          } else {
            this.values.add(dateFormat.parse(value.toString()));
          }
        }
        break;
      case NUMERIC:
        for (Object value : values) {
          if (value instanceof Number) {
            this.values.add(((Number) value).doubleValue());
          } else {
            this.values.add(new Double(value.toString()));
          }
        }
        break;
      case STRING:
      default:
        for (Object value : values) {
          this.values.add(value.toString().toUpperCase());
        }
        break;
    }
  }

  public String getField() {
    return field;
  }

  public boolean match(Object testValue) {
    if (values.isEmpty() || testValue == null) {
      if (dataType.equals(DataType.LIST)) {
        return false;
      }
      return false;
    }
    switch (dataType) {
      case DATE:
        if (testValue instanceof Date) {
          return matchDate((Date) testValue);
        } else {
          try {
            return matchDate(dateFormat.parse(testValue.toString()));
          } catch (ParseException ex) {
            return true;
          }
        }
      case NUMERIC:
        if (testValue instanceof Number) {
          return matchNumeric(((Number) testValue).doubleValue());
        } else {
          return matchNumeric(new Double(testValue.toString()));
        }
      case LIST:
        String upperTestValue = testValue.toString().toUpperCase();
        for (Object value : values) {
          String v = value.toString();
          if (v.equals(upperTestValue)) {
            return true;
          }
        }
        return false;
      case STRING:
      default:
        return matchString(testValue.toString().toUpperCase());
    }
  }

  private boolean matchDate(Date testDate) {
    Date dateValue = (Date) values.get(0);

    switch (comparisonType) {
      case LT:
        return (testDate.compareTo(dateValue) < 0);
      case GT:
        return (testDate.compareTo(dateValue) > 0);
      case EQ:
      default:
        return (testDate.compareTo(dateValue) == 0);
    }
  }

  private boolean matchNumeric(Double testNumber) {
    Double dateValue = (Double) values.get(0);
    switch (comparisonType) {
      case LT:
        return (testNumber.compareTo(dateValue) < 0);
      case GT:
        return (testNumber.compareTo(dateValue) > 0);
      case EQ:
      default:
        return (testNumber.compareTo(dateValue) == 0);
    }
  }

  private boolean matchString(String testString) {
    String stringValue = (String) values.get(0);
    switch (comparisonType) {
      case LT:
        return (testString.compareTo(stringValue) < 0);
      case GT:
        return (testString.compareTo(stringValue) > 0);
      case EQ:
      default:
        for (Object value : values) {
          String v = value.toString();
          if (testString.startsWith(v)) {
            return true;
          }
        }
        return false;
    }
  }

  public String toString() {
    return field + " " + dataType + " " + comparisonType + " " + values.get(0);
  }
}
