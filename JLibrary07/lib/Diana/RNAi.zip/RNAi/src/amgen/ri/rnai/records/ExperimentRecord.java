/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.util.ExtString;
import amgen.ri.xml.ExtXMLElement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import org.jdom.Element;

/**
 *
 * @author jemcdowe
 */
public final class ExperimentRecord extends AbstractRecord {
  static final long serialVersionUID = -1896083375116319310L;

  public ExperimentRecord(JSONObject obj) throws JSONException {
    super(obj, "experiment_id");
    if (obj.has("analysis_id")) {
      setAnalysis_id(obj.getInt("analysis_id"));
    }
  }

  public ExperimentRecord(String recordID) {
    super(recordID);
  }

  public ExperimentRecord(ResultSet rset) throws SQLException {
    super(rset.getString("EXPERIMENT_ID"));
    setExperimentID(rset.getInt("EXPERIMENT_ID"));
    setCellLine(rset.getString("CELL_LINE"));
    setExperimentType(rset.getString("EXPERIMENT_TYPE"));
    setLibrary(rset.getString("LIBRARY"));
    setGeneCount(rset.getInt("GENE_COUNT"));
    setExperimentDate(rset.getTimestamp("EXPERIMENT_DATE"));
    setExperimentName(rset.getString("EXPERIMENT_NAME"));
    addAnalyses(rset.getString("ANALYSES"));
  }

  public JSONArray getAnalyses() {
    return getArray("analyses");
  }


  /**
   * Get the value of analysis_id
   *
   * @return the value of analysis_id
   */
  public int getAnalysis_id() {
    Number val= getNumber("analysis_id");
    return (val== null ? -1 : val.intValue());
  }

  /**
   * Set the value of analysis_id
   *
   * @param analysis_id new value of analysis_id
   */
  public void setAnalysis_id(int analysis_id) {
    add("analysis_id", analysis_id);
  }

  
  public void addAnalyses(String analysis) {
    if (analysis != null) {
      String[] analyses = analysis.split(";");
      for (String analysisName : analyses) {
        addToArray("analyses", analysisName);
      }
    }
  }

  public int getExperimentID() {
    return getNumber("experiment_id").intValue();
  }

  public void setExperimentID(int experimentID) {
    add("experiment_id", experimentID);
  }

  public void setExperimentName(String experimentName) {
    add("experiment_name", experimentName);
  }

  public String getExperimentName() {
    return getString("experiment_name");
  }

  public void setCellLine(String cellLine) {
    add("cell_line", cellLine);
  }

  public String getCellLine() {
    return getString("cell_line");
  }

  public void setExperimentType(String experimentType) {
    add("experiment_type", experimentType);
  }

  public String getExperimentType() {
    return getString("experiment_type");
  }

  public void setLibrary(String library) {
    add("library", library);
  }

  public String getLibrary() {
    return getString("library");
  }

  public void setGeneCount(int geneCount) {
    add("gene_count", geneCount);
  }

  public int getGeneCount() {
    return getNumber("gene_count").intValue();
  }

  public void setExperimentDate(Date experimentDate) {
    add("experiment_date", experimentDate);
  }

  public Date getExperimentDate() {
    return getDate("experiment_date");
  }

  public void setLastAnalyzed(Date lastAnalyzedDate) {
    add("last_analyzed", lastAnalyzedDate);
  }

  public Date getLastAnalyzed() {
    return getDate("last_analyzed");
  }

  public String getAnalyzedBy() {
    return getString("analyzed_by");
  }

  public String getAnalyzedByUsername() {
    return getString("analyzed_username");
  }

  public String getQCBy() {
    return getString("qc_by");
  }

  public String getStatus() {
    return getString("status");

  }

  public String getUploadedBy() {
    return getString("uploaded_by");
  }

  public String getUploadedByUsername() {
    return getString("uploaded_username");
  }

  public String getVisibility() {
    return getString("visibility");
  }

  /**
   * Returns is the value is a Date
   *
   * @param key
   * @return
   */
  public boolean isDate(String key) {
    return (ExtString.equals(key, "last_analyzed") || ExtString.equals(key, "experiment_date"));
  }

  @Override
  public Element asXML() {
    Element el = super.asXML();
    ExtXMLElement.addAttribute(el, "experiment_id", getExperimentID() + "");
    return el;
  }
}
