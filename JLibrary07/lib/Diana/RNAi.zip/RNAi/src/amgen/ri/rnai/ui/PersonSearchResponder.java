/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.ui;

import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author jemcdowe
 */
public class PersonSearchResponder extends AbstractResponder implements JSONResponderIF {
  public PersonSearchResponder(MainUI servletBase) {
    super(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    String query = getParameter("query");
    String username = getParameter("username");
    if (ExtString.hasLength(query)) {
      return createResponseJSON("persons", searchPersonRecords(query));
    } else if (ExtString.hasLength(username)) {
      return createResponseJSON("persons",  Arrays.asList(lookupPersonRecord(username)));
    }
    return null;
  }
}