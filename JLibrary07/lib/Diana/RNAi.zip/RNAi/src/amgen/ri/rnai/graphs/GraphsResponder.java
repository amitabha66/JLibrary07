/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.graphs;

import amgen.ri.json.JSONArray;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.rnai.util.AppServerReturnObject;
import amgen.ri.servlet.SessionLogin;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtImage;
import amgen.ri.util.ExtString;
import java.awt.Dimension;
import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.Iterator;
import java.util.*;

public class GraphsResponder extends AbstractResponder implements JSONResponderIF {
  enum Action {
    SURVIVAL,
    HISTOGRAMGENECOLLECTION,
    UNKNOWN;

    public static Action fromString(String s) {
      try {
        return Action.valueOf(s.toUpperCase().replaceAll("\\W+", "_"));
      } catch (Exception e) {
      }
      return UNKNOWN;
    }
  };
  private Action action;

  public GraphsResponder(MainUI servletBase) {
    super(servletBase);
    action = Action.fromString(getParameter("action"));
  }

  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    try {
      String userName = SessionLogin.getSessionLogin(this.getServletBase().getHttpServletRequest()).getUsername();
      switch (action) {
        case SURVIVAL:/*
           * ExperimentRecord experimentRecord =
           * getExperimentRecordFromParameter("experiment_id");
           * List<GeneRecord> targetGeneRecords =
           * getGeneRecordsFromParameter("gene_id");
           * List<GeneRecord> controlGeneRecords =
           * getGeneRecordsFromGeneSymbolParameter("control_gene_symbols");
           *
           * SurvivalPlot survivalPlot = new SurvivalPlot(getServletBase());
           * AppServerReturnObject asro = survivalPlot.process(experimentRecord,
           * targetGeneRecords, controlGeneRecords);
           * if (asro.isCallSucceed()) {
           * jResponse = (JSONObject) asro.getReturnObject();
           * } else {
           * jResponse.put("message", asro.getReturnObject());
           * }
           */
          break;
        case HISTOGRAMGENECOLLECTION:
          GeneRecord geneRecord = getGeneRecordFromParameter("gene_id");
          HistogramGeneCollection histogramGeneCollection = new HistogramGeneCollection(getServletBase());
          try {
            jResponse = histogramGeneCollection.process(geneRecord);
          } catch (RAnalysisFailureException re) {
            jResponse.put("message", re.getMessage());
          }
          break;
      }
      getLogger().debug(jResponse);
      return jResponse;
    } catch (Exception e) {
      e.printStackTrace();
      throw new IllegalArgumentException("Survival plot failed: " + e.getMessage());
    }
  }
}
