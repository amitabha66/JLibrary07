
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze.geneticinteraction;

import amgen.ri.rnai.analyze.geneticinteraction.GIExperiments;
import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.mail.SendMessage;
import amgen.ri.rnai.R.AbstractRAnalysis;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.apache.commons.io.FilenameUtils;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jayanthi
 */
public class GIAnalysisArchived extends AbstractRAnalysis {
  
  private MainUI servletBase;
  private PersonRecordIF requestor;
  private GIAnalysisDetails analysisDetails;
  private String serverPath = "";
  private URL webPath;
  private List<GIExperiments> giExperiments;
  private Set<ExperimentRecord> experimentRecords;

  public GIAnalysisArchived(MainUI servletBase) throws IOException {
    super(servletBase);
    this.servletBase = servletBase;
    this.requestor = servletBase.getPersonRecord();
    this.serverPath = servletBase.getSessionWorkDir().getAbsolutePath();
    this.webPath = new URL("http://ussf-papp-dweb1.amgen.com:9091/discovery/assays/data/repository/RNAi/gi");
    this.giExperiments = new ArrayList<GIExperiments>();
    this.experimentRecords = new LinkedHashSet<ExperimentRecord>();
  }
/*
  public JSONObject process(String all_experiment_id) throws RAnalysisFailureException {
    JSONObject jResponse = new JSONObject();

    List<Integer> experimentIDs = new ArrayList<Integer>();
    for (String expID : all_experiment_id.split(",")) {
      if (ExtString.isAInteger(expID)) {
        experimentIDs.add(new Integer(expID));
      }
    }
    experimentRecords.addAll(getExperiments(experimentIDs, servletBase.getPersonRecord()));
    if (experimentRecords.size() < 2) {
      throw new RAnalysisFailureException("Invalid experiments in analysis");
    }
    for (ExperimentRecord expRecord : experimentRecords) {
      expRecord.setExperimentName(expRecord.getExperimentName().replaceAll("[^a-zA-Z0-9]+", "_"));
    }
    analysisDetails = new GIAnalysisDetails(experimentRecords);
    analysisDetails.setStartTime(null);
    //String type = "POC";
    String type = "ZSCORE";
    try {
      analyze(jResponse, type);
    } catch (Exception ex) {
      Logger.getLogger(GIAnalysisArchived.class.getName()).log(Level.SEVERE, null, ex);
      throw new RAnalysisFailureException("Unable to analyze experiments", ex);
    }
    analysisDetails.setEndTime(null);
    return jResponse;
  }

  public List<GIExperiments> getGIExperiments() {
    return giExperiments;
  }

  public GIAnalysisDetails getGIAnalysisDetails() {
    return analysisDetails;
  }

  private List<GIExperiments> analyze(JSONObject jResponse, String type) throws IOException, SQLException, JSONException, RAnalysisFailureException {
    File parentFolderFile = new File(this.serverPath, "zips");
    parentFolderFile.mkdirs();
    File zipOutServerPath = new File(parentFolderFile, requestor.getUsername() + "_" + System.currentTimeMillis() + ".zip");
    URL zipOutWebPath = new URL(this.webPath + "/zips/" + requestor.getUsername() + "_" + System.currentTimeMillis() + ".zip");

    ZipOutputStream zip = new ZipOutputStream(new FileOutputStream(zipOutServerPath));
    TreeSet<ExperimentRecord> experimentsRecordTree = new TreeSet<ExperimentRecord>(experimentRecords);


    for (ExperimentRecord experimentRecordA : experimentsRecordTree) {
      for (ExperimentRecord experimentRecordB : experimentsRecordTree.tailSet(experimentRecordA, false)) {
        String comb_key = experimentRecordA.getExperimentID() + "_" + experimentRecordB.getExperimentID();

        String result_name = "EID_" + experimentRecordA.getExperimentID() + "EName_" + experimentRecordA.getExperimentName() + "__VS__"
                + "EID_" + experimentRecordB.getExperimentID() + "EName_" + experimentRecordB.getExperimentName();

        GIExperiments gie = new GIExperiments(experimentRecordA, experimentRecordB, type);
        giExperiments.add(gie);
        gie.setDataFile(new File(this.serverPath, "E" + comb_key + "_D_" + type + ".txt"));
        gie.setScriptFile(new File(this.serverPath, "E" + comb_key + "_R_" + type + ".sh"));
        gie.setResultFile(new File(this.serverPath, "E" + comb_key + "_GI_" + type + ".txt"));
        gie.setWebResultURL(webPath);
        saveDataValues(gie, type);

        if (!gie.getResults().isEmpty()) {
          String rArguments =
                  FilenameUtils.separatorsToUnix(gie.getDataFile().getAbsolutePath()) + " "
                  + FilenameUtils.separatorsToUnix(gie.getResultFile().getAbsolutePath()) + " "
                  + gie.getExperimentA().getExperimentName() + " "
                  + gie.getExperimentB().getExperimentName();
          runRCommand(rArguments);

          gie.setResultsFromResultFile();
          analysisDetails.addGIExperimentResults(gie);

          ByteArrayInputStream fin = new ByteArrayInputStream(gie.getRawResults());
          zip.putNextEntry(new ZipEntry(result_name + ".txt"));
          int length;
          byte[] buffer = new byte[1024];
          while ((length = fin.read(buffer)) > 0) {
            zip.write(buffer, 0, length);
          }

          zip.closeEntry();
          fin.close();
          giExperiments.add(gie);

          JSONObject jCollection = new JSONObject();
          jCollection.put("value", zipOutWebPath);
          jCollection.put("label", result_name);
          jResponse.append("gi_results", jCollection);
        }
      }
    }
    zip.close();
    sendEmail("Genetic Interaction Analysis Results", "Download Results from: " + zipOutWebPath);
    return giExperiments;
  }

  private void saveDataValues(GIExperiments gie, String type) throws SQLException, IOException {
    Set<Integer> geneIDs = new HashSet<Integer>();

    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      sqlSession.getMapper(Mapper.class).getGeneticInteractionResults(gie);
      String results = gie.getGiInputResults();
      results = "value_a\tvalue_b\tgene_symbol\tgene_id\trnai_id\n" + results;
      ExtFile.writeTextFile(gie.getDataFile(), results);
      for (String line : results.split("[\\r\\n]+")) {
        String[] fields = line.split("\\t+");
        if (fields.length == 5 && ExtString.isAInteger(fields[3])) {
          geneIDs.add(new Integer(fields[3]));
        }
      }
      gie.setGeneRecords(getGenes(geneIDs, servletBase.getPersonRecord()));
    } finally {
      close(sqlSession);
    }
  }

  private void sendEmail(String subject_str, String message) {
    try {
      String from = "global-rg-comm@amgen.com";
      String subject = subject_str + "";
      String to[] = {
        (servletBase == null ? "jayanthi@amgen.com" : servletBase.getPersonRecord().getEmail())
      };
      SendMessage send = new SendMessage();
      send.sendMessage(to, from, subject, message);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
*/
  @Override
  public String getRCodeFileName() {
    return "Genetic_Interaction_algorithm_v2.R";
  }
}
