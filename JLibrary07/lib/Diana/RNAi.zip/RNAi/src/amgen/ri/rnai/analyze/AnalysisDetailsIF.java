/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.analyze;

import amgen.ri.rnai.records.ExperimentRecord;
import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Properties;

/**
 *
 * @author jemcdowe
 */
public interface AnalysisDetailsIF {

  String getAnalysisName();
  String getAnalysisType();

  Properties getAnalysisProperties();

  boolean hasFinished();

  File getAnalysisLog();

  Date getEndTime();

  Date getStartTime();

  String getKey();

  boolean isValid();

  List<ExperimentRecord> getExperimentRecords();

  String getElapsedTime();
  
}
