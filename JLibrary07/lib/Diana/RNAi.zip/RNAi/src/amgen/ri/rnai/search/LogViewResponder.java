/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONObject;
import amgen.ri.rnai.dao.Mapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.OperationLogRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import java.util.List;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jemcdowe
 */
public class LogViewResponder extends AbstractResponder implements JSONResponderIF {
  enum Request {
    EXPERIMENT_LOGS, LOG_CONTENTS;

    public static Request toRequest(String s) {
      try {
        return Request.valueOf(s.toUpperCase());
      } catch (Exception e) {
      }
      return EXPERIMENT_LOGS;
    }

    public static Request toRequest(AbstractResponder responder) {
      try {
        return Request.toRequest(responder.getServletBase().getParameter("rx"));
      } catch (Exception e) {
      }
      return EXPERIMENT_LOGS;
    }
  };

  public LogViewResponder(MainUI servletBase) {
    super(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    SqlSession rnaiSession = null;
    try {
      int logID = getParameterInteger("log_id", -1);
      rnaiSession = getSqlSessionFactory("rnai").openSession();
      switch (Request.toRequest(this)) {
        case EXPERIMENT_LOGS:
          List<ExperimentRecord> expRecords = getExperimentRecordsFromParameter("experiment_id");
          if (!expRecords.isEmpty()) {
            try {
              Mapper rnaiMapper = rnaiSession.getMapper(Mapper.class);
              for (ExperimentRecord expRecord : expRecords) {
                List<OperationLogRecord> expOpLogs = rnaiMapper.getExperimentOperationLogs(expRecord.getExperimentID());
                if (!expOpLogs.isEmpty()) {
                  JSONObject jNode = new JSONObject();
                  jResponse.append("nodes", jNode);
                  jNode.put("id", "exp." + expRecord.getExperimentID());
                  jNode.put("text", expRecord.getExperimentName());
                  jNode.put("expanded", (expRecords.size()== 1));
                  for (OperationLogRecord expOpLog : expOpLogs) {
                    jNode.append("children", expOpLog.asNode());
                  }
                }
              }

            } catch (Exception e) {
              e.printStackTrace();
            }
          }
          break;
        case LOG_CONTENTS:
          if (logID > 0) {
            try {
              Mapper rnaiMapper = rnaiSession.getMapper(Mapper.class);
              OperationLogRecord opLog = rnaiMapper.getOperationLog(logID);
              jResponse.append("logs", opLog);
            } catch (Exception e) {
              e.printStackTrace();
            }
          }
          break;
      }
    } catch (Throwable t) {
      t.printStackTrace();
    } finally {
      close(rnaiSession);
    }
    return jResponse;
  }
}
