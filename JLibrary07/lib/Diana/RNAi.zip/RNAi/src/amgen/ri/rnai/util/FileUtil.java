package amgen.ri.rnai.util;

import java.io.InputStream;
import java.io.BufferedOutputStream;
import java.io.FileWriter;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.OutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.*;
import java.io.*;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipEntry;
import org.apache.commons.io.IOUtils;
import java.util.zip.ZipInputStream;

public class FileUtil {
	public FileUtil() {
	}

	public static void unZipFiles(String filename, String destinationname) {
		try {

			byte[] buf = new byte[1024];
			ZipInputStream zipinputstream = null;
			ZipEntry zipentry;
			zipinputstream = new ZipInputStream(new FileInputStream(filename));

			zipentry = zipinputstream.getNextEntry();
			while (zipentry != null) {
				// for each entry to be extracted
				String entryName = zipentry.getName();
				System.out.println("entryname " + entryName);
				int n;
				FileOutputStream fileoutputstream;
				File newFile = new File(entryName);
				String directory = newFile.getParent();
				if (directory == null) {
					if (newFile.isDirectory()) {
						break;
					}
				}

				fileoutputstream = new FileOutputStream(destinationname + entryName);
				while ((n = zipinputstream.read(buf, 0, 1024)) > -1) {
					fileoutputstream.write(buf, 0, n);
				}

				fileoutputstream.close();
				zipinputstream.closeEntry();
				zipentry = zipinputstream.getNextEntry();

			} // while

			zipinputstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void addFolderToZip(File folder, ZipOutputStream zip, String baseName) throws IOException {
		File[] files = folder.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				addFolderToZip(file, zip, baseName);
			} else {
				String name = file.getAbsolutePath().substring(baseName.length());
				ZipEntry zipEntry = new ZipEntry(name);
				zip.putNextEntry(zipEntry);
				IOUtils.copy(new FileInputStream(file), zip);
				zip.closeEntry();
			}
		}
	}

	public static boolean deleteDir(File dir) {
		if (dir.isDirectory()) {
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++) {
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success) {
					return false;
				}
			}
		}

		// The directory is now empty so delete it
		return dir.delete();
	}

	public static boolean moveFiles(File destDir, File srcDir, String pattern) {
		if (srcDir.isDirectory()) {
			File[] children = srcDir.listFiles();
			for (int i = 0; i < children.length; i++) {
				boolean success = moveFiles(destDir, children[i], pattern);
				if (!success) {
					return false;
				}
			}
		} else {
			if (srcDir.getName().indexOf(pattern)>=0) {
				System.out.println("Moving: " + srcDir.getName());
				return srcDir.renameTo(new File(destDir, srcDir.getName()));
			} else {
				System.out.println("Not Moving: " + srcDir.getName());
				return true;
			}
		}
		return true;
	}

	public static AppServerReturnObject compressFiles(String inDir, String outFilename) {
		AppServerReturnObject asro = new AppServerReturnObject("Failed compressFiles", false, null);
		// These are the files to include in the ZIP file
		File cwd = new File(inDir);
		File[] inputs = cwd.listFiles();

		// Create a buffer for reading the files
		byte[] buf = new byte[1024];

		try {
			// Create the ZIP file
			// String outFilename = "outfile.zip";
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));

			// Compress the files
			for (int i = 0; i < inputs.length; i++) {
				FileInputStream in = new FileInputStream(inputs[i]);

				// Add ZIP entry to output stream.
				out.putNextEntry(new ZipEntry(inputs[i].getName()));

				// Transfer bytes from the file to the ZIP file
				int len;
				while ((len = in.read(buf)) > 0) {
					out.write(buf, 0, len);
				}

				// Complete the entry
				out.closeEntry();
				in.close();
			}

			// Complete the ZIP file
			out.close();
			asro.setCallSucceed(true);
		} catch (IOException e) {
		}
		return asro;
	}

	public static void appendStringFrom(String filePath, String removeLine, String content, String prefix, String suffix) {
		try {
			File file = new File(filePath);
			RandomAccessFile raf = new RandomAccessFile(file, "rw");
			if (raf.length() == 0) {
				raf.writeBytes(prefix + "\n" + content + "\n" + suffix);
				raf.close();
				return;
			}
			long current = raf.length() - 100;
			raf.seek(current);
			String line = null;
			while ((line = raf.readLine()) != null) {
				long tempcur = current;
				current = current + line.length() + 1;
				if (line.equalsIgnoreCase(removeLine)) {
					raf.seek(tempcur);
					raf.writeBytes(content + "\n" + removeLine);
				}
			}
			raf.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void removeLineFromFile(String file, String lineToRemove) {
		try {
			File inFile = new File(file);
			if (!inFile.isFile()) {
				System.out.println("Parameter is not an existing file");
				return;
			}

			// Construct the new file that will later be renamed to the original
			// filename.
			File tempFile = new File(inFile.getAbsolutePath() + ".tmp");
			BufferedReader br = new BufferedReader(new FileReader(file));
			PrintWriter pw = new PrintWriter(new FileWriter(tempFile));
			String line = null;
			// Read from the original file and write to the new
			// unless content matches data to be removed.
			while ((line = br.readLine()) != null) {
				if (!line.trim().equals(lineToRemove)) {
					pw.println(line);
					pw.flush();
				}
			}

			pw.close();
			br.close();
			// Delete the original file
			if (!inFile.delete()) {
				System.out.println("Could not delete file");
				return;
			}
			// Rename the new file to the filename the original file had.
			if (!tempFile.renameTo(inFile)) {
				System.out.println("Could not rename file");
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} catch (IOException ex) {
			ex.printStackTrace();
		}
	}

	public static String readInputFromFile(String fromFile) {
		try {
			String items = "";
			BufferedReader br = new BufferedReader(new FileReader(fromFile));
			String line = null;
			while ((line = br.readLine()) != null) {
				items = items + line + "\n";
			}
			return items;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String readInputFromFileMakeInClause(String fromFile, String type) {
		try {
			String whereClause = "";
			BufferedReader br = new BufferedReader(new FileReader(fromFile));
			String line = null;
			while ((line = br.readLine()) != null) {
				String key = line;
				if (type.equalsIgnoreCase("string")) {
					whereClause = whereClause + "'" + key.trim() + "', ";
				} else if (type.equalsIgnoreCase("number")) {
					whereClause = whereClause + key + ", ";
				}
			}
			if (whereClause.length() > 0) {
				whereClause = whereClause.substring(0, whereClause.lastIndexOf(","));
			}

			return whereClause;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static ArrayList readInputFromFile(String fromFile, boolean makeArrayList) {
		try {
			ArrayList items = new ArrayList();
			BufferedReader br = new BufferedReader(new FileReader(fromFile));
			String line = null;
			while ((line = br.readLine()) != null) {
				if (!items.contains(line)) {
					items.add(line);
				}
			}
			return items;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	/*
	 * public static String readFileAsString(String filePath) throws
	 * java.io.IOException { StringBuffer fileData = new StringBuffer(1000);
	 * BufferedReader reader = new BufferedReader( new FileReader(filePath));
	 * char[] buf = new char[1024]; int numRead = 0; while ( (numRead =
	 * reader.read(buf)) != -1) { fileData.append(buf, 0, numRead); }
	 * reader.close();
	 * 
	 * //String ss = new String(fileData.ba, "UTF-8"); String ss = new
	 * String(fileData.toString().getBytes(), "UTF-8"); //return
	 * fileData.toString().ge; return ss; }
	 */

	public static String readFileAsString(String input) throws IOException {
		return readFileAsString(input, "UTF-8");
	}

	public static String readFileAsString(String input, String charset) throws IOException {
		Reader reader = null;
		StringWriter writer = new StringWriter();
		try {
			reader = new BufferedReader(new InputStreamReader(new FileInputStream(input), charset));
			final int BUFSIZ = 1024;
			char buf[] = new char[BUFSIZ];
			int len = 0;
			while ((len = reader.read(buf)) > 0) {
				writer.write(buf, 0, len);
			}
		} finally {
			if (reader != null) {
				reader.close();
			}
			if (writer != null) {
				writer.close();
			}
		}
		return writer.toString();
	}

	public static void writeHashMap(HashMap map, String toFile, String title) {
		try {

			PrintStream ps = new PrintStream(new FileOutputStream(toFile));
			if (title != null) {
				ps.println(title);
			}
			for (Object key : map.keySet()) {
				ps.println((String) key + "\t" + (String) map.get(key));
				ps.flush();
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeHashMap(HashMap map, String toFile) {
		try {
			writeHashMap(map, toFile, null);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeStringArray(String[] items, String toFile) {
		try {
			PrintStream ps = new PrintStream(new FileOutputStream(toFile));
			for (String s : items) {
				ps.println(s);
				ps.flush();
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeStringArrayList(ArrayList items, String toFile) {
		writeStringArrayList(items, toFile, false);
	}

	public static void writeStringArrayList(ArrayList items, String toFile, boolean append) {
		try {
			PrintStream ps = new PrintStream(new FileOutputStream(toFile, append));
			for (int i = 0; i < items.size(); i++) {
				String line = items.get(i).toString();
				// System.out.println(line);
				ps.println(line);
				ps.flush();
			}
			ps.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Properties loadPropertiesFile(String filePath) throws Exception {
		Properties properties = new Properties();
		properties.load(new FileInputStream(filePath));
		return properties;

	}

	public static Properties writePropertiesFile(String filePath, Properties properties) throws Exception {
		if (properties != null) {
			FileOutputStream fos = new FileOutputStream(filePath);
			properties.store(fos, null);
			fos.close();
		}
		return properties;

	}

	public static void writeStringFile(String ss, String toFile, boolean append) {
		try {
			File outFile = new File(toFile);
			// FileWriter out = new FileWriter(outFile, append);
			OutputStreamWriter out = new OutputStreamWriter(new FileOutputStream(outFile), "UTF-8");
			out.write(ss);
			out.flush();
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeStringFile(String ss, String toFile) {
		try {
			writeStringFile(ss, toFile, false);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeByteArrayFile(byte[] ba, String toFile) {
		try {
			File outFile = new File(toFile);
			FileWriter out = new FileWriter(outFile);
			String ss = new String(ba, "UTF-8");
			String ss_replaced = ss.replace('µ', 'u');
			out.write(ss_replaced);
			out.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void writeURLtoFile(String urlstring, String toFile) {
		try {
			URL url = new URL(urlstring);
			BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));

			String inputLine;
			PrintStream ps1 = new PrintStream(new FileOutputStream(toFile));

			while ((inputLine = in.readLine()) != null) {
				ps1.print(inputLine);
				ps1.flush();
			}
			ps1.close();
			in.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static byte[] loadBytesFromURL(String urlstring) throws IOException {
		URL url = new URL(urlstring);
		return loadBytesFromURL(url);
	}

	public static byte[] loadBytesFromURL(URL url) throws IOException {
		byte[] b = null;
		URLConnection con = url.openConnection();
		int size = con.getContentLength();
		InputStream in = null;

		try {
			if ((in = con.getInputStream()) != null) {
				b = (size != -1) ? loadBytesFromStreamForSize(in, size) : loadBytesFromStream(in);
			}
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException ioe) {
				}
			}
		}
		return b;
	}

	public static byte[] loadBytesFromStreamForSize(InputStream in, int size) throws IOException {
		int count, index = 0;
		byte[] b = new byte[size];

		// read in the bytes from input stream
		while ((count = in.read(b, index, size)) > 0) {
			size -= count;
			index += count;
		}
		return b;
	}

	public static byte[] loadBytesFromStream(InputStream in) throws IOException {
		return loadBytesFromStream(in, 256);
	}

	public static byte[] loadBytesFromStream(InputStream in, int chunkSize) throws IOException {
		if (chunkSize < 1) {
			chunkSize = 256;
		}

		int count;
		ByteArrayOutputStream bo = new ByteArrayOutputStream();
		byte[] b = new byte[chunkSize];
		try {
			while ((count = in.read(b, 0, chunkSize)) > 0) {
				bo.write(b, 0, count);
			}
			byte[] thebytes = bo.toByteArray();
			return thebytes;
		} finally {
			bo.close();
			bo = null;
		}
	}

	/*
        public static byte[] getBytesFromObject(Object o) throws IOException {
		if (o == null) {
			return "".getBytes();
		}
		FastByteArrayOutputStream bos = new FastByteArrayOutputStream();
		ObjectOutputStream out = new ObjectOutputStream(bos);
		out.writeObject(o);
		out.close();
		return bos.getByteArray();

	}*/

	public static byte[] getBytesFromFile(File file) throws IOException {
		InputStream is = new FileInputStream(file);

		// Get the size of the file
		long length = file.length();

		if (length > Integer.MAX_VALUE) {
			// File is too large
		}

		// Create the byte array to hold the data
		byte[] bytes = new byte[(int) length];

		// Read in the bytes
		int offset = 0;
		int numRead = 0;
		while (offset < bytes.length && (numRead = is.read(bytes, offset, bytes.length - offset)) >= 0) {
			offset += numRead;
		}

		// Ensure all the bytes have been read in
		if (offset < bytes.length) {
			throw new IOException("Could not completely read file " + file.getName());
		}

		// Close the input stream and return bytes
		is.close();
		return bytes;
	}

	public static AppServerReturnObject fileCopy(String fromFile, String toFile) {
		AppServerReturnObject asro = new AppServerReturnObject("File copy failed", false, null);
		try {
			File inputFile = new File(fromFile);
			File outputFile = new File(toFile);

			FileReader in = new FileReader(inputFile);
			FileWriter out = new FileWriter(outputFile);
			int c;

			while ((c = in.read()) != -1) {
				out.write(c);
			}

			in.close();
			out.close();
			asro.setCallSucceed(true);
			return asro;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return asro;
	}

	public static AppServerReturnObject fileCopy(File inputFile, File outputFile) {
		AppServerReturnObject asro = new AppServerReturnObject("File copy failed", false, null);
		try {

			FileReader in = new FileReader(inputFile);
			FileWriter out = new FileWriter(outputFile);
			int c;

			while ((c = in.read()) != -1) {
				out.write(c);
			}

			in.close();
			out.close();
			asro.setCallSucceed(true);
			return asro;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return asro;
	}

	public static AppServerReturnObject fileBinCopy(String fromFile, String toFile) {
		AppServerReturnObject asro = new AppServerReturnObject("File copy failed", false, null);
		try {
			File inputFile = new File(fromFile);
			File outputFile = new File(toFile);

			InputStream in = new BufferedInputStream(new FileInputStream(fromFile));
			OutputStream out = new BufferedOutputStream(new FileOutputStream(toFile));

			int bufLen = 20000 * 1024;
			byte[] buf = new byte[bufLen];
			byte[] tmp = null;
			int len = 0;

			while ((len = in.read(buf, 0, bufLen)) != -1) {
				out.write(buf, 0, len);
			}

			in.close();
			out.close();
			asro.setCallSucceed(true);
			return asro;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return asro;
	}

	public static void removePatternFromFile(String path, String pattern) {
		try {
			Vector v = new Vector();
			BufferedReader br = new BufferedReader(new FileReader(path));
			String line = null;
			while ((line = br.readLine()) != null && !line.startsWith(pattern)) {
				v.addElement(line);
			}
			FileOutputStream fos = new FileOutputStream(path);
			PrintStream ps = new PrintStream(fos);
			for (int i = 0; i < v.size(); i++) {
				ps.print((String) v.elementAt(i));
				ps.flush();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void movePVFolder(String path, String folder) {
		String cur_pvc_path = path + File.separator + folder;
		java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMddyyyy");
		String val = "DayCache_" + sdf.format(new java.util.Date(System.currentTimeMillis()));

		String pvc_t_path = path + File.separator + "TEMP";
		File pvc_t = new File(pvc_t_path);
		if (!pvc_t.exists()) {
			pvc_t.mkdirs();
		}

		String cur_pvc_t_path = pvc_t_path + File.separator + folder;

		File cur_pvc = new File(cur_pvc_path);
		if (cur_pvc.exists()) {
			cur_pvc.renameTo(new File(cur_pvc_t_path));
		}

		File new_pvc_path = new File(cur_pvc_path);
		new_pvc_path.mkdirs();

		File cur_pvc_t = new File(cur_pvc_t_path);
		cur_pvc_t.renameTo(new File(cur_pvc_path + File.separator + val));

	}

	public static void main(String[] args) throws Exception {
		testmoveFiles();
		// testloadfromURL();
		// testZip();
		// testUnZip();
		// testPVFolderMove();

	}

	public static void testmoveFiles() {
		try {
			String srcDir = "\\\\ussf-marin\\ASF_Data_App_Discovery\\assays\\data\\repository\\RG\\moveTest\\srcDir";
			String destDir = "\\\\ussf-marin\\ASF_Data_App_Discovery\\assays\\data\\repository\\RG\\moveTest\\destDir";
			String pattern = "pat";
			FileUtil.moveFiles(new File(destDir), new File(srcDir), pattern);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void testPVFolderMove() {
		try {
			String path = "E:\\repository\\RG\\ProjectViewV2Prod";
			String folder = "5402480_T";
			FileUtil.movePVFolder(path, folder);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void testloadfromURL() {
		try {
			// FileUtil.writeURLtoFile("http://www.ncbi.nlm.nih.gov/entrez/viewer.fcgi?db=[nucleotide%20|%20protein]&dopt=gbc&sendto=t&list_uids=NM_000075",
			// "c://ncbiresult.xml");
			// FileUtil.writeURLtoFile("http://www.yahoo.com",
			// "c://ncbiresult.xml");
			// byte[] b =
			// FileUtil.loadBytesFromURL("http://www.ncbi.nlm.nih.gov/entrez/viewer.fcgi?db=[nucleotide%20|%20protein]&dopt=gbc&sendto=t&list_uids=NM_000075");

			byte[] b = FileUtil.loadBytesFromURL("http://raagam.net/P/Poovellam%20Un%20Vaasam/Tamilmp3world.Com%20-%20Kadhal%20Vandhadhum.mp3");
			if (b == null) {
				System.out.println("b is null");
			} else {
				// System.out.println(b.toString());
				FileUtil.writeByteArrayFile(b, "H://testcase//soa//kadhalvanthatum.mp3");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public static void testZip() {
		try {
			// name of zip file to create
			String outFilename = "E:\\repository\\CAST\\automation_data_analysis\\reviews\\jayanthi-1270507879424.zip";
			// create ZipOutputStream object
			ZipOutputStream out = new ZipOutputStream(new FileOutputStream(outFilename));
			// path to the folder to be zipped
			File zipFolder = new File("E:\\repository\\CAST\\automation_data_analysis\\jayanthi-1270507879424");
			// get path prefix so that the zip file does not contain the whole
			// path
			// eg. if folder to be zipped is /home/lalit/test
			// the zip file when opened will have test folder and not
			// home/lalit/test folder
			int len = zipFolder.getAbsolutePath().lastIndexOf(File.separator);
			String baseName = zipFolder.getAbsolutePath().substring(0, len + 1);
			addFolderToZip(zipFolder, out, baseName);

			out.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	public static void testUnZip() {
		try {

			String zipFile = "E:\\repository\\RG\\fileupload\\cast\\bioassay_raw.zip";
			String outFolder = "E:\\repository\\RG\\fileupload\\cast\\input\\";
			FileUtil.unZipFiles(zipFile, outFolder);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
