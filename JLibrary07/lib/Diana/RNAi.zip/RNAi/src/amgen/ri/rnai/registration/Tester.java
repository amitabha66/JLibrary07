/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.registration;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

/**
 *
 * @author jemcdowe
 */
public class Tester {
  public static void main(String[] args) throws Exception {

    HttpClient httpclient = new DefaultHttpClient();
    HttpPost httppost = new HttpPost("http://ussf239481.am.corp.amgen.com:8080/RNAi//blastrefseq.go");
    //HttpPost httppost = new HttpPost("http://uswa-papp-rgb01.amgen.com:8081/RNAi/blastrefseq.go");

    // Add your data
    List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>(2);
    nameValuePairs.add(new BasicNameValuePair("in", "852645:GCCUAUUACACAUACAUCUTT"));
    nameValuePairs.add(new BasicNameValuePair("species", "Human"));
    httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

    // Execute HTTP Post Request
    HttpResponse response = httpclient.execute(httppost);
    HttpEntity entity = response.getEntity();
    if (response.getStatusLine().getStatusCode() == 200) {
      System.out.println(EntityUtils.toString(entity));
    } else {
      Header errorMsgHeader = response.getFirstHeader("ERROR_MSG");
      if (errorMsgHeader != null) {
        System.out.println(errorMsgHeader.getValue());
      }
    }
  }
}
