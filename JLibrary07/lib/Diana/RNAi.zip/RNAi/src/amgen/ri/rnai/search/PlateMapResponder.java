/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.search;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.ldap.PersonRecordIF;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.jproc.RNAiSearchInputType;
import amgen.ri.rnai.jproc.RNAiSearchOutputType;
import amgen.ri.rnai.records.AbstractRecord;
import amgen.ri.rnai.records.CollectionRecord;
import amgen.ri.rnai.records.PlateInfo;
import amgen.ri.rnai.records.RNAiRecord;
import amgen.ri.rnai.ui.AbstractResponder;
import amgen.ri.rnai.ui.JSONResponderIF;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import java.io.FileWriter;
import java.io.IOException;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;
import java.util.logging.Level;
import javax.xml.rpc.ServiceException;
import org.apache.log4j.Logger;

/**
 *
 * @author jemcdowe
 */
public class PlateMapResponder extends AbstractResponder implements JSONResponderIF {
  enum ClientRequest {
    PLATE_LAYER, RNAI_WELLS, WELL_DETAILS, FIND;

    public static ClientRequest fromRequest(MainUI request) {
      try {
        return ClientRequest.valueOf(request.getParameter("rx").toUpperCase());
      } catch (Exception e) {
        return PLATE_LAYER;
      }
    }
  };
  private ClientRequest clientRequest;

  enum LayerTypes {
    COMPOUND_ID, VENDOR, VENDOR_ID, ENTREZGENE_ID, GENE_SYMBOL, UNKNOWN;

    public static LayerTypes fromString(String s) {
      try {
        return LayerTypes.valueOf(s.replaceAll("\\s+", "_").toUpperCase());
      } catch (Exception e) {
        return UNKNOWN;
      }
    }

    public static String toLabel(LayerTypes type) {
      return ExtString.toTitleCase(type.toString().replace('_', ' ')).replaceFirst("Id", "ID");
    }
  };

  public PlateMapResponder(MainUI servletBase) {
    super(servletBase);
    //servletBase.printRequest();
    clientRequest = ClientRequest.fromRequest(servletBase);
  }

  @Override
  public JSONObject getResponse() {
    JSONObject jResponse = new JSONObject();
    PlateInfo plateInfo = null;
    String barcode = getParameter("barcode");
    if (ExtString.hasLength(barcode)) {
      List<? extends AbstractRecord> plateInfos = new PlateMapSearch(this, Arrays.asList(barcode)).asList();
      if (plateInfos.size() > 0) {
        plateInfo = (PlateInfo) plateInfos.get(0);
      }
    }
    Connection rnaiConnection = null;
    try {
      rnaiConnection = getRNAiConnection();
      switch (clientRequest) {
        default:
          //jResponse = getPlateLayer(barcode, LayerTypes.fromString(getServletBase().getParameter("layer")), rnaiConnection);            
          jResponse.append("plates", plateInfo);
          for (LayerTypes layerType : LayerTypes.values()) {
            if (!layerType.equals(LayerTypes.UNKNOWN)) {
              JSONObject jLayerType = new JSONObject();
              jResponse.append("LayerTypes", jLayerType);
              jLayerType.put("label", LayerTypes.toLabel(layerType));
              jLayerType.put("type", layerType.toString().toLowerCase());
            }
          }
          List<JSONObject> jWells = plateInfo.getWells();
          Map<String, JSONObject> wellMap = new HashMap<String, JSONObject>();
          for (JSONObject jWell : jWells) {
            int wellrow = jWell.optInt("wellrow", -1);
            int wellcol = jWell.optInt("wellcol", -1);
            if (wellcol > 0 && wellrow > 0) {
              jWell.put("compound_id", jWell.getInt("root_number")+"#"+jWell.getInt("lot_number"));
              wellMap.put(wellrow + ":" + wellcol, jWell);
            }
          }         
          
          JSONObject jEmptyWell= new JSONObject();
          jEmptyWell.put("entrezgene_id", "");
          jEmptyWell.put("gene_symbol", "");
          jEmptyWell.put("compound_id", "");
          jEmptyWell.put("vendor", "");
          jEmptyWell.put("vendor_id", "");          
          
          for (int row = 1; row <= plateInfo.getRows(); row++) {
            JSONObject jRow = new JSONObject();
            jResponse.append("Rows", jRow);
            for (int col = 0; col <= plateInfo.getCols(); col++) {
              String wellKey = row + ":" + col;
              if (wellMap.containsKey(wellKey)) {
                jRow.put(col+"", wellMap.get(wellKey));
              } else {
                jRow.put(col+"", jEmptyWell);                
              }
            }
          }
          break;
        case WELL_DETAILS:
          //jResponse = getWellDetails(barcode, rnaiConnection);
          break;
        case RNAI_WELLS:/*
           * if (getParameter("barcode") != null) {
           * PlateMapIF plate = null;
           * List<String> compoundIDs = new ArrayList<String>();
           * //Get compound IDs from a plate
           * plate =
           * getPlate(getParameter("barcode")).getPlateMap(rnaiConnection);
           * int rowCount = plate.getPlateMap().getNumRows();
           * int colCount = plate.getPlateMap().getNumCols();
           * for (int r = 1; r <= rowCount; r++) {
           * String row = "" + (char) ('A' + r - 1);
           * for (int c = 1; c <= colCount; c++) {
           * ExtPlateWellContents extPlateWellContents =
           * plate.getExtContentMap().get(row + c);
           * if (extPlateWellContents != null) {
           * String compoundID = extPlateWellContents.getCompoundID();
           * compoundIDs.add(compoundID);
           * }
           * }
           * }
           * if (compoundIDs.isEmpty()) {
           * break;
           * }
           * RNAiSearch rnaiSearch = new RNAiSearch(null, compoundIDs, null,
           * null, RNAiSearchOutputType.RNAI, new
           * SessionCache(getServletBase()),
           * getServletBase().getPersonRecord());
           * List<AbstractRecord> rnaiRecords = rnaiSearch.asList();
           * for (AbstractRecord rnaiRecord : rnaiRecords) {
           * ((RNAiRecord) rnaiRecord).setPlateWells(plate);
           * }
           * jResponse.put("wells", rnaiRecords);
           * }
           */
          break;
        case FIND:
        /*
         * verifyParameter(new String[]{"query"});
         * barcode = getParameter("query");
         * JSONObject jLayer = new JSONObject();
         * PlateMapIF plate = getPlate(barcode).getPlateMap(rnaiConnection);
         *
         * int rowCount = plate.getPlateMap().getNumRows();
         * int colCount = plate.getPlateMap().getNumCols();
         *
         * jLayer.put("barcode", barcode);
         * jLayer.put("density", rowCount * colCount);
         * jLayer.put("rows", rowCount);
         * jLayer.put("cols", colCount);
         *
         * jResponse.append("plates", jLayer);
         * break;
         *
         */
      }
    } catch (Exception e) {
      Logger.getLogger("rnai").debug(e.getMessage(), e);
    } finally {
      closeResources(rnaiConnection);
    }
    return jResponse;
  }
  /*
   * public JSONObject getPlateLayer(String barcode, LayerTypes layer,
   * Connection rnaiConnection) throws JSONException, RemoteException,
   * ServiceException, SQLException, IOException {
   * JSONObject jLayer = new JSONObject();
   * Plate plate = getPlate(barcode);
   * PlateMapIF plateMap = plate.getPlateMap(rnaiConnection);
   *
   * int rowCount = plateMap.getPlateMap().getNumRows();
   * int colCount = plateMap.getPlateMap().getNumCols();
   *
   * JSONObject density = new JSONObject();
   * jLayer.put("density", density);
   * density.put("rows", rowCount);
   * density.put("cols", colCount);
   *
   * for (int r = 1; r <= rowCount; r++) {
   * String row = "" + (char) ('A' + r - 1);
   * JSONObject jRow = new JSONObject();
   * JSONObject jWellIDs = new JSONObject();
   * jLayer.append("Rows", jRow);
   * jLayer.append("WellIDs", jWellIDs);
   * for (int c = 1; c <= colCount; c++) {
   * ExtPlateWellContents extPlateWellContents =
   * plateMap.getExtContentMap().get(row + c);
   * String well = "";
   * String wellID = "";
   * if (extPlateWellContents != null) {
   * String geneSymbol = extPlateWellContents.getGeneSymbol();
   * String egID = extPlateWellContents.getEntrezGeneID();
   * wellID = extPlateWellContents.getCompoundID();
   * switch (layer) {
   * case COMPOUND_ID:
   * well = extPlateWellContents.getCompoundID();
   * break;
   * case VENDOR:
   * well = extPlateWellContents.getVendor();
   * break;
   * case VENDOR_ID:
   * well = extPlateWellContents.getVendorID();
   * break;
   * case GENE_ID:
   * if (egID != null) {
   * well = egID;
   * }
   * break;
   * case GENE_SYMBOL:
   * default:
   * if (geneSymbol != null) {
   * well = geneSymbol;
   * }
   * break;
   * }
   * }
   * jRow.put(c + "", well);
   * jWellIDs.put(c + "", wellID);
   * }
   * }
   * return jLayer;
   * }
   *
   * public JSONObject getWellDetails(String barcode, Connection rnaiConnection)
   * throws JSONException, RemoteException, ServiceException, SQLException,
   * IOException {
   * JSONObject jWell = new JSONObject();
   * String well = getServletBase().getParameter("well");
   * String[] wellFields = well.split(":");
   * Plate plate = getPlate(barcode);
   * PlateMapIF plateMap = plate.getPlateMap(rnaiConnection);
   *
   * String row = "" + (char) ('A' + ExtString.toInteger(wellFields[0]));
   * String col = wellFields[1];
   *
   * ExtPlateWellContents extPlateWellContents =
   * plateMap.getExtContentMap().get(row + col);
   * if (extPlateWellContents != null) {
   * jWell.put("Symbol", (extPlateWellContents.getGeneSymbol() == null ? "" :
   * extPlateWellContents.getGeneSymbol()));
   * jWell.put("Entrez Gene ID", (extPlateWellContents.getEntrezGeneID() == null
   * ? "" : extPlateWellContents.getEntrezGeneID()));
   * jWell.put("Compound ID", extPlateWellContents.getCompoundID());
   * jWell.put("Vendor", extPlateWellContents.getVendor());
   * jWell.put("Vendor ID", extPlateWellContents.getVendorID());
   * }
   *
   * return jWell;
   * }
   */
}
