/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.export;

import amgen.ri.rnai.analyze.AnalysisImageIF;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.servlet.ServletBase;
import amgen.ri.util.Debug;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @version $id$
 *
 */
@WebServlet(name = "Export2PNG", urlPatterns = {"/export2png.go"})
public class Export2PNG extends MainUI {
  public Export2PNG() {
    super();
  }

  public Export2PNG(HttpServletRequest req, HttpServletResponse resp) {
    super(req, resp);
  }

  /**
   *
   * @param req HttpServletRequest
   * @param resp HttpServletResponse
   * @return TBXServlet
   */
  @Override
  protected ServletBase getServlet(HttpServletRequest req, HttpServletResponse resp) {
    return new Export2PNG(req, resp);
  }

  /**
   *
   * @return String @todo Implement this amgen.ri.aig.AIGServlet method
   */
  protected String getServletMimeType() {
    return "image/png";
  }

  /**
   *
   * @throws Exception
   */
  protected void performRequest() throws Exception {
    try {
      response.setContentType("image/png");
      response.addHeader("Content-disposition", "attachment; filename=" + getParameter("name") + ".png");
      String imgKey = getParameter("imgKey");
      if (imgKey != null) {
        SessionCache sessionCache = new SessionCache(this);
        AnalysisImageIF cachedImage = (AnalysisImageIF) sessionCache.get(SessionCache.CacheType.ANALYSIS, imgKey);
        ImageIO.write(cachedImage.getImage(), "png", response.getOutputStream());
      } else {
        String pngURL = getParameter("pngURL");
        File pngFile = new File(getCrossSessionDir(), pngURL);
        BufferedImage img;
        if (pngFile.exists()) {
          img = ImageIO.read(pngFile);
        } else if (pngURL.startsWith("/RNAi")) {
          img = null;
        } else {
          img = ImageIO.read(new URL(pngURL));
        }
        ImageIO.write(img, "png", response.getOutputStream());
      }
      response.getOutputStream().flush();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}