/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import amgen.ri.rnai.jproc.RNAiSearchJProc;
import amgen.ri.util.Debug;
import amgen.ri.util.ExtString;
import org.apache.commons.lang.StringUtils;

/**
 *
 * @author jemcdowe
 */
public class GeneMixtureRecord extends GeneRecord {

  public GeneMixtureRecord(JSONObject obj) throws JSONException {
    super(obj, "gene_mixture_id");
    add("is_mixture", true);
    for(String key : JSONObject.getNames(obj)) {
      String value= obj.optString(key);
      if (value!= null && value.contains(RNAiSearchJProc.GENE_MIX_DELIMITER)) {
        add(key+"s", value);
        String[] values= StringUtils.split(value, RNAiSearchJProc.GENE_MIX_DELIMITER);
        if (values.length> 0 && ExtString.allIsEqual(values, values[0])) {
          add(key, values[0]);
        }
      }
    }
  }  
}
