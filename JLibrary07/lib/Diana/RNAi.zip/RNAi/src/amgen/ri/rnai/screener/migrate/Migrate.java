/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.screener.migrate;

import amgen.ri.aldi.merlin.net.ws.MerlinServicesLocator;
import amgen.ri.aldi.merlin.net.ws.MerlinServicesSoap_PortType;
import amgen.ri.oracle.OraConnectionManager;
import amgen.ri.oracle.OraSQLManager;
import amgen.ri.rnai.cache.SessionCache;
import amgen.ri.rnai.search.ResourceFactory;
import amgen.ri.rnai.util.AppServerReturnObject;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Namespace;
import org.jdom.input.SAXBuilder;
import org.jdom.xpath.XPath;

/**
 *
 * @author jayanthi
 */
public class Migrate extends ResourceFactory {

    HashMap TAMap = new HashMap();
    HashMap ModifiedCellLines = new HashMap();

    public Migrate(SessionCache sessionCache) {
      super(sessionCache);
    }

    public void populateExceptions() {
        TAMap.put("Hematology".toLowerCase(), "Hematology");
        TAMap.put("Nephrology".toLowerCase(), "Nephrology");
        TAMap.put("Metabolic Disorders".toLowerCase(), "Metabolic Disorders");
        TAMap.put("Oncology Therapeutics".toLowerCase(), "Oncology Therapeutics");
        TAMap.put("Inflammation".toLowerCase(), "Inflammation");
        TAMap.put("Oncology".toLowerCase(), "Oncology");
        TAMap.put("NA".toLowerCase(), "NA");
        TAMap.put("Non TA Specific".toLowerCase(), "Non TA Specific");
        TAMap.put("Neuroscience".toLowerCase(), "Neuroscience");
        TAMap.put("Hematology/Oncology".toLowerCase(), "Hematology/Oncology");
        TAMap.put("ONCOLOGY-SUPPORTIVE".toLowerCase(), "ONCOLOGY-SUPPORTIVE");
        TAMap.put("Unknown".toLowerCase(), "Unknown");
        TAMap.put("Bone".toLowerCase(), "Bone");
        TAMap.put("Information System Projects".toLowerCase(), "Information System Projects");
        TAMap.put("General Medicine".toLowerCase(), "General Medicine");
        TAMap.put("Oncology_Wnt".toLowerCase(), "Oncology");
        TAMap.put("p53/MDM2".toLowerCase(), "Oncology");
        TAMap.put("Oncology Toxic".toLowerCase(), "Oncology");
        TAMap.put("Wnt".toLowerCase(), "Oncology");
        TAMap.put("Oncology Followup".toLowerCase(), "Oncology");
        TAMap.put("EPOR".toLowerCase(), "Oncology");

        ModifiedCellLines.put("NA", "NA");
    }

    public AppServerReturnObject getTA(String TA) throws Exception {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        try {
            if (TAMap.containsKey(TA.toLowerCase())) {
                String TAMapped = (String) TAMap.get(TA.toLowerCase());
                asro.setCallSucceed(true);
                asro.setReturnObject(TAMapped);
                return asro;
            } else {
                asro.setCallSucceed(false);
                asro.setComment(TA + "Not Found");
                return asro;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    private AppServerReturnObject getId(Connection conn, String seqName) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        try {
            String queryString = "";
            queryString = "select " + seqName + ".nextval from dual";
            String seqId = "";
            Statement stmtSeqId = conn.createStatement();
            ResultSet rsSeqId = stmtSeqId.executeQuery(queryString);
            if (rsSeqId.next()) {
                seqId = Integer.toString(rsSeqId.getInt(1));
                rsSeqId.close();
                stmtSeqId.close();
                asro.setReturnObject(seqId);
                asro.setCallSucceed(true);
                return asro;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject getCellLinesAgainstRTFDirectRead(String cellline) throws Exception {
        AppServerReturnObject asro = new AppServerReturnObject("Failed getExpId", false, null);
        try {
            Namespace rtf_ns = Namespace.getNamespace("r", "http://rtf.research.amgen.com/rtf/schema/v1");
            SAXBuilder builder = new SAXBuilder();
            String url = "http://rtf/rtf/REST/xml/term/5806296/term;text=" + cellline.trim() + "?detail=4208";
            //System.out.println(url);
            Document doc = null;
            try {
                doc = builder.build(new URL(url));
            } catch (Exception e) {
                asro.setCallSucceed(false);
                asro.setComment(cellline + " not found in RTF");
                return asro;
            }
            Namespace RTF = Namespace.getNamespace("r", "http://rtf.research.amgen.com/rtf/schema/v1");
            XPath xPathName = XPath.newInstance("/r:term/@id");
            xPathName.addNamespace(RTF);
            Attribute attr = (Attribute) xPathName.selectSingleNode(doc);
            asro.setCallSucceed(true);
            asro.setReturnObject(attr.getValue());
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject deleteExperiment(Connection conn, String old_exp_deleteIds, String new_exp_deleteIds) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

        try {

            Statement stmt_gruop_annotation = conn.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String updateQ = "";

            String sub_sql = "";
            if (old_exp_deleteIds != null && old_exp_deleteIds.length() > 0) {
                sub_sql = "select new_experiment_id from tmp_map_experiments where old_experiment_id in (" + old_exp_deleteIds + ")";
            } else if (new_exp_deleteIds != null && new_exp_deleteIds.length() > 0) {
                sub_sql = "select new_experiment_id from tmp_map_experiments where new_experiment_id in (" + new_exp_deleteIds + ")";
            } else {
                asro.setCallSucceed(false);
                asro.setComment("invalid input \n" + sub_sql);
                return asro;
            }

            updateQ = "delete from experiment_well where experiment_id in (" + sub_sql + ")";
            //System.out.println(updateQ);
            stmt_gruop_annotation.addBatch(updateQ);
            updateQ = "delete from experiment_plate where experiment_id in (" + sub_sql + ")";
            //System.out.println(updateQ);
            stmt_gruop_annotation.addBatch(updateQ);
            updateQ = "delete from experiment_annotation_value where experiment_id in (" + sub_sql + ")";
            //System.out.println(updateQ);
            stmt_gruop_annotation.addBatch(updateQ);
            updateQ = "delete from experiment where experiment_id in (" + sub_sql + ")";
            //System.out.println(updateQ);
            stmt_gruop_annotation.addBatch(updateQ);

            if (old_exp_deleteIds != null && old_exp_deleteIds.length() > 0) {
                updateQ = "delete from tmp_map_experiments where old_experiment_id in (" + old_exp_deleteIds + ")";
                //System.out.println(updateQ);
                stmt_gruop_annotation.addBatch(updateQ);

                updateQ = "delete from tmp_map_experiments_details where old_experiment_id in (" + old_exp_deleteIds + ")";
                //System.out.println(updateQ);
                stmt_gruop_annotation.addBatch(updateQ);
            } else if (new_exp_deleteIds != null && new_exp_deleteIds.length() > 0) {
                updateQ = "delete from tmp_map_experiments where new_experiment_id in (" + new_exp_deleteIds + ")";
                //System.out.println(updateQ);
                stmt_gruop_annotation.addBatch(updateQ);

                updateQ = "delete from tmp_map_experiments_details where new_experiment_id in (" + new_exp_deleteIds + ")";
                //System.out.println(updateQ);
                stmt_gruop_annotation.addBatch(updateQ);
            }

            int[] updateCountsExperiment = stmt_gruop_annotation.executeBatch();
            stmt_gruop_annotation.close();
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject getMBarcode(Connection conn, String plate_id) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            String queryString =
                    "select * from invrs3_map where map = '" + plate_id + "'" + "\n";
                    //"select * from SAMPLEBANK_SIRNA_MAP where map = '" + plate_id + "'" + "\n";
            //System.out.println(queryString);
            Statement ps1 = conn.createStatement();
            ResultSet rs1 = ps1.executeQuery(queryString);
            if (rs1.next()) {
                asro.setCallSucceed(true);
                return asro;
            }else{
                System.out.println(queryString);
            }
            rs1.close();
            ps1.close();
        } catch (Exception e) {
            e.printStackTrace();

        }
        return asro;
    }

    private AppServerReturnObject getParentBarcode(String child_barcode, MerlinServicesSoap_PortType merlinServices) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            //System.out.println(merlinServices + "\n" + child_barcode);
            String[] parent_barcodes = merlinServices.getParentPlateBarcodes(child_barcode);
            if (parent_barcodes.length == 0) {
                asro.setCallSucceed(false);
                asro.setComment("Unable to find barcode for: " + child_barcode);
                return asro;
            } else if (parent_barcodes.length > 1) {
                asro.setCallSucceed(false);
                asro.setComment("More than one parent barcode for: " + child_barcode);
                return asro;
            } else {
                asro.setCallSucceed(true);
                asro.setReturnObject(parent_barcodes[0]);
                return asro;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject migrateExperimentPlates(Connection conn, MerlinServicesSoap_PortType merlin, String old_experiment_id, String new_experiment_id) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            String scr_plate_sql = "insert into experiment_plate(child_barcode, experiment_id, parent_barcode, status, plate_source) "
                    + "values (?,?,?,?,?)";
            PreparedStatement stmt_plates = conn.prepareCall(scr_plate_sql);

            String sql_plates = "select distinct barcode as child_barcode from sirna.poc_set2@sfsirna where experiment_id = " + old_experiment_id;
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql_plates);
            int count = 0;
            while (rs.next()) {
                count++;
                String child_barcode = rs.getString("child_barcode");
                String plate_source = "";
                String parent_barcode = "";
                if (child_barcode.matches("\\d+")) {
                    asro = this.getParentBarcode(child_barcode, merlin);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    plate_source = "MOSAIC";
                    parent_barcode = (String) asro.getReturnObject();
                } else if (child_barcode.matches("M\\d+")) {
                    asro = getMBarcode(conn, child_barcode);
                    if (!asro.isCallSucceed()) {
                        return asro;
                    }
                    plate_source = "RS3";
                } else {
                    plate_source = "UnRegistered";
                }
                stmt_plates.setString(1, child_barcode);
                stmt_plates.setString(2, new_experiment_id);
                stmt_plates.setString(3, parent_barcode);
                stmt_plates.setString(4, "Migrated");
                stmt_plates.setString(5, plate_source);
                stmt_plates.addBatch();

                if (count % 100 == 0) {
                    System.out.println("Mid plate commit for : " + count);
                    int[] updateCountsPlate = stmt_plates.executeBatch();
                    conn.commit();
                    stmt_plates.close();
                    stmt_plates = conn.prepareStatement(scr_plate_sql);
                }

            }
            stmt_plates.executeBatch();
            asro.setCallSucceed(true);
            return asro;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject migrateExperiments() {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        Connection conn = null;
        try {
            conn = getRNAiConnection();
            MerlinServicesSoap_PortType merlin = new MerlinServicesLocator().getMerlinServicesSoap(new URL("http://usto-papp-aldi1:81/MerlinServices.asmx?WSDL"));

            String expstoload = "select experiment_id from sirna.experiments_set2@sfsirna where experiment_id not in (select old_experiment_id from tmp_map_experiments where status = 'Completed')";
            //String expstoload = "select experiment_id from sirna.experiments_set2@sfsirna where quality = 'GOOD' and experiment_id not in (select old_experiment_id from tmp_map_experiments)";
            //String expstoload = "select experiment_id from sirna.experiments_set2@sfsirna where quality = 'GOOD' and experiment_id in (select old_experiment_id from tmp_map_experiments where status in ('Errors'))";
            //String expstoload = "select experiment_id from sirna.experiments_set2@sfsirna where quality = 'GOOD' and experiment_id in (select old_experiment_id from tmp_map_experiments where status in ('migrateExperimentPlates Errors'))";
            
            ArrayList old_exps = new ArrayList();
            /*
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(expstoload);
            while (rs.next()) {
                old_exps.add(rs.getString("experiment_id"));
            }
            */
            
            old_exps.add("684");
            

            for (int i = 0; i < old_exps.size(); i++) {
                String old_experiment_id = (String) old_exps.get(i);
                System.out.println("Processing " + old_experiment_id);

                asro = this.deleteExperiment(conn, old_experiment_id, null);
                if (!asro.isCallSucceed()) {
                    return asro;
                }
                asro = migrateSingleExperiment(conn, merlin, old_experiment_id);
                if (!asro.isCallSucceed()) {
                    return asro;
                }
                conn.commit();
                OraSQLManager.closeResources(conn);
                conn = new OraSQLManager().getConnection("RNAI_INDEX");
            }


        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);
        }
        return asro;
    }

    public AppServerReturnObject migrateSingleExperiment(Connection conn, MerlinServicesSoap_PortType merlin, String old_experiment_id) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);

        try {
            conn.setAutoCommit(false);
            asro = getId(conn, "rnai_experiment");
            if (!asro.isCallSucceed()) {
                return asro;
            }
            String new_experiment_id = (String) asro.getReturnObject();

            String qualityCheckSql = "select * from sirna.experiments_set2@sfsirna where experiment_id = " + old_experiment_id;
            //System.out.println(qualityCheckSql);
            PreparedStatement pse = conn.prepareStatement(qualityCheckSql);
            ResultSet rse = pse.executeQuery();
            if (!rse.next()) {
                asro.setCallSucceed(false);
                asro.setComment("Experiment not found");
                return asro;
            }
            String map_exp_sql = "insert into tmp_map_experiments(new_experiment_id, old_experiment_id, status) values (?,?,?)";
            PreparedStatement psme = conn.prepareCall(map_exp_sql);
            psme.setString(1, new_experiment_id);
            psme.setString(2, old_experiment_id);
            String quality = rse.getString("quality");
            if (!quality.equalsIgnoreCase("GOOD")) {
                psme.setString(3, "Invalid");
                psme.addBatch();
                psme.executeBatch();
                conn.commit();
                asro.setCallSucceed(true);
                return asro;
            }

            String insert_scr_exp_sql = "insert into experiment(experiment_id, assay_code, qc_session_name, qc_owner, upload_person, qc_date, upload_date, layer_name, gene_count, visibility, status, analysis_date)"
                    + "select " + new_experiment_id + " as experiment_id, assay_code, experiment_name as qc_session_name, null as qc_owner, 'SYSTEM' as upload_person, null as qc_date, "
                    + "sysdate as upload_date, null as layer_name, gene_count,'Public' as visibility, 'Valid' as status, last_analyzed as analysis_date "
                    + "from sirna.experiments_set2@sfsirna where experiment_id = " + old_experiment_id;
            System.out.println(insert_scr_exp_sql);
            Statement stmt1 = conn.createStatement();
            stmt1.executeUpdate(insert_scr_exp_sql);

            asro = migrateExperimentPlates(conn, merlin, old_experiment_id, new_experiment_id);
            if (!asro.isCallSucceed()) {
                psme.setString(3, "migrateExperimentPlates Errors");
                psme.addBatch();
                psme.executeBatch();
                conn.commit();
                asro.setCallSucceed(true);
                return asro;

            }

            String insert_scr_exp_well_sql = "insert into experiment_well (result_id, child_barcode, experiment_id, substance_id, well, poc, oga_flag, zscore) "
                    + "select "
                    + "RNAI_result.nextval,"
                    + "barcode as child_barcode, " + new_experiment_id + " as experiment_id, s.substance_id, wellrow||wellcolumn as well, poc, oga_flag, zscore"
                    + " from rgdh.sm_substance@RGWA0630P s, sirna.poc_set2@sfsirna p"
                    + " where s.root_number = substr(compound_id,0,instr(compound_id,'#')-1) "
                    + "and s.lot_number = substr(compound_id,instr(compound_id,'#')+1) "
                    + "and experiment_id = " + old_experiment_id;
            //System.out.println(insert_scr_exp_well_sql);
            Statement stmt2 = conn.createStatement();
            stmt2.executeUpdate(insert_scr_exp_well_sql);

            asro = migrateAnnotations(conn, new_experiment_id, old_experiment_id);
            if (!asro.isCallSucceed()) {
                return asro;
            }
            Boolean addedErrors = (Boolean) asro.getReturnObject();
            if (addedErrors == false) {
                psme.setString(3, "Completed");
            } else {
                psme.setString(3, "Errors");
            }
            psme.addBatch();
            psme.executeBatch();
            conn.commit();
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            try {
                conn.rollback();
            } catch (Exception e1) {
                e.printStackTrace();
            }
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject migrateAnnotations(Connection conn, String new_experiment_id, String old_experiment_id) {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        try {
            boolean addedErrors = false;
            String annotation_insert_sql = "insert into EXPERIMENT_ANNOTATION_VALUE(EXPERIMENT_ANNOTATION_VALUE_id, experiment_id, annotation_id, annotation_option_id, value)"
                    + "values (?,?,?,?,?)";
            PreparedStatement stmt_annotations = conn.prepareCall(annotation_insert_sql);
            String error_sql = "insert into tmp_map_experiments_details(new_experiment_id, old_experiment_id, failed_step, comments) values (?,?,?,?)";
            PreparedStatement annotations_errors = conn.prepareCall(error_sql);

            String query_se =
                    "select cell_line, culture, " + "\n"
                    + "oncogenic_state, cell_line_source, cell_line_catalog, cell_morphology, cells_per_well, " + "\n"
                    + "freeze_media, passage_number, storage_location, frozen_by, frozen_date, experiment_type, " + "\n"
                    + "endpoint_assay, library, project, algorithm, " + "\n"
                    + "screener, assay_developer, reagent_lot, comments, " + "\n"
                    + "assay_development_data, modifier, modifier_concentration, growth_media, growth_serum, screen_media, screen_serum, " + "\n"
                    + "transfection_reagent, sirna_concentration, incubation_length, transfection_reagent, plate_type, plate_format " + "\n"
                    + "from sirna.experiments_set2@sfsirna where experiment_id = " + old_experiment_id;
            //System.out.println(query_se);
            PreparedStatement pse = conn.prepareStatement(query_se);
            ResultSet rse = pse.executeQuery();
            if (!rse.next()) {
                asro.setCallSucceed(false);
                asro.setComment("Experiment not found");
                return asro;
            }

            String query_am = "select new_annotation_name, old_annotation_name, annotation_id, source from tmp_map_annotations ma, annotation a "
                    + "where new_annotation_name = a.annotation_name ";
            PreparedStatement psam = conn.prepareStatement(query_am);
            ResultSet rsam = psam.executeQuery();

            while (rsam.next()) {

                String new_annotation_name = rsam.getString("new_annotation_name");
                String old_annotation_name = rsam.getString("old_annotation_name");
                String annotation_id = rsam.getString("annotation_id");
                String source = rsam.getString("source");
                //System.out.println(annotation_id + ":" + new_annotation_name + ":" + old_annotation_name);
                String current_value = rse.getString(old_annotation_name.trim());

                if (current_value == null || current_value.length() == 0 || current_value.equalsIgnoreCase("N/A")) {
                    continue;
                }
                asro = getId(conn, "RNAI_annotation");
                if (!asro.isCallSucceed()) {
                    return asro;
                }
                String result_id = (String) asro.getReturnObject();
                if (source.equalsIgnoreCase("ANNOTATION_OPTIONS")) {
                    String query_ao = "select RECTIFY_NON_ASCII(annotation_option_name), annotation_option_id from annotation_option where annotation_id = "
                            + annotation_id + " and lower(RECTIFY_NON_ASCII(annotation_option_name)) = lower(RECTIFY_NON_ASCII('" + current_value + "'))";
                    //System.out.println(query_ao);
                    PreparedStatement psao = conn.prepareStatement(query_ao);
                    ResultSet rsao = psao.executeQuery();
                    if (rsao.next()) {
                        String annotation_option_id = rsao.getString("annotation_option_id");
                        stmt_annotations.setString(1, result_id);
                        stmt_annotations.setString(2, new_experiment_id);
                        stmt_annotations.setString(3, annotation_id);
                        stmt_annotations.setString(4, annotation_option_id);
                        stmt_annotations.setString(5, current_value);
                        stmt_annotations.addBatch();
                    } else {
                        addedErrors = true;
                        annotations_errors.setString(1, new_experiment_id);
                        annotations_errors.setString(2, old_experiment_id);
                        annotations_errors.setString(3, "AnnotationOptions");
                        annotations_errors.setString(4, annotation_id + ":" + new_annotation_name + ":" + old_annotation_name + ":" + current_value);
                        annotations_errors.addBatch();
                    }
                } else if (source.equalsIgnoreCase("RTF_CELLLINE")) {

                    if (this.ModifiedCellLines.containsKey(current_value)) {
                        String modified_cellline = current_value;
                        String cellline = (String) this.ModifiedCellLines.get(current_value);

                        String annotation_option_id = null;
                        stmt_annotations.setString(1, result_id);
                        stmt_annotations.setString(2, new_experiment_id);
                        stmt_annotations.setString(3, annotation_id);
                        stmt_annotations.setString(4, annotation_option_id);
                        stmt_annotations.setString(5, (String) asro.getReturnObject());
                        stmt_annotations.addBatch();

                        annotation_id = "181";//HARD CODED
                        stmt_annotations.setString(1, result_id);
                        stmt_annotations.setString(2, new_experiment_id);
                        stmt_annotations.setString(3, annotation_id);
                        stmt_annotations.setString(4, annotation_option_id);
                        stmt_annotations.setString(5, (String) asro.getReturnObject());
                        stmt_annotations.addBatch();

                    } else {
                        asro = getCellLinesAgainstRTFDirectRead(current_value);
                        if (!asro.isCallSucceed()) {
                            addedErrors = true;
                            annotations_errors.setString(1, new_experiment_id);
                            annotations_errors.setString(2, old_experiment_id);
                            annotations_errors.setString(3, "RTF");
                            annotations_errors.setString(4, annotation_id + ":" + new_annotation_name + ":" + old_annotation_name + ":" + current_value);
                            annotations_errors.addBatch();
                        } else {
                            String annotation_option_id = null;
                            stmt_annotations.setString(1, result_id);
                            stmt_annotations.setString(2, new_experiment_id);
                            stmt_annotations.setString(3, annotation_id);
                            stmt_annotations.setString(4, annotation_option_id);
                            stmt_annotations.setString(5, (String) asro.getReturnObject());
                            stmt_annotations.addBatch();
                        }
                    }
                } else if (source.equalsIgnoreCase("COLLECTIONS") || source.equalsIgnoreCase("FREE_TEXT") || source.equalsIgnoreCase("FREE_DATE")) {
                    String annotation_option_id = null;
                    stmt_annotations.setString(1, result_id);
                    stmt_annotations.setString(2, new_experiment_id);
                    stmt_annotations.setString(3, annotation_id);
                    stmt_annotations.setString(4, annotation_option_id);
                    stmt_annotations.setString(5, current_value);
                    stmt_annotations.addBatch();
                } else if (source.equalsIgnoreCase("RDH_TA")) {
                    asro = getTA(current_value.trim());
                    if (!asro.isCallSucceed()) {
                        addedErrors = true;
                        annotations_errors.setString(1, old_experiment_id);
                        annotations_errors.setString(2, old_experiment_id);
                        annotations_errors.setString(3, "RDH_TA");
                        annotations_errors.setString(4, annotation_id + ":" + new_annotation_name + ":" + old_annotation_name + ":" + current_value);
                        annotations_errors.addBatch();
                    } else {
                        String annotation_option_id = null;
                        stmt_annotations.setString(1, result_id);
                        stmt_annotations.setString(2, new_experiment_id);
                        stmt_annotations.setString(3, annotation_id);
                        stmt_annotations.setString(4, annotation_option_id);
                        stmt_annotations.setString(5, (String) asro.getReturnObject());
                        stmt_annotations.addBatch();
                    }
                } else {
                    addedErrors = true;
                    annotations_errors.setString(1, new_experiment_id);
                    annotations_errors.setString(2, old_experiment_id);
                    annotations_errors.setString(3, "Annotation Source Not Defined");
                    annotations_errors.setString(4, annotation_id + ":" + new_annotation_name + ":" + old_annotation_name + ":" + current_value);
                    annotations_errors.addBatch();
                }

            }
            stmt_annotations.executeBatch();
            annotations_errors.executeBatch();
            asro.setReturnObject(new Boolean(addedErrors));
            asro.setCallSucceed(true);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return asro;
    }

    public AppServerReturnObject evaluate_annotation_optionstype() {
        AppServerReturnObject asro = new AppServerReturnObject("Failed", false, null);
        Connection conn = null;
        try {

            String outputFilePath1 = "H:\\projects\\RNAi\\annotations\\CI_UnmatchedAnnotationOptions.txt";
            String outputFilePath2 = "H:\\projects\\RNAi\\annotations\\CI_EmptyOrNullAnnotations.txt";
            PrintStream psw1 = new PrintStream(new FileOutputStream(outputFilePath1));
            PrintStream psw2 = new PrintStream(new FileOutputStream(outputFilePath2));

            conn = getRNAiConnection();
            String queryString = "select new_annotation_name, old_annotation_name, annotation_id from map_annotations ma, annotation a "

                    + "where new_annotation_name = a.annotation_name "
                    + "and source = 'ANNOTATION_OPTIONS'";

            //System.out.println(queryString);
            PreparedStatement ps1 = conn.prepareStatement(queryString);
            ResultSet rs = ps1.executeQuery();
            while (rs.next()) {
                String new_annotation_name = rs.getString("new_annotation_name");
                String old_annotation_name = rs.getString("old_annotation_name");
                String annotation_id = rs.getString("annotation_id");

                String query_exps = "select distinct " + old_annotation_name.trim() + " as annotation from sirna.experiments_set2@sfsirna where upper(quality) = 'GOOD' "
                        + " and lower(" + old_annotation_name + ") not in (select lower(annotation_option_name) from annotation_option where annotation_id = " + annotation_id + ")";


                String query_null_exps = "select experiment_id, experiment_name from sirna.experiments_set2@sfsirna  where upper(quality) = 'GOOD'  and "
                        + old_annotation_name + " is null or length(" + old_annotation_name + ")=0";
                //System.out.println(query_exps);
                PreparedStatement ps2 = conn.prepareStatement(query_exps);
                ResultSet rs2 = ps2.executeQuery();
                psw1.println("\nValues not in the anotation_option_list for annotation: " + new_annotation_name + "\t" + old_annotation_name + "\t" + annotation_id);
                while (rs2.next()) {
                    psw1.println(rs2.getString("annotation"));
                }

                psw2.println("\nExperiments that have null or empty for annotation :" + new_annotation_name + "\t" + old_annotation_name + "\t" + annotation_id);
                //System.out.println(query_null_exps);
                PreparedStatement ps3 = conn.prepareStatement(query_null_exps);
                ResultSet rs3 = ps3.executeQuery();
                while (rs3.next()) {
                    psw2.println(rs3.getString("experiment_id") + rs3.getString("experiment_name"));
                }
                psw1.println("\n\n");
                psw2.println("\n\n");
                rs2.close();
                rs3.close();
            }
            rs.close();
            psw1.flush();
            psw1.close();
            psw2.flush();
            psw2.close();
            asro.setCallSucceed(true);
            asro.setReturnObject(null);
            return asro;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn);

        }
        return asro;
    }

    public static void main(String[] args) throws Exception {
        //OraConnectionManager.getInstance().addCache("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@ussf-tdbx-ora03:1771:sf0010d.amgen.com");

        //Migrate m = new Migrate();
        //m.evaluate_annotation_optionstype();

        //Migrate m = new Migrate();
        //m.getCellLinesAgainstRTFDirectRead("HCC1187");

        testAddAnnoations();
    }

    public static void testAddAnnoations() throws Exception {
       OraConnectionManager.addConnectionPool("RNAI_INDEX", "jdbc:oracle:thin:RNAI_INDEX/!b1F7d0/eb9LTGvH4AH2Hyw==@uswa-ddbx-ora10:1521:wa0630d.amgen.com");

        Migrate m = new Migrate(null);
        m.populateExceptions();
        m.migrateExperiments();
    }
}
