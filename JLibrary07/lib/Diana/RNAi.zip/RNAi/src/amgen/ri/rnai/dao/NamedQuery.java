/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.dao;

import amgen.ri.json.JSONObject;
import amgen.ri.util.Debug;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

/**
 *
 * @author jemcdowe
 */
public class NamedQuery {
  private String queryName;
  private List<Map<String, String>> parameters;
  private String results;

  public NamedQuery(String queryName) {
    this.queryName = queryName;
    this.parameters = new ArrayList<Map<String, String>>();
  }

  public void addParameters(Map<String, String> params) {
    this.parameters.add(params);
  }

  public List<Map<String, String>> getParameters() {
    return parameters;
  }

  /**
   * Get the value of queryName
   *
   * @return the value of queryName
   */
  public String getQueryName() {
    return queryName;
  }

  /**
   * Set the value of queryName
   *
   * @param queryName new value of queryName
   */
  public void setQueryName(String queryName) {
    this.queryName = queryName;
  }

  public void addParameter(String name, String value) {
    Map<String, String> params = new HashMap<String, String>();
    params.put(name, value);
    parameters.add(params);
  }

  /**
   * @return the results
   */
  public String getResults() {
    return results;
  }

  /**
   * @param results the results to set
   */
  public void setResults(String results) {
    this.results = results;
  }

}
