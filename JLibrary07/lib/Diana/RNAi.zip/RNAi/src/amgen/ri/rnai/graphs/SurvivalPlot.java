package amgen.ri.rnai.graphs;

import amgen.ri.rnai.R.AbstractRAnalysis;
import amgen.ri.rnai.R.RAnalysisFailureException;
import amgen.ri.rnai.analyze.SurvivalAnalysisDetails;
import amgen.ri.rnai.dao.SurvivalPlotInput;
import amgen.ri.rnai.dao.SurvivalPlotMapper;
import amgen.ri.rnai.records.ExperimentRecord;
import amgen.ri.rnai.records.GeneMixtureRecord;
import amgen.ri.rnai.records.GeneRecord;
import amgen.ri.rnai.ui.MainUI;
import amgen.ri.util.ExtFile;
import amgen.ri.util.ExtString;
import com.google.common.base.Predicate;
import com.google.common.collect.Collections2;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import javax.imageio.ImageIO;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.ibatis.session.SqlSession;

/**
 *
 * @author jayanthi
 */
public class SurvivalPlot extends AbstractRAnalysis {
  private ExperimentRecord experimentRecord;

  public SurvivalPlot(MainUI servletBase) throws IOException {
    super(servletBase);
  }

  public SurvivalAnalysisDetails process(ExperimentRecord experimentRecord, List<GeneRecord> targetGeneRecords, List<GeneRecord> controlGeneRecords) throws SQLException, IOException, RAnalysisFailureException {
    SurvivalAnalysisDetails survivalPlotAnalysis = new SurvivalAnalysisDetails(experimentRecord, targetGeneRecords, controlGeneRecords);
    this.experimentRecord = experimentRecord;
    String fileBaseName = "G" + ExtString.join(joinIDs(targetGeneRecords), '_') + "_E" + experimentRecord.getExperimentID();

    File dataFile = new File(getServletBase().getSessionWorkDir(), fileBaseName + ".poc");
    File idFile = new File(getServletBase().getSessionWorkDir(), fileBaseName + "_ID.sh");
    File imageFileDir = new File(getServletBase().getSessionWorkDir(), "survival");
    imageFileDir.mkdirs();
    File imageFile = new File(imageFileDir, fileBaseName + ".png");
    getPlotValues(dataFile, idFile, targetGeneRecords, controlGeneRecords);

    String rArguments = join(targetGeneRecords, "gene_symbol", ',') + " " + "\""
            + experimentRecord.getExperimentName().replaceAll("\\W", "_") + "\"" + " "
            + FilenameUtils.separatorsToUnix(dataFile.getAbsolutePath()) + " "
            + FilenameUtils.separatorsToUnix(imageFile.getAbsolutePath()) + " "
            + FilenameUtils.separatorsToUnix(idFile.getAbsolutePath());

    runRCommand(rArguments);

    survivalPlotAnalysis.setSurvivalImage(ImageIO.read(imageFile));

    return survivalPlotAnalysis;

  }

  private void getPlotValues(File dataFile, File idFile, final List<GeneRecord> targetGeneRecords, final List<GeneRecord> controlGeneRecords) throws SQLException, IOException {
    SqlSession sqlSession = null;
    try {
      sqlSession = getRNAiSqlSession();
      final Set<Integer> targetGeneIDs = new HashSet<Integer>();
      final Set<Integer> targetGeneMixtureIDs = new HashSet<Integer>();
      for (GeneRecord g : targetGeneRecords) {
        if (g instanceof GeneMixtureRecord) {
          targetGeneMixtureIDs.add(g.getGeneID());
        } else {
          targetGeneIDs.add(g.getGeneID());
        }
      }
      final Set<Integer> controlGeneIDs = new HashSet<Integer>();
      final Set<Integer> controlGeneMixtureIDs = new HashSet<Integer>();
      for (GeneRecord g : controlGeneRecords) {
        if (g instanceof GeneMixtureRecord) {
          controlGeneMixtureIDs.add(g.getGeneID());
        } else {
          controlGeneIDs.add(g.getGeneID());
        }
      }

      SurvivalPlotInput survivalPlotInput = new SurvivalPlotInput(experimentRecord, targetGeneRecords, controlGeneRecords);
      sqlSession.getMapper(SurvivalPlotMapper.class).getSurvivalPlotData(survivalPlotInput);
      
      Set<SurvivalPlotData> survivalPlotData = new LinkedHashSet<SurvivalPlotData>(survivalPlotInput.getSurvivalPlotData());

      Set<SurvivalPlotData> allSurvivalPlotData = Sets.filter(survivalPlotData, new Predicate<SurvivalPlotData>() {
        public boolean apply(SurvivalPlotData survivalPlotData) {
          return !(survivalPlotData.isMixture()
                  ? (targetGeneMixtureIDs.contains(survivalPlotData.getGeneID()) || controlGeneMixtureIDs.contains(survivalPlotData.getGeneID()))
                  : (targetGeneIDs.contains(survivalPlotData.getGeneID()) || controlGeneIDs.contains(survivalPlotData.getGeneID())));
        }
      });
      Set<SurvivalPlotData> controlSurvivalPlotData = Sets.filter(survivalPlotData, new Predicate<SurvivalPlotData>() {
        public boolean apply(SurvivalPlotData survivalPlotData) {
          return (survivalPlotData.isMixture()
                  ? (controlGeneMixtureIDs.contains(survivalPlotData.getGeneID()))
                  : (controlGeneIDs.contains(survivalPlotData.getGeneID())));
        }
      });
      Set<SurvivalPlotData> targetSurvivalPlotData = Sets.filter(survivalPlotData, new Predicate<SurvivalPlotData>() {
        public boolean apply(SurvivalPlotData survivalPlotData) {
          return (survivalPlotData.isMixture()
                  ? (targetGeneMixtureIDs.contains(survivalPlotData.getGeneID()))
                  : (targetGeneIDs.contains(survivalPlotData.getGeneID())));
        }
      });

      //Create ID File
      Set<String> geneSymbols = new LinkedHashSet<String>();
      geneSymbols.add("_ALL_");
      for (SurvivalPlotData s : controlSurvivalPlotData) {
        geneSymbols.add(s.getPrimaryGeneSymbol());
      }
      for (SurvivalPlotData s : targetSurvivalPlotData) {
        geneSymbols.add(s.getPrimaryGeneSymbol());
      }
      PrintWriter idWriter = new PrintWriter(idFile);
      idWriter.println("GENE\tID_SORT");
      int count = 1;
      for (String geneSymbol : geneSymbols) {
        idWriter.println(geneSymbol + "\t" + (count++));
      }
      idWriter.close();

      //Create POC File
      PrintWriter dataWriter = new PrintWriter(dataFile);
      dataWriter.println("POC\t1\tGENE\n");
      for (SurvivalPlotData s : allSurvivalPlotData) {
        dataWriter.println(s.getPoc() + "\t1\t_ALL_");
      }
      for (SurvivalPlotData s : controlSurvivalPlotData) {
        dataWriter.println(s.getPoc() + "\t1\t" + s.getPrimaryGeneSymbol());
      }
      for (SurvivalPlotData s : targetSurvivalPlotData) {
        dataWriter.println(s.getPoc() + "\t1\t" + s.getPrimaryGeneSymbol());
      }
      dataWriter.close();
    } catch(Exception e) {
      e.printStackTrace();
    } finally {
      close(sqlSession);
    }

  }

  @Override
  public String getRCodeFileName() {
    return "survival_v1.R";
  }

}
