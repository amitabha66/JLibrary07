/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package amgen.ri.rnai.records;

import amgen.ri.json.JSONException;
import amgen.ri.json.JSONObject;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Encapsulates a Collection Record
 * 
 * @author jemcdowe
 */
public class CollectionRecord extends AbstractRecord {  

  public CollectionRecord(JSONObject source) throws JSONException {
    super(source, "collection_id");
  }

  public CollectionRecord(AbstractRecord record) throws JSONException {
    super(record);
  }

  public CollectionRecord(String recordID) {
    super(recordID);
  }

  public int getCollectionID() {
    return getNumber("collection_id").intValue();
  }

  public int getExperimentCount() {
    return getNumber("experiment_count").intValue();
  }

  public String getCollectionName() {
    return getString("collection_name");
  }

  public Date getCreated() {
    return getDate("created");
  }

  public String getCreatedBy() {
    return getString("created_by");
  }  

  public String getCreatedByName() {
    return getString("created_by_nme");
  }  

  public Set<String> getMembers() {
    Set<String> memberSet= new HashSet<String>();
    List<JSONObject> members= getList("members");
    for(JSONObject member : members) {
      try {
        memberSet.add(member.getString("member"));
      } catch (JSONException ex) {
      }
    }
    return memberSet;
  }   
}
