##library("Cairo");

args <-  commandArgs();
symbol = args[5];
input = paste(args[6],sep="");
baseDir = paste(args[7], sep="");
outfile = paste(args[8], sep="");
pvalData <- read.delim(input, header=T, sep="\t", as.is=T);
cutoff = 0.05;


cat("#Images",file=outfile,sep="\n");


##seperate pvalue by the library
lib = unique(pvalData$collection);

for (screen in lib) {
	if(nchar(screen)>0){
	
  
  select = pvalData$collection == screen;
  pvalData1 = pvalData[select,];
  numexp = nrow(pvalData1);
  
  ##order by tissue of origin, then by p-value
  pvalOrder1 <- order(pvalData1$tissue, pvalData1$corrected_pval);
  pvalData1 <- pvalData1[pvalOrder1,];
  
  ##order by p-value only, for barchart
  pvalOrder2 <- order(pvalData1$corrected_pval);
  pvalData2 <- pvalData1[pvalOrder2,];
  
  ##color the cell lines with p-value < 0.05 red
  pcolor = rep ("darkblue", numexp);
  pcolor[pvalData1$corrected_pval <= cutoff] = "darkred";

  ##determine the height of the graph by number of experiments
  high = round(3 * numexp / 10, 1) + 1;
  if (high < 3) { high = 3 }

  ###########################################################################
  ##plot the BH corrected p-value to file
  ##file1 = paste("/mnt/siRNA/myHTML/plots/pvalue/",symbol,"_",screen,".png",sep="");
  file1 = paste(baseDir,symbol,"_",gsub("[^[:alnum:]]", "", screen),"_corp.png",sep="");
  cat(paste(screen,'\t','CorrectedPvalue', '\t', file1),file=outfile,append=TRUE,sep="\n");
  ##output barchart,  height=9, width=4
  bitmap(file1, res=216, height=high, width=4, family="mono");
  ##bitmap(file1, type="jpeg", res=200, height=9, width=4, family="mono");
  par(mar=c(4,14,2,2), cex.lab=1.5);
  layout(matrix(c(1,2,3)), heights=c(3,3,2.5));
  ##reverse the vector since barplot is drawing from bottom up
  barplot(pvalData2$corrected_pval, names.arg=pvalData2$experiment_name, horiz=T, space=1, col="white", las=2, cex.names=0.9, xlim=c(0,1), font.axis=2, main=paste(symbol, " corrected p-value in all cell lines screened by",screen,"library", sep=" "), xlab=paste(symbol, " corrected p-value", sep="") );
  abline(v=cutoff, col="red",lty=2);

  ##output dotchart
  dotchart(pvalData1$corrected_pval, labels=pvalData1$experiment_name, groups=factor(pvalData1$tissue), gcolor="darkcyan", color=pcolor, pch=20, xlim=c(0,1), lcolor='white', cex=0.75, xlab=paste(symbol, " corrected p-value", sep=""), main=paste(symbol, " corrected p-value distribution by tissue of origin",sep=" "));
  abline(v=cutoff, col="red",lty=2);
  
  ##output pvalue histogram
  hist(pvalData1$corrected_pval, breaks=10, xlab=paste(symbol, " corrected p-value", sep=""), xlim=c(0,1), main=paste(symbol, "p-value distribution",sep=" "));
  graphics.off();

  ###########################################################################
  ##order by tissue of origin, then by raw p-value
  pvalOrder1 <- order(pvalData1$tissue, pvalData1$raw_pval);
  pvalData1 <- pvalData1[pvalOrder1,];
  
  ##order by p-value only, for barchart
  pvalOrder2 <- order(pvalData1$raw_pval);
  pvalData2 <- pvalData1[pvalOrder2,];
  
  ##change p-value to -log, color the cell lines with p-value < 0.05 red
  pcolor = rep ("darkblue", numexp);
  pcolor[pvalData1$raw_pval <= cutoff] = "darkred";
  
  ##file2 = paste("/mnt/siRNA/myHTML/plots/rawp/",symbol,"_",screen,".png",sep="");  
  file2 = paste(baseDir,symbol,"_",gsub("[^[:alnum:]]", "", screen),"_rawp.png",sep="");  
  cat(paste(screen,'\t','RawPvalue','\t',file2),file=outfile,append=TRUE,sep="\n");
  ##output barchart,  height=9, width=4
  bitmap(file2, res=216, height=high, width=4, family="mono");
  par(mar=c(4,14,2,2), cex.lab=1.5);
  layout(matrix(c(1,2,3)), heights=c(3,3,2.5));
  barplot(pvalData2$raw_pval, names.arg=pvalData2$experiment_name, horiz=T, space=1, col="white", las=2, cex.names=0.9, font.axis=2, main=paste(symbol, "raw p-value in all cell lines screened by",screen,"library", sep=" "), xlab=paste(symbol, " raw p-value", sep=""));
  abline(v=cutoff, col="red",lty=2);

  ##output dotchart
  dotchart(pvalData1$raw_pval, labels=pvalData1$experiment_name, groups=factor(pvalData1$tissue), gcolor="darkcyan", color=pcolor, pch=20, lcolor='white', cex=0.75, main=paste(symbol, "raw p-value distribution by tissue of origin",sep=" "), xlab=paste(symbol, " raw p-value", sep=""));
  abline(v=cutoff, col="red",lty=2);
  
  ##output pvalue histogram
  hist(pvalData1$raw_pval, breaks=10, xlab=paste(symbol, " raw p-value", sep=""), xlim=c(0,1), main=paste(symbol, "raw p-value distribution",sep=" "));
  graphics.off();

  ###########################################################################
  ##plot the histogram for raw p-value, in -log10 scale
  LOG1 = -log10(pvalData1$raw_pval);

  ##file3 = paste("/mnt/siRNA/myHTML/plots/rawp/",symbol,"_",screen,"_log.png",sep="");  
  file3 = paste(baseDir,symbol,"_",gsub("[^[:alnum:]]", "", screen),"_rawp_log.png",sep="");  
  cat(paste(screen,'\t','RawLogPvalue','\t',file3),file=outfile,append=TRUE,sep="\n");
  ##output barchart,  height=9, width=4
  bitmap(file3, res=216, height=high, width=4, family="mono");
  par(mar=c(4,14,2,2), cex.lab=1.5);
  layout(matrix(c(1,2,3)), heights=c(3,3,2.5));
  barplot(-log10(pvalData2$raw_pval), names.arg=pvalData2$experiment_name, horiz=T, space=1, col="white", las=2, cex.names=0.9, font.axis=2, main=paste(symbol, "-log10(raw p-value) in all cell lines screened by",screen,"library", sep=" "), xlab=paste(symbol, " -log10(raw p-value)", sep=""));
  abline(v=-log10(cutoff), col="red", lty=2);

  ##output dotchart
  dotchart(LOG1, labels=pvalData1$experiment_name, groups=factor(pvalData1$tissue), gcolor="darkcyan", color=pcolor, pch=20, lcolor='white', cex=0.75, main=paste(symbol, "-log10(raw p-value) distribution by tissue of origin",sep=" "), xlab=paste(symbol, "-log10(raw p-value)", sep=""));
  abline(v=-log10(cutoff), col="red", lty=2);
  
  ##output pvalue histogram
  hist(LOG1, breaks=10, xlab=paste(symbol, "-log10(raw p-value)", sep=" "), main=paste(symbol, "-log10(raw p-value) distribution",sep=" "));
  graphics.off();           
  
  ###########################################################################
  ##plot the histogram for qnorm transformed p-value, as z-score
  ##p-value = 1 is problem for qnorm
  Z1 = -qnorm(pvalData1$raw_pval);
  Z2 = -qnorm(pvalData2$raw_pval)
  Z1[Z1==-Inf] = -4.5;
  Z2[Z2==-Inf] = -4.5; 

  ##file4 = paste("/mnt/siRNA/myHTML/plots/rawp/",symbol,"_",screen,"_z.png",sep=""); 
  file4 = paste(baseDir,symbol,"_",gsub("[^[:alnum:]]", "", screen),"_rawp_z.png",sep=""); 
  cat(paste(screen,'\t','RawPvalueZ','\t',file4),file=outfile,append=TRUE,sep="\n");
  ##output barchart,  height=9, width=4
  bitmap(file4, res=216, height=high, width=4, family="mono");
  par(mar=c(4,14,2,2), cex.lab=1.5);
  layout(matrix(c(1,2,3)), heights=c(3,3,2.5));
  barplot(Z2, names.arg=pvalData2$experiment_name, horiz=T, space=1, col="white", las=2, cex.names=0.9, font.axis=2, main=paste(symbol, "-Z-score in all cell lines screened by",screen,"library", sep=" "), xlab=paste(symbol, " -Z-score", sep=""));
  abline(v=-qnorm(cutoff), col="red", lty=2);

  ##output dotchart
  dotchart(Z1, labels=pvalData1$experiment_name, groups=factor(pvalData1$tissue), gcolor="darkcyan", color=pcolor, pch=20, lcolor='white', cex=0.75, main=paste(symbol, "-Z-score distribution by tissue of origin",sep=" "), xlab=paste(symbol, "-Z-score", sep=""));
  abline(v=-qnorm(cutoff), col="red", lty=2);
  
  ##output pvalue histogram
  hist(Z1, breaks=10, xlab=paste(symbol, "-Z-score", sep=" "), main=paste(symbol, "-Z-score distribution",sep=" "));
  graphics.off();
  }

}

##draw graph for all p-values
if (length(lib) > 1) {
  pvalOrder <- order(pvalData$cell_line, pvalData$raw_pval);
  pvalData <- pvalData[pvalOrder,];
  totalpval = nrow(pvalData);

  tcolor = 2;
  pcolor = rep ("", totalpval);
  colrange = c()
  for (i in 1:length(lib)) {
    select = pvalData$collection == lib[i];
    pcolor[select] = i;
    colrange = c(colrange, i);
  }
  
  high = round( totalpval / 12, 1) + 1;
  ##file1 = paste("/mnt/siRNA/myHTML/plots/pvalue/",symbol,"_all.png",sep="");
  file1 = paste(baseDir,symbol,"_corp_all.png",sep="");
  cat(paste('all','\t','CorrectedPvalue','\t',file1),file=outfile,append=TRUE,sep="\n");
  bitmap(file1, res=216, height=high, width=4, family="mono");
  dotchart(pvalData$corrected_pval, labels=pvalData$experiment_name, groups=factor(pvalData$cell_line), gcolor="darkcyan", color=pcolor, pch=20, xlim=c(0,1), lcolor='white', cex=0.75, xlab=paste(symbol, " corrected p-value", sep=""), main=paste(symbol, " corrected p-value distribution by cell line", sep=" "));
  abline(v=cutoff, col="darkcyan",lty=2);
  legend("topright", lib, text.col=colrange, bty='n', cex=0.75);
  graphics.off();
  
  ##file2 = paste("/mnt/siRNA/myHTML/plots/rawp/",  symbol,"_all.png",sep="");
  file2 = paste(baseDir,symbol,"_rawp_all.png",sep="");
  cat(paste('all','\t','RawPvalue','\t',file2),file=outfile,append=TRUE,sep="\n");
  bitmap(file2, res=216, height=high, width=4, family="mono");
  dotchart(pvalData$raw_pval, labels=pvalData$experiment_name, groups=factor(pvalData$cell_line), gcolor="darkcyan", color=pcolor, pch=20, lcolor='white', cex=0.75, main=paste(symbol, "raw p-value distribution by cell line", sep=" "), xlab=paste(symbol, " raw p-value", sep=""));
  abline(v=cutoff, col="darkcyan",lty=2);
  legend("topright", lib, text.col=colrange, bty='n', cex=0.75);
  graphics.off();
  ##print(paste("done output graph to", file2, sep=" ")); 
  ##change into -log10 scale
  ##file3 = paste("/mnt/siRNA/myHTML/plots/rawp/",  symbol,"_all_log.png",sep="");
  file3 = paste(baseDir,symbol,"_rawp_all_log.png",sep="");
  cat(paste('all','\t','RawLogPvalue','\t',file3),file=outfile,append=TRUE,sep="\n");
  bitmap(file3, res=216, height=high, width=4, family="mono");
  dotchart(-log10(pvalData$raw_pval), labels=pvalData$experiment_name, groups=factor(pvalData$cell_line), gcolor="darkcyan", color=pcolor, pch=20, lcolor='white', cex=0.75, main=paste(symbol, "-log10(raw p-value) distribution by cell line",sep=" "), xlab=paste(symbol, "-log10(raw p-value)", sep=" "));
  abline(v=-log10(cutoff), col="darkcyan",lty=2);
  legend("topright", lib, text.col=colrange, bty='n', cex=0.75);
  graphics.off();
}
